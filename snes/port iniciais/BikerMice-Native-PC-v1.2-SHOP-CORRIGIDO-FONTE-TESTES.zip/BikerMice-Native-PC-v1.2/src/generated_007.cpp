#include "generated.hpp"
void sub_00FFE0_E1M1X1CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x2082F1u: goto L_2082F1;
    case 0x2082F3u: goto L_2082F3;
    case 0x2082F6u: goto L_2082F6;
    case 0x2082F9u: goto L_2082F9;
    case 0x2082FCu: goto L_2082FC;
    case 0x2082FFu: goto L_2082FF;
    case 0x208300u: goto L_208300;
    case 0x208303u: goto L_208303;
    case 0x208305u: goto L_208305;
    case 0x208308u: goto L_208308;
    case 0x20830Au: goto L_20830A;
    case 0x20830Du: goto L_20830D;
    case 0x20830Fu: goto L_20830F;
    case 0x208312u: goto L_208312;
    case 0x208314u: goto L_208314;
    case 0x208317u: goto L_208317;
    case 0x20831Au: goto L_20831A;
    case 0x20831Cu: goto L_20831C;
    case 0x20831Fu: goto L_20831F;
    case 0x208321u: goto L_208321;
    case 0x208324u: goto L_208324;
    case 0x208327u: goto L_208327;
    case 0x20832Au: goto L_20832A;
    case 0x20832Cu: goto L_20832C;
    case 0x20832Fu: goto L_20832F;
    case 0x208332u: goto L_208332;
    case 0x208335u: goto L_208335;
    case 0x208338u: goto L_208338;
    case 0x20833Bu: goto L_20833B;
    case 0x20833Eu: goto L_20833E;
    case 0x208340u: goto L_208340;
    case 0x208343u: goto L_208343;
    case 0x208345u: goto L_208345;
    case 0x208348u: goto L_208348;
    case 0x20834Au: goto L_20834A;
    case 0x20834Eu: goto L_20834E;
    case 0x208350u: goto L_208350;
    case 0x208353u: goto L_208353;
    case 0x208355u: goto L_208355;
    case 0x208358u: goto L_208358;
    case 0x20835Au: goto L_20835A;
    case 0x20835Du: goto L_20835D;
    case 0x20835Fu: goto L_20835F;
    case 0x208362u: goto L_208362;
    case 0x208364u: goto L_208364;
    case 0x208367u: goto L_208367;
    case 0x20836Au: goto L_20836A;
    case 0x20836Du: goto L_20836D;
    case 0x208370u: goto L_208370;
    case 0x208373u: goto L_208373;
    case 0x208376u: goto L_208376;
    case 0x208379u: goto L_208379;
    case 0x20837Cu: goto L_20837C;
    case 0x20837Eu: goto L_20837E;
    case 0x208380u: goto L_208380;
    case 0x208382u: goto L_208382;
    case 0x208385u: goto L_208385;
    case 0x208389u: goto L_208389;
    case 0x20838Bu: goto L_20838B;
    case 0x20838Eu: goto L_20838E;
    case 0x208391u: goto L_208391;
    case 0x208393u: goto L_208393;
    case 0x208395u: goto L_208395;
    case 0x208398u: goto L_208398;
    case 0x20839Bu: goto L_20839B;
    case 0x20839Eu: goto L_20839E;
    case 0x2083A1u: goto L_2083A1;
    case 0x2083A4u: goto L_2083A4;
    case 0x2083A7u: goto L_2083A7;
    case 0x2083AAu: goto L_2083AA;
    case 0x2083ADu: goto L_2083AD;
    case 0x2083AFu: goto L_2083AF;
    case 0x2083B1u: goto L_2083B1;
    case 0x2083B4u: goto L_2083B4;
    case 0x2083B7u: goto L_2083B7;
    case 0x2083BAu: goto L_2083BA;
    case 0x2083BCu: goto L_2083BC;
    case 0x2083BEu: goto L_2083BE;
    case 0x2083C1u: goto L_2083C1;
    case 0x2083C4u: goto L_2083C4;
    case 0x2083C7u: goto L_2083C7;
    case 0x2083CAu: goto L_2083CA;
    case 0x2083CDu: goto L_2083CD;
    case 0x2083CFu: goto L_2083CF;
    case 0x2083D1u: goto L_2083D1;
    case 0x2083D4u: goto L_2083D4;
    case 0x2083D7u: goto L_2083D7;
    case 0x2083D9u: goto L_2083D9;
    case 0x2083DBu: goto L_2083DB;
    case 0x2083DEu: goto L_2083DE;
    case 0x2083E1u: goto L_2083E1;
    case 0x2083E3u: goto L_2083E3;
    case 0x2083E6u: goto L_2083E6;
    case 0x2083E8u: goto L_2083E8;
    case 0x2083EAu: goto L_2083EA;
    case 0x2083EDu: goto L_2083ED;
    case 0x2083EFu: goto L_2083EF;
    case 0x2083F1u: goto L_2083F1;
    case 0x2083F4u: goto L_2083F4;
    case 0x2083F7u: goto L_2083F7;
    case 0x2083F9u: goto L_2083F9;
    case 0x2083FCu: goto L_2083FC;
    case 0x2083FFu: goto L_2083FF;
    case 0x208402u: goto L_208402;
    case 0x208404u: goto L_208404;
    case 0x208407u: goto L_208407;
    case 0x208408u: goto L_208408;
    case 0x20840Bu: goto L_20840B;
    case 0x20840Du: goto L_20840D;
    case 0x20840Fu: goto L_20840F;
    case 0x208412u: goto L_208412;
    case 0x208415u: goto L_208415;
    case 0x208417u: goto L_208417;
    case 0x208419u: goto L_208419;
    case 0x20841Cu: goto L_20841C;
    case 0x20841Eu: goto L_20841E;
    case 0x208421u: goto L_208421;
    case 0x208423u: goto L_208423;
    case 0x208425u: goto L_208425;
    case 0x208428u: goto L_208428;
    case 0x20842Au: goto L_20842A;
    case 0x20842Du: goto L_20842D;
    case 0x20842Fu: goto L_20842F;
    case 0x208431u: goto L_208431;
    case 0x208434u: goto L_208434;
    case 0x208438u: goto L_208438;
    case 0x20843Bu: goto L_20843B;
    case 0x20843Du: goto L_20843D;
    case 0x20843Fu: goto L_20843F;
    case 0x208442u: goto L_208442;
    case 0x208446u: goto L_208446;
    case 0x208448u: goto L_208448;
    case 0x20844Bu: goto L_20844B;
    case 0x20844Eu: goto L_20844E;
    case 0x208451u: goto L_208451;
    case 0x208454u: goto L_208454;
    case 0x208457u: goto L_208457;
    case 0x20845Au: goto L_20845A;
    case 0x20845Du: goto L_20845D;
    case 0x208460u: goto L_208460;
    case 0x208462u: goto L_208462;
    case 0x208464u: goto L_208464;
    case 0x208467u: goto L_208467;
    case 0x20846Au: goto L_20846A;
    case 0x20846Du: goto L_20846D;
    case 0x20846Fu: goto L_20846F;
    case 0x208471u: goto L_208471;
    case 0x208473u: goto L_208473;
    case 0x208474u: goto L_208474;
    case 0x208476u: goto L_208476;
    case 0x808000u: goto L_808000;
    case 0x808001u: goto L_808001;
    case 0x808003u: goto L_808003;
    case 0x808006u: goto L_808006;
    case 0x808007u: goto L_808007;
    case 0x808009u: goto L_808009;
    case 0x80800Au: goto L_80800A;
    case 0x80800Du: goto L_80800D;
    case 0x808011u: goto L_808011;
    case 0x808014u: goto L_808014;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_2082F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082F1 LDA
    cpu.setA(0x0u, 8);
    goto L_2082F3;
L_2082F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F3u, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082F3 STA
    hw.write(cpu.address("abs", 0x2121u), cpu.a, cpu.m8?8:16);
    goto L_2082F6;
L_2082F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082F6 LDX
    cpu.setX(0x0u, 16);
    goto L_2082F9;
L_2082F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82F9u, 4u + 1u, 3u, cpu.address("absx", 0x93FAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082F9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x93FAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2082FC;
L_2082FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FCu, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082FC STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_2082FF;
L_2082FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x82FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x82FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2082FF INX
    cpu.inc('X');
    goto L_208300;
L_208300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8300u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208300 CPX
    cpu.compareX(0xFFu);
    goto L_208303;
L_208303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8303u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8303u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208303 BNE -> $2082F9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2082F9; }
    goto L_208305;
L_208305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8305u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8305u, 6u, 3u, cpu.address("abs", 0x8731u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208305 JSR -> $208731 stack real
    { cpu.push16Value(hw,0x8307u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8308u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8731u), 0x208305u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208308;
L_208308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8308u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8308u,0x208308u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8308u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208308 LDA
    cpu.setA(0x3u, 8);
    goto L_20830A;
L_20830A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Au, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20830A STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_20830D;
L_20830D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20830D LDA
    cpu.setA(0x2u, 8);
    goto L_20830F;
L_20830F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x830Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x830Fu, 4u, 3u, cpu.address("abs", 0x1002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20830F STA
    hw.write(cpu.address("abs", 0x1002u), cpu.a, cpu.m8?8:16);
    goto L_208312;
L_208312:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8312u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8312u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8312u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208312 LDA
    cpu.setA(0x1u, 8);
    goto L_208314;
L_208314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8314u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8314u, 4u, 3u, cpu.address("abs", 0x1003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208314 STA
    hw.write(cpu.address("abs", 0x1003u), cpu.a, cpu.m8?8:16);
    goto L_208317;
L_208317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8317u, 4u, 3u, cpu.address("abs", 0x1000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208317 STZ
    hw.write(cpu.address("abs", 0x1000u), 0, cpu.m8?8:16);
    goto L_20831A;
L_20831A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20831A LDA
    cpu.setA(0x2u, 8);
    goto L_20831C;
L_20831C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Cu, 4u, 3u, cpu.address("abs", 0x1006u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20831C STA
    hw.write(cpu.address("abs", 0x1006u), cpu.a, cpu.m8?8:16);
    goto L_20831F;
L_20831F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x831Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x831Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20831F LDA
    cpu.setA(0xB0u, 8);
    goto L_208321;
L_208321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8321u, 4u, 3u, cpu.address("abs", 0x1007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208321 STA
    hw.write(cpu.address("abs", 0x1007u), cpu.a, cpu.m8?8:16);
    goto L_208324;
L_208324:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8324u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8324u, 4u, 3u, cpu.address("abs", 0x1010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208324 STZ
    hw.write(cpu.address("abs", 0x1010u), 0, cpu.m8?8:16);
    goto L_208327;
L_208327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8327u, 4u, 3u, cpu.address("abs", 0x1011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208327 STZ
    hw.write(cpu.address("abs", 0x1011u), 0, cpu.m8?8:16);
    goto L_20832A;
L_20832A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20832A LDA
    cpu.setA(0x50u, 8);
    goto L_20832C;
L_20832C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Cu, 4u, 3u, cpu.address("abs", 0x101Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20832C STA
    hw.write(cpu.address("abs", 0x101Au), cpu.a, cpu.m8?8:16);
    goto L_20832F;
L_20832F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x832Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x832Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x832Fu, 4u, 3u, cpu.address("abs", 0x1018u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20832F STZ
    hw.write(cpu.address("abs", 0x1018u), 0, cpu.m8?8:16);
    goto L_208332;
L_208332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8332u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8332u, 4u, 3u, cpu.address("abs", 0x1019u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208332 STZ
    hw.write(cpu.address("abs", 0x1019u), 0, cpu.m8?8:16);
    goto L_208335;
L_208335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8335u, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208335 STZ
    hw.write(cpu.address("abs", 0x1022u), 0, cpu.m8?8:16);
    goto L_208338;
L_208338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8338u, 4u, 3u, cpu.address("abs", 0x101Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208338 STZ
    hw.write(cpu.address("abs", 0x101Cu), 0, cpu.m8?8:16);
    goto L_20833B;
L_20833B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Bu, 4u, 3u, cpu.address("abs", 0x101Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20833B STZ
    hw.write(cpu.address("abs", 0x101Du), 0, cpu.m8?8:16);
    goto L_20833E;
L_20833E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x833Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x833Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x833Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20833E LDA
    cpu.setA(0x31u, 8);
    goto L_208340;
L_208340:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8340u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8340u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8340u, 4u, 3u, cpu.address("abs", 0x1024u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208340 STA
    hw.write(cpu.address("abs", 0x1024u), cpu.a, cpu.m8?8:16);
    goto L_208343;
L_208343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8343u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8343u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208343 LDA
    cpu.setA(0x30u, 8);
    goto L_208345;
L_208345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8345u, 4u, 3u, cpu.address("abs", 0x1026u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208345 STA
    hw.write(cpu.address("abs", 0x1026u), cpu.a, cpu.m8?8:16);
    goto L_208348;
L_208348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8348u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208348 LDA
    cpu.setA(0x1u, 8);
    goto L_20834A;
L_20834A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Au, 5u, 4u, 0x70011Cu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20834A STA
    hw.write(0x70011Cu, cpu.a, cpu.m8?8:16);
    goto L_20834E;
L_20834E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x834Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x834Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20834E LDA
    cpu.setA(0x0u, 8);
    goto L_208350;
L_208350:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8350u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8350u, 4u, 3u, cpu.address("abs", 0x102Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208350 STA
    hw.write(cpu.address("abs", 0x102Au), cpu.a, cpu.m8?8:16);
    goto L_208353;
L_208353:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8353u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8353u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208353 LDA
    cpu.setA(0x63u, 8);
    goto L_208355;
L_208355:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8355u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8355u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8355u, 4u, 3u, cpu.address("abs", 0x1028u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208355 STA
    hw.write(cpu.address("abs", 0x1028u), cpu.a, cpu.m8?8:16);
    goto L_208358;
L_208358:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8358u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8358u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8358u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208358 LDA
    cpu.setA(0x2Fu, 8);
    goto L_20835A;
L_20835A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Au, 4u, 3u, cpu.address("abs", 0x102Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835A STA
    hw.write(cpu.address("abs", 0x102Cu), cpu.a, cpu.m8?8:16);
    goto L_20835D;
L_20835D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835D ADC
    cpu.adc(0x8u);
    goto L_20835F;
L_20835F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x835Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x835Fu, 4u, 3u, cpu.address("abs", 0x102Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20835F STA
    hw.write(cpu.address("abs", 0x102Eu), cpu.a, cpu.m8?8:16);
    goto L_208362;
L_208362:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8362u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8362u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208362 LDA
    cpu.setA(0x38u, 8);
    goto L_208364;
L_208364:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8364u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8364u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8364u, 4u, 3u, cpu.address("abs", 0x1030u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208364 STA
    hw.write(cpu.address("abs", 0x1030u), cpu.a, cpu.m8?8:16);
    goto L_208367;
L_208367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8367u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208367 STZ
    hw.write(cpu.address("abs", 0x1032u), 0, cpu.m8?8:16);
    goto L_20836A;
L_20836A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20836A LDX
    cpu.setX(0x0u, 16);
    goto L_20836D;
L_20836D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x836Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x836Du, 5u, 3u, cpu.address("abs", 0x1033u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20836D STX
    hw.write(cpu.address("abs", 0x1033u), cpu.x, cpu.x8?8:16);
    goto L_208370;
L_208370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8370u, 5u, 3u, cpu.address("abs", 0x1035u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208370 STX
    hw.write(cpu.address("abs", 0x1035u), cpu.x, cpu.x8?8:16);
    goto L_208373;
L_208373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8373u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8373u, 5u, 3u, cpu.address("abs", 0x1037u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208373 STX
    hw.write(cpu.address("abs", 0x1037u), cpu.x, cpu.x8?8:16);
    goto L_208376;
L_208376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8376u, 5u, 3u, cpu.address("abs", 0x1038u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208376 STX
    hw.write(cpu.address("abs", 0x1038u), cpu.x, cpu.x8?8:16);
    goto L_208379;
L_208379:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8379u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8379u, 4u, 3u, cpu.address("abs", 0x1FF0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208379 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20837C;
L_20837C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20837C CMP
    cpu.compareA(0x0u);
    goto L_20837E;
L_20837E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x837Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x837Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x837Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20837E BEQ -> $208389
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208389; }
    goto L_208380;
L_208380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8380u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8380u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208380 LDA
    cpu.setA(0xFu, 8);
    goto L_208382;
L_208382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8382u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8382u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208382 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_208385;
L_208385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8385u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8385u, 4u, 4u, 0x208033u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208385 JML -> $208033
    hw.requestDispatch(0x208033u,0x208385u); return;
L_208389:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8389u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8389u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8389u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208389 LDA
    cpu.setA(0x8Fu, 8);
    goto L_20838B;
L_20838B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Bu, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20838B STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_20838E;
L_20838E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x838Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x838Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x838Eu, 6u, 3u, cpu.address("abs", 0x87DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20838E JSR -> $2087DE stack real
    { cpu.push16Value(hw,0x8390u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8391u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x87DEu), 0x20838Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208391;
L_208391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8391u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8391u,0x208391u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8391u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208391 REP
    cpu.rep(0x30u);
    goto L_208393;
L_208393:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8393u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8393u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8393u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208393 SEP
    cpu.sep(0x20u);
    goto L_208395;
L_208395:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8395u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8395u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208395 STZ
    hw.write(cpu.address("abs", 0x1016u), 0, cpu.m8?8:16);
    goto L_208398;
L_208398:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8398u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8398u, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208398 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_20839B;
L_20839B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Bu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20839B STZ
    hw.write(cpu.address("abs", 0x1015u), 0, cpu.m8?8:16);
    goto L_20839E;
L_20839E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x839Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x839Eu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20839E JSR -> $20876C stack real
    { cpu.push16Value(hw,0x83A0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x20839Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A1;
L_2083A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A1u,0x2083A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A1u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083A1 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x83A3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x2083A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A4;
L_2083A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A4u,0x2083A4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A4u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083A4 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x83A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83A7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x2083A4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083A7;
L_2083A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83A7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83A7u,0x2083A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83A7u, 6u, 3u, cpu.address("abs", 0x1015u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083A7 INC
    cpu.incMem(hw, cpu.address("abs", 0x1015u), cpu.m8?8:16);
    goto L_2083AA;
L_2083AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AAu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1015u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083AD;
L_2083AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AD CMP
    cpu.compareA(0x3u);
    goto L_2083AF;
L_2083AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083AF BNE -> $20839E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20839E; }
    goto L_2083B1;
L_2083B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B1u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1016u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083B4;
L_2083B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B4u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B4 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_2083B7;
L_2083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083B7 INC
    cpu.incMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_2083BA;
L_2083BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083BA CMP
    cpu.compareA(0xFu);
    goto L_2083BC;
L_2083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083BC BNE -> $20839B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20839B; }
    goto L_2083BE;
L_2083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083BE JSR -> $20876C stack real
    { cpu.push16Value(hw,0x83C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x2083BEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C1;
L_2083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C1u,0x2083C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C1 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x83C3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x2083C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C4;
L_2083C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C4u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C4u,0x2083C4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C4u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C4 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x83C6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83C7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x2083C4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083C7;
L_2083C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83C7u,0x2083C7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C7u, 6u, 3u, cpu.address("abs", 0x847Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083C7 JSR -> $20847A stack real
    { cpu.push16Value(hw,0x83C9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83CAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x847Au), 0x2083C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083CA;
L_2083CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CAu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83CAu,0x2083CAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CAu, 6u, 3u, cpu.address("abs", 0x8727u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083CA JSR -> $208727 stack real
    { cpu.push16Value(hw,0x83CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83CDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8727u), 0x2083CAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083CD;
L_2083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83CDu,0x2083CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083CD REP
    cpu.rep(0x30u);
    goto L_2083CF;
L_2083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083CF SEP
    cpu.sep(0x20u);
    goto L_2083D1;
L_2083D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D1u, 4u, 3u, cpu.address("abs", 0x4218u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D1 STZ
    hw.write(cpu.address("abs", 0x4218u), 0, cpu.m8?8:16);
    goto L_2083D4;
L_2083D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D4u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083D7;
L_2083D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D7 AND
    cpu.logicAnd(0x10u);
    goto L_2083D9;
L_2083D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083D9 BNE -> $208446
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208446; }
    goto L_2083DB;
L_2083DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DBu, 4u, 3u, cpu.address("abs", 0x0512u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083DB LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x512u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083DE;
L_2083DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83DEu, 4u, 3u, cpu.address("abs", 0x102Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083DE CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x102Eu), cpu.m8?8:16));
    goto L_2083E1;
L_2083E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E1 BEQ -> $2083FC
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083FC; }
    goto L_2083E3;
L_2083E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E3u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083E6;
L_2083E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E6 AND
    cpu.logicAnd(0x80u);
    goto L_2083E8;
L_2083E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083E8 BEQ -> $2083F9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083F9; }
    goto L_2083EA;
L_2083EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EAu, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083EA LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1032u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083ED;
L_2083ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083ED BNE -> $2083FC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_2083FC; }
    goto L_2083EF;
L_2083EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083EF LDA
    cpu.setA(0x1u, 8);
    goto L_2083F1;
L_2083F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F1u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F1 STA
    hw.write(cpu.address("abs", 0x1032u), cpu.a, cpu.m8?8:16);
    goto L_2083F4;
L_2083F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F4u, 6u, 3u, cpu.address("abs", 0x85B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $2083F4 JSR -> $2085B5 stack real
    { cpu.push16Value(hw,0x83F6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x83F7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x85B5u), 0x2083F4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_2083F7;
L_2083F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83F7u,0x2083F7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F7 BRA -> $2083BE
    goto L_2083BE;
L_2083F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83F9u, 4u, 3u, cpu.address("abs", 0x1032u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083F9 STZ
    hw.write(cpu.address("abs", 0x1032u), 0, cpu.m8?8:16);
    goto L_2083FC;
L_2083FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FCu, 4u, 3u, cpu.address("abs", 0x0512u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x512u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2083FF;
L_2083FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83FFu, 4u, 3u, cpu.address("abs", 0x1030u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2083FF CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1030u), cpu.m8?8:16));
    goto L_208402;
L_208402:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8402u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8402u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208402 BNE -> $20842A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_208404;
L_208404:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8404u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8404u, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208404 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1022u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208407;
L_208407:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8407u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8407u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208407 INC
    cpu.inc('A');
    goto L_208408;
L_208408:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8408u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8408u, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208408 STA
    hw.write(cpu.address("abs", 0x1022u), cpu.a, cpu.m8?8:16);
    goto L_20840B;
L_20840B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840B CMP
    cpu.compareA(0x7u);
    goto L_20840D;
L_20840D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840D BNE -> $20842A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_20840F;
L_20840F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x840Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x840Fu, 4u, 3u, cpu.address("abs", 0x1022u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20840F STZ
    hw.write(cpu.address("abs", 0x1022u), 0, cpu.m8?8:16);
    goto L_208412;
L_208412:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8412u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8412u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208412 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208415;
L_208415:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8415u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8415u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208415 AND
    cpu.logicAnd(0x2u);
    goto L_208417;
L_208417:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8417u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8417u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8417u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208417 BEQ -> $20841E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20841E; }
    goto L_208419;
L_208419:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8419u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8419u, 6u, 3u, cpu.address("abs", 0x854Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208419 JSR -> $20854E stack real
    { cpu.push16Value(hw,0x841Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x841Cu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x854Eu), 0x208419u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_20841C;
L_20841C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Cu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x841Cu,0x20841Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20841C BRA -> $2083BE
    goto L_2083BE;
L_20841E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x841Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x841Eu, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20841E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208421;
L_208421:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8421u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8421u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208421 AND
    cpu.logicAnd(0x1u);
    goto L_208423;
L_208423:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8423u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8423u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8423u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208423 BEQ -> $20842A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_20842A; }
    goto L_208425;
L_208425:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8425u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8425u, 6u, 3u, cpu.address("abs", 0x84E7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208425 JSR -> $2084E7 stack real
    { cpu.push16Value(hw,0x8427u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8428u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x84E7u), 0x208425u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208428;
L_208428:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8428u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8428u,0x208428u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8428u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8428u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208428 BRA -> $2083BE
    goto L_2083BE;
L_20842A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Au, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20842D;
L_20842D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842D AND
    cpu.logicAnd(0x8u);
    goto L_20842F;
L_20842F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x842Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x842Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20842F BEQ -> $208438
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208438; }
    goto L_208431;
L_208431:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8431u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8431u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8431u, 6u, 3u, cpu.address("abs", 0x86C8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208431 JSR -> $2086C8 stack real
    { cpu.push16Value(hw,0x8433u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8434u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86C8u), 0x208431u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208434;
L_208434:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8434u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8434u,0x208434u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8434u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8434u, 4u, 4u, 0x2083BEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208434 JML -> $2083BE
    cpu.pb=0x20u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_2083BE;
L_208438:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8438u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8438u, 4u, 3u, cpu.address("abs", 0x4219u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208438 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4219u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20843B;
L_20843B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20843B AND
    cpu.logicAnd(0x4u);
    goto L_20843D;
L_20843D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20843D BEQ -> $208442
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_208442; }
    goto L_20843F;
L_20843F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x843Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x843Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x843Fu, 6u, 3u, cpu.address("abs", 0x86F7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20843F JSR -> $2086F7 stack real
    { cpu.push16Value(hw,0x8441u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8442u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86F7u), 0x20843Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208442;
L_208442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8442u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8442u,0x208442u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8442u, 4u, 4u, 0x2083BEu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208442 JML -> $2083BE
    cpu.pb=0x20u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_2083BE;
L_208446:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8446u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8446u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208446 LDA
    cpu.setA(0xFu, 8);
    goto L_208448;
L_208448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8448u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208448 STA
    hw.write(cpu.address("abs", 0x1016u), cpu.a, cpu.m8?8:16);
    goto L_20844B;
L_20844B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Bu, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20844B STZ
    hw.write(cpu.address("abs", 0x1015u), 0, cpu.m8?8:16);
    goto L_20844E;
L_20844E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x844Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x844Eu, 6u, 3u, cpu.address("abs", 0x876Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20844E JSR -> $20876C stack real
    { cpu.push16Value(hw,0x8450u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8451u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x876Cu), 0x20844Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208451;
L_208451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8451u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8451u,0x208451u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8451u, 6u, 3u, cpu.address("abs", 0x8740u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208451 JSR -> $208740 stack real
    { cpu.push16Value(hw,0x8453u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8454u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8740u), 0x208451u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208454;
L_208454:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8454u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8454u,0x208454u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8454u, 6u, 3u, cpu.address("abs", 0x8811u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208454 JSR -> $208811 stack real
    { cpu.push16Value(hw,0x8456u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8457u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8811u), 0x208454u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_208457;
L_208457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8457u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8457u,0x208457u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8457u, 6u, 3u, cpu.address("abs", 0x847Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $208457 JSR -> $20847A stack real
    { cpu.push16Value(hw,0x8459u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x845Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x847Au), 0x208457u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_20845A;
L_20845A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Au))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x845Au,0x20845Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Au, 6u, 3u, cpu.address("abs", 0x1015u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20845A INC
    cpu.incMem(hw, cpu.address("abs", 0x1015u), cpu.m8?8:16);
    goto L_20845D;
L_20845D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x845Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x845Du, 4u, 3u, cpu.address("abs", 0x1015u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20845D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1015u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208460;
L_208460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8460u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8460u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208460 CMP
    cpu.compareA(0x2u);
    goto L_208462;
L_208462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8462u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8462u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208462 BNE -> $20844E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20844E; }
    goto L_208464;
L_208464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8464u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8464u, 4u, 3u, cpu.address("abs", 0x1016u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208464 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1016u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208467;
L_208467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8467u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8467u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208467 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_20846A;
L_20846A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Au, 6u, 3u, cpu.address("abs", 0x1016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846A DEC
    cpu.decMem(hw, cpu.address("abs", 0x1016u), cpu.m8?8:16);
    goto L_20846D;
L_20846D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846D CMP
    cpu.compareA(0x0u);
    goto L_20846F;
L_20846F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x846Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x846Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20846F BNE -> $20844B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_20844B; }
    goto L_208471;
L_208471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8471u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8471u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8471u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208471 LDA
    cpu.setA(0xFFu, 8);
    goto L_208473;
L_208473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8473u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8473u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208473 DEC
    cpu.decReg('A');
    goto L_208474;
L_208474:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8474u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8474u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8474u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208474 BNE -> $208473
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208473; }
    goto L_208476;
L_208476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8476u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8476u, 4u, 4u, 0x80FF90u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208476 JML -> $80FF90
    hw.requestDispatch(0x80FF90u,0x208476u); return;
L_808000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u,cpu,0xD8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8000u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808000 CLD
    cpu.setFlag('D', false);
    goto L_808001;
L_808001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808001 REP
    cpu.rep(0x30u);
    goto L_808003;
L_808003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8003u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808003 LDX
    cpu.setX(0x1A7u, 16);
    goto L_808006;
L_808006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808006 TXS
    cpu.transfer("TXS");
    goto L_808007;
L_808007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8007u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8007u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808007 REP
    cpu.rep(0x30u);
    goto L_808009;
L_808009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8009u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8009u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808009 PHB
    cpu.push("PHB", hw);
    goto L_80800A;
L_80800A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80800A LDA
    cpu.setA(0x0u, 16);
    goto L_80800D;
L_80800D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x800Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x800Du, 6u, 4u, 0x000000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80800D STA
    hw.write(0x0u, cpu.a, cpu.m8?8:16);
    goto L_808011;
L_808011:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8011u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8011u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808011 LDA
    cpu.setA(0x1FFBu, 16);
    goto L_808014;
L_808014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8014u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808014 LDX
    cpu.setX(0x1u, 16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8017u,0x808014u); return;
}

void sub_808AC5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808AC5u: goto L_808AC5;
    case 0x808AC7u: goto L_808AC7;
    case 0x808AC8u: goto L_808AC8;
    case 0x808ACBu: goto L_808ACB;
    case 0x808ACFu: goto L_808ACF;
    case 0x808AD2u: goto L_808AD2;
    case 0x808AD5u: goto L_808AD5;
    case 0x808AD6u: goto L_808AD6;
    case 0x808AD7u: goto L_808AD7;
    case 0x808ADAu: goto L_808ADA;
    case 0x808ADBu: goto L_808ADB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808AC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AC5 REP
    cpu.rep(0x30u);
    goto L_808AC7;
L_808AC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC7u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AC7 PHB
    cpu.push("PHB", hw);
    goto L_808AC8;
L_808AC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AC8 LDA
    cpu.setA(0x0u, 16);
    goto L_808ACB;
L_808ACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACBu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACBu, 6u, 4u, 0x000000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ACB STA
    hw.write(0x0u, cpu.a, cpu.m8?8:16);
    goto L_808ACF;
L_808ACF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ACFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ACFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808ACF LDA
    cpu.setA(0x135u, 16);
    goto L_808AD2;
L_808AD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD2 LDX
    cpu.setX(0x1u, 16);
    goto L_808AD5;
L_808AD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD5 TXY
    cpu.transfer("TXY");
    goto L_808AD6;
L_808AD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AD6 INY
    cpu.inc('Y');
    goto L_808AD7;
L_808AD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AD7u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8AD7u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808AD7 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808ADA;
L_808ADA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808ADA PLB
    cpu.pop("PLB", hw);
    goto L_808ADB;
L_808ADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8ADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8ADBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808ADB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808ADBu);return;} hw.unresolvedReturn(0x808ADBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C38_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C38u: goto L_808C38;
    case 0x808C3Bu: goto L_808C3B;
    case 0x808C3Eu: goto L_808C3E;
    case 0x808C41u: goto L_808C41;
    case 0x808C44u: goto L_808C44;
    case 0x808C47u: goto L_808C47;
    case 0x808C48u: goto L_808C48;
    case 0x808C49u: goto L_808C49;
    case 0x808C4Au: goto L_808C4A;
    case 0x808C4Bu: goto L_808C4B;
    case 0x808C4Cu: goto L_808C4C;
    case 0x808C4Fu: goto L_808C4F;
    case 0x808C52u: goto L_808C52;
    case 0x808C55u: goto L_808C55;
    case 0x808C58u: goto L_808C58;
    case 0x808C59u: goto L_808C59;
    case 0x808C5Au: goto L_808C5A;
    case 0x808C5Bu: goto L_808C5B;
    case 0x808C5Eu: goto L_808C5E;
    case 0x808C61u: goto L_808C61;
    case 0x808C64u: goto L_808C64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C38 STA
    hw.write(cpu.address("abs", 0x1FE0u), cpu.a, cpu.m8?8:16);
    goto L_808C3B;
L_808C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C3E;
L_808C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3E ORA
    cpu.logicOr(0x20u);
    goto L_808C41;
L_808C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u, 5u, 3u, cpu.address("abs", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C41 STA
    hw.write(cpu.address("abs", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_808C44;
L_808C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C47;
L_808C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C47 LSR
    cpu.lsrA();
    goto L_808C48;
L_808C48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C48 LSR
    cpu.lsrA();
    goto L_808C49;
L_808C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C49 LSR
    cpu.lsrA();
    goto L_808C4A;
L_808C4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4A LSR
    cpu.lsrA();
    goto L_808C4B;
L_808C4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4B LSR
    cpu.lsrA();
    goto L_808C4C;
L_808C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4C AND
    cpu.logicAnd(0x1Fu);
    goto L_808C4F;
L_808C4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4F ORA
    cpu.logicOr(0x40u);
    goto L_808C52;
L_808C52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u, 5u, 3u, cpu.address("abs", 0x1FE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C52 STA
    hw.write(cpu.address("abs", 0x1FE4u), cpu.a, cpu.m8?8:16);
    goto L_808C55;
L_808C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C58;
L_808C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C58 XBA
    cpu.xba();
    goto L_808C59;
L_808C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C59 LSR
    cpu.lsrA();
    goto L_808C5A;
L_808C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5A LSR
    cpu.lsrA();
    goto L_808C5B;
L_808C5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C5E;
L_808C5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5E ORA
    cpu.logicOr(0x80u);
    goto L_808C61;
L_808C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u, 5u, 3u, cpu.address("abs", 0x1FE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C61 STA
    hw.write(cpu.address("abs", 0x1FE6u), cpu.a, cpu.m8?8:16);
    goto L_808C64;
L_808C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808C64 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808C64u);return;} hw.unresolvedReturn(0x808C64u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C38_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C38u: goto L_808C38;
    case 0x808C3Bu: goto L_808C3B;
    case 0x808C3Eu: goto L_808C3E;
    case 0x808C41u: goto L_808C41;
    case 0x808C44u: goto L_808C44;
    case 0x808C47u: goto L_808C47;
    case 0x808C48u: goto L_808C48;
    case 0x808C49u: goto L_808C49;
    case 0x808C4Au: goto L_808C4A;
    case 0x808C4Bu: goto L_808C4B;
    case 0x808C4Cu: goto L_808C4C;
    case 0x808C4Fu: goto L_808C4F;
    case 0x808C52u: goto L_808C52;
    case 0x808C55u: goto L_808C55;
    case 0x808C58u: goto L_808C58;
    case 0x808C59u: goto L_808C59;
    case 0x808C5Au: goto L_808C5A;
    case 0x808C5Bu: goto L_808C5B;
    case 0x808C5Eu: goto L_808C5E;
    case 0x808C61u: goto L_808C61;
    case 0x808C64u: goto L_808C64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C38 STA
    hw.write(cpu.address("abs", 0x1FE0u), cpu.a, cpu.m8?8:16);
    goto L_808C3B;
L_808C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C3E;
L_808C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3E ORA
    cpu.logicOr(0x20u);
    goto L_808C41;
L_808C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u, 5u, 3u, cpu.address("abs", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C41 STA
    hw.write(cpu.address("abs", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_808C44;
L_808C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C47;
L_808C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C47 LSR
    cpu.lsrA();
    goto L_808C48;
L_808C48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C48 LSR
    cpu.lsrA();
    goto L_808C49;
L_808C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C49 LSR
    cpu.lsrA();
    goto L_808C4A;
L_808C4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4A LSR
    cpu.lsrA();
    goto L_808C4B;
L_808C4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4B LSR
    cpu.lsrA();
    goto L_808C4C;
L_808C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4C AND
    cpu.logicAnd(0x1Fu);
    goto L_808C4F;
L_808C4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4F ORA
    cpu.logicOr(0x40u);
    goto L_808C52;
L_808C52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u, 5u, 3u, cpu.address("abs", 0x1FE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C52 STA
    hw.write(cpu.address("abs", 0x1FE4u), cpu.a, cpu.m8?8:16);
    goto L_808C55;
L_808C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C58;
L_808C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C58 XBA
    cpu.xba();
    goto L_808C59;
L_808C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C59 LSR
    cpu.lsrA();
    goto L_808C5A;
L_808C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5A LSR
    cpu.lsrA();
    goto L_808C5B;
L_808C5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C5E;
L_808C5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5E ORA
    cpu.logicOr(0x80u);
    goto L_808C61;
L_808C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u, 5u, 3u, cpu.address("abs", 0x1FE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C61 STA
    hw.write(cpu.address("abs", 0x1FE6u), cpu.a, cpu.m8?8:16);
    goto L_808C64;
L_808C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808C64 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808C64u);return;} hw.unresolvedReturn(0x808C64u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808C38_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808C38u: goto L_808C38;
    case 0x808C3Bu: goto L_808C3B;
    case 0x808C3Eu: goto L_808C3E;
    case 0x808C41u: goto L_808C41;
    case 0x808C44u: goto L_808C44;
    case 0x808C47u: goto L_808C47;
    case 0x808C48u: goto L_808C48;
    case 0x808C49u: goto L_808C49;
    case 0x808C4Au: goto L_808C4A;
    case 0x808C4Bu: goto L_808C4B;
    case 0x808C4Cu: goto L_808C4C;
    case 0x808C4Fu: goto L_808C4F;
    case 0x808C52u: goto L_808C52;
    case 0x808C55u: goto L_808C55;
    case 0x808C58u: goto L_808C58;
    case 0x808C59u: goto L_808C59;
    case 0x808C5Au: goto L_808C5A;
    case 0x808C5Bu: goto L_808C5B;
    case 0x808C5Eu: goto L_808C5E;
    case 0x808C61u: goto L_808C61;
    case 0x808C64u: goto L_808C64;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808C38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C38u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C38 STA
    hw.write(cpu.address("abs", 0x1FE0u), cpu.a, cpu.m8?8:16);
    goto L_808C3B;
L_808C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C3E;
L_808C3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C3E ORA
    cpu.logicOr(0x20u);
    goto L_808C41;
L_808C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C41u, 5u, 3u, cpu.address("abs", 0x1FE2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C41 STA
    hw.write(cpu.address("abs", 0x1FE2u), cpu.a, cpu.m8?8:16);
    goto L_808C44;
L_808C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C44u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C47;
L_808C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C47 LSR
    cpu.lsrA();
    goto L_808C48;
L_808C48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C48 LSR
    cpu.lsrA();
    goto L_808C49;
L_808C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C49 LSR
    cpu.lsrA();
    goto L_808C4A;
L_808C4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4A LSR
    cpu.lsrA();
    goto L_808C4B;
L_808C4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4B LSR
    cpu.lsrA();
    goto L_808C4C;
L_808C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4C AND
    cpu.logicAnd(0x1Fu);
    goto L_808C4F;
L_808C4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C4Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C4F ORA
    cpu.logicOr(0x40u);
    goto L_808C52;
L_808C52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C52u, 5u, 3u, cpu.address("abs", 0x1FE4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C52 STA
    hw.write(cpu.address("abs", 0x1FE4u), cpu.a, cpu.m8?8:16);
    goto L_808C55;
L_808C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C55u, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C55 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808C58;
L_808C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C58u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C58 XBA
    cpu.xba();
    goto L_808C59;
L_808C59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C59u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C59 LSR
    cpu.lsrA();
    goto L_808C5A;
L_808C5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5A LSR
    cpu.lsrA();
    goto L_808C5B;
L_808C5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5B AND
    cpu.logicAnd(0x1Fu);
    goto L_808C5E;
L_808C5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C5Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C5E ORA
    cpu.logicOr(0x80u);
    goto L_808C61;
L_808C61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C61u, 5u, 3u, cpu.address("abs", 0x1FE6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808C61 STA
    hw.write(cpu.address("abs", 0x1FE6u), cpu.a, cpu.m8?8:16);
    goto L_808C64;
L_808C64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8C64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8C64u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808C64 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808C64u);return;} hw.unresolvedReturn(0x808C64u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AE39_E0M1X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE39u: goto L_80AE39;
    case 0x80AE3Bu: goto L_80AE3B;
    case 0x80AE3Eu: goto L_80AE3E;
    case 0x80AE40u: goto L_80AE40;
    case 0x80AE43u: goto L_80AE43;
    case 0x80AE45u: goto L_80AE45;
    case 0x80AE46u: goto L_80AE46;
    case 0x80AE47u: goto L_80AE47;
    case 0x80AE4Au: goto L_80AE4A;
    case 0x80AE4Du: goto L_80AE4D;
    case 0x80AE4Fu: goto L_80AE4F;
    case 0x80AE51u: goto L_80AE51;
    case 0x80AE54u: goto L_80AE54;
    case 0x80AE56u: goto L_80AE56;
    case 0x80AE58u: goto L_80AE58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE39 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE3B;
L_80AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE3E;
L_80AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3E STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80AE40;
L_80AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE43;
L_80AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80AE45;
L_80AE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE45 INX
    cpu.inc('X');
    goto L_80AE46;
L_80AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE46 INX
    cpu.inc('X');
    goto L_80AE47;
L_80AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 6u, 3u, cpu.address("abs", 0xAF79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE47 JSR -> $80AF79 stack real
    { cpu.push16Value(hw,0xAE49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAF79u), 0x80AE47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE4A;
L_80AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE4Au,0x80AE4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4A LDA
    cpu.setA(0x80u, 16);
    goto L_80AE4D;
L_80AE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE4F;
L_80AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4F BPL -> $80AE54
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AE54; }
    goto L_80AE51;
L_80AE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE51 LDA
    cpu.setA(0x400u, 16);
    goto L_80AE54;
L_80AE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE54 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80AE56;
L_80AE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE56 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80AE58;
L_80AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE58u);return;} hw.unresolvedReturn(0x80AE58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AE39_E0M1X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE39u: goto L_80AE39;
    case 0x80AE3Bu: goto L_80AE3B;
    case 0x80AE3Eu: goto L_80AE3E;
    case 0x80AE40u: goto L_80AE40;
    case 0x80AE43u: goto L_80AE43;
    case 0x80AE45u: goto L_80AE45;
    case 0x80AE46u: goto L_80AE46;
    case 0x80AE47u: goto L_80AE47;
    case 0x80AE4Au: goto L_80AE4A;
    case 0x80AE4Du: goto L_80AE4D;
    case 0x80AE4Fu: goto L_80AE4F;
    case 0x80AE51u: goto L_80AE51;
    case 0x80AE54u: goto L_80AE54;
    case 0x80AE56u: goto L_80AE56;
    case 0x80AE58u: goto L_80AE58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE39 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE3B;
L_80AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE3E;
L_80AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3E STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80AE40;
L_80AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE43;
L_80AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80AE45;
L_80AE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE45 INX
    cpu.inc('X');
    goto L_80AE46;
L_80AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE46 INX
    cpu.inc('X');
    goto L_80AE47;
L_80AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 6u, 3u, cpu.address("abs", 0xAF79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE47 JSR -> $80AF79 stack real
    { cpu.push16Value(hw,0xAE49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAF79u), 0x80AE47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE4A;
L_80AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE4Au,0x80AE4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4A LDA
    cpu.setA(0x80u, 16);
    goto L_80AE4D;
L_80AE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE4F;
L_80AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4F BPL -> $80AE54
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AE54; }
    goto L_80AE51;
L_80AE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE51 LDA
    cpu.setA(0x400u, 16);
    goto L_80AE54;
L_80AE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE54 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80AE56;
L_80AE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE56 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80AE58;
L_80AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE58u);return;} hw.unresolvedReturn(0x80AE58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80AE39_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AE39u: goto L_80AE39;
    case 0x80AE3Bu: goto L_80AE3B;
    case 0x80AE3Eu: goto L_80AE3E;
    case 0x80AE40u: goto L_80AE40;
    case 0x80AE43u: goto L_80AE43;
    case 0x80AE45u: goto L_80AE45;
    case 0x80AE46u: goto L_80AE46;
    case 0x80AE47u: goto L_80AE47;
    case 0x80AE4Au: goto L_80AE4A;
    case 0x80AE4Du: goto L_80AE4D;
    case 0x80AE4Fu: goto L_80AE4F;
    case 0x80AE51u: goto L_80AE51;
    case 0x80AE54u: goto L_80AE54;
    case 0x80AE56u: goto L_80AE56;
    case 0x80AE58u: goto L_80AE58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AE39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE39u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE39 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE3B;
L_80AE3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Bu, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE3E;
L_80AE3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE3Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE3E STA
    hw.write(cpu.address("dp", 0x15u), cpu.a, cpu.m8?8:16);
    goto L_80AE40;
L_80AE40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE40u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE40 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE43;
L_80AE43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE43u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE43 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_80AE45;
L_80AE45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE45 INX
    cpu.inc('X');
    goto L_80AE46;
L_80AE46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE46 INX
    cpu.inc('X');
    goto L_80AE47;
L_80AE47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE47u, 6u, 3u, cpu.address("abs", 0xAF79u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE47 JSR -> $80AF79 stack real
    { cpu.push16Value(hw,0xAE49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAF79u), 0x80AE47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE4A;
L_80AE4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE4Au,0x80AE4Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4A LDA
    cpu.setA(0x80u, 16);
    goto L_80AE4D;
L_80AE4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x07u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x7u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE4F;
L_80AE4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE4Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE4F BPL -> $80AE54
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AE54; }
    goto L_80AE51;
L_80AE51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE51 LDA
    cpu.setA(0x400u, 16);
    goto L_80AE54;
L_80AE54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE54u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE54 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80AE56;
L_80AE56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE56u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE56 INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80AE58;
L_80AE58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80AE58u);return;} hw.unresolvedReturn(0x80AE58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80BBD8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BBD8u: goto L_80BBD8;
    case 0x80BBDAu: goto L_80BBDA;
    case 0x80BBDBu: goto L_80BBDB;
    case 0x80BBDCu: goto L_80BBDC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BBD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBD8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BBDA;
L_80BBDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBDA ASL
    cpu.aslA();
    goto L_80BBDB;
L_80BBDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BBDB TAX
    cpu.transfer("TAX");
    goto L_80BBDC;
L_80BBDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBBDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDCu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBBDCu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBBDFu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BBDC JMP (BBDF,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBBDFu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BBDCu); return; }
}

void sub_80C6FE_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C6FEu: goto L_80C6FE;
    case 0x80C701u: goto L_80C701;
    case 0x80C704u: goto L_80C704;
    case 0x80C707u: goto L_80C707;
    case 0x80C709u: goto L_80C709;
    case 0x80C70Cu: goto L_80C70C;
    case 0x80C70Eu: goto L_80C70E;
    case 0x80C711u: goto L_80C711;
    case 0x80C714u: goto L_80C714;
    case 0x80C716u: goto L_80C716;
    case 0x80C719u: goto L_80C719;
    case 0x80C71Cu: goto L_80C71C;
    case 0x80C71Eu: goto L_80C71E;
    case 0x80C721u: goto L_80C721;
    case 0x80C722u: goto L_80C722;
    case 0x80C723u: goto L_80C723;
    case 0x80C726u: goto L_80C726;
    case 0x80C728u: goto L_80C728;
    case 0x80C729u: goto L_80C729;
    case 0x80C72Cu: goto L_80C72C;
    case 0x80C72Du: goto L_80C72D;
    case 0x80C72Eu: goto L_80C72E;
    case 0x80C731u: goto L_80C731;
    case 0x80C734u: goto L_80C734;
    case 0x80C735u: goto L_80C735;
    case 0x80C736u: goto L_80C736;
    case 0x80C738u: goto L_80C738;
    case 0x80C73Au: goto L_80C73A;
    case 0x80C73Bu: goto L_80C73B;
    case 0x80C73Du: goto L_80C73D;
    case 0x80C73Eu: goto L_80C73E;
    case 0x80C741u: goto L_80C741;
    case 0x80C743u: goto L_80C743;
    case 0x80C744u: goto L_80C744;
    case 0x80C745u: goto L_80C745;
    case 0x80C748u: goto L_80C748;
    case 0x80C74Au: goto L_80C74A;
    case 0x80C74Du: goto L_80C74D;
    case 0x80C750u: goto L_80C750;
    case 0x80C751u: goto L_80C751;
    case 0x80C752u: goto L_80C752;
    case 0x80C754u: goto L_80C754;
    case 0x80C756u: goto L_80C756;
    case 0x80C757u: goto L_80C757;
    case 0x80C759u: goto L_80C759;
    case 0x80C75Au: goto L_80C75A;
    case 0x80C75Du: goto L_80C75D;
    case 0x80C75Fu: goto L_80C75F;
    case 0x80C760u: goto L_80C760;
    case 0x80C761u: goto L_80C761;
    case 0x80C764u: goto L_80C764;
    case 0x80C766u: goto L_80C766;
    case 0x80C767u: goto L_80C767;
    case 0x80C768u: goto L_80C768;
    case 0x80C76Bu: goto L_80C76B;
    case 0x80C76Eu: goto L_80C76E;
    case 0x80C76Fu: goto L_80C76F;
    case 0x80C770u: goto L_80C770;
    case 0x80C773u: goto L_80C773;
    case 0x80C775u: goto L_80C775;
    case 0x80C776u: goto L_80C776;
    case 0x80C779u: goto L_80C779;
    case 0x80C77Au: goto L_80C77A;
    case 0x80C77Bu: goto L_80C77B;
    case 0x80C77Eu: goto L_80C77E;
    case 0x80C781u: goto L_80C781;
    case 0x80C783u: goto L_80C783;
    case 0x80C784u: goto L_80C784;
    case 0x80C785u: goto L_80C785;
    case 0x80C786u: goto L_80C786;
    case 0x80C788u: goto L_80C788;
    case 0x80C78Au: goto L_80C78A;
    case 0x80C78Bu: goto L_80C78B;
    case 0x80C78Cu: goto L_80C78C;
    case 0x80C78Eu: goto L_80C78E;
    case 0x80C790u: goto L_80C790;
    case 0x80C793u: goto L_80C793;
    case 0x80C795u: goto L_80C795;
    case 0x80C797u: goto L_80C797;
    case 0x80C798u: goto L_80C798;
    case 0x80C79Bu: goto L_80C79B;
    case 0x80C79Du: goto L_80C79D;
    case 0x80C7A0u: goto L_80C7A0;
    case 0x80C7A3u: goto L_80C7A3;
    case 0x80C7A5u: goto L_80C7A5;
    case 0x80C7A6u: goto L_80C7A6;
    case 0x80C7A7u: goto L_80C7A7;
    case 0x80C7A8u: goto L_80C7A8;
    case 0x80C7AAu: goto L_80C7AA;
    case 0x80C7ACu: goto L_80C7AC;
    case 0x80C7ADu: goto L_80C7AD;
    case 0x80C7AEu: goto L_80C7AE;
    case 0x80C7B0u: goto L_80C7B0;
    case 0x80C7B2u: goto L_80C7B2;
    case 0x80C7B5u: goto L_80C7B5;
    case 0x80C7B7u: goto L_80C7B7;
    case 0x80C7B9u: goto L_80C7B9;
    case 0x80C7BAu: goto L_80C7BA;
    case 0x80C7BDu: goto L_80C7BD;
    case 0x80C7BFu: goto L_80C7BF;
    case 0x80C7C0u: goto L_80C7C0;
    case 0x80C7C1u: goto L_80C7C1;
    case 0x80C7C4u: goto L_80C7C4;
    case 0x80C7C6u: goto L_80C7C6;
    case 0x80C7C9u: goto L_80C7C9;
    case 0x80C7CCu: goto L_80C7CC;
    case 0x80C7CEu: goto L_80C7CE;
    case 0x80C7D1u: goto L_80C7D1;
    case 0x80C7D2u: goto L_80C7D2;
    case 0x80C7D3u: goto L_80C7D3;
    case 0x80C7D6u: goto L_80C7D6;
    case 0x80C7D8u: goto L_80C7D8;
    case 0x80C7D9u: goto L_80C7D9;
    case 0x80C7DCu: goto L_80C7DC;
    case 0x80C7DDu: goto L_80C7DD;
    case 0x80C7DEu: goto L_80C7DE;
    case 0x80C7E1u: goto L_80C7E1;
    case 0x80C7E4u: goto L_80C7E4;
    case 0x80C7E5u: goto L_80C7E5;
    case 0x80C7E6u: goto L_80C7E6;
    case 0x80C7E8u: goto L_80C7E8;
    case 0x80C7EAu: goto L_80C7EA;
    case 0x80C7EBu: goto L_80C7EB;
    case 0x80C7EDu: goto L_80C7ED;
    case 0x80C7EEu: goto L_80C7EE;
    case 0x80C7F1u: goto L_80C7F1;
    case 0x80C7F3u: goto L_80C7F3;
    case 0x80C7F4u: goto L_80C7F4;
    case 0x80C7F5u: goto L_80C7F5;
    case 0x80C7F6u: goto L_80C7F6;
    case 0x80C7F7u: goto L_80C7F7;
    case 0x80C7FAu: goto L_80C7FA;
    case 0x80C7FCu: goto L_80C7FC;
    case 0x80C7FFu: goto L_80C7FF;
    case 0x80C802u: goto L_80C802;
    case 0x80C803u: goto L_80C803;
    case 0x80C804u: goto L_80C804;
    case 0x80C806u: goto L_80C806;
    case 0x80C808u: goto L_80C808;
    case 0x80C809u: goto L_80C809;
    case 0x80C80Bu: goto L_80C80B;
    case 0x80C80Cu: goto L_80C80C;
    case 0x80C80Fu: goto L_80C80F;
    case 0x80C811u: goto L_80C811;
    case 0x80C812u: goto L_80C812;
    case 0x80C813u: goto L_80C813;
    case 0x80C814u: goto L_80C814;
    case 0x80C815u: goto L_80C815;
    case 0x80C818u: goto L_80C818;
    case 0x80C81Au: goto L_80C81A;
    case 0x80C81Bu: goto L_80C81B;
    case 0x80C81Cu: goto L_80C81C;
    case 0x80C81Fu: goto L_80C81F;
    case 0x80C822u: goto L_80C822;
    case 0x80C823u: goto L_80C823;
    case 0x80C824u: goto L_80C824;
    case 0x80C827u: goto L_80C827;
    case 0x80C829u: goto L_80C829;
    case 0x80C82Au: goto L_80C82A;
    case 0x80C82Du: goto L_80C82D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FEu, 5u, 3u, cpu.address("abs", 0x0560u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C6FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x560u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C701;
L_80C701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC701u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C701 AND
    cpu.logicAnd(0xFFu);
    goto L_80C704;
L_80C704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C704 CMP
    cpu.compareA(0x3Fu);
    goto L_80C707;
L_80C707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C707 BCC -> $80C711
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C711; }
    goto L_80C709;
L_80C709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C709 CMP
    cpu.compareA(0xC0u);
    goto L_80C70C;
L_80C70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C70C BCS -> $80C711
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C711; }
    goto L_80C70E;
L_80C70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu, 3u, 3u, cpu.address("abs", 0xC7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C70E JMP -> $80C7C1
    goto L_80C7C1;
L_80C711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC711u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC711u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C711 CMP
    cpu.compareA(0x80u);
    goto L_80C714;
L_80C714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC714u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC714u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C714 BCC -> $80C719
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C719; }
    goto L_80C716;
L_80C716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C716 EOR
    cpu.logicXor(0xFFFFu);
    goto L_80C719;
L_80C719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C719 BIT
    cpu.bit(0x20u, true);
    goto L_80C71C;
L_80C71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C71C BNE -> $80C768
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C768; }
    goto L_80C71E;
L_80C71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C71E AND
    cpu.logicAnd(0x1Fu);
    goto L_80C721;
L_80C721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C721 ASL
    cpu.aslA();
    goto L_80C722;
L_80C722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC722u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C722 TAY
    cpu.transfer("TAY");
    goto L_80C723;
L_80C723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C723 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C726;
L_80C726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C726 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C728;
L_80C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C728 PHB
    cpu.push("PHB", hw);
    goto L_80C729;
L_80C729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC729u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC729u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C729 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C72C;
L_80C72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C72C PLB
    cpu.pop("PLB", hw);
    goto L_80C72D;
L_80C72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C72D PLB
    cpu.pop("PLB", hw);
    goto L_80C72E;
L_80C72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C72E LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C731;
L_80C731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C731 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C734;
L_80C734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C734 TDC
    cpu.tdc();
    goto L_80C735;
L_80C735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C735 CLC
    cpu.setFlag('C', false);
    goto L_80C736;
L_80C736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C736 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C738;
L_80C738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC738u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C738 BCC -> $80C73B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C73B; }
    goto L_80C73A;
L_80C73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73A DEY
    cpu.decReg('Y');
    goto L_80C73B;
L_80C73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C73D;
L_80C73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73D TYA
    cpu.transfer("TYA");
    goto L_80C73E;
L_80C73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73E STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C741;
L_80C741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C741 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C743;
L_80C743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC743u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC743u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C743 DEX
    cpu.decReg('X');
    goto L_80C744;
L_80C744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C744 DEX
    cpu.decReg('X');
    goto L_80C745;
L_80C745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C745 CPX
    cpu.compareX(0xB800u);
    goto L_80C748;
L_80C748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC748u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C748 BCS -> $80C735
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C735; }
    goto L_80C74A;
L_80C74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C74A LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C74D;
L_80C74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C74D LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C750;
L_80C750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C750 TDC
    cpu.tdc();
    goto L_80C751;
L_80C751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC751u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC751u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C751 CLC
    cpu.setFlag('C', false);
    goto L_80C752;
L_80C752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C752 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C754;
L_80C754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C754 BCC -> $80C757
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C757; }
    goto L_80C756;
L_80C756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C756 INY
    cpu.inc('Y');
    goto L_80C757;
L_80C757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC757u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC757u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C757 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C759;
L_80C759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C759 TYA
    cpu.transfer("TYA");
    goto L_80C75A;
L_80C75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75A STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C75D;
L_80C75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C75F;
L_80C75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75F INX
    cpu.inc('X');
    goto L_80C760;
L_80C760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C760 INX
    cpu.inc('X');
    goto L_80C761;
L_80C761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC761u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC761u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C761 CPX
    cpu.compareX(0xB9C0u);
    goto L_80C764;
L_80C764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C764 BCC -> $80C751
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C751; }
    goto L_80C766;
L_80C766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC766u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC766u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C766 PLB
    cpu.pop("PLB", hw);
    goto L_80C767;
L_80C767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C767 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C767u);return;} hw.unresolvedReturn(0x80C767u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C768 AND
    cpu.logicAnd(0x1Fu);
    goto L_80C76B;
L_80C76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76B EOR
    cpu.logicXor(0x1Fu);
    goto L_80C76E;
L_80C76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76E ASL
    cpu.aslA();
    goto L_80C76F;
L_80C76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76F TAY
    cpu.transfer("TAY");
    goto L_80C770;
L_80C770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC770u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC770u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C770 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C773;
L_80C773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C773 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C775;
L_80C775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC775u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC775u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C775 PHB
    cpu.push("PHB", hw);
    goto L_80C776;
L_80C776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C776 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C779;
L_80C779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C779 PLB
    cpu.pop("PLB", hw);
    goto L_80C77A;
L_80C77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C77A PLB
    cpu.pop("PLB", hw);
    goto L_80C77B;
L_80C77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C77B LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C77E;
L_80C77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C77E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C781;
L_80C781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C781 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C783;
L_80C783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C783 TDC
    cpu.tdc();
    goto L_80C784;
L_80C784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C784 TAY
    cpu.transfer("TAY");
    goto L_80C785;
L_80C785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC785u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C785 CLC
    cpu.setFlag('C', false);
    goto L_80C786;
L_80C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C786 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C788;
L_80C788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C788 BCC -> $80C78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C78C; }
    goto L_80C78A;
L_80C78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78A DEX
    cpu.decReg('X');
    goto L_80C78B;
L_80C78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78B DEX
    cpu.decReg('X');
    goto L_80C78C;
L_80C78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C78E;
L_80C78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C790;
L_80C790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C790 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C793;
L_80C793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C793 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C795;
L_80C795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C795 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C797;
L_80C797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC797u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C797 INY
    cpu.inc('Y');
    goto L_80C798;
L_80C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C798 CPY
    cpu.compareY(0x70u);
    goto L_80C79B;
L_80C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C79B BCC -> $80C785
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C785; }
    goto L_80C79D;
L_80C79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C79D LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7A0;
L_80C7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A0u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7A3;
L_80C7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A3 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C7A5;
L_80C7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A5u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A5 TDC
    cpu.tdc();
    goto L_80C7A6;
L_80C7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A6 TAY
    cpu.transfer("TAY");
    goto L_80C7A7;
L_80C7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A7 CLC
    cpu.setFlag('C', false);
    goto L_80C7A8;
L_80C7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C7AA;
L_80C7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AA BCC -> $80C7AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7AE; }
    goto L_80C7AC;
L_80C7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AC INX
    cpu.inc('X');
    goto L_80C7AD;
L_80C7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AD INX
    cpu.inc('X');
    goto L_80C7AE;
L_80C7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AE STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C7B0;
L_80C7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7B2;
L_80C7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B2 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C7B5;
L_80C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7B7;
L_80C7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B7 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C7B9;
L_80C7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B9 INY
    cpu.inc('Y');
    goto L_80C7BA;
L_80C7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7BA CPY
    cpu.compareY(0x70u);
    goto L_80C7BD;
L_80C7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7BD BCC -> $80C7A7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7A7; }
    goto L_80C7BF;
L_80C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7BF PLB
    cpu.pop("PLB", hw);
    goto L_80C7C0;
L_80C7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C7C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C7C0u);return;} hw.unresolvedReturn(0x80C7C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C1 CMP
    cpu.compareA(0x80u);
    goto L_80C7C4;
L_80C7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C4 BCS -> $80C7C9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7C9; }
    goto L_80C7C6;
L_80C7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C6 EOR
    cpu.logicXor(0xFFFFu);
    goto L_80C7C9;
L_80C7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C9 BIT
    cpu.bit(0x20u, true);
    goto L_80C7CC;
L_80C7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7CC BNE -> $80C81C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C81C; }
    goto L_80C7CE;
L_80C7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7CE AND
    cpu.logicAnd(0x1Fu);
    goto L_80C7D1;
L_80C7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D1 ASL
    cpu.aslA();
    goto L_80C7D2;
L_80C7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D2 TAY
    cpu.transfer("TAY");
    goto L_80C7D3;
L_80C7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7D6;
L_80C7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C7D8;
L_80C7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7D8 PHB
    cpu.push("PHB", hw);
    goto L_80C7D9;
L_80C7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C7D9 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C7DC;
L_80C7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7DC PLB
    cpu.pop("PLB", hw);
    goto L_80C7DD;
L_80C7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7DD PLB
    cpu.pop("PLB", hw);
    goto L_80C7DE;
L_80C7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7DE LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7E1;
L_80C7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E1u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E1u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E1 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C7E4;
L_80C7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E4 TDC
    cpu.tdc();
    goto L_80C7E5;
L_80C7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E5 CLC
    cpu.setFlag('C', false);
    goto L_80C7E6;
L_80C7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C7E8;
L_80C7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E8 BCC -> $80C7EB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7EB; }
    goto L_80C7EA;
L_80C7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EA INY
    cpu.inc('Y');
    goto L_80C7EB;
L_80C7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EB STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C7ED;
L_80C7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7ED TYA
    cpu.transfer("TYA");
    goto L_80C7EE;
L_80C7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EEu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EE STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C7F1;
L_80C7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7F3;
L_80C7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F3 INY
    cpu.inc('Y');
    goto L_80C7F4;
L_80C7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F4 INY
    cpu.inc('Y');
    goto L_80C7F5;
L_80C7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F5 DEX
    cpu.decReg('X');
    goto L_80C7F6;
L_80C7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F6 DEX
    cpu.decReg('X');
    goto L_80C7F7;
L_80C7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F7u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F7 CPX
    cpu.compareX(0xB800u);
    goto L_80C7FA;
L_80C7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FA BCS -> $80C7E5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7E5; }
    goto L_80C7FC;
L_80C7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FC LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7FF;
L_80C7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FFu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FFu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FF LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C802;
L_80C802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC802u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC802u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C802 TDC
    cpu.tdc();
    goto L_80C803;
L_80C803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C803 CLC
    cpu.setFlag('C', false);
    goto L_80C804;
L_80C804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC804u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C804 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C806;
L_80C806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C806 BCC -> $80C809
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C809; }
    goto L_80C808;
L_80C808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC808u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C808 DEY
    cpu.decReg('Y');
    goto L_80C809;
L_80C809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C809 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C80B;
L_80C80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80B TYA
    cpu.transfer("TYA");
    goto L_80C80C;
L_80C80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80C STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C80F;
L_80C80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C811;
L_80C811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C811 DEY
    cpu.decReg('Y');
    goto L_80C812;
L_80C812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC812u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C812 DEY
    cpu.decReg('Y');
    goto L_80C813;
L_80C813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C813 INX
    cpu.inc('X');
    goto L_80C814;
L_80C814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC814u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC814u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C814 INX
    cpu.inc('X');
    goto L_80C815;
L_80C815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC815u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC815u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C815 CPX
    cpu.compareX(0xB9C0u);
    goto L_80C818;
L_80C818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C818 BCC -> $80C803
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C803; }
    goto L_80C81A;
L_80C81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C81A PLB
    cpu.pop("PLB", hw);
    goto L_80C81B;
L_80C81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C81B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C81Bu);return;} hw.unresolvedReturn(0x80C81Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C81C AND
    cpu.logicAnd(0x1Fu);
    goto L_80C81F;
L_80C81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C81F EOR
    cpu.logicXor(0x1Fu);
    goto L_80C822;
L_80C822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC822u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C822 ASL
    cpu.aslA();
    goto L_80C823;
L_80C823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C823 TAY
    cpu.transfer("TAY");
    goto L_80C824;
L_80C824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC824u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC824u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C824 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C827;
L_80C827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C827 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C829;
L_80C829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C829 PHB
    cpu.push("PHB", hw);
    goto L_80C82A;
L_80C82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C82A PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C82D;
L_80C82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C82D PLB
    cpu.pop("PLB", hw);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC82Eu,0x80C82Du); return;
}

void sub_80C6FE_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C6FEu: goto L_80C6FE;
    case 0x80C701u: goto L_80C701;
    case 0x80C704u: goto L_80C704;
    case 0x80C707u: goto L_80C707;
    case 0x80C709u: goto L_80C709;
    case 0x80C70Cu: goto L_80C70C;
    case 0x80C70Eu: goto L_80C70E;
    case 0x80C711u: goto L_80C711;
    case 0x80C714u: goto L_80C714;
    case 0x80C716u: goto L_80C716;
    case 0x80C719u: goto L_80C719;
    case 0x80C71Cu: goto L_80C71C;
    case 0x80C71Eu: goto L_80C71E;
    case 0x80C721u: goto L_80C721;
    case 0x80C722u: goto L_80C722;
    case 0x80C723u: goto L_80C723;
    case 0x80C726u: goto L_80C726;
    case 0x80C728u: goto L_80C728;
    case 0x80C729u: goto L_80C729;
    case 0x80C72Cu: goto L_80C72C;
    case 0x80C72Du: goto L_80C72D;
    case 0x80C72Eu: goto L_80C72E;
    case 0x80C731u: goto L_80C731;
    case 0x80C734u: goto L_80C734;
    case 0x80C735u: goto L_80C735;
    case 0x80C736u: goto L_80C736;
    case 0x80C738u: goto L_80C738;
    case 0x80C73Au: goto L_80C73A;
    case 0x80C73Bu: goto L_80C73B;
    case 0x80C73Du: goto L_80C73D;
    case 0x80C73Eu: goto L_80C73E;
    case 0x80C741u: goto L_80C741;
    case 0x80C743u: goto L_80C743;
    case 0x80C744u: goto L_80C744;
    case 0x80C745u: goto L_80C745;
    case 0x80C748u: goto L_80C748;
    case 0x80C74Au: goto L_80C74A;
    case 0x80C74Du: goto L_80C74D;
    case 0x80C750u: goto L_80C750;
    case 0x80C751u: goto L_80C751;
    case 0x80C752u: goto L_80C752;
    case 0x80C754u: goto L_80C754;
    case 0x80C756u: goto L_80C756;
    case 0x80C757u: goto L_80C757;
    case 0x80C759u: goto L_80C759;
    case 0x80C75Au: goto L_80C75A;
    case 0x80C75Du: goto L_80C75D;
    case 0x80C75Fu: goto L_80C75F;
    case 0x80C760u: goto L_80C760;
    case 0x80C761u: goto L_80C761;
    case 0x80C764u: goto L_80C764;
    case 0x80C766u: goto L_80C766;
    case 0x80C767u: goto L_80C767;
    case 0x80C768u: goto L_80C768;
    case 0x80C76Bu: goto L_80C76B;
    case 0x80C76Eu: goto L_80C76E;
    case 0x80C76Fu: goto L_80C76F;
    case 0x80C770u: goto L_80C770;
    case 0x80C773u: goto L_80C773;
    case 0x80C775u: goto L_80C775;
    case 0x80C776u: goto L_80C776;
    case 0x80C779u: goto L_80C779;
    case 0x80C77Au: goto L_80C77A;
    case 0x80C77Bu: goto L_80C77B;
    case 0x80C77Eu: goto L_80C77E;
    case 0x80C781u: goto L_80C781;
    case 0x80C783u: goto L_80C783;
    case 0x80C784u: goto L_80C784;
    case 0x80C785u: goto L_80C785;
    case 0x80C786u: goto L_80C786;
    case 0x80C788u: goto L_80C788;
    case 0x80C78Au: goto L_80C78A;
    case 0x80C78Bu: goto L_80C78B;
    case 0x80C78Cu: goto L_80C78C;
    case 0x80C78Eu: goto L_80C78E;
    case 0x80C790u: goto L_80C790;
    case 0x80C793u: goto L_80C793;
    case 0x80C795u: goto L_80C795;
    case 0x80C797u: goto L_80C797;
    case 0x80C798u: goto L_80C798;
    case 0x80C79Bu: goto L_80C79B;
    case 0x80C79Du: goto L_80C79D;
    case 0x80C7A0u: goto L_80C7A0;
    case 0x80C7A3u: goto L_80C7A3;
    case 0x80C7A5u: goto L_80C7A5;
    case 0x80C7A6u: goto L_80C7A6;
    case 0x80C7A7u: goto L_80C7A7;
    case 0x80C7A8u: goto L_80C7A8;
    case 0x80C7AAu: goto L_80C7AA;
    case 0x80C7ACu: goto L_80C7AC;
    case 0x80C7ADu: goto L_80C7AD;
    case 0x80C7AEu: goto L_80C7AE;
    case 0x80C7B0u: goto L_80C7B0;
    case 0x80C7B2u: goto L_80C7B2;
    case 0x80C7B5u: goto L_80C7B5;
    case 0x80C7B7u: goto L_80C7B7;
    case 0x80C7B9u: goto L_80C7B9;
    case 0x80C7BAu: goto L_80C7BA;
    case 0x80C7BDu: goto L_80C7BD;
    case 0x80C7BFu: goto L_80C7BF;
    case 0x80C7C0u: goto L_80C7C0;
    case 0x80C7C1u: goto L_80C7C1;
    case 0x80C7C4u: goto L_80C7C4;
    case 0x80C7C6u: goto L_80C7C6;
    case 0x80C7C9u: goto L_80C7C9;
    case 0x80C7CCu: goto L_80C7CC;
    case 0x80C7CEu: goto L_80C7CE;
    case 0x80C7D1u: goto L_80C7D1;
    case 0x80C7D2u: goto L_80C7D2;
    case 0x80C7D3u: goto L_80C7D3;
    case 0x80C7D6u: goto L_80C7D6;
    case 0x80C7D8u: goto L_80C7D8;
    case 0x80C7D9u: goto L_80C7D9;
    case 0x80C7DCu: goto L_80C7DC;
    case 0x80C7DDu: goto L_80C7DD;
    case 0x80C7DEu: goto L_80C7DE;
    case 0x80C7E1u: goto L_80C7E1;
    case 0x80C7E4u: goto L_80C7E4;
    case 0x80C7E5u: goto L_80C7E5;
    case 0x80C7E6u: goto L_80C7E6;
    case 0x80C7E8u: goto L_80C7E8;
    case 0x80C7EAu: goto L_80C7EA;
    case 0x80C7EBu: goto L_80C7EB;
    case 0x80C7EDu: goto L_80C7ED;
    case 0x80C7EEu: goto L_80C7EE;
    case 0x80C7F1u: goto L_80C7F1;
    case 0x80C7F3u: goto L_80C7F3;
    case 0x80C7F4u: goto L_80C7F4;
    case 0x80C7F5u: goto L_80C7F5;
    case 0x80C7F6u: goto L_80C7F6;
    case 0x80C7F7u: goto L_80C7F7;
    case 0x80C7FAu: goto L_80C7FA;
    case 0x80C7FCu: goto L_80C7FC;
    case 0x80C7FFu: goto L_80C7FF;
    case 0x80C802u: goto L_80C802;
    case 0x80C803u: goto L_80C803;
    case 0x80C804u: goto L_80C804;
    case 0x80C806u: goto L_80C806;
    case 0x80C808u: goto L_80C808;
    case 0x80C809u: goto L_80C809;
    case 0x80C80Bu: goto L_80C80B;
    case 0x80C80Cu: goto L_80C80C;
    case 0x80C80Fu: goto L_80C80F;
    case 0x80C811u: goto L_80C811;
    case 0x80C812u: goto L_80C812;
    case 0x80C813u: goto L_80C813;
    case 0x80C814u: goto L_80C814;
    case 0x80C815u: goto L_80C815;
    case 0x80C818u: goto L_80C818;
    case 0x80C81Au: goto L_80C81A;
    case 0x80C81Bu: goto L_80C81B;
    case 0x80C81Cu: goto L_80C81C;
    case 0x80C81Fu: goto L_80C81F;
    case 0x80C822u: goto L_80C822;
    case 0x80C823u: goto L_80C823;
    case 0x80C824u: goto L_80C824;
    case 0x80C827u: goto L_80C827;
    case 0x80C829u: goto L_80C829;
    case 0x80C82Au: goto L_80C82A;
    case 0x80C82Du: goto L_80C82D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FEu, 5u, 3u, cpu.address("abs", 0x0560u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C6FE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x560u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C701;
L_80C701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC701u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC701u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C701 AND
    cpu.logicAnd(0xFFu);
    goto L_80C704;
L_80C704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C704 CMP
    cpu.compareA(0x3Fu);
    goto L_80C707;
L_80C707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C707 BCC -> $80C711
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C711; }
    goto L_80C709;
L_80C709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C709 CMP
    cpu.compareA(0xC0u);
    goto L_80C70C;
L_80C70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C70C BCS -> $80C711
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C711; }
    goto L_80C70E;
L_80C70E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Eu, 3u, 3u, cpu.address("abs", 0xC7C1u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C70E JMP -> $80C7C1
    goto L_80C7C1;
L_80C711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC711u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC711u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C711 CMP
    cpu.compareA(0x80u);
    goto L_80C714;
L_80C714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC714u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC714u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C714 BCC -> $80C719
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C719; }
    goto L_80C716;
L_80C716:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC716u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC716u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C716 EOR
    cpu.logicXor(0xFFFFu);
    goto L_80C719;
L_80C719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC719u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C719 BIT
    cpu.bit(0x20u, true);
    goto L_80C71C;
L_80C71C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C71C BNE -> $80C768
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C768; }
    goto L_80C71E;
L_80C71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C71E AND
    cpu.logicAnd(0x1Fu);
    goto L_80C721;
L_80C721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C721 ASL
    cpu.aslA();
    goto L_80C722;
L_80C722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC722u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC722u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C722 TAY
    cpu.transfer("TAY");
    goto L_80C723;
L_80C723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C723 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C726;
L_80C726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C726 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C728;
L_80C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C728 PHB
    cpu.push("PHB", hw);
    goto L_80C729;
L_80C729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC729u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC729u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C729 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C72C;
L_80C72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C72C PLB
    cpu.pop("PLB", hw);
    goto L_80C72D;
L_80C72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C72D PLB
    cpu.pop("PLB", hw);
    goto L_80C72E;
L_80C72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C72E LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C731;
L_80C731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C731 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C734;
L_80C734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C734 TDC
    cpu.tdc();
    goto L_80C735;
L_80C735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC735u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C735 CLC
    cpu.setFlag('C', false);
    goto L_80C736;
L_80C736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C736 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C738;
L_80C738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC738u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC738u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C738 BCC -> $80C73B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C73B; }
    goto L_80C73A;
L_80C73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73A DEY
    cpu.decReg('Y');
    goto L_80C73B;
L_80C73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C73D;
L_80C73D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73D TYA
    cpu.transfer("TYA");
    goto L_80C73E;
L_80C73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C73E STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C741;
L_80C741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C741 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C743;
L_80C743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC743u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC743u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C743 DEX
    cpu.decReg('X');
    goto L_80C744;
L_80C744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C744 DEX
    cpu.decReg('X');
    goto L_80C745;
L_80C745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC745u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C745 CPX
    cpu.compareX(0xB800u);
    goto L_80C748;
L_80C748:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC748u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC748u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC748u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C748 BCS -> $80C735
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C735; }
    goto L_80C74A;
L_80C74A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C74A LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C74D;
L_80C74D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Du, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C74D LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C750;
L_80C750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C750 TDC
    cpu.tdc();
    goto L_80C751;
L_80C751:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC751u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC751u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC751u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C751 CLC
    cpu.setFlag('C', false);
    goto L_80C752;
L_80C752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C752 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C754;
L_80C754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C754 BCC -> $80C757
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C757; }
    goto L_80C756;
L_80C756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C756 INY
    cpu.inc('Y');
    goto L_80C757;
L_80C757:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC757u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC757u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC757u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C757 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C759;
L_80C759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C759 TYA
    cpu.transfer("TYA");
    goto L_80C75A;
L_80C75A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Au, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75A STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C75D;
L_80C75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C75F;
L_80C75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C75F INX
    cpu.inc('X');
    goto L_80C760;
L_80C760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C760 INX
    cpu.inc('X');
    goto L_80C761;
L_80C761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC761u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC761u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C761 CPX
    cpu.compareX(0xB9C0u);
    goto L_80C764;
L_80C764:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC764u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC764u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C764 BCC -> $80C751
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C751; }
    goto L_80C766;
L_80C766:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC766u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC766u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC766u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C766 PLB
    cpu.pop("PLB", hw);
    goto L_80C767;
L_80C767:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC767u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC767u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C767 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C767u);return;} hw.unresolvedReturn(0x80C767u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C768 AND
    cpu.logicAnd(0x1Fu);
    goto L_80C76B;
L_80C76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76B EOR
    cpu.logicXor(0x1Fu);
    goto L_80C76E;
L_80C76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76E ASL
    cpu.aslA();
    goto L_80C76F;
L_80C76F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C76F TAY
    cpu.transfer("TAY");
    goto L_80C770;
L_80C770:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC770u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC770u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC770u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C770 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C773;
L_80C773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C773 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C775;
L_80C775:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC775u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC775u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC775u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C775 PHB
    cpu.push("PHB", hw);
    goto L_80C776;
L_80C776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C776 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C779;
L_80C779:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC779u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC779u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C779 PLB
    cpu.pop("PLB", hw);
    goto L_80C77A;
L_80C77A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C77A PLB
    cpu.pop("PLB", hw);
    goto L_80C77B;
L_80C77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C77B LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C77E;
L_80C77E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Eu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C77E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C781;
L_80C781:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC781u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC781u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C781 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C783;
L_80C783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C783 TDC
    cpu.tdc();
    goto L_80C784;
L_80C784:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC784u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC784u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C784 TAY
    cpu.transfer("TAY");
    goto L_80C785;
L_80C785:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC785u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC785u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC785u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C785 CLC
    cpu.setFlag('C', false);
    goto L_80C786;
L_80C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C786 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C788;
L_80C788:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC788u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC788u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C788 BCC -> $80C78C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C78C; }
    goto L_80C78A;
L_80C78A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Au,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78A DEX
    cpu.decReg('X');
    goto L_80C78B;
L_80C78B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78B DEX
    cpu.decReg('X');
    goto L_80C78C;
L_80C78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C78E;
L_80C78E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C78E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C790;
L_80C790:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC790u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC790u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C790 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C793;
L_80C793:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC793u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC793u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C793 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C795;
L_80C795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C795 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C797;
L_80C797:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC797u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC797u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC797u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C797 INY
    cpu.inc('Y');
    goto L_80C798;
L_80C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C798 CPY
    cpu.compareY(0x70u);
    goto L_80C79B;
L_80C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C79B BCC -> $80C785
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C785; }
    goto L_80C79D;
L_80C79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C79D LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7A0;
L_80C7A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A0u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7A3;
L_80C7A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A3 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80C7A5;
L_80C7A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A5u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A5 TDC
    cpu.tdc();
    goto L_80C7A6;
L_80C7A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A6 TAY
    cpu.transfer("TAY");
    goto L_80C7A7;
L_80C7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A7 CLC
    cpu.setFlag('C', false);
    goto L_80C7A8;
L_80C7A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7A8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C7AA;
L_80C7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AA BCC -> $80C7AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7AE; }
    goto L_80C7AC;
L_80C7AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AC INX
    cpu.inc('X');
    goto L_80C7AD;
L_80C7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AD INX
    cpu.inc('X');
    goto L_80C7AE;
L_80C7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7AE STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C7B0;
L_80C7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7B2;
L_80C7B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B2u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B2 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C7B5;
L_80C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7B7;
L_80C7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B7 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C7B9;
L_80C7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7B9 INY
    cpu.inc('Y');
    goto L_80C7BA;
L_80C7BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7BA CPY
    cpu.compareY(0x70u);
    goto L_80C7BD;
L_80C7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7BD BCC -> $80C7A7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7A7; }
    goto L_80C7BF;
L_80C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7BF PLB
    cpu.pop("PLB", hw);
    goto L_80C7C0;
L_80C7C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C7C0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C7C0u);return;} hw.unresolvedReturn(0x80C7C0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C1 CMP
    cpu.compareA(0x80u);
    goto L_80C7C4;
L_80C7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C4 BCS -> $80C7C9
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7C9; }
    goto L_80C7C6;
L_80C7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C6 EOR
    cpu.logicXor(0xFFFFu);
    goto L_80C7C9;
L_80C7C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C9u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7C9 BIT
    cpu.bit(0x20u, true);
    goto L_80C7CC;
L_80C7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7CC BNE -> $80C81C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C81C; }
    goto L_80C7CE;
L_80C7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7CE AND
    cpu.logicAnd(0x1Fu);
    goto L_80C7D1;
L_80C7D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D1 ASL
    cpu.aslA();
    goto L_80C7D2;
L_80C7D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D2 TAY
    cpu.transfer("TAY");
    goto L_80C7D3;
L_80C7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7D6;
L_80C7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7D6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C7D8;
L_80C7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7D8 PHB
    cpu.push("PHB", hw);
    goto L_80C7D9;
L_80C7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C7D9 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C7DC;
L_80C7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7DC PLB
    cpu.pop("PLB", hw);
    goto L_80C7DD;
L_80C7DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DDu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DDu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C7DD PLB
    cpu.pop("PLB", hw);
    goto L_80C7DE;
L_80C7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7DE LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7E1;
L_80C7E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E1u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E1u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E1 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C7E4;
L_80C7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E4 TDC
    cpu.tdc();
    goto L_80C7E5;
L_80C7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E5u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E5 CLC
    cpu.setFlag('C', false);
    goto L_80C7E6;
L_80C7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C7E8;
L_80C7E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7E8 BCC -> $80C7EB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7EB; }
    goto L_80C7EA;
L_80C7EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EAu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EA INY
    cpu.inc('Y');
    goto L_80C7EB;
L_80C7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EB STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C7ED;
L_80C7ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7ED TYA
    cpu.transfer("TYA");
    goto L_80C7EE;
L_80C7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7EEu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7EE STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C7F1;
L_80C7F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C7F3;
L_80C7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F3 INY
    cpu.inc('Y');
    goto L_80C7F4;
L_80C7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F4 INY
    cpu.inc('Y');
    goto L_80C7F5;
L_80C7F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F5 DEX
    cpu.decReg('X');
    goto L_80C7F6;
L_80C7F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F6 DEX
    cpu.decReg('X');
    goto L_80C7F7;
L_80C7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F7u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7F7 CPX
    cpu.compareX(0xB800u);
    goto L_80C7FA;
L_80C7FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FAu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FA BCS -> $80C7E5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C7E5; }
    goto L_80C7FC;
L_80C7FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FCu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FC LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C7FF;
L_80C7FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FFu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7FFu, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C7FF LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C802;
L_80C802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC802u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC802u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C802 TDC
    cpu.tdc();
    goto L_80C803;
L_80C803:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC803u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC803u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C803 CLC
    cpu.setFlag('C', false);
    goto L_80C804;
L_80C804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC804u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C804 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C806;
L_80C806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC806u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C806 BCC -> $80C809
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C809; }
    goto L_80C808;
L_80C808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC808u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC808u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C808 DEY
    cpu.decReg('Y');
    goto L_80C809;
L_80C809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC809u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C809 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C80B;
L_80C80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80B TYA
    cpu.transfer("TYA");
    goto L_80C80C;
L_80C80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Cu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80C STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C80F;
L_80C80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC80Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C80F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C811;
L_80C811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C811 DEY
    cpu.decReg('Y');
    goto L_80C812;
L_80C812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC812u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC812u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C812 DEY
    cpu.decReg('Y');
    goto L_80C813;
L_80C813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC813u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C813 INX
    cpu.inc('X');
    goto L_80C814;
L_80C814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC814u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC814u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C814 INX
    cpu.inc('X');
    goto L_80C815;
L_80C815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC815u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC815u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C815 CPX
    cpu.compareX(0xB9C0u);
    goto L_80C818;
L_80C818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC818u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C818 BCC -> $80C803
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C803; }
    goto L_80C81A;
L_80C81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C81A PLB
    cpu.pop("PLB", hw);
    goto L_80C81B;
L_80C81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C81B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C81Bu);return;} hw.unresolvedReturn(0x80C81Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80C81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C81C AND
    cpu.logicAnd(0x1Fu);
    goto L_80C81F;
L_80C81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC81Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C81F EOR
    cpu.logicXor(0x1Fu);
    goto L_80C822;
L_80C822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC822u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C822 ASL
    cpu.aslA();
    goto L_80C823;
L_80C823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC823u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C823 TAY
    cpu.transfer("TAY");
    goto L_80C824;
L_80C824:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC824u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC824u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC824u, 5u + 1u, 3u, cpu.address("absy", 0xA38Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C824 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA38Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C827;
L_80C827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC827u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C827 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80C829;
L_80C829:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC829u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC829u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C829 PHB
    cpu.push("PHB", hw);
    goto L_80C82A;
L_80C82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Au, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C82A PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80C82D;
L_80C82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C82D PLB
    cpu.pop("PLB", hw);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC82Eu,0x80C82Du); return;
}

void sub_829ED1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829ED1u: goto L_829ED1;
    case 0x829ED4u: goto L_829ED4;
    case 0x829ED7u: goto L_829ED7;
    case 0x829EDAu: goto L_829EDA;
    case 0x829EDBu: goto L_829EDB;
    case 0x829EDEu: goto L_829EDE;
    case 0x829EE2u: goto L_829EE2;
    case 0x829EE5u: goto L_829EE5;
    case 0x829EE6u: goto L_829EE6;
    case 0x829EE9u: goto L_829EE9;
    case 0x829EEBu: goto L_829EEB;
    case 0x829EEEu: goto L_829EEE;
    case 0x829EF0u: goto L_829EF0;
    case 0x829EF3u: goto L_829EF3;
    case 0x829EF6u: goto L_829EF6;
    case 0x829EFAu: goto L_829EFA;
    case 0x829EFDu: goto L_829EFD;
    case 0x829EFEu: goto L_829EFE;
    case 0x829F00u: goto L_829F00;
    case 0x829F03u: goto L_829F03;
    case 0x829F07u: goto L_829F07;
    case 0x829F08u: goto L_829F08;
    case 0x829F0Bu: goto L_829F0B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED1 LDX
    cpu.setX(0x568u, 16);
    goto L_829ED4;
L_829ED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED4u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829ED7;
L_829ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829ED7 EOR
    cpu.logicXor(0xFFFFu);
    goto L_829EDA;
L_829EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EDA INC
    cpu.inc('A');
    goto L_829EDB;
L_829EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EDB LDY
    cpu.setY(0x0u, 16);
    goto L_829EDE;
L_829EDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDEu, 8u, 4u, 0x80C8A8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829EDE JSL -> $80C8A8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EE1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EE2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C8A8u, 0x829EDEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829EE2;
L_829EE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EE2u,0x829EE2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE2 LDA
    cpu.setA(0x80u, 16);
    goto L_829EE5;
L_829EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE5 SEC
    cpu.setFlag('C', true);
    goto L_829EE6;
L_829EE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE6u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE6 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x1C02u), cpu.m8?8:16));
    goto L_829EE9;
L_829EE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EE9 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_829EEB;
L_829EEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EEB CMP
    cpu.compareA(0x80u);
    goto L_829EEE;
L_829EEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EEE BCC -> $829EF3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_829EF3; }
    goto L_829EF0;
L_829EF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EF0 LDA
    cpu.setA(0x80u, 16);
    goto L_829EF3;
L_829EF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EF3 LDY
    cpu.setY(0x13u, 16);
    goto L_829EF6;
L_829EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 8u, 4u, 0x80C8A8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829EF6 JSL -> $80C8A8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EF9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EFAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C8A8u, 0x829EF6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829EFA;
L_829EFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EFAu,0x829EFAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EFA LDA
    cpu.setA(0xE0u, 16);
    goto L_829EFD;
L_829EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EFD SEC
    cpu.setFlag('C', true);
    goto L_829EFE;
L_829EFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829EFE SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_829F00;
L_829F00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F00u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F00 LDY
    cpu.setY(0x14u, 16);
    goto L_829F03;
L_829F03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F03u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F03u, 8u, 4u, 0x80C8A8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F03 JSL -> $80C8A8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F06u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F07u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C8A8u, 0x829F03u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829F07;
L_829F07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F07u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F07u,0x829F07u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F07u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F07 TDC
    cpu.tdc();
    goto L_829F08;
L_829F08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F08u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F08u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829F08 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_829F0B;
L_829F0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829F0B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829F0Bu);return;} hw.unresolvedReturn(0x829F0Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82EFD8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82EFD8u: goto L_82EFD8;
    case 0x82EFDAu: goto L_82EFDA;
    case 0x82EFDCu: goto L_82EFDC;
    case 0x82EFDEu: goto L_82EFDE;
    case 0x82EFE0u: goto L_82EFE0;
    case 0x82EFE2u: goto L_82EFE2;
    case 0x82EFE4u: goto L_82EFE4;
    case 0x82EFE8u: goto L_82EFE8;
    case 0x82EFEAu: goto L_82EFEA;
    case 0x82EFEDu: goto L_82EFED;
    case 0x82EFF1u: goto L_82EFF1;
    case 0x82EFF3u: goto L_82EFF3;
    case 0x82EFF4u: goto L_82EFF4;
    case 0x82EFF7u: goto L_82EFF7;
    case 0x82EFF9u: goto L_82EFF9;
    case 0x82EFFBu: goto L_82EFFB;
    case 0x82EFFCu: goto L_82EFFC;
    case 0x82EFFFu: goto L_82EFFF;
    case 0x82F000u: goto L_82F000;
    case 0x82F004u: goto L_82F004;
    case 0x82F006u: goto L_82F006;
    case 0x82F009u: goto L_82F009;
    case 0x82F00Du: goto L_82F00D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82EFD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFD8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFD8 STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_82EFDA;
L_82EFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDAu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFDA STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_82EFDC;
L_82EFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFDC STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82EFDE;
L_82EFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFDEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFDE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82EFE0;
L_82EFE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFE0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82EFE2;
L_82EFE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFE2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82EFE4;
L_82EFE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE4u, 8u, 4u, 0x8098B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82EFE4 JSL -> $8098B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFE7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFE8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B4u, 0x82EFE4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82EFE8;
L_82EFE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFE8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFE8u,0x82EFE8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE8u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFE8 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82EFEA;
L_82EFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEAu, 6u, 3u, cpu.address("abs", 0xF00Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82EFEA JSR -> $82F00F stack real
    { cpu.push16Value(hw,0xEFECu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFEDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF00Fu), 0x82EFEAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82EFED;
L_82EFED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFEDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFEDu,0x82EFEDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFEDu, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82EFED JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xEFF0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xEFF1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x82EFEDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82EFF1;
L_82EFF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xEFF1u,0x82EFF1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFF1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82EFF3;
L_82EFF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF3u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFF3 CLC
    cpu.setFlag('C', false);
    goto L_82EFF4;
L_82EFF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFF4 ADC
    cpu.adc(0x10u);
    goto L_82EFF7;
L_82EFF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFF7 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82EFF9;
L_82EFF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFF9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82EFFB;
L_82EFFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFFB CLC
    cpu.setFlag('C', false);
    goto L_82EFFC;
L_82EFFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFFC ADC
    cpu.adc(0x20u);
    goto L_82EFFF;
L_82EFFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xEFFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xEFFFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82EFFF TAY
    cpu.transfer("TAY");
    goto L_82F000;
L_82F000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF000u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF000u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF000u, 8u, 4u, 0x8098B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F000 JSL -> $8098B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF003u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF004u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B4u, 0x82F000u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F004;
L_82F004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF004u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF004u,0x82F004u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF004u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF004u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F004 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82F006;
L_82F006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF006u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF006u, 6u, 3u, cpu.address("abs", 0xF00Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82F006 JSR -> $82F00F stack real
    { cpu.push16Value(hw,0xF008u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF009u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF00Fu), 0x82F006u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F009;
L_82F009:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF009u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF009u,0x82F009u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF009u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF009u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F009 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF00Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF00Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x82F009u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82F00D;
L_82F00D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF00Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF00Du,0x82F00Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF00Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F00D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F00Du);return;} hw.unresolvedReturn(0x82F00Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_838ED5_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839002u: goto L_839002;
    case 0x839003u: goto L_839003;
    case 0x839006u: goto L_839006;
    case 0x839007u: goto L_839007;
    case 0x83900Au: goto L_83900A;
    case 0x83900Du: goto L_83900D;
    case 0x83900Eu: goto L_83900E;
    case 0x839010u: goto L_839010;
    case 0x839013u: goto L_839013;
    case 0x839014u: goto L_839014;
    case 0x839015u: goto L_839015;
    case 0x839017u: goto L_839017;
    case 0x83901Au: goto L_83901A;
    case 0x83901Du: goto L_83901D;
    case 0x839020u: goto L_839020;
    case 0x839023u: goto L_839023;
    case 0x839026u: goto L_839026;
    case 0x839029u: goto L_839029;
    case 0x83902Cu: goto L_83902C;
    case 0x83902Eu: goto L_83902E;
    case 0x839031u: goto L_839031;
    case 0x839034u: goto L_839034;
    case 0x839035u: goto L_839035;
    case 0x839038u: goto L_839038;
    case 0x839039u: goto L_839039;
    case 0x83903Bu: goto L_83903B;
    case 0x83903Eu: goto L_83903E;
    case 0x83903Fu: goto L_83903F;
    case 0x839041u: goto L_839041;
    case 0x839044u: goto L_839044;
    case 0x839047u: goto L_839047;
    case 0x83904Au: goto L_83904A;
    case 0x83904Du: goto L_83904D;
    case 0x839050u: goto L_839050;
    case 0x839052u: goto L_839052;
    case 0x839055u: goto L_839055;
    case 0x839058u: goto L_839058;
    case 0x83905Au: goto L_83905A;
    case 0x83905Du: goto L_83905D;
    case 0x839060u: goto L_839060;
    case 0x839062u: goto L_839062;
    case 0x839064u: goto L_839064;
    case 0x839066u: goto L_839066;
    case 0x839068u: goto L_839068;
    case 0x839069u: goto L_839069;
    case 0x83906Au: goto L_83906A;
    case 0x83906Cu: goto L_83906C;
    case 0x83906Du: goto L_83906D;
    case 0x839070u: goto L_839070;
    case 0x839073u: goto L_839073;
    case 0x839076u: goto L_839076;
    case 0x839077u: goto L_839077;
    case 0x83907Au: goto L_83907A;
    case 0x83907Bu: goto L_83907B;
    case 0x83907Eu: goto L_83907E;
    case 0x839081u: goto L_839081;
    case 0x839084u: goto L_839084;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9002u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839002 CLC
    cpu.setFlag('C', false);
    goto L_839003;
L_839003:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9003u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9003u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839003 ADC
    cpu.adc(0x20u);
    goto L_839006;
L_839006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9006u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839006 SEC
    cpu.setFlag('C', true);
    goto L_839007;
L_839007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9007u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839007 SBC
    cpu.sbc(0x10u);
    goto L_83900A;
L_83900A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900A AND
    cpu.logicAnd(0xF0u);
    goto L_83900D;
L_83900D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900D CLC
    cpu.setFlag('C', false);
    goto L_83900E;
L_83900E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x900Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x900Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83900E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839010;
L_839010:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9010u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9010u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839010 EOR
    cpu.logicXor(0xFFFFu);
    goto L_839013;
L_839013:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9013u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9013u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839013 INC
    cpu.inc('A');
    goto L_839014;
L_839014:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9014u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9014u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839014 SEC
    cpu.setFlag('C', true);
    goto L_839015;
L_839015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9015u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839015 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839017;
L_839017:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9017u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9017u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839017 AND
    cpu.logicAnd(0xF0u);
    goto L_83901A;
L_83901A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Au, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83901A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83901D;
L_83901D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x901Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x901Du, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83901D STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839020;
L_839020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9020u, 6u, 3u, cpu.address("abs", 0x8D8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839020 JSR -> $838D8D stack real
    { cpu.push16Value(hw,0x9022u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9023u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x8D8Du), 0x839020u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839023;
L_839023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9023u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9023u,0x839023u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9023u, 8u, 3u, cpu.address("abs", 0x1BA4u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839023 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA4u), cpu.m8?8:16);
    goto L_839026;
L_839026:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9026u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9026u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839026 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839029;
L_839029:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9029u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9029u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839029 CMP
    cpu.compareA(0x8u);
    goto L_83902C;
L_83902C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83902C BCS -> $839052
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839052; }
    goto L_83902E;
L_83902E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x902Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x902Eu, 3u, 3u, cpu.address("abs", 0x8ED8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83902E JMP -> $838ED8
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8ED8u),0x83902Eu); return;
L_839031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9031u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839031 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839034;
L_839034:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9034u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9034u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839034 CLC
    cpu.setFlag('C', false);
    goto L_839035;
L_839035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9035u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9035u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839035 ADC
    cpu.adc(0x40u);
    goto L_839038;
L_839038:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9038u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9038u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839038 SEC
    cpu.setFlag('C', true);
    goto L_839039;
L_839039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9039u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9039u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839039 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83903B;
L_83903B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903B AND
    cpu.logicAnd(0x80u);
    goto L_83903E;
L_83903E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903E CLC
    cpu.setFlag('C', false);
    goto L_83903F;
L_83903F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x903Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x903Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83903F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839041;
L_839041:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9041u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9041u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839041 AND
    cpu.logicAnd(0xF0u);
    goto L_839044;
L_839044:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9044u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9044u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839044 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839047;
L_839047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9047u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839047 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_83904A;
L_83904A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Au, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83904A STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_83904D;
L_83904D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Du, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83904D STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839050;
L_839050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9050u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839050 BRA -> $839020
    goto L_839020;
L_839052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 6u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839052 STZ
    hw.write(cpu.address("absx", 0x10A6u), 0, cpu.m8?8:16);
    goto L_839055;
L_839055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 6u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839055 STZ
    hw.write(cpu.address("absx", 0x10A8u), 0, cpu.m8?8:16);
    goto L_839058;
L_839058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9058u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839058 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83905A;
L_83905A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Au, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83905A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83905D;
L_83905D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Du, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83905D STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839060;
L_839060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839060 STZ
    hw.write(cpu.address("dpx", 0x1Au), 0, cpu.m8?8:16);
    goto L_839062;
L_839062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9062u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839062 STZ
    hw.write(cpu.address("dpx", 0x1Cu), 0, cpu.m8?8:16);
    goto L_839064;
L_839064:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9064u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9064u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9064u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839064 STZ
    hw.write(cpu.address("dpx", 0x16u), 0, cpu.m8?8:16);
    goto L_839066;
L_839066:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9066u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u,cpu,0x74u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9066u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839066 STZ
    hw.write(cpu.address("dpx", 0x18u), 0, cpu.m8?8:16);
    goto L_839068;
L_839068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839068 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839068u);return;} hw.unresolvedReturn(0x839068u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839069:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9069u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9069u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839069 PHA
    cpu.push("PHA", hw);
    goto L_83906A;
L_83906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83906A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83906C;
L_83906C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83906C LSR
    cpu.lsrA();
    goto L_83906D;
L_83906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 6u, 3u, cpu.address("abs", 0x946Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83906D JSR -> $83946D stack real
    { cpu.push16Value(hw,0x906Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9070u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x946Du), 0x83906Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839070;
L_839070:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9070u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9070u,0x839070u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9070u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839070 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839073;
L_839073:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9073u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9073u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839073 EOR
    cpu.logicXor(0xFFFFu);
    goto L_839076;
L_839076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839076 INC
    cpu.inc('A');
    goto L_839077;
L_839077:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9077u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9077u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839077 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83907A;
L_83907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83907A PLA
    cpu.pop("PLA", hw);
    goto L_83907B;
L_83907B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83907B AND
    cpu.logicAnd(0xFFu);
    goto L_83907E;
L_83907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83907E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839081;
L_839081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839081 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839084;
L_839084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9084u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u, 3u, 3u, cpu.address("abs", 0x8D8Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839084 JMP -> $838D8D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x8D8Du),0x839084u); return;
}

void sub_83F73B_E0M0X0C1_part7(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83FA26u: goto L_83FA26;
    case 0x83FA28u: goto L_83FA28;
    case 0x83FA29u: goto L_83FA29;
    case 0x83FA2Bu: goto L_83FA2B;
    case 0x83FA2Eu: goto L_83FA2E;
    case 0x83FA30u: goto L_83FA30;
    case 0x83FA31u: goto L_83FA31;
    case 0x83FA33u: goto L_83FA33;
    case 0x83FA35u: goto L_83FA35;
    case 0x83FA36u: goto L_83FA36;
    case 0x83FA39u: goto L_83FA39;
    case 0x83FA3Bu: goto L_83FA3B;
    case 0x83FA3Cu: goto L_83FA3C;
    case 0x83FA3Eu: goto L_83FA3E;
    case 0x83FA40u: goto L_83FA40;
    case 0x83FA42u: goto L_83FA42;
    case 0x83FA45u: goto L_83FA45;
    case 0x83FA47u: goto L_83FA47;
    case 0x83FA4Au: goto L_83FA4A;
    case 0x83FA4Bu: goto L_83FA4B;
    case 0x83FA4Eu: goto L_83FA4E;
    case 0x83FA50u: goto L_83FA50;
    case 0x83FA52u: goto L_83FA52;
    case 0x83FA55u: goto L_83FA55;
    case 0x83FA57u: goto L_83FA57;
    case 0x83FA5Bu: goto L_83FA5B;
    case 0x83FA5Eu: goto L_83FA5E;
    case 0x83FA60u: goto L_83FA60;
    case 0x83FA62u: goto L_83FA62;
    case 0x83FA64u: goto L_83FA64;
    case 0x83FA66u: goto L_83FA66;
    case 0x83FA67u: goto L_83FA67;
    case 0x83FA68u: goto L_83FA68;
    case 0x83FA6Au: goto L_83FA6A;
    case 0x83FA6Cu: goto L_83FA6C;
    case 0x83FA6Du: goto L_83FA6D;
    case 0x83FA6Fu: goto L_83FA6F;
    case 0x83FA71u: goto L_83FA71;
    case 0x83FA74u: goto L_83FA74;
    case 0x83FA76u: goto L_83FA76;
    case 0x83FA77u: goto L_83FA77;
    case 0x83FA79u: goto L_83FA79;
    case 0x83FA7Cu: goto L_83FA7C;
    case 0x83FA7Eu: goto L_83FA7E;
    case 0x83FA7Fu: goto L_83FA7F;
    case 0x83FA81u: goto L_83FA81;
    case 0x83FA83u: goto L_83FA83;
    case 0x83FA84u: goto L_83FA84;
    case 0x83FA85u: goto L_83FA85;
    case 0x83FA87u: goto L_83FA87;
    case 0x83FA89u: goto L_83FA89;
    case 0x83FA8Au: goto L_83FA8A;
    case 0x83FA8Cu: goto L_83FA8C;
    case 0x83FA8Eu: goto L_83FA8E;
    case 0x83FA91u: goto L_83FA91;
    case 0x83FA93u: goto L_83FA93;
    case 0x83FA94u: goto L_83FA94;
    case 0x83FA96u: goto L_83FA96;
    case 0x83FA99u: goto L_83FA99;
    case 0x83FA9Bu: goto L_83FA9B;
    case 0x83FA9Cu: goto L_83FA9C;
    case 0x83FA9Fu: goto L_83FA9F;
    case 0x83FAA0u: goto L_83FAA0;
    case 0x83FAA2u: goto L_83FAA2;
    case 0x83FAA5u: goto L_83FAA5;
    case 0x83FAA6u: goto L_83FAA6;
    case 0x83FAA8u: goto L_83FAA8;
    case 0x83FAABu: goto L_83FAAB;
    case 0x83FAACu: goto L_83FAAC;
    case 0x83FAAEu: goto L_83FAAE;
    case 0x83FAB1u: goto L_83FAB1;
    case 0x83FAB4u: goto L_83FAB4;
    case 0x83FAB6u: goto L_83FAB6;
    case 0x83FAB8u: goto L_83FAB8;
    case 0x83FABBu: goto L_83FABB;
    case 0x83FABEu: goto L_83FABE;
    case 0x83FAC1u: goto L_83FAC1;
    case 0x83FAC3u: goto L_83FAC3;
    case 0x83FAC5u: goto L_83FAC5;
    case 0x83FAC8u: goto L_83FAC8;
    case 0x83FACAu: goto L_83FACA;
    case 0x83FACCu: goto L_83FACC;
    case 0x83FACEu: goto L_83FACE;
    case 0x83FAD1u: goto L_83FAD1;
    case 0x83FAD4u: goto L_83FAD4;
    case 0x83FAD7u: goto L_83FAD7;
    case 0x83FAD9u: goto L_83FAD9;
    case 0x83FADBu: goto L_83FADB;
    case 0x83FADDu: goto L_83FADD;
    case 0x83FADFu: goto L_83FADF;
    case 0x83FAE1u: goto L_83FAE1;
    case 0x83FAE2u: goto L_83FAE2;
    case 0x83FAE5u: goto L_83FAE5;
    case 0x83FAE7u: goto L_83FAE7;
    case 0x83FAE8u: goto L_83FAE8;
    case 0x83FAEAu: goto L_83FAEA;
    case 0x83FAECu: goto L_83FAEC;
    case 0x83FAEEu: goto L_83FAEE;
    case 0x83FAF1u: goto L_83FAF1;
    case 0x83FAF3u: goto L_83FAF3;
    case 0x83FAF4u: goto L_83FAF4;
    case 0x83FAF6u: goto L_83FAF6;
    case 0x83FAF9u: goto L_83FAF9;
    case 0x83FAFBu: goto L_83FAFB;
    case 0x83FAFCu: goto L_83FAFC;
    case 0x83FAFFu: goto L_83FAFF;
    case 0x83FB02u: goto L_83FB02;
    case 0x83FB04u: goto L_83FB04;
    case 0x83FB06u: goto L_83FB06;
    case 0x83FB09u: goto L_83FB09;
    case 0x83FB0Au: goto L_83FB0A;
    case 0x83FB0Cu: goto L_83FB0C;
    case 0x83FB0Eu: goto L_83FB0E;
    case 0x83FB10u: goto L_83FB10;
    case 0x83FB11u: goto L_83FB11;
    case 0x83FB14u: goto L_83FB14;
    case 0x83FB16u: goto L_83FB16;
    case 0x83FB17u: goto L_83FB17;
    case 0x83FB19u: goto L_83FB19;
    case 0x83FB1Bu: goto L_83FB1B;
    case 0x83FB1Eu: goto L_83FB1E;
    case 0x83FB20u: goto L_83FB20;
    case 0x83FB23u: goto L_83FB23;
    case 0x83FB26u: goto L_83FB26;
    case 0x83FB27u: goto L_83FB27;
    case 0x83FB29u: goto L_83FB29;
    case 0x83FB2Bu: goto L_83FB2B;
    case 0x83FB2Eu: goto L_83FB2E;
    case 0x83FB2Fu: goto L_83FB2F;
    case 0x83FB31u: goto L_83FB31;
    case 0x83FB34u: goto L_83FB34;
    case 0x83FB36u: goto L_83FB36;
    case 0x83FB39u: goto L_83FB39;
    case 0x83FB3Cu: goto L_83FB3C;
    case 0x83FB3Du: goto L_83FB3D;
    case 0x83FB3Fu: goto L_83FB3F;
    case 0x83FB41u: goto L_83FB41;
    case 0x83FB44u: goto L_83FB44;
    case 0x83FB45u: goto L_83FB45;
    case 0x83FB47u: goto L_83FB47;
    case 0x83FB49u: goto L_83FB49;
    case 0x83FB4Au: goto L_83FB4A;
    case 0x83FB4Du: goto L_83FB4D;
    case 0x83FB4Fu: goto L_83FB4F;
    case 0x83FB50u: goto L_83FB50;
    case 0x83FB52u: goto L_83FB52;
    case 0x83FB54u: goto L_83FB54;
    case 0x83FB56u: goto L_83FB56;
    case 0x83FB59u: goto L_83FB59;
    case 0x83FB5Cu: goto L_83FB5C;
    case 0x83FB5Fu: goto L_83FB5F;
    case 0x83FB61u: goto L_83FB61;
    case 0x83FB62u: goto L_83FB62;
    case 0x83FB64u: goto L_83FB64;
    case 0x83FB67u: goto L_83FB67;
    case 0x83FB69u: goto L_83FB69;
    case 0x83FB6Cu: goto L_83FB6C;
    case 0x83FB6Du: goto L_83FB6D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83FA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA26u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA26 REP
    cpu.rep(0x20u);
    goto L_83FA28;
L_83FA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA28u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA28u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA28 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA28u);return;} hw.unresolvedReturn(0x83FA28u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA29 SBC
    cpu.sbc(0x40u);
    goto L_83FA2B;
L_83FA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA2B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA2E;
L_83FA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA2E REP
    cpu.rep(0x20u);
    goto L_83FA30;
L_83FA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA30u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA30u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA30 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA30u);return;} hw.unresolvedReturn(0x83FA30u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA31 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA33;
L_83FA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA33u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA33 AND
    cpu.logicAnd(0xF0u);
    goto L_83FA35;
L_83FA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA35 SEC
    cpu.setFlag('C', true);
    goto L_83FA36;
L_83FA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA36u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA36u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA36 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83FA39;
L_83FA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA39 BEQ -> $83FA4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA4B; }
    goto L_83FA3B;
L_83FA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3B ASL
    cpu.aslA();
    goto L_83FA3C;
L_83FA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3C LDA
    cpu.setA(0x82u, 8);
    goto L_83FA3E;
L_83FA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3E BCC -> $83FA42
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA42; }
    goto L_83FA40;
L_83FA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA40 LDA
    cpu.setA(0x81u, 8);
    goto L_83FA42;
L_83FA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA42u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA42u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA42 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FA45;
L_83FA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA45 REP
    cpu.rep(0x20u);
    goto L_83FA47;
L_83FA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA47u, 6u, 3u, cpu.address("abs", 0xFCD0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FA47 JSR -> $83FCD0 stack real
    { cpu.push16Value(hw,0xFA49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFA4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFCD0u), 0x83FA47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FA4A;
L_83FA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA4Au);return;} hw.unresolvedReturn(0x83FA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA4Au);return;} hw.unresolvedReturn(0x83FA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA4Au,0x83FA4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Bu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA4B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA4E;
L_83FA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA4E BEQ -> $83FA45
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA45; }
    goto L_83FA50;
L_83FA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA50u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA50 REP
    cpu.rep(0x20u);
    goto L_83FA52;
L_83FA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA52u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA52u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA52 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA55;
L_83FA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA55 BNE -> $83FA7C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA7C; }
    goto L_83FA57;
L_83FA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA57u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA57u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA57 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFA5Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83FA57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FA5B;
L_83FA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,0x83FA5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Bu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA5B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA5E;
L_83FA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Eu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA5E CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83FA60;
L_83FA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA60u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA60 BMI -> $83FA7F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FA7F; }
    goto L_83FA62;
L_83FA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA62u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA62u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA62 SEP
    cpu.sep(0x20u);
    goto L_83FA64;
L_83FA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA64u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA64 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA66;
L_83FA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA66u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA66 TAY
    cpu.transfer("TAY");
    goto L_83FA67;
L_83FA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA67u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA67 SEC
    cpu.setFlag('C', true);
    goto L_83FA68;
L_83FA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA68u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA68 SBC
    cpu.sbc(0x20u);
    goto L_83FA6A;
L_83FA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6A CMP
    cpu.compareA(0x80u);
    goto L_83FA6C;
L_83FA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6C TYA
    cpu.transfer("TYA");
    goto L_83FA6D;
L_83FA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6D BCS -> $83FA77
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA77; }
    goto L_83FA6F;
L_83FA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6F SBC
    cpu.sbc(0x3Fu);
    goto L_83FA71;
L_83FA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA71 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA74;
L_83FA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA74u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA74 REP
    cpu.rep(0x20u);
    goto L_83FA76;
L_83FA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA76u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA76 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA76u);return;} hw.unresolvedReturn(0x83FA76u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA77u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA77 ADC
    cpu.adc(0x3Fu);
    goto L_83FA79;
L_83FA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA79 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA7C;
L_83FA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7C REP
    cpu.rep(0x20u);
    goto L_83FA7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7C REP
    cpu.rep(0x20u);
    goto L_83FA7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,0x83FA7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA7E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA7Eu);return;} hw.unresolvedReturn(0x83FA7Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7F SEP
    cpu.sep(0x20u);
    goto L_83FA81;
L_83FA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA81 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA83;
L_83FA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA83u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA83 TAY
    cpu.transfer("TAY");
    goto L_83FA84;
L_83FA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA84u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA84u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA84 SEC
    cpu.setFlag('C', true);
    goto L_83FA85;
L_83FA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA85 SBC
    cpu.sbc(0x20u);
    goto L_83FA87;
L_83FA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA87u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA87 CMP
    cpu.compareA(0x80u);
    goto L_83FA89;
L_83FA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA89 TYA
    cpu.transfer("TYA");
    goto L_83FA8A;
L_83FA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8A BCS -> $83FA94
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA94; }
    goto L_83FA8C;
L_83FA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8C ADC
    cpu.adc(0x40u);
    goto L_83FA8E;
L_83FA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Eu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA91;
L_83FA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA91 REP
    cpu.rep(0x20u);
    goto L_83FA93;
L_83FA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA93u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA93u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA93 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA93u);return;} hw.unresolvedReturn(0x83FA93u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA94u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA94 SBC
    cpu.sbc(0x40u);
    goto L_83FA96;
L_83FA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA96u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA96 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA99;
L_83FA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA99 REP
    cpu.rep(0x20u);
    goto L_83FA9B;
L_83FA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA9B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA9Bu);return;} hw.unresolvedReturn(0x83FA9Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Cu, 5u + 1u, 3u, cpu.address("absy", 0x0007u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA9C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA9F;
L_83FA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA9F LSR
    cpu.lsrA();
    goto L_83FAA0;
L_83FAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA0 BCS -> $83FAA5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAA5; }
    goto L_83FAA2;
L_83FAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA2u, 3u, 3u, cpu.address("abs", 0xE21Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA2 JMP -> $83E21E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE21Eu),0x83FAA2u); return;
L_83FAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA5 LSR
    cpu.lsrA();
    goto L_83FAA6;
L_83FAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA6 BCC -> $83FAAB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAAB; }
    goto L_83FAA8;
L_83FAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA8u, 3u, 3u, cpu.address("abs", 0xFB8Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA8 JMP -> $83FB8E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFB8Eu),0x83FAA8u); return;
L_83FAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAB LSR
    cpu.lsrA();
    goto L_83FAAC;
L_83FAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAACu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAC BCC -> $83FABB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FABB; }
    goto L_83FAAE;
L_83FAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAAEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAB1;
L_83FAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB1 CMP
    cpu.compareA(0x920u);
    goto L_83FAB4;
L_83FAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB4 BPL -> $83FACC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FACC; }
    goto L_83FAB6;
L_83FAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAB8;
L_83FAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB8u, 3u, 3u, cpu.address("abs", 0xE22Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB8 JMP -> $83E22F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE22Fu),0x83FAB8u); return;
L_83FABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFABBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFABBu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FABB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FABE;
L_83FABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFABEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FABE CMP
    cpu.compareA(0x920u);
    goto L_83FAC1;
L_83FAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC1 BPL -> $83FAC8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FAC8; }
    goto L_83FAC3;
L_83FAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAC5;
L_83FAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u, 3u, 3u, cpu.address("abs", 0xE396u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC5 JMP -> $83E396
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE396u),0x83FAC5u); return;
L_83FAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FACA;
L_83FACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACA BRA -> $83FACE
    goto L_83FACE;
L_83FACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FACE;
L_83FACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACEu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83FAD1;
L_83FAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD1 ADC
    cpu.adc(0x14u);
    goto L_83FAD4;
L_83FAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD4 CMP
    cpu.compareA(0x28u);
    goto L_83FAD7;
L_83FAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD7 BCC -> $83FB04
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB04; }
    goto L_83FAD9;
L_83FAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD9 BPL -> $83FAFC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FAFC; }
    goto L_83FADB;
L_83FADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADB SEP
    cpu.sep(0x20u);
    goto L_83FADD;
L_83FADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADD LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FADF;
L_83FADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADF AND
    cpu.logicAnd(0xF0u);
    goto L_83FAE1;
L_83FAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE1 SEC
    cpu.setFlag('C', true);
    goto L_83FAE2;
L_83FAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE2u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE2u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE2 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83FAE5;
L_83FAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE5 BEQ -> $83FAF4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FAF4; }
    goto L_83FAE7;
L_83FAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE7 ASL
    cpu.aslA();
    goto L_83FAE8;
L_83FAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE8 LDA
    cpu.setA(0x82u, 8);
    goto L_83FAEA;
L_83FAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEA BCC -> $83FAEE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAEE; }
    goto L_83FAEC;
L_83FAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEC LDA
    cpu.setA(0x81u, 8);
    goto L_83FAEE;
L_83FAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FAF1;
L_83FAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF1 REP
    cpu.rep(0x20u);
    goto L_83FAF3;
L_83FAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FAF3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FAF3u);return;} hw.unresolvedReturn(0x83FAF3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF4 LDA
    cpu.setA(0x80u, 8);
    goto L_83FAF6;
L_83FAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FAF9;
L_83FAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF9 REP
    cpu.rep(0x20u);
    goto L_83FAFB;
L_83FAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FAFB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FAFBu);return;} hw.unresolvedReturn(0x83FAFBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAFC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAFF;
L_83FAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAFF CMP
    cpu.compareA(0x500u);
    goto L_83FB02;
L_83FB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB02 BMI -> $83FB6D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FB6D; }
    goto L_83FB04;
L_83FB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB04u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB04 SEP
    cpu.sep(0x20u);
    goto L_83FB06;
L_83FB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u, 4u + 1u, 3u, cpu.address("absx", 0x10DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB09;
L_83FB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB09 LSR
    cpu.lsrA();
    goto L_83FB0A;
L_83FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0A BCS -> $83FB45
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB45; }
    goto L_83FB0C;
L_83FB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB0E;
L_83FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0E AND
    cpu.logicAnd(0xF0u);
    goto L_83FB10;
L_83FB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB10 SEC
    cpu.setFlag('C', true);
    goto L_83FB11;
L_83FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB11 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83FB14;
L_83FB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB14u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB14 BEQ -> $83FB62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FB62; }
    goto L_83FB16;
L_83FB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB16 ASL
    cpu.aslA();
    goto L_83FB17;
L_83FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB17 BCC -> $83FB2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB2F; }
    goto L_83FB19;
L_83FB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB19 LDA
    cpu.setA(0x81u, 8);
    goto L_83FB1B;
L_83FB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB1B STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB1E;
L_83FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB1E LDA
    cpu.setA(0x10u, 8);
    goto L_83FB20;
L_83FB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB20u, 4u, 3u, cpu.address("abs", 0x1BB2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB20 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FB23;
L_83FB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB23 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB26;
L_83FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB26 XBA
    cpu.xba();
    goto L_83FB27;
L_83FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB27 LDA
    cpu.setA(0x1u, 8);
    goto L_83FB29;
L_83FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB29 REP
    cpu.rep(0x20u);
    goto L_83FB2B;
L_83FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB2B STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83FB2E;
L_83FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB2E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB2Eu);return;} hw.unresolvedReturn(0x83FB2Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB2F LDA
    cpu.setA(0x82u, 8);
    goto L_83FB31;
L_83FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB31 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB34;
L_83FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB34 LDA
    cpu.setA(0x20u, 8);
    goto L_83FB36;
L_83FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 4u, 3u, cpu.address("abs", 0x1BB2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB36 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FB39;
L_83FB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB39 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB3C;
L_83FB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3C XBA
    cpu.xba();
    goto L_83FB3D;
L_83FB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3D LDA
    cpu.setA(0x1u, 8);
    goto L_83FB3F;
L_83FB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3F REP
    cpu.rep(0x20u);
    goto L_83FB41;
L_83FB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB41 STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83FB44;
L_83FB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB44u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB44u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB44 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB44u);return;} hw.unresolvedReturn(0x83FB44u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB45 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB47;
L_83FB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB47 AND
    cpu.logicAnd(0xF0u);
    goto L_83FB49;
L_83FB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB49 SEC
    cpu.setFlag('C', true);
    goto L_83FB4A;
L_83FB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83FB4D;
L_83FB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4D BEQ -> $83FB62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FB62; }
    goto L_83FB4F;
L_83FB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4F ASL
    cpu.aslA();
    goto L_83FB50;
L_83FB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB50u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB50 LDA
    cpu.setA(0x82u, 8);
    goto L_83FB52;
L_83FB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB52u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB52 BCC -> $83FB56
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB56; }
    goto L_83FB54;
L_83FB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB54u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB54 LDA
    cpu.setA(0x81u, 8);
    goto L_83FB56;
L_83FB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB56u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB56u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB56 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB59;
L_83FB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u, 4u + 1u, 3u, cpu.address("absx", 0x10DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB5C;
L_83FB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB5C STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB5F;
L_83FB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB5F REP
    cpu.rep(0x20u);
    goto L_83FB61;
L_83FB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB61 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB61u);return;} hw.unresolvedReturn(0x83FB61u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB62 LDA
    cpu.setA(0x80u, 8);
    goto L_83FB64;
L_83FB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB64 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB67;
L_83FB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB67u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB67 REP
    cpu.rep(0x20u);
    goto L_83FB69;
L_83FB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB69 STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83FB6C;
L_83FB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB6C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB6Cu);return;} hw.unresolvedReturn(0x83FB6Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB6D SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB6Fu,0x83FB6Du); return;
}

void sub_83F73B_E0M0X0CQ_part7(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83FA26u: goto L_83FA26;
    case 0x83FA28u: goto L_83FA28;
    case 0x83FA29u: goto L_83FA29;
    case 0x83FA2Bu: goto L_83FA2B;
    case 0x83FA2Eu: goto L_83FA2E;
    case 0x83FA30u: goto L_83FA30;
    case 0x83FA31u: goto L_83FA31;
    case 0x83FA33u: goto L_83FA33;
    case 0x83FA35u: goto L_83FA35;
    case 0x83FA36u: goto L_83FA36;
    case 0x83FA39u: goto L_83FA39;
    case 0x83FA3Bu: goto L_83FA3B;
    case 0x83FA3Cu: goto L_83FA3C;
    case 0x83FA3Eu: goto L_83FA3E;
    case 0x83FA40u: goto L_83FA40;
    case 0x83FA42u: goto L_83FA42;
    case 0x83FA45u: goto L_83FA45;
    case 0x83FA47u: goto L_83FA47;
    case 0x83FA4Au: goto L_83FA4A;
    case 0x83FA4Bu: goto L_83FA4B;
    case 0x83FA4Eu: goto L_83FA4E;
    case 0x83FA50u: goto L_83FA50;
    case 0x83FA52u: goto L_83FA52;
    case 0x83FA55u: goto L_83FA55;
    case 0x83FA57u: goto L_83FA57;
    case 0x83FA5Bu: goto L_83FA5B;
    case 0x83FA5Eu: goto L_83FA5E;
    case 0x83FA60u: goto L_83FA60;
    case 0x83FA62u: goto L_83FA62;
    case 0x83FA64u: goto L_83FA64;
    case 0x83FA66u: goto L_83FA66;
    case 0x83FA67u: goto L_83FA67;
    case 0x83FA68u: goto L_83FA68;
    case 0x83FA6Au: goto L_83FA6A;
    case 0x83FA6Cu: goto L_83FA6C;
    case 0x83FA6Du: goto L_83FA6D;
    case 0x83FA6Fu: goto L_83FA6F;
    case 0x83FA71u: goto L_83FA71;
    case 0x83FA74u: goto L_83FA74;
    case 0x83FA76u: goto L_83FA76;
    case 0x83FA77u: goto L_83FA77;
    case 0x83FA79u: goto L_83FA79;
    case 0x83FA7Cu: goto L_83FA7C;
    case 0x83FA7Eu: goto L_83FA7E;
    case 0x83FA7Fu: goto L_83FA7F;
    case 0x83FA81u: goto L_83FA81;
    case 0x83FA83u: goto L_83FA83;
    case 0x83FA84u: goto L_83FA84;
    case 0x83FA85u: goto L_83FA85;
    case 0x83FA87u: goto L_83FA87;
    case 0x83FA89u: goto L_83FA89;
    case 0x83FA8Au: goto L_83FA8A;
    case 0x83FA8Cu: goto L_83FA8C;
    case 0x83FA8Eu: goto L_83FA8E;
    case 0x83FA91u: goto L_83FA91;
    case 0x83FA93u: goto L_83FA93;
    case 0x83FA94u: goto L_83FA94;
    case 0x83FA96u: goto L_83FA96;
    case 0x83FA99u: goto L_83FA99;
    case 0x83FA9Bu: goto L_83FA9B;
    case 0x83FA9Cu: goto L_83FA9C;
    case 0x83FA9Fu: goto L_83FA9F;
    case 0x83FAA0u: goto L_83FAA0;
    case 0x83FAA2u: goto L_83FAA2;
    case 0x83FAA5u: goto L_83FAA5;
    case 0x83FAA6u: goto L_83FAA6;
    case 0x83FAA8u: goto L_83FAA8;
    case 0x83FAABu: goto L_83FAAB;
    case 0x83FAACu: goto L_83FAAC;
    case 0x83FAAEu: goto L_83FAAE;
    case 0x83FAB1u: goto L_83FAB1;
    case 0x83FAB4u: goto L_83FAB4;
    case 0x83FAB6u: goto L_83FAB6;
    case 0x83FAB8u: goto L_83FAB8;
    case 0x83FABBu: goto L_83FABB;
    case 0x83FABEu: goto L_83FABE;
    case 0x83FAC1u: goto L_83FAC1;
    case 0x83FAC3u: goto L_83FAC3;
    case 0x83FAC5u: goto L_83FAC5;
    case 0x83FAC8u: goto L_83FAC8;
    case 0x83FACAu: goto L_83FACA;
    case 0x83FACCu: goto L_83FACC;
    case 0x83FACEu: goto L_83FACE;
    case 0x83FAD1u: goto L_83FAD1;
    case 0x83FAD4u: goto L_83FAD4;
    case 0x83FAD7u: goto L_83FAD7;
    case 0x83FAD9u: goto L_83FAD9;
    case 0x83FADBu: goto L_83FADB;
    case 0x83FADDu: goto L_83FADD;
    case 0x83FADFu: goto L_83FADF;
    case 0x83FAE1u: goto L_83FAE1;
    case 0x83FAE2u: goto L_83FAE2;
    case 0x83FAE5u: goto L_83FAE5;
    case 0x83FAE7u: goto L_83FAE7;
    case 0x83FAE8u: goto L_83FAE8;
    case 0x83FAEAu: goto L_83FAEA;
    case 0x83FAECu: goto L_83FAEC;
    case 0x83FAEEu: goto L_83FAEE;
    case 0x83FAF1u: goto L_83FAF1;
    case 0x83FAF3u: goto L_83FAF3;
    case 0x83FAF4u: goto L_83FAF4;
    case 0x83FAF6u: goto L_83FAF6;
    case 0x83FAF9u: goto L_83FAF9;
    case 0x83FAFBu: goto L_83FAFB;
    case 0x83FAFCu: goto L_83FAFC;
    case 0x83FAFFu: goto L_83FAFF;
    case 0x83FB02u: goto L_83FB02;
    case 0x83FB04u: goto L_83FB04;
    case 0x83FB06u: goto L_83FB06;
    case 0x83FB09u: goto L_83FB09;
    case 0x83FB0Au: goto L_83FB0A;
    case 0x83FB0Cu: goto L_83FB0C;
    case 0x83FB0Eu: goto L_83FB0E;
    case 0x83FB10u: goto L_83FB10;
    case 0x83FB11u: goto L_83FB11;
    case 0x83FB14u: goto L_83FB14;
    case 0x83FB16u: goto L_83FB16;
    case 0x83FB17u: goto L_83FB17;
    case 0x83FB19u: goto L_83FB19;
    case 0x83FB1Bu: goto L_83FB1B;
    case 0x83FB1Eu: goto L_83FB1E;
    case 0x83FB20u: goto L_83FB20;
    case 0x83FB23u: goto L_83FB23;
    case 0x83FB26u: goto L_83FB26;
    case 0x83FB27u: goto L_83FB27;
    case 0x83FB29u: goto L_83FB29;
    case 0x83FB2Bu: goto L_83FB2B;
    case 0x83FB2Eu: goto L_83FB2E;
    case 0x83FB2Fu: goto L_83FB2F;
    case 0x83FB31u: goto L_83FB31;
    case 0x83FB34u: goto L_83FB34;
    case 0x83FB36u: goto L_83FB36;
    case 0x83FB39u: goto L_83FB39;
    case 0x83FB3Cu: goto L_83FB3C;
    case 0x83FB3Du: goto L_83FB3D;
    case 0x83FB3Fu: goto L_83FB3F;
    case 0x83FB41u: goto L_83FB41;
    case 0x83FB44u: goto L_83FB44;
    case 0x83FB45u: goto L_83FB45;
    case 0x83FB47u: goto L_83FB47;
    case 0x83FB49u: goto L_83FB49;
    case 0x83FB4Au: goto L_83FB4A;
    case 0x83FB4Du: goto L_83FB4D;
    case 0x83FB4Fu: goto L_83FB4F;
    case 0x83FB50u: goto L_83FB50;
    case 0x83FB52u: goto L_83FB52;
    case 0x83FB54u: goto L_83FB54;
    case 0x83FB56u: goto L_83FB56;
    case 0x83FB59u: goto L_83FB59;
    case 0x83FB5Cu: goto L_83FB5C;
    case 0x83FB5Fu: goto L_83FB5F;
    case 0x83FB61u: goto L_83FB61;
    case 0x83FB62u: goto L_83FB62;
    case 0x83FB64u: goto L_83FB64;
    case 0x83FB67u: goto L_83FB67;
    case 0x83FB69u: goto L_83FB69;
    case 0x83FB6Cu: goto L_83FB6C;
    case 0x83FB6Du: goto L_83FB6D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83FA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA26u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA26u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA26 REP
    cpu.rep(0x20u);
    goto L_83FA28;
L_83FA28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA28u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA28u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA28 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA28u);return;} hw.unresolvedReturn(0x83FA28u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA29 SBC
    cpu.sbc(0x40u);
    goto L_83FA2B;
L_83FA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA2B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA2E;
L_83FA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA2Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA2E REP
    cpu.rep(0x20u);
    goto L_83FA30;
L_83FA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA30u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA30u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA30 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA30u);return;} hw.unresolvedReturn(0x83FA30u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA31 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA33;
L_83FA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA33u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA33u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA33 AND
    cpu.logicAnd(0xF0u);
    goto L_83FA35;
L_83FA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA35u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA35 SEC
    cpu.setFlag('C', true);
    goto L_83FA36;
L_83FA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA36u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA36u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA36 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83FA39;
L_83FA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA39u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA39 BEQ -> $83FA4B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA4B; }
    goto L_83FA3B;
L_83FA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3B ASL
    cpu.aslA();
    goto L_83FA3C;
L_83FA3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3C LDA
    cpu.setA(0x82u, 8);
    goto L_83FA3E;
L_83FA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA3Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA3E BCC -> $83FA42
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA42; }
    goto L_83FA40;
L_83FA40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA40u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA40u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA40 LDA
    cpu.setA(0x81u, 8);
    goto L_83FA42;
L_83FA42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA42u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA42u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA42 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FA45;
L_83FA45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA45 REP
    cpu.rep(0x20u);
    goto L_83FA47;
L_83FA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA47u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA47u, 6u, 3u, cpu.address("abs", 0xFCD0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FA47 JSR -> $83FCD0 stack real
    { cpu.push16Value(hw,0xFA49u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFA4Au,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFCD0u), 0x83FA47u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FA4A;
L_83FA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA4Au);return;} hw.unresolvedReturn(0x83FA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA4A RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA4Au);return;} hw.unresolvedReturn(0x83FA4Au,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA4Au,0x83FA4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FA4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Bu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA4B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA4E;
L_83FA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA4E BEQ -> $83FA45
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA45; }
    goto L_83FA50;
L_83FA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA50u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA50u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA50 REP
    cpu.rep(0x20u);
    goto L_83FA52;
L_83FA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA52u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA52u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA52 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA55;
L_83FA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA55 BNE -> $83FA7C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FA7C; }
    goto L_83FA57;
L_83FA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA57u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA57u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA57 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFA5Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83FA57u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FA5B;
L_83FA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA5Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,0x83FA5Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Bu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA5B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA5E;
L_83FA5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Eu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA5Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA5E CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83FA60;
L_83FA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA60u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA60u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA60 BMI -> $83FA7F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FA7F; }
    goto L_83FA62;
L_83FA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA62u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA62u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA62 SEP
    cpu.sep(0x20u);
    goto L_83FA64;
L_83FA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA64u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA64u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA64 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA66;
L_83FA66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA66u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA66 TAY
    cpu.transfer("TAY");
    goto L_83FA67;
L_83FA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA67u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA67 SEC
    cpu.setFlag('C', true);
    goto L_83FA68;
L_83FA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA68u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA68 SBC
    cpu.sbc(0x20u);
    goto L_83FA6A;
L_83FA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6A CMP
    cpu.compareA(0x80u);
    goto L_83FA6C;
L_83FA6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6C TYA
    cpu.transfer("TYA");
    goto L_83FA6D;
L_83FA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6D BCS -> $83FA77
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA77; }
    goto L_83FA6F;
L_83FA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA6Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA6F SBC
    cpu.sbc(0x3Fu);
    goto L_83FA71;
L_83FA71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA71u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA71 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA74;
L_83FA74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA74u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA74u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA74 REP
    cpu.rep(0x20u);
    goto L_83FA76;
L_83FA76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA76u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA76u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA76 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA76u);return;} hw.unresolvedReturn(0x83FA76u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA77u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA77 ADC
    cpu.adc(0x3Fu);
    goto L_83FA79;
L_83FA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA79u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA79 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA7C;
L_83FA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7C REP
    cpu.rep(0x20u);
    goto L_83FA7E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7C REP
    cpu.rep(0x20u);
    goto L_83FA7E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFA7Cu,0x83FA7Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FA7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA7E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA7Eu);return;} hw.unresolvedReturn(0x83FA7Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA7Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA7F SEP
    cpu.sep(0x20u);
    goto L_83FA81;
L_83FA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA81u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA81 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA83;
L_83FA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA83u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA83u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA83 TAY
    cpu.transfer("TAY");
    goto L_83FA84;
L_83FA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA84u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA84u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA84 SEC
    cpu.setFlag('C', true);
    goto L_83FA85;
L_83FA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA85 SBC
    cpu.sbc(0x20u);
    goto L_83FA87;
L_83FA87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA87u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA87 CMP
    cpu.compareA(0x80u);
    goto L_83FA89;
L_83FA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA89 TYA
    cpu.transfer("TYA");
    goto L_83FA8A;
L_83FA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8A BCS -> $83FA94
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FA94; }
    goto L_83FA8C;
L_83FA8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8C ADC
    cpu.adc(0x40u);
    goto L_83FA8E;
L_83FA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA8Eu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA8E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA91;
L_83FA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA91u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA91 REP
    cpu.rep(0x20u);
    goto L_83FA93;
L_83FA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA93u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA93u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA93 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA93u);return;} hw.unresolvedReturn(0x83FA93u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA94u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA94u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA94 SBC
    cpu.sbc(0x40u);
    goto L_83FA96;
L_83FA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA96u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA96u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA96 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83FA99;
L_83FA99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA99u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA99 REP
    cpu.rep(0x20u);
    goto L_83FA9B;
L_83FA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FA9B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FA9Bu);return;} hw.unresolvedReturn(0x83FA9Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Cu, 5u + 1u, 3u, cpu.address("absy", 0x0007u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA9C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FA9F;
L_83FA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FA9F LSR
    cpu.lsrA();
    goto L_83FAA0;
L_83FAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA0 BCS -> $83FAA5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAA5; }
    goto L_83FAA2;
L_83FAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA2u, 3u, 3u, cpu.address("abs", 0xE21Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA2 JMP -> $83E21E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE21Eu),0x83FAA2u); return;
L_83FAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA5 LSR
    cpu.lsrA();
    goto L_83FAA6;
L_83FAA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA6 BCC -> $83FAAB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAAB; }
    goto L_83FAA8;
L_83FAA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAA8u, 3u, 3u, cpu.address("abs", 0xFB8Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAA8 JMP -> $83FB8E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xFB8Eu),0x83FAA8u); return;
L_83FAAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAABu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAB LSR
    cpu.lsrA();
    goto L_83FAAC;
L_83FAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAACu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAC BCC -> $83FABB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FABB; }
    goto L_83FAAE;
L_83FAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAAEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAAEu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAAE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAB1;
L_83FAB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB1 CMP
    cpu.compareA(0x920u);
    goto L_83FAB4;
L_83FAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB4 BPL -> $83FACC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FACC; }
    goto L_83FAB6;
L_83FAB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAB8;
L_83FAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAB8u, 3u, 3u, cpu.address("abs", 0xE22Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAB8 JMP -> $83E22F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE22Fu),0x83FAB8u); return;
L_83FABB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFABBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFABBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFABBu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FABB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FABE;
L_83FABE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFABEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFABEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFABEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FABE CMP
    cpu.compareA(0x920u);
    goto L_83FAC1;
L_83FAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC1 BPL -> $83FAC8
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FAC8; }
    goto L_83FAC3;
L_83FAC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAC5;
L_83FAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC5u, 3u, 3u, cpu.address("abs", 0xE396u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC5 JMP -> $83E396
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xE396u),0x83FAC5u); return;
L_83FAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAC8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAC8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FACA;
L_83FACA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACAu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACA BRA -> $83FACE
    goto L_83FACE;
L_83FACC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACCu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FACE;
L_83FACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFACEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFACEu, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FACE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83FAD1;
L_83FAD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD1 ADC
    cpu.adc(0x14u);
    goto L_83FAD4;
L_83FAD4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD4 CMP
    cpu.compareA(0x28u);
    goto L_83FAD7;
L_83FAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD7 BCC -> $83FB04
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB04; }
    goto L_83FAD9;
L_83FAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAD9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAD9 BPL -> $83FAFC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FAFC; }
    goto L_83FADB;
L_83FADB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADB SEP
    cpu.sep(0x20u);
    goto L_83FADD;
L_83FADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADD LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FADF;
L_83FADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFADFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFADFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FADF AND
    cpu.logicAnd(0xF0u);
    goto L_83FAE1;
L_83FAE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE1 SEC
    cpu.setFlag('C', true);
    goto L_83FAE2;
L_83FAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE2u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE2u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE2 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83FAE5;
L_83FAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE5 BEQ -> $83FAF4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FAF4; }
    goto L_83FAE7;
L_83FAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE7 ASL
    cpu.aslA();
    goto L_83FAE8;
L_83FAE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAE8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAE8 LDA
    cpu.setA(0x82u, 8);
    goto L_83FAEA;
L_83FAEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEA BCC -> $83FAEE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FAEE; }
    goto L_83FAEC;
L_83FAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEC LDA
    cpu.setA(0x81u, 8);
    goto L_83FAEE;
L_83FAEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAEEu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAEE STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FAF1;
L_83FAF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF1 REP
    cpu.rep(0x20u);
    goto L_83FAF3;
L_83FAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FAF3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FAF3u);return;} hw.unresolvedReturn(0x83FAF3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FAF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF4 LDA
    cpu.setA(0x80u, 8);
    goto L_83FAF6;
L_83FAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF6u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF6 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FAF9;
L_83FAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAF9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAF9 REP
    cpu.rep(0x20u);
    goto L_83FAFB;
L_83FAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FAFB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FAFBu);return;} hw.unresolvedReturn(0x83FAFBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FAFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFCu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAFC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FAFF;
L_83FAFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFAFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFAFFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FAFF CMP
    cpu.compareA(0x500u);
    goto L_83FB02;
L_83FB02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB02 BMI -> $83FB6D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FB6D; }
    goto L_83FB04;
L_83FB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB04u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB04 SEP
    cpu.sep(0x20u);
    goto L_83FB06;
L_83FB06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB06u, 4u + 1u, 3u, cpu.address("absx", 0x10DAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB06 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB09;
L_83FB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB09u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB09 LSR
    cpu.lsrA();
    goto L_83FB0A;
L_83FB0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0A BCS -> $83FB45
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB45; }
    goto L_83FB0C;
L_83FB0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB0E;
L_83FB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB0E AND
    cpu.logicAnd(0xF0u);
    goto L_83FB10;
L_83FB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB10u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB10 SEC
    cpu.setFlag('C', true);
    goto L_83FB11;
L_83FB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB11u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB11 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83FB14;
L_83FB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB14u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB14 BEQ -> $83FB62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FB62; }
    goto L_83FB16;
L_83FB16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB16u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB16u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB16 ASL
    cpu.aslA();
    goto L_83FB17;
L_83FB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB17 BCC -> $83FB2F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB2F; }
    goto L_83FB19;
L_83FB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB19u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB19 LDA
    cpu.setA(0x81u, 8);
    goto L_83FB1B;
L_83FB1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Bu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB1B STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB1E;
L_83FB1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB1Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB1E LDA
    cpu.setA(0x10u, 8);
    goto L_83FB20;
L_83FB20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB20u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB20u, 4u, 3u, cpu.address("abs", 0x1BB2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB20 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FB23;
L_83FB23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB23u, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB23 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB26;
L_83FB26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB26u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB26 XBA
    cpu.xba();
    goto L_83FB27;
L_83FB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB27 LDA
    cpu.setA(0x1u, 8);
    goto L_83FB29;
L_83FB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB29u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB29 REP
    cpu.rep(0x20u);
    goto L_83FB2B;
L_83FB2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Bu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB2B STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83FB2E;
L_83FB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB2E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB2Eu);return;} hw.unresolvedReturn(0x83FB2Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB2Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB2F LDA
    cpu.setA(0x82u, 8);
    goto L_83FB31;
L_83FB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB31u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB31 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB34;
L_83FB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB34 LDA
    cpu.setA(0x20u, 8);
    goto L_83FB36;
L_83FB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB36u, 4u, 3u, cpu.address("abs", 0x1BB2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB36 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FB39;
L_83FB39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB39u, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB39 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB3C;
L_83FB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Cu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Cu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3C XBA
    cpu.xba();
    goto L_83FB3D;
L_83FB3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3D LDA
    cpu.setA(0x1u, 8);
    goto L_83FB3F;
L_83FB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB3Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB3F REP
    cpu.rep(0x20u);
    goto L_83FB41;
L_83FB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB41u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB41 STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83FB44;
L_83FB44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB44u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB44u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB44 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB44u);return;} hw.unresolvedReturn(0x83FB44u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB45 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB47;
L_83FB47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB47 AND
    cpu.logicAnd(0xF0u);
    goto L_83FB49;
L_83FB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB49 SEC
    cpu.setFlag('C', true);
    goto L_83FB4A;
L_83FB4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Au, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83FB4D;
L_83FB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4D BEQ -> $83FB62
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FB62; }
    goto L_83FB4F;
L_83FB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB4F ASL
    cpu.aslA();
    goto L_83FB50;
L_83FB50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB50u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB50 LDA
    cpu.setA(0x82u, 8);
    goto L_83FB52;
L_83FB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB52u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB52u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB52 BCC -> $83FB56
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FB56; }
    goto L_83FB54;
L_83FB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB54u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB54 LDA
    cpu.setA(0x81u, 8);
    goto L_83FB56;
L_83FB56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB56u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB56u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB56 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB59;
L_83FB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB59u, 4u + 1u, 3u, cpu.address("absx", 0x10DBu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FB5C;
L_83FB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Cu, 4u, 3u, cpu.address("abs", 0x1BB0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB5C STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FB5F;
L_83FB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB5Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB5F REP
    cpu.rep(0x20u);
    goto L_83FB61;
L_83FB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB61u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB61 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB61u);return;} hw.unresolvedReturn(0x83FB61u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB62u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB62u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB62 LDA
    cpu.setA(0x80u, 8);
    goto L_83FB64;
L_83FB64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB64u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB64 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83FB67;
L_83FB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB67u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB67u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB67 REP
    cpu.rep(0x20u);
    goto L_83FB69;
L_83FB69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB69u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB69 STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83FB6C;
L_83FB6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FB6C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83FB6Cu);return;} hw.unresolvedReturn(0x83FB6Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83FB6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFB6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFB6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FB6D SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFB6Fu,0x83FB6Du); return;
}

void sub_8486B2_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486B2u: goto L_8486B2;
    case 0x8486B5u: goto L_8486B5;
    case 0x8486B7u: goto L_8486B7;
    case 0x8486B9u: goto L_8486B9;
    case 0x8486BAu: goto L_8486BA;
    case 0x8486BBu: goto L_8486BB;
    case 0x8486BEu: goto L_8486BE;
    case 0x8486BFu: goto L_8486BF;
    case 0x8486C2u: goto L_8486C2;
    case 0x8486C4u: goto L_8486C4;
    case 0x8486C5u: goto L_8486C5;
    case 0x8486C9u: goto L_8486C9;
    case 0x8486CAu: goto L_8486CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B2 LDX
    cpu.setX(0xAC0u, 16);
    goto L_8486B5;
L_8486B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B5u,0x8486B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 BEQ -> $8486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486C5; }
    goto L_8486B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 BEQ -> $8486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486C5; }
    goto L_8486B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B7u,0x8486B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 TXA
    cpu.transfer("TXA");
    goto L_8486BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 TXA
    cpu.transfer("TXA");
    goto L_8486BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B9u,0x8486B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BA CLC
    cpu.setFlag('C', false);
    goto L_8486BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BA CLC
    cpu.setFlag('C', false);
    goto L_8486BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BAu,0x8486BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BB ADC
    cpu.adc(0x50u);
    goto L_8486BE;
L_8486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BE TAX
    cpu.transfer("TAX");
    goto L_8486BF;
L_8486BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BF CPX
    cpu.compareX(0x1790u);
    goto L_8486C2;
L_8486C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C2 BCC -> $8486B5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8486B5; }
    goto L_8486C4;
L_8486C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486C4u);return;} hw.unresolvedReturn(0x8486C4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8486C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8486C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8486C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8486C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C5u,0x8486C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C9 CLC
    cpu.setFlag('C', false);
    goto L_8486CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C9 CLC
    cpu.setFlag('C', false);
    goto L_8486CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C9u,0x8486C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486CA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486CAu);return;} hw.unresolvedReturn(0x8486CAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8486B2_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486B2u: goto L_8486B2;
    case 0x8486B5u: goto L_8486B5;
    case 0x8486B7u: goto L_8486B7;
    case 0x8486B9u: goto L_8486B9;
    case 0x8486BAu: goto L_8486BA;
    case 0x8486BBu: goto L_8486BB;
    case 0x8486BEu: goto L_8486BE;
    case 0x8486BFu: goto L_8486BF;
    case 0x8486C2u: goto L_8486C2;
    case 0x8486C4u: goto L_8486C4;
    case 0x8486C5u: goto L_8486C5;
    case 0x8486C9u: goto L_8486C9;
    case 0x8486CAu: goto L_8486CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B2 LDX
    cpu.setX(0xAC0u, 16);
    goto L_8486B5;
L_8486B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B5u,0x8486B5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 BEQ -> $8486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486C5; }
    goto L_8486B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 BEQ -> $8486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486C5; }
    goto L_8486B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B7u,0x8486B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 TXA
    cpu.transfer("TXA");
    goto L_8486BA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 TXA
    cpu.transfer("TXA");
    goto L_8486BA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B9u,0x8486B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BA CLC
    cpu.setFlag('C', false);
    goto L_8486BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BA CLC
    cpu.setFlag('C', false);
    goto L_8486BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BAu,0x8486BAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BB ADC
    cpu.adc(0x50u);
    goto L_8486BE;
L_8486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BE TAX
    cpu.transfer("TAX");
    goto L_8486BF;
L_8486BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BF CPX
    cpu.compareX(0x1790u);
    goto L_8486C2;
L_8486C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C2 BCC -> $8486B5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8486B5; }
    goto L_8486C4;
L_8486C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486C4u);return;} hw.unresolvedReturn(0x8486C4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8486C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8486C9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8486C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8486C9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C5u,0x8486C5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C9 CLC
    cpu.setFlag('C', false);
    goto L_8486CA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C9 CLC
    cpu.setFlag('C', false);
    goto L_8486CA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C9u,0x8486C9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486CA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486CAu);return;} hw.unresolvedReturn(0x8486CAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8486B2_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8486B2u: goto L_8486B2;
    case 0x8486B5u: goto L_8486B5;
    case 0x8486B7u: goto L_8486B7;
    case 0x8486B9u: goto L_8486B9;
    case 0x8486BAu: goto L_8486BA;
    case 0x8486BBu: goto L_8486BB;
    case 0x8486BEu: goto L_8486BE;
    case 0x8486BFu: goto L_8486BF;
    case 0x8486C2u: goto L_8486C2;
    case 0x8486C4u: goto L_8486C4;
    case 0x8486C5u: goto L_8486C5;
    case 0x8486C9u: goto L_8486C9;
    case 0x8486CAu: goto L_8486CA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8486B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B2 LDX
    cpu.setX(0xAC0u, 16);
    goto L_8486B5;
L_8486B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8486B7;
L_8486B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B7 BEQ -> $8486C5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8486C5; }
    goto L_8486B9;
L_8486B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486B9 TXA
    cpu.transfer("TXA");
    goto L_8486BA;
L_8486BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BA CLC
    cpu.setFlag('C', false);
    goto L_8486BB;
L_8486BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BB ADC
    cpu.adc(0x50u);
    goto L_8486BE;
L_8486BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BE TAX
    cpu.transfer("TAX");
    goto L_8486BF;
L_8486BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486BF CPX
    cpu.compareX(0x1790u);
    goto L_8486C2;
L_8486C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C2 BCC -> $8486B5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8486B5; }
    goto L_8486C4;
L_8486C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486C4u);return;} hw.unresolvedReturn(0x8486C4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8486C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486C5 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8486C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8486C9;
L_8486C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86C9u,0x8486C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8486C9 CLC
    cpu.setFlag('C', false);
    goto L_8486CA;
L_8486CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8486CA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8486CAu);return;} hw.unresolvedReturn(0x8486CAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_84880A_E0M1X1C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x84880Au: goto L_84880A;
    case 0x84880Cu: goto L_84880C;
    case 0x84880Eu: goto L_84880E;
    case 0x84880Fu: goto L_84880F;
    case 0x848811u: goto L_848811;
    case 0x848812u: goto L_848812;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_84880A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84880C;
L_84880C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880C AND
    cpu.logicAnd(0x1Fu);
    goto L_84880E;
L_84880E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880E LSR
    cpu.lsrA();
    goto L_84880F;
L_84880F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x880Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x880Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84880F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_848811;
L_848811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8811u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848811 CLC
    cpu.setFlag('C', false);
    goto L_848812;
L_848812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8812u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848812 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x848812u);return;} hw.unresolvedReturn(0x848812u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_849081_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849081u: goto L_849081;
    case 0x849084u: goto L_849084;
    case 0x849085u: goto L_849085;
    case 0x849089u: goto L_849089;
    case 0x84908Bu: goto L_84908B;
    case 0x84908Eu: goto L_84908E;
    case 0x849090u: goto L_849090;
    case 0x849092u: goto L_849092;
    case 0x849094u: goto L_849094;
    case 0x849096u: goto L_849096;
    case 0x849098u: goto L_849098;
    case 0x84909Bu: goto L_84909B;
    case 0x84909Du: goto L_84909D;
    case 0x84909Fu: goto L_84909F;
    case 0x8490A2u: goto L_8490A2;
    case 0x8490A5u: goto L_8490A5;
    case 0x8490A9u: goto L_8490A9;
    case 0x8490ABu: goto L_8490AB;
    case 0x8490AEu: goto L_8490AE;
    case 0x8490B0u: goto L_8490B0;
    case 0x8490B3u: goto L_8490B3;
    case 0x8490B7u: goto L_8490B7;
    case 0x8490B8u: goto L_8490B8;
    case 0x8490B9u: goto L_8490B9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849081:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9081u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9081u, 6u, 3u, cpu.address("abs", 0x9246u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849081 JSR -> $849246 stack real
    { cpu.push16Value(hw,0x9083u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9084u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9246u), 0x849081u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849084;
L_849084:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9084u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9084u,0x849084u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9084u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849084 TXY
    cpu.transfer("TXY");
    goto L_849085;
L_849085:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9085u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9085u, 8u, 4u, 0x848699u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849085 JSL -> $848699 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9088u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9089u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848699u, 0x849085u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849089;
L_849089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9089u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849089 BCS -> $8490B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8490B8; }
    goto L_84908B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9089u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849089 BCS -> $8490B8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8490B8; }
    goto L_84908B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9089u,0x849089u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84908B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908B LDA
    cpu.setA(0x20u, 16);
    goto L_84908E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908B LDA
    cpu.setA(0x20u, 16);
    goto L_84908E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x908Bu,0x84908Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84908E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x908Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849090;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x908Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84908E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849090;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x908Eu,0x84908Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849090:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9090u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849090 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849092;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9090u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849090 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849092;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9090u,0x849090u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9092u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849092 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849094;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9092u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849092 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849094;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9092u,0x849092u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9094u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849094 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849096;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9094u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849094 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849096;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9094u,0x849094u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9096u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849096 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849098;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9096u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849096 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_849098;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9096u,0x849096u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849098:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9098u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849098 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84909B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9098u, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849098 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84909B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9098u,0x849098u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84909B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84909D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909B STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84909D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x909Bu,0x84909Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84909D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909D STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_84909F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909D STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_84909F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x909Du,0x84909Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84909F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x909Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909F LDY
    cpu.setY(0x8F4Cu, 16);
    goto L_8490A2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x909Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84909F LDY
    cpu.setY(0x8F4Cu, 16);
    goto L_8490A2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x909Fu,0x84909Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A2 LDA
    cpu.setA(0x1u, 16);
    goto L_8490A5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A2 LDA
    cpu.setA(0x1u, 16);
    goto L_8490A5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A2u,0x8490A2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490A5 JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8490A5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8490A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A5u, 8u, 4u, 0x80C39Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490A5 JSL -> $80C39F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90A8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90A9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C39Fu, 0x8490A5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8490A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A5u,0x8490A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8490AB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490A9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8490AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90A9u,0x8490A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490AE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ABu, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8490AE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90ABu,0x8490ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90AEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AE BMI -> $8490B7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8490B7; }
    goto L_8490B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90AEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490AE BMI -> $8490B7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8490B7; }
    goto L_8490B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90AEu,0x8490AEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B0 LDA
    cpu.setA(0x2Eu, 16);
    goto L_8490B3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B0 LDA
    cpu.setA(0x2Eu, 16);
    goto L_8490B3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B0u,0x8490B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B3 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90B7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x8490B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8490B7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B3u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B3 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x90B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90B7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x8490B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8490B7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B3u,0x8490B3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8490B7u);return;} hw.unresolvedReturn(0x8490B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B7 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8490B7u);return;} hw.unresolvedReturn(0x8490B7u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B7u,0x8490B7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B8 TYX
    cpu.transfer("TYX");
    goto L_8490B9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8490B8 TYX
    cpu.transfer("TYX");
    goto L_8490B9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B8u,0x8490B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8490B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90B9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8490B9u);return;} hw.unresolvedReturn(0x8490B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8490B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8490B9u);return;} hw.unresolvedReturn(0x8490B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90B9u,0x8490B9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

