#include "generated.hpp"
void sub_208731_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x208731u: goto L_208731;
    case 0x208732u: goto L_208732;
    case 0x208735u: goto L_208735;
    case 0x208737u: goto L_208737;
    case 0x208739u: goto L_208739;
    case 0x20873Bu: goto L_20873B;
    case 0x20873Eu: goto L_20873E;
    case 0x20873Fu: goto L_20873F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_208731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $208731 PHA
    cpu.push("PHA", hw);
    goto L_208732;
L_208732:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8732u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8732u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208732 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_208735;
L_208735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8735u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208735 AND
    cpu.logicAnd(0x80u);
    goto L_208737;
L_208737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208737 CMP
    cpu.compareA(0x80u);
    goto L_208739;
L_208739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208739 BNE -> $208732
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_208732; }
    goto L_20873B;
L_20873B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Bu, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20873B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_20873E;
L_20873E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $20873E PLA
    cpu.pop("PLA", hw);
    goto L_20873F;
L_20873F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x873Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x873Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20873F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x20873Fu);return;} hw.unresolvedReturn(0x20873Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809B1F_E0M0X0CQ_part14(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D66u: goto L_809D66;
    case 0x809D68u: goto L_809D68;
    case 0x809D6Bu: goto L_809D6B;
    case 0x809D6Cu: goto L_809D6C;
    case 0x809D6Du: goto L_809D6D;
    case 0x809D6Fu: goto L_809D6F;
    case 0x809D72u: goto L_809D72;
    case 0x809D74u: goto L_809D74;
    case 0x809D77u: goto L_809D77;
    case 0x809D79u: goto L_809D79;
    case 0x809D7Au: goto L_809D7A;
    case 0x809D7Du: goto L_809D7D;
    case 0x809D80u: goto L_809D80;
    case 0x809D82u: goto L_809D82;
    case 0x809D85u: goto L_809D85;
    case 0x809D86u: goto L_809D86;
    case 0x809D88u: goto L_809D88;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D66u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D66u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D66 BPL -> $809D6B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D6B; }
    goto L_809D68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D66u,0x809D66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D68u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D68u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D68u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D68 ORA
    cpu.logicOr(0xFFu);
    goto L_809D6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D68u,0x809D68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6B XBA
    cpu.xba();
    goto L_809D6C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D6Bu,0x809D6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6C CLC
    cpu.setFlag('C', false);
    goto L_809D6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D6Cu,0x809D6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_809D6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D6Du,0x809D6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D6Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D6F CMP
    cpu.compareA(0xF0u);
    goto L_809D72;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D6Fu,0x809D6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D72u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D72u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D72u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D72 BCC -> $809D79
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809D79; }
    goto L_809D74;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D72u,0x809D72u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D74u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D74u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D74 CMP
    cpu.compareA(0xFFF0u);
    goto L_809D77;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D74u,0x809D74u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D77u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D77 BCC -> $809D51
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809D51u,0x809D77u); return; }
    goto L_809D79;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D77u,0x809D77u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D79u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D79u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D79u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D79 TAY
    cpu.transfer("TAY");
    goto L_809D7A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D79u,0x809D79u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Au, 5u + 1u, 3u, cpu.address("absx", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D7A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D7D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D7Au,0x809D7Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D7Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D7Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D7D AND
    cpu.logicAnd(0xFF00u);
    goto L_809D80;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D7Du,0x809D7Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D80u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D80u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D80 BPL -> $809D85
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809D85; }
    goto L_809D82;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D80u,0x809D80u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D82u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D82u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D82 ORA
    cpu.logicOr(0x1u);
    goto L_809D85;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D82u,0x809D82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D85u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D85u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D85u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D85 XBA
    cpu.xba();
    goto L_809D86;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D85u,0x809D85u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D86u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D86u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D86u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D86 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_809D88;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D86u,0x809D86u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D88u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D88u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D88 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D8Au,0x809D88u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D88u,0x809D88u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DD5_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E31u: goto L_809E31;
    case 0x809E33u: goto L_809E33;
    case 0x809E34u: goto L_809E34;
    case 0x809E36u: goto L_809E36;
    case 0x809E39u: goto L_809E39;
    case 0x809E3Eu: goto L_809E3E;
    case 0x809E40u: goto L_809E40;
    case 0x809E41u: goto L_809E41;
    case 0x809E42u: goto L_809E42;
    case 0x809E44u: goto L_809E44;
    case 0x809E46u: goto L_809E46;
    case 0x809E49u: goto L_809E49;
    case 0x809E4Bu: goto L_809E4B;
    case 0x809E4Cu: goto L_809E4C;
    case 0x809E4Du: goto L_809E4D;
    case 0x809E4Eu: goto L_809E4E;
    case 0x809E4Fu: goto L_809E4F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E31u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E31 SEP
    cpu.sep(0x20u);
    goto L_809E33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E31u,0x809E31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E33 ASL
    cpu.aslA();
    goto L_809E34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E33u,0x809E33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E34u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E34u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E34 BPL -> $809E39
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809E39; }
    goto L_809E36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E34u,0x809E34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 3u, 3u, cpu.address("abs", 0x9F9Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E36 JMP -> $809F9D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9F9Du),0x809E36u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x809E36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E39u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u, 3u, 3u, cpu.address("abs", 0x9EC9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E39 JMP -> $809EC9
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9EC9u),0x809E39u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E39u,0x809E39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E3E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809E40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E3Eu,0x809E3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E40u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E40 INY
    cpu.inc('Y');
    goto L_809E41;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E40u,0x809E40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E41u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E41u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E41 INY
    cpu.inc('Y');
    goto L_809E42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E41u,0x809E41u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E42u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E42u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E42 BRA -> $809DF4
    hw.requestDispatch(0x809DF4u,0x809E42u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E42u,0x809E42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E44u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E44 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809E46;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E44 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809E46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E44u,0x809E44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E46u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E46 LDY
    cpu.setY(0xF0F0u, 16);
    goto L_809E49;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E46 LDY
    cpu.setY(0xF0F0u, 16);
    goto L_809E49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E46u,0x809E46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E49u))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E49 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E4B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E49 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E49u,0x809E49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Bu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4B PHY
    cpu.push("PHY", hw);
    goto L_809E4C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4B PHY
    cpu.push("PHY", hw);
    goto L_809E4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Bu,0x809E4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Cu))return;
  // 10 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4C PHY
    cpu.push("PHY", hw);
    goto L_809E4D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4C PHY
    cpu.push("PHY", hw);
    goto L_809E4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,0x809E4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4D SEC
    cpu.setFlag('C', true);
    goto L_809E4E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4D SEC
    cpu.setFlag('C', true);
    goto L_809E4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Du,0x809E4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Eu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4E ROR
    cpu.rorA();
    goto L_809E4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Eu,0x809E4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Fu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4F LSR
    cpu.lsrA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E50u,0x809E4Fu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Fu,0x809E4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DBC_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809E31u: goto L_809E31;
    case 0x809E33u: goto L_809E33;
    case 0x809E34u: goto L_809E34;
    case 0x809E36u: goto L_809E36;
    case 0x809E39u: goto L_809E39;
    case 0x809E3Eu: goto L_809E3E;
    case 0x809E40u: goto L_809E40;
    case 0x809E41u: goto L_809E41;
    case 0x809E42u: goto L_809E42;
    case 0x809E44u: goto L_809E44;
    case 0x809E46u: goto L_809E46;
    case 0x809E49u: goto L_809E49;
    case 0x809E4Bu: goto L_809E4B;
    case 0x809E4Cu: goto L_809E4C;
    case 0x809E4Du: goto L_809E4D;
    case 0x809E4Eu: goto L_809E4E;
    case 0x809E4Fu: goto L_809E4F;
    case 0x809E50u: goto L_809E50;
    case 0x809E52u: goto L_809E52;
    case 0x809E54u: goto L_809E54;
    case 0x809E56u: goto L_809E56;
    case 0x809E57u: goto L_809E57;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809E31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E31u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E31u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E31 SEP
    cpu.sep(0x20u);
    goto L_809E33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E31u,0x809E31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E33u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E33 ASL
    cpu.aslA();
    goto L_809E34;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E33u,0x809E33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E34u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E34u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E34 BPL -> $809E39
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_809E39; }
    goto L_809E36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E34u,0x809E34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E36u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E36u, 3u, 3u, cpu.address("abs", 0x9F9Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E36 JMP -> $809F9D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9F9Du),0x809E36u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E36u,0x809E36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E39u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E39u, 3u, 3u, cpu.address("abs", 0x9EC9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E39 JMP -> $809EC9
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9EC9u),0x809E39u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E39u,0x809E39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E3Eu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E3Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E3E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809E40;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E3Eu,0x809E3Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E40u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E40 INY
    cpu.inc('Y');
    goto L_809E41;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E40u,0x809E40u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E41u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E41u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E41 INY
    cpu.inc('Y');
    goto L_809E42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E41u,0x809E41u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E42u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E42u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E42u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E42 BRA -> $809DF4
    hw.requestDispatch(0x809DF4u,0x809E42u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E42u,0x809E42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E44u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E44u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E44 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809E46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E44u,0x809E44u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E46u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E46 LDY
    cpu.setY(0xF0F0u, 16);
    goto L_809E49;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E46u,0x809E46u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E49u))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E49u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E49 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809E4B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E49u,0x809E49u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Bu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4B PHY
    cpu.push("PHY", hw);
    goto L_809E4C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Bu,0x809E4Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Cu))return;
  // 7 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809E4C PHY
    cpu.push("PHY", hw);
    goto L_809E4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Cu,0x809E4Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Du))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4D SEC
    cpu.setFlag('C', true);
    goto L_809E4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Du,0x809E4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Eu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4E ROR
    cpu.rorA();
    goto L_809E4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Eu,0x809E4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E4Fu))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E4F LSR
    cpu.lsrA();
    goto L_809E50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E4Fu,0x809E4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E50u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E50u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E50 BCC -> $809E4B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_809E4B; }
    goto L_809E52;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E50u,0x809E50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E52u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E52u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E52u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E52 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_809E54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E52u,0x809E52u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E54u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E54u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E54 LDA
    cpu.setA(0x55u, 8);
    goto L_809E56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E54u,0x809E54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E56u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E56 INX
    cpu.inc('X');
    goto L_809E57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E56u,0x809E56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809E57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E57u))return;
  // 6 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E57u,cpu,0xE4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809E57 CPX
    cpu.compareX(hw.readW(cpu.address("dp", 0x1Eu), cpu.x8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E59u,0x809E57u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E57u,0x809E57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A436_E0M0X0CQ_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A60Cu: goto L_80A60C;
    case 0x80A60Eu: goto L_80A60E;
    case 0x80A610u: goto L_80A610;
    case 0x80A611u: goto L_80A611;
    case 0x80A614u: goto L_80A614;
    case 0x80A617u: goto L_80A617;
    case 0x80A619u: goto L_80A619;
    case 0x80A61Cu: goto L_80A61C;
    case 0x80A61Eu: goto L_80A61E;
    case 0x80A61Fu: goto L_80A61F;
    case 0x80A621u: goto L_80A621;
    case 0x80A622u: goto L_80A622;
    case 0x80A625u: goto L_80A625;
    case 0x80A627u: goto L_80A627;
    case 0x80A628u: goto L_80A628;
    case 0x80A629u: goto L_80A629;
    case 0x80A62Au: goto L_80A62A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A60C REP
    cpu.rep(0x20u);
    goto L_80A60E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA60Cu,0x80A60Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A60E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A610;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA60Eu,0x80A60Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA610u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A610 CLC
    cpu.setFlag('C', false);
    goto L_80A611;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA610u,0x80A610u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA611u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA611u, 5u + 1u, 3u, cpu.address("absy", 0x3000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A611 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0x3000u), cpu.m8?8:16));
    goto L_80A614;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA611u,0x80A611u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA614u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA614u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A614 CMP
    cpu.compareA(0x50u);
    goto L_80A617;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA614u,0x80A614u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA617u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA617u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA617u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A617 BCC -> $80A5FF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80A5FFu,0x80A617u); return; }
    goto L_80A619;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA617u,0x80A617u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A619 CMP
    cpu.compareA(0xE0u);
    goto L_80A61C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA619u,0x80A619u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A61C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A61C BCS -> $80A5FF
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80A5FFu,0x80A61Cu); return; }
    goto L_80A61E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Cu,0x80A61Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A61E TAX
    cpu.transfer("TAX");
    goto L_80A61F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Eu,0x80A61Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A61F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A621;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA61Fu,0x80A61Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA621u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A621 SEC
    cpu.setFlag('C', true);
    goto L_80A622;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA621u,0x80A621u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 5u + 1u, 3u, cpu.address("absy", 0x1800u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A622 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1800u), cpu.m8?8:16));
    goto L_80A625;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA622u,0x80A622u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A625 SEP
    cpu.sep(0x20u);
    goto L_80A627;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA625u,0x80A625u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA627u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA627u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A627 PHA
    cpu.push("PHA", hw);
    goto L_80A628;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA627u,0x80A627u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA628u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA628u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A628 TXA
    cpu.transfer("TXA");
    goto L_80A629;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA628u,0x80A628u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA629u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A629 PHA
    cpu.push("PHA", hw);
    goto L_80A62A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA629u,0x80A629u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Au, 4u + 1u, 3u, cpu.address("absy", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A62A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4800u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA62Du,0x80A62Au); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA62Au,0x80A62Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B0D1_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B0D1u: goto L_82B0D1;
    case 0x82B0D4u: goto L_82B0D4;
    case 0x82B0D7u: goto L_82B0D7;
    case 0x82B0D9u: goto L_82B0D9;
    case 0x82B0DDu: goto L_82B0DD;
    case 0x82B0DEu: goto L_82B0DE;
    case 0x82B0E0u: goto L_82B0E0;
    case 0x82B0E4u: goto L_82B0E4;
    case 0x82B0E7u: goto L_82B0E7;
    case 0x82B0E9u: goto L_82B0E9;
    case 0x82B0EBu: goto L_82B0EB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B0D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D1u, 5u, 3u, cpu.address("abs", 0x1F50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F50u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0D4;
L_82B0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D4u, 5u, 3u, cpu.address("abs", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B00u), cpu.m8?8:16));
    goto L_82B0D7;
L_82B0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D7 BEQ -> $82B0DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0DE; }
    goto L_82B0D9;
L_82B0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u, 8u, 4u, 0x80E256u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0D9 JSL -> $80E256 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0DDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E256u, 0x82B0D9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0DD;
L_82B0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0DDu,0x82B0DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0DDu);return;} hw.unresolvedReturn(0x82B0DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0DE STZ
    hw.write(cpu.address("dp", 0x66u), 0, cpu.m8?8:16);
    goto L_82B0E0;
L_82B0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0E0 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0E4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x82B0E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0E4;
L_82B0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0E4u,0x82B0E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E4 LDA
    cpu.setA(0x1u, 16);
    goto L_82B0E7;
L_82B0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E7 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_82B0E9;
L_82B0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E9 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B0EB;
L_82B0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0EB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0EBu);return;} hw.unresolvedReturn(0x82B0EBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B0D1_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B0D1u: goto L_82B0D1;
    case 0x82B0D4u: goto L_82B0D4;
    case 0x82B0D7u: goto L_82B0D7;
    case 0x82B0D9u: goto L_82B0D9;
    case 0x82B0DDu: goto L_82B0DD;
    case 0x82B0DEu: goto L_82B0DE;
    case 0x82B0E0u: goto L_82B0E0;
    case 0x82B0E4u: goto L_82B0E4;
    case 0x82B0E7u: goto L_82B0E7;
    case 0x82B0E9u: goto L_82B0E9;
    case 0x82B0EBu: goto L_82B0EB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B0D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D1u, 5u, 3u, cpu.address("abs", 0x1F50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1F50u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B0D4;
L_82B0D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D4u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D4u, 5u, 3u, cpu.address("abs", 0x1B00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D4 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B00u), cpu.m8?8:16));
    goto L_82B0D7;
L_82B0D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0D7 BEQ -> $82B0DE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B0DE; }
    goto L_82B0D9;
L_82B0D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0D9u, 8u, 4u, 0x80E256u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0D9 JSL -> $80E256 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0DDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80E256u, 0x82B0D9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0DD;
L_82B0DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0DDu,0x82B0DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0DDu);return;} hw.unresolvedReturn(0x82B0DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B0DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0DEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x66u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0DE STZ
    hw.write(cpu.address("dp", 0x66u), 0, cpu.m8?8:16);
    goto L_82B0E0;
L_82B0E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E0u, 8u, 4u, 0x809979u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0E0 JSL -> $809979 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB0E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB0E4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809979u, 0x82B0E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B0E4;
L_82B0E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB0E4u,0x82B0E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E4 LDA
    cpu.setA(0x1u, 16);
    goto L_82B0E7;
L_82B0E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E7 STA
    hw.write(cpu.address("dp", 0x86u), cpu.a, cpu.m8?8:16);
    goto L_82B0E9;
L_82B0E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0E9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B0E9 INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B0EB;
L_82B0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EBu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB0EBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B0EB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B0EBu);return;} hw.unresolvedReturn(0x82B0EBu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B47D_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B47Du: goto L_82B47D;
    case 0x82B47Eu: goto L_82B47E;
    case 0x82B47Fu: goto L_82B47F;
    case 0x82B481u: goto L_82B481;
    case 0x82B483u: goto L_82B483;
    case 0x82B484u: goto L_82B484;
    case 0x82B487u: goto L_82B487;
    case 0x82B48Au: goto L_82B48A;
    case 0x82B48Bu: goto L_82B48B;
    case 0x82B48Cu: goto L_82B48C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B47D PHA
    cpu.push("PHA", hw);
    goto L_82B47E;
L_82B47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B47E TYA
    cpu.transfer("TYA");
    goto L_82B47F;
L_82B47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B47F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B481;
L_82B481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B481 BEQ -> $82B487
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B487; }
    goto L_82B483;
L_82B483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB483u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB483u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B483 CLC
    cpu.setFlag('C', false);
    goto L_82B484;
L_82B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B484 ADC
    cpu.adc(0x200u);
    goto L_82B487;
L_82B487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB487u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u, 6u, 3u, cpu.address("absy", 0x1C4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B487 STA
    hw.write(cpu.address("absy", 0x1C4Cu), cpu.a, cpu.m8?8:16);
    goto L_82B48A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u, 6u, 3u, cpu.address("absy", 0x1C4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B487 STA
    hw.write(cpu.address("absy", 0x1C4Cu), cpu.a, cpu.m8?8:16);
    goto L_82B48A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB487u,0x82B487u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B48A TAY
    cpu.transfer("TAY");
    goto L_82B48B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B48A TAY
    cpu.transfer("TAY");
    goto L_82B48B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB48Au,0x82B48Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48B PLA
    cpu.pop("PLA", hw);
    goto L_82B48C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48B PLA
    cpu.pop("PLA", hw);
    goto L_82B48C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB48Bu,0x82B48Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B48Cu);return;} hw.unresolvedReturn(0x82B48Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B48Cu);return;} hw.unresolvedReturn(0x82B48Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB48Cu,0x82B48Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82B47D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B47Du: goto L_82B47D;
    case 0x82B47Eu: goto L_82B47E;
    case 0x82B47Fu: goto L_82B47F;
    case 0x82B481u: goto L_82B481;
    case 0x82B483u: goto L_82B483;
    case 0x82B484u: goto L_82B484;
    case 0x82B487u: goto L_82B487;
    case 0x82B48Au: goto L_82B48A;
    case 0x82B48Bu: goto L_82B48B;
    case 0x82B48Cu: goto L_82B48C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B47D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B47D PHA
    cpu.push("PHA", hw);
    goto L_82B47E;
L_82B47E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B47E TYA
    cpu.transfer("TYA");
    goto L_82B47F;
L_82B47F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB47Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB47Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B47F LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B481;
L_82B481:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB481u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB481u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B481 BEQ -> $82B487
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B487; }
    goto L_82B483;
L_82B483:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB483u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB483u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB483u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B483 CLC
    cpu.setFlag('C', false);
    goto L_82B484;
L_82B484:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB484u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB484u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B484 ADC
    cpu.adc(0x200u);
    goto L_82B487;
L_82B487:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB487u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB487u, 6u, 3u, cpu.address("absy", 0x1C4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B487 STA
    hw.write(cpu.address("absy", 0x1C4Cu), cpu.a, cpu.m8?8:16);
    goto L_82B48A;
L_82B48A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B48A TAY
    cpu.transfer("TAY");
    goto L_82B48B;
L_82B48B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48B PLA
    cpu.pop("PLA", hw);
    goto L_82B48C;
L_82B48C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB48Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB48Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B48C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B48Cu);return;} hw.unresolvedReturn(0x82B48Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E622_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E622u: goto L_82E622;
    case 0x82E623u: goto L_82E623;
    case 0x82E627u: goto L_82E627;
    case 0x82E628u: goto L_82E628;
    case 0x82E62Cu: goto L_82E62C;
    case 0x82E630u: goto L_82E630;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE622u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE622u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E622 PHA
    cpu.push("PHA", hw);
    goto L_82E623;
L_82E623:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE623u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE623u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE623u, 8u, 4u, 0x8098B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E623 JSL -> $8098B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE626u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE627u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B4u, 0x82E623u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E627;
L_82E627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE627u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE627u,0x82E627u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE627u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE627u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E627 PLA
    cpu.pop("PLA", hw);
    goto L_82E628;
L_82E628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE628u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE628u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E628 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE62Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE62Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x82E628u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E62C;
L_82E62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE62Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE62Cu,0x82E62Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Cu, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E62C JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE62Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE630u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x82E62Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E630;
L_82E630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE630u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE630u,0x82E630u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE630u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE630u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E630 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82E630u);return;} hw.unresolvedReturn(0x82E630u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8390E9_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8390E7u: goto L_8390E7;
    case 0x8390E8u: goto L_8390E8;
    case 0x8390E9u: goto L_8390E9;
    case 0x8390ECu: goto L_8390EC;
    case 0x8390EFu: goto L_8390EF;
    case 0x8390F1u: goto L_8390F1;
    case 0x8390F4u: goto L_8390F4;
    case 0x8390F6u: goto L_8390F6;
    case 0x8390F9u: goto L_8390F9;
    case 0x8390FBu: goto L_8390FB;
    case 0x8390FEu: goto L_8390FE;
    case 0x839100u: goto L_839100;
    case 0x839103u: goto L_839103;
    case 0x839105u: goto L_839105;
    case 0x839106u: goto L_839106;
    case 0x839108u: goto L_839108;
    case 0x83910Bu: goto L_83910B;
    case 0x83910Cu: goto L_83910C;
    case 0x83910Fu: goto L_83910F;
    case 0x839110u: goto L_839110;
    case 0x839112u: goto L_839112;
    case 0x839115u: goto L_839115;
    case 0x839118u: goto L_839118;
    case 0x83911Au: goto L_83911A;
    case 0x83911Du: goto L_83911D;
    case 0x839120u: goto L_839120;
    case 0x839122u: goto L_839122;
    case 0x839125u: goto L_839125;
    case 0x839127u: goto L_839127;
    case 0x83912Au: goto L_83912A;
    case 0x83912Cu: goto L_83912C;
    case 0x83912Fu: goto L_83912F;
    case 0x839130u: goto L_839130;
    case 0x839133u: goto L_839133;
    case 0x839135u: goto L_839135;
    case 0x839138u: goto L_839138;
    case 0x83913Au: goto L_83913A;
    case 0x83913Bu: goto L_83913B;
    case 0x83913Eu: goto L_83913E;
    case 0x839141u: goto L_839141;
    case 0x839143u: goto L_839143;
    case 0x839146u: goto L_839146;
    case 0x839149u: goto L_839149;
    case 0x83914Bu: goto L_83914B;
    case 0x83914Du: goto L_83914D;
    case 0x83914Eu: goto L_83914E;
    case 0x83914Fu: goto L_83914F;
    case 0x839150u: goto L_839150;
    case 0x839152u: goto L_839152;
    case 0x839155u: goto L_839155;
    case 0x839158u: goto L_839158;
    case 0x83915Bu: goto L_83915B;
    case 0x83915Du: goto L_83915D;
    case 0x83915Fu: goto L_83915F;
    case 0x839161u: goto L_839161;
    case 0x839164u: goto L_839164;
    case 0x839167u: goto L_839167;
    case 0x839169u: goto L_839169;
    case 0x83916Bu: goto L_83916B;
    case 0x83916Cu: goto L_83916C;
    case 0x83916Fu: goto L_83916F;
    case 0x839171u: goto L_839171;
    case 0x839173u: goto L_839173;
    case 0x839174u: goto L_839174;
    case 0x839177u: goto L_839177;
    case 0x839179u: goto L_839179;
    case 0x83917Bu: goto L_83917B;
    case 0x83917Eu: goto L_83917E;
    case 0x839180u: goto L_839180;
    case 0x839183u: goto L_839183;
    case 0x839184u: goto L_839184;
    case 0x839187u: goto L_839187;
    case 0x839189u: goto L_839189;
    case 0x83918Bu: goto L_83918B;
    case 0x83918Du: goto L_83918D;
    case 0x83918Fu: goto L_83918F;
    case 0x839192u: goto L_839192;
    case 0x839194u: goto L_839194;
    case 0x839196u: goto L_839196;
    case 0x839198u: goto L_839198;
    case 0x83919Au: goto L_83919A;
    case 0x83919Cu: goto L_83919C;
    case 0x83919Du: goto L_83919D;
    case 0x8391A0u: goto L_8391A0;
    case 0x8391A2u: goto L_8391A2;
    case 0x8391A5u: goto L_8391A5;
    case 0x8391A8u: goto L_8391A8;
    case 0x8391AAu: goto L_8391AA;
    case 0x8391ADu: goto L_8391AD;
    case 0x8391B0u: goto L_8391B0;
    case 0x8391B1u: goto L_8391B1;
    case 0x8391B3u: goto L_8391B3;
    case 0x8391B6u: goto L_8391B6;
    case 0x8391B8u: goto L_8391B8;
    case 0x8391BBu: goto L_8391BB;
    case 0x8391BCu: goto L_8391BC;
    case 0x8391BFu: goto L_8391BF;
    case 0x8391C1u: goto L_8391C1;
    case 0x8391C4u: goto L_8391C4;
    case 0x8391C7u: goto L_8391C7;
    case 0x8391C9u: goto L_8391C9;
    case 0x8391CCu: goto L_8391CC;
    case 0x8391CFu: goto L_8391CF;
    case 0x8391D0u: goto L_8391D0;
    case 0x8391D2u: goto L_8391D2;
    case 0x8391D5u: goto L_8391D5;
    case 0x8391D7u: goto L_8391D7;
    case 0x8391DAu: goto L_8391DA;
    case 0x8391DDu: goto L_8391DD;
    case 0x8391DFu: goto L_8391DF;
    case 0x8391E2u: goto L_8391E2;
    case 0x8391E3u: goto L_8391E3;
    case 0x8391E6u: goto L_8391E6;
    case 0x8391E8u: goto L_8391E8;
    case 0x8391EBu: goto L_8391EB;
    case 0x8391EEu: goto L_8391EE;
    case 0x8391F0u: goto L_8391F0;
    case 0x8391F3u: goto L_8391F3;
    case 0x8391F6u: goto L_8391F6;
    case 0x8391F8u: goto L_8391F8;
    case 0x8391FAu: goto L_8391FA;
    case 0x8391FDu: goto L_8391FD;
    case 0x8391FEu: goto L_8391FE;
    case 0x839201u: goto L_839201;
    case 0x839203u: goto L_839203;
    case 0x839204u: goto L_839204;
    case 0x839207u: goto L_839207;
    case 0x839209u: goto L_839209;
    case 0x83920Au: goto L_83920A;
    case 0x83920Du: goto L_83920D;
    case 0x83920Fu: goto L_83920F;
    case 0x839212u: goto L_839212;
    case 0x839213u: goto L_839213;
    case 0x839216u: goto L_839216;
    case 0x839218u: goto L_839218;
    case 0x83921Au: goto L_83921A;
    case 0x83921Bu: goto L_83921B;
    case 0x83921Cu: goto L_83921C;
    case 0x83921Fu: goto L_83921F;
    case 0x839221u: goto L_839221;
    case 0x839222u: goto L_839222;
    case 0x839224u: goto L_839224;
    case 0x839226u: goto L_839226;
    case 0x839228u: goto L_839228;
    case 0x839229u: goto L_839229;
    case 0x83922Au: goto L_83922A;
    case 0x83922Cu: goto L_83922C;
    case 0x83922Fu: goto L_83922F;
    case 0x839231u: goto L_839231;
    case 0x839234u: goto L_839234;
    case 0x839235u: goto L_839235;
    case 0x839238u: goto L_839238;
    case 0x839239u: goto L_839239;
    case 0x83923Cu: goto L_83923C;
    case 0x83923Eu: goto L_83923E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8390E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E7 CLC
    cpu.setFlag('C', false);
    goto L_8390E8;
L_8390E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8390E8u);return;} hw.unresolvedReturn(0x8390E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8390E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390EC;
L_8390EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16));
    goto L_8390EF;
L_8390EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EF BNE -> $8390E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390E7; }
    goto L_8390F1;
L_8390F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F4;
L_8390F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F4 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390F6;
L_8390F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F9;
L_8390F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F9 BMI -> $839130
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390FB;
L_8390FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FB CMP
    cpu.compareA(0x300u);
    goto L_8390FE;
L_8390FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FE BCC -> $839130
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839100;
L_839100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839100 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839103;
L_839103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839103 BMI -> $839108
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839108; }
    goto L_839105;
L_839105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839105 DEC
    cpu.decReg('A');
    goto L_839106;
L_839106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839106 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839108;
L_839108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839108 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83910B;
L_83910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910B CLC
    cpu.setFlag('C', false);
    goto L_83910C;
L_83910C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910C ADC
    cpu.adc(0x90u);
    goto L_83910F;
L_83910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910F SEC
    cpu.setFlag('C', true);
    goto L_839110;
L_839110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839110 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839112;
L_839112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839112 AND
    cpu.logicAnd(0xF0u);
    goto L_839115;
L_839115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839115 CMP
    cpu.compareA(0x20u);
    goto L_839118;
L_839118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839118 BCS -> $839130
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_83911A;
L_83911A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911A CMP
    cpu.compareA(0x10u);
    goto L_83911D;
L_83911D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911D LDA
    cpu.setA(0x10u, 16);
    goto L_839120;
L_839120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839120 BCS -> $839125
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839125; }
    goto L_839122;
L_839122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839122 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_839125;
L_839125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839125 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_839127;
L_839127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839127 LDA
    cpu.setA(0x4u, 16);
    goto L_83912A;
L_83912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912A STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_83912C;
L_83912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912C STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_83912F;
L_83912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83912F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83912Fu);return;} hw.unresolvedReturn(0x83912Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9130u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839130 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839133;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839130 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839133;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9130u,0x839130u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9133u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839133 BPL -> $839138
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839138; }
    goto L_839135;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839133 BPL -> $839138
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839138; }
    goto L_839135;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9133u,0x839133u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9135u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 3u, 3u, cpu.address("abs", 0x933Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839135 JMP -> $83933F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x933Fu),0x839135u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 3u, 3u, cpu.address("abs", 0x933Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839135 JMP -> $83933F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x933Fu),0x839135u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9135u,0x839135u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839138 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83913A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839138 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83913A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9138u,0x839138u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913A SEC
    cpu.setFlag('C', true);
    goto L_83913B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913A SEC
    cpu.setFlag('C', true);
    goto L_83913B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Au,0x83913Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913B SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_83913E;
L_83913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913E AND
    cpu.logicAnd(0xFFu);
    goto L_839141;
L_839141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839141 BNE -> $839146
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839146; }
    goto L_839143;
L_839143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 3u, 3u, cpu.address("abs", 0x91DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839143 JMP -> $8391DA
    goto L_8391DA;
L_839146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839146 AND
    cpu.logicAnd(0x80u);
    goto L_839149;
L_839149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839149 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83914B;
L_83914B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83914D;
L_83914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914D ASL
    cpu.aslA();
    goto L_83914E;
L_83914E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914E ASL
    cpu.aslA();
    goto L_83914F;
L_83914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914F TAY
    cpu.transfer("TAY");
    goto L_839150;
L_839150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839150 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_839152;
L_839152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839152 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839155;
L_839155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839155 AND
    cpu.logicAnd(0xFF00u);
    goto L_839158;
L_839158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 5u + 1u, 3u, cpu.address("absy", 0xD5CFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839158 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5CFu), cpu.m8?8:16));
    goto L_83915B;
L_83915B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83915D;
L_83915D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915D BPL -> $839161
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839161; }
    goto L_83915F;
L_83915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915F DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_839161;
L_839161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839161 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839164;
L_839164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839164 AND
    cpu.logicAnd(0x8000u);
    goto L_839167;
L_839167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839167 BNE -> $839171
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839171; }
    goto L_839169;
L_839169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839169 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83916B;
L_83916B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916B ASL
    cpu.aslA();
    goto L_83916C;
L_83916C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916C ADC
    cpu.adc(0x54u);
    goto L_83916F;
L_83916F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916F BRA -> $839183
    goto L_839183;
L_839171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839171 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839173;
L_839173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839173 ASL
    cpu.aslA();
    goto L_839174;
L_839174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839174 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839177;
L_839177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839177 BMI -> $839180
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839180; }
    goto L_839179;
L_839179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839179 BEQ -> $839183
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839183; }
    goto L_83917B;
L_83917B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917B ADC
    cpu.adc(0x38u);
    goto L_83917E;
L_83917E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917E BRA -> $839183
    goto L_839183;
L_839180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839180 ADC
    cpu.adc(0x1Cu);
    goto L_839183;
L_839183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839183 TAY
    cpu.transfer("TAY");
    goto L_839184;
L_839184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 5u + 1u, 3u, cpu.address("absy", 0xD561u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839184 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD561u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839187;
L_839187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839187 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_839189;
L_839189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839189 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83918B;
L_83918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918B STZ
    hw.write(cpu.address("dp", 0x20u), 0, cpu.m8?8:16);
    goto L_83918D;
L_83918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_83918F;
L_83918F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu, 5u + 1u, 3u, cpu.address("absy", 0xD55Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD55Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839192;
L_839192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839192 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_839194;
L_839194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839194 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839196;
L_839196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839196 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839198;
L_839198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839198 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83919A;
L_83919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919A BEQ -> $8391BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391BB; }
    goto L_83919C;
L_83919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919C SEC
    cpu.setFlag('C', true);
    goto L_83919D;
L_83919D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A0;
L_8391A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A0 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391A2;
L_8391A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A2 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391A5;
L_8391A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A8;
L_8391A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391AA;
L_8391AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AA AND
    cpu.logicAnd(0xFFu);
    goto L_8391AD;
L_8391AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AD STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391B0;
L_8391B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B0 SEC
    cpu.setFlag('C', true);
    goto L_8391B1;
L_8391B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B1 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391B3;
L_8391B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B3 BIT
    cpu.bit(0x80u, true);
    goto L_8391B6;
L_8391B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B6 BEQ -> $8391DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391B8;
L_8391B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391B8u); return;
L_8391BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BB CLC
    cpu.setFlag('C', false);
    goto L_8391BC;
L_8391BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391BF;
L_8391BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391C1;
L_8391C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C1 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391C4;
L_8391C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391C7;
L_8391C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391C9;
L_8391C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C9 AND
    cpu.logicAnd(0xFFu);
    goto L_8391CC;
L_8391CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CC STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391CF;
L_8391CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CF SEC
    cpu.setFlag('C', true);
    goto L_8391D0;
L_8391D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D0 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391D2;
L_8391D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D2 BIT
    cpu.bit(0x80u, true);
    goto L_8391D5;
L_8391D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D5 BNE -> $8391DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391D7;
L_8391D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D7 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391D7u); return;
L_8391DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391DD;
L_8391DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DD BPL -> $8391E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8391E3; }
    goto L_8391DF;
L_8391DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DF EOR
    cpu.logicXor(0xFFFFu);
    goto L_8391E2;
L_8391E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E2 INC
    cpu.inc('A');
    goto L_8391E3;
L_8391E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E3 CMP
    cpu.compareA(0x40u);
    goto L_8391E6;
L_8391E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E6 BCS -> $8391EB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8391EB; }
    goto L_8391E8;
L_8391E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391E8u); return;
L_8391EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391EE;
L_8391EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EE BNE -> $83925F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Fu,0x8391EEu); return; }
    goto L_8391F0;
L_8391F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391F3;
L_8391F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F3 CMP
    cpu.compareA(0x6u);
    goto L_8391F6;
L_8391F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F6 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x8391F6u); return; }
    goto L_8391F8;
L_8391F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391FA;
L_8391FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FA STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8391FD;
L_8391FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FD SEC
    cpu.setFlag('C', true);
    goto L_8391FE;
L_8391FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FE SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_839201;
L_839201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839201 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x839201u); return; }
    goto L_839203;
L_839203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839203 TAY
    cpu.transfer("TAY");
    goto L_839204;
L_839204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839204 AND
    cpu.logicAnd(0x80u);
    goto L_839207;
L_839207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839207 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839209;
L_839209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839209 TYA
    cpu.transfer("TYA");
    goto L_83920A;
L_83920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920A BIT
    cpu.bit(0x80u, true);
    goto L_83920D;
L_83920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920D BEQ -> $839213
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839213; }
    goto L_83920F;
L_83920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920F EOR
    cpu.logicXor(0x7Fu);
    goto L_839212;
L_839212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839212 INC
    cpu.inc('A');
    goto L_839213;
L_839213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839213 AND
    cpu.logicAnd(0x7Fu);
    goto L_839216;
L_839216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839216 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839218;
L_839218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839218 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921A;
L_83921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921A ASL
    cpu.aslA();
    goto L_83921B;
L_83921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921B TAY
    cpu.transfer("TAY");
    goto L_83921C;
L_83921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 5u + 1u, 3u, cpu.address("absy", 0xD665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921F;
L_83921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_839221;
L_839221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839221 TAY
    cpu.transfer("TAY");
    goto L_839222;
L_839222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839222 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_839224;
L_839224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839224 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_839226;
L_839226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839226 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839228;
L_839228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839228 LSR
    cpu.lsrA();
    goto L_839229;
L_839229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839229 DEC
    cpu.decReg('A');
    goto L_83922A;
L_83922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922A BNE -> $839231
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839231; }
    goto L_83922C;
L_83922C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922C LDA
    cpu.setA(0xFFFEu, 16);
    goto L_83922F;
L_83922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_839231;
L_839231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839231 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839234;
L_839234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839234 XBA
    cpu.xba();
    goto L_839235;
L_839235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839235 AND
    cpu.logicAnd(0xFFu);
    goto L_839238;
L_839238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839238 CLC
    cpu.setFlag('C', false);
    goto L_839239;
L_839239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 5u + 1u, 3u, cpu.address("absy", 0xD61Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839239 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD61Fu), cpu.m8?8:16));
    goto L_83923C;
L_83923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83923E;
L_83923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9240u,0x83923Eu); return;
}

void sub_8390E9_E0M0X0C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8390E7u: goto L_8390E7;
    case 0x8390E8u: goto L_8390E8;
    case 0x8390E9u: goto L_8390E9;
    case 0x8390ECu: goto L_8390EC;
    case 0x8390EFu: goto L_8390EF;
    case 0x8390F1u: goto L_8390F1;
    case 0x8390F4u: goto L_8390F4;
    case 0x8390F6u: goto L_8390F6;
    case 0x8390F9u: goto L_8390F9;
    case 0x8390FBu: goto L_8390FB;
    case 0x8390FEu: goto L_8390FE;
    case 0x839100u: goto L_839100;
    case 0x839103u: goto L_839103;
    case 0x839105u: goto L_839105;
    case 0x839106u: goto L_839106;
    case 0x839108u: goto L_839108;
    case 0x83910Bu: goto L_83910B;
    case 0x83910Cu: goto L_83910C;
    case 0x83910Fu: goto L_83910F;
    case 0x839110u: goto L_839110;
    case 0x839112u: goto L_839112;
    case 0x839115u: goto L_839115;
    case 0x839118u: goto L_839118;
    case 0x83911Au: goto L_83911A;
    case 0x83911Du: goto L_83911D;
    case 0x839120u: goto L_839120;
    case 0x839122u: goto L_839122;
    case 0x839125u: goto L_839125;
    case 0x839127u: goto L_839127;
    case 0x83912Au: goto L_83912A;
    case 0x83912Cu: goto L_83912C;
    case 0x83912Fu: goto L_83912F;
    case 0x839130u: goto L_839130;
    case 0x839133u: goto L_839133;
    case 0x839135u: goto L_839135;
    case 0x839138u: goto L_839138;
    case 0x83913Au: goto L_83913A;
    case 0x83913Bu: goto L_83913B;
    case 0x83913Eu: goto L_83913E;
    case 0x839141u: goto L_839141;
    case 0x839143u: goto L_839143;
    case 0x839146u: goto L_839146;
    case 0x839149u: goto L_839149;
    case 0x83914Bu: goto L_83914B;
    case 0x83914Du: goto L_83914D;
    case 0x83914Eu: goto L_83914E;
    case 0x83914Fu: goto L_83914F;
    case 0x839150u: goto L_839150;
    case 0x839152u: goto L_839152;
    case 0x839155u: goto L_839155;
    case 0x839158u: goto L_839158;
    case 0x83915Bu: goto L_83915B;
    case 0x83915Du: goto L_83915D;
    case 0x83915Fu: goto L_83915F;
    case 0x839161u: goto L_839161;
    case 0x839164u: goto L_839164;
    case 0x839167u: goto L_839167;
    case 0x839169u: goto L_839169;
    case 0x83916Bu: goto L_83916B;
    case 0x83916Cu: goto L_83916C;
    case 0x83916Fu: goto L_83916F;
    case 0x839171u: goto L_839171;
    case 0x839173u: goto L_839173;
    case 0x839174u: goto L_839174;
    case 0x839177u: goto L_839177;
    case 0x839179u: goto L_839179;
    case 0x83917Bu: goto L_83917B;
    case 0x83917Eu: goto L_83917E;
    case 0x839180u: goto L_839180;
    case 0x839183u: goto L_839183;
    case 0x839184u: goto L_839184;
    case 0x839187u: goto L_839187;
    case 0x839189u: goto L_839189;
    case 0x83918Bu: goto L_83918B;
    case 0x83918Du: goto L_83918D;
    case 0x83918Fu: goto L_83918F;
    case 0x839192u: goto L_839192;
    case 0x839194u: goto L_839194;
    case 0x839196u: goto L_839196;
    case 0x839198u: goto L_839198;
    case 0x83919Au: goto L_83919A;
    case 0x83919Cu: goto L_83919C;
    case 0x83919Du: goto L_83919D;
    case 0x8391A0u: goto L_8391A0;
    case 0x8391A2u: goto L_8391A2;
    case 0x8391A5u: goto L_8391A5;
    case 0x8391A8u: goto L_8391A8;
    case 0x8391AAu: goto L_8391AA;
    case 0x8391ADu: goto L_8391AD;
    case 0x8391B0u: goto L_8391B0;
    case 0x8391B1u: goto L_8391B1;
    case 0x8391B3u: goto L_8391B3;
    case 0x8391B6u: goto L_8391B6;
    case 0x8391B8u: goto L_8391B8;
    case 0x8391BBu: goto L_8391BB;
    case 0x8391BCu: goto L_8391BC;
    case 0x8391BFu: goto L_8391BF;
    case 0x8391C1u: goto L_8391C1;
    case 0x8391C4u: goto L_8391C4;
    case 0x8391C7u: goto L_8391C7;
    case 0x8391C9u: goto L_8391C9;
    case 0x8391CCu: goto L_8391CC;
    case 0x8391CFu: goto L_8391CF;
    case 0x8391D0u: goto L_8391D0;
    case 0x8391D2u: goto L_8391D2;
    case 0x8391D5u: goto L_8391D5;
    case 0x8391D7u: goto L_8391D7;
    case 0x8391DAu: goto L_8391DA;
    case 0x8391DDu: goto L_8391DD;
    case 0x8391DFu: goto L_8391DF;
    case 0x8391E2u: goto L_8391E2;
    case 0x8391E3u: goto L_8391E3;
    case 0x8391E6u: goto L_8391E6;
    case 0x8391E8u: goto L_8391E8;
    case 0x8391EBu: goto L_8391EB;
    case 0x8391EEu: goto L_8391EE;
    case 0x8391F0u: goto L_8391F0;
    case 0x8391F3u: goto L_8391F3;
    case 0x8391F6u: goto L_8391F6;
    case 0x8391F8u: goto L_8391F8;
    case 0x8391FAu: goto L_8391FA;
    case 0x8391FDu: goto L_8391FD;
    case 0x8391FEu: goto L_8391FE;
    case 0x839201u: goto L_839201;
    case 0x839203u: goto L_839203;
    case 0x839204u: goto L_839204;
    case 0x839207u: goto L_839207;
    case 0x839209u: goto L_839209;
    case 0x83920Au: goto L_83920A;
    case 0x83920Du: goto L_83920D;
    case 0x83920Fu: goto L_83920F;
    case 0x839212u: goto L_839212;
    case 0x839213u: goto L_839213;
    case 0x839216u: goto L_839216;
    case 0x839218u: goto L_839218;
    case 0x83921Au: goto L_83921A;
    case 0x83921Bu: goto L_83921B;
    case 0x83921Cu: goto L_83921C;
    case 0x83921Fu: goto L_83921F;
    case 0x839221u: goto L_839221;
    case 0x839222u: goto L_839222;
    case 0x839224u: goto L_839224;
    case 0x839226u: goto L_839226;
    case 0x839228u: goto L_839228;
    case 0x839229u: goto L_839229;
    case 0x83922Au: goto L_83922A;
    case 0x83922Cu: goto L_83922C;
    case 0x83922Fu: goto L_83922F;
    case 0x839231u: goto L_839231;
    case 0x839234u: goto L_839234;
    case 0x839235u: goto L_839235;
    case 0x839238u: goto L_839238;
    case 0x839239u: goto L_839239;
    case 0x83923Cu: goto L_83923C;
    case 0x83923Eu: goto L_83923E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8390E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E7 CLC
    cpu.setFlag('C', false);
    goto L_8390E8;
L_8390E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8390E8u);return;} hw.unresolvedReturn(0x8390E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8390E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390EC;
L_8390EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16));
    goto L_8390EF;
L_8390EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EF BNE -> $8390E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390E7; }
    goto L_8390F1;
L_8390F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F4;
L_8390F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F4 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390F6;
L_8390F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F9;
L_8390F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F9 BMI -> $839130
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390FB;
L_8390FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FB CMP
    cpu.compareA(0x300u);
    goto L_8390FE;
L_8390FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FE BCC -> $839130
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839100;
L_839100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839100 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839103;
L_839103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839103 BMI -> $839108
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839108; }
    goto L_839105;
L_839105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839105 DEC
    cpu.decReg('A');
    goto L_839106;
L_839106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839106 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839108;
L_839108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839108 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83910B;
L_83910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910B CLC
    cpu.setFlag('C', false);
    goto L_83910C;
L_83910C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910C ADC
    cpu.adc(0x90u);
    goto L_83910F;
L_83910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910F SEC
    cpu.setFlag('C', true);
    goto L_839110;
L_839110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839110 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839112;
L_839112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839112 AND
    cpu.logicAnd(0xF0u);
    goto L_839115;
L_839115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839115 CMP
    cpu.compareA(0x20u);
    goto L_839118;
L_839118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839118 BCS -> $839130
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_83911A;
L_83911A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911A CMP
    cpu.compareA(0x10u);
    goto L_83911D;
L_83911D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911D LDA
    cpu.setA(0x10u, 16);
    goto L_839120;
L_839120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839120 BCS -> $839125
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839125; }
    goto L_839122;
L_839122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839122 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_839125;
L_839125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839125 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_839127;
L_839127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839127 LDA
    cpu.setA(0x4u, 16);
    goto L_83912A;
L_83912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912A STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_83912C;
L_83912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912C STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_83912F;
L_83912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83912F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83912Fu);return;} hw.unresolvedReturn(0x83912Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9130u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839130 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839133;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839130 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839133;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9130u,0x839130u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9133u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839133 BPL -> $839138
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839138; }
    goto L_839135;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839133 BPL -> $839138
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839138; }
    goto L_839135;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9133u,0x839133u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9135u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 3u, 3u, cpu.address("abs", 0x933Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839135 JMP -> $83933F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x933Fu),0x839135u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 3u, 3u, cpu.address("abs", 0x933Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839135 JMP -> $83933F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x933Fu),0x839135u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9135u,0x839135u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839138 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83913A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839138 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83913A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9138u,0x839138u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913A SEC
    cpu.setFlag('C', true);
    goto L_83913B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913A SEC
    cpu.setFlag('C', true);
    goto L_83913B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x913Au,0x83913Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913B SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_83913E;
L_83913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913E AND
    cpu.logicAnd(0xFFu);
    goto L_839141;
L_839141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839141 BNE -> $839146
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839146; }
    goto L_839143;
L_839143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 3u, 3u, cpu.address("abs", 0x91DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839143 JMP -> $8391DA
    goto L_8391DA;
L_839146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839146 AND
    cpu.logicAnd(0x80u);
    goto L_839149;
L_839149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839149 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83914B;
L_83914B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83914D;
L_83914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914D ASL
    cpu.aslA();
    goto L_83914E;
L_83914E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914E ASL
    cpu.aslA();
    goto L_83914F;
L_83914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914F TAY
    cpu.transfer("TAY");
    goto L_839150;
L_839150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839150 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_839152;
L_839152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839152 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839155;
L_839155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839155 AND
    cpu.logicAnd(0xFF00u);
    goto L_839158;
L_839158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 5u + 1u, 3u, cpu.address("absy", 0xD5CFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839158 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5CFu), cpu.m8?8:16));
    goto L_83915B;
L_83915B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83915D;
L_83915D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915D BPL -> $839161
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839161; }
    goto L_83915F;
L_83915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915F DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_839161;
L_839161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839161 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839164;
L_839164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839164 AND
    cpu.logicAnd(0x8000u);
    goto L_839167;
L_839167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839167 BNE -> $839171
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839171; }
    goto L_839169;
L_839169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839169 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83916B;
L_83916B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916B ASL
    cpu.aslA();
    goto L_83916C;
L_83916C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916C ADC
    cpu.adc(0x54u);
    goto L_83916F;
L_83916F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916F BRA -> $839183
    goto L_839183;
L_839171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839171 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839173;
L_839173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839173 ASL
    cpu.aslA();
    goto L_839174;
L_839174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839174 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839177;
L_839177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839177 BMI -> $839180
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839180; }
    goto L_839179;
L_839179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839179 BEQ -> $839183
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839183; }
    goto L_83917B;
L_83917B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917B ADC
    cpu.adc(0x38u);
    goto L_83917E;
L_83917E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917E BRA -> $839183
    goto L_839183;
L_839180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839180 ADC
    cpu.adc(0x1Cu);
    goto L_839183;
L_839183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839183 TAY
    cpu.transfer("TAY");
    goto L_839184;
L_839184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 5u + 1u, 3u, cpu.address("absy", 0xD561u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839184 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD561u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839187;
L_839187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839187 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_839189;
L_839189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839189 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83918B;
L_83918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918B STZ
    hw.write(cpu.address("dp", 0x20u), 0, cpu.m8?8:16);
    goto L_83918D;
L_83918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_83918F;
L_83918F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu, 5u + 1u, 3u, cpu.address("absy", 0xD55Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD55Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839192;
L_839192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839192 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_839194;
L_839194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839194 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839196;
L_839196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839196 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839198;
L_839198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839198 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83919A;
L_83919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919A BEQ -> $8391BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391BB; }
    goto L_83919C;
L_83919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919C SEC
    cpu.setFlag('C', true);
    goto L_83919D;
L_83919D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A0;
L_8391A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A0 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391A2;
L_8391A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A2 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391A5;
L_8391A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A8;
L_8391A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391AA;
L_8391AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AA AND
    cpu.logicAnd(0xFFu);
    goto L_8391AD;
L_8391AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AD STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391B0;
L_8391B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B0 SEC
    cpu.setFlag('C', true);
    goto L_8391B1;
L_8391B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B1 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391B3;
L_8391B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B3 BIT
    cpu.bit(0x80u, true);
    goto L_8391B6;
L_8391B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B6 BEQ -> $8391DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391B8;
L_8391B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391B8u); return;
L_8391BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BB CLC
    cpu.setFlag('C', false);
    goto L_8391BC;
L_8391BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391BF;
L_8391BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391C1;
L_8391C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C1 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391C4;
L_8391C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391C7;
L_8391C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391C9;
L_8391C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C9 AND
    cpu.logicAnd(0xFFu);
    goto L_8391CC;
L_8391CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CC STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391CF;
L_8391CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CF SEC
    cpu.setFlag('C', true);
    goto L_8391D0;
L_8391D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D0 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391D2;
L_8391D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D2 BIT
    cpu.bit(0x80u, true);
    goto L_8391D5;
L_8391D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D5 BNE -> $8391DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391D7;
L_8391D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D7 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391D7u); return;
L_8391DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391DD;
L_8391DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DD BPL -> $8391E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8391E3; }
    goto L_8391DF;
L_8391DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DF EOR
    cpu.logicXor(0xFFFFu);
    goto L_8391E2;
L_8391E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E2 INC
    cpu.inc('A');
    goto L_8391E3;
L_8391E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E3 CMP
    cpu.compareA(0x40u);
    goto L_8391E6;
L_8391E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E6 BCS -> $8391EB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8391EB; }
    goto L_8391E8;
L_8391E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391E8u); return;
L_8391EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391EE;
L_8391EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EE BNE -> $83925F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Fu,0x8391EEu); return; }
    goto L_8391F0;
L_8391F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391F3;
L_8391F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F3 CMP
    cpu.compareA(0x6u);
    goto L_8391F6;
L_8391F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F6 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x8391F6u); return; }
    goto L_8391F8;
L_8391F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391FA;
L_8391FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FA STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8391FD;
L_8391FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FD SEC
    cpu.setFlag('C', true);
    goto L_8391FE;
L_8391FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FE SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_839201;
L_839201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839201 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x839201u); return; }
    goto L_839203;
L_839203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839203 TAY
    cpu.transfer("TAY");
    goto L_839204;
L_839204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839204 AND
    cpu.logicAnd(0x80u);
    goto L_839207;
L_839207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839207 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839209;
L_839209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839209 TYA
    cpu.transfer("TYA");
    goto L_83920A;
L_83920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920A BIT
    cpu.bit(0x80u, true);
    goto L_83920D;
L_83920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920D BEQ -> $839213
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839213; }
    goto L_83920F;
L_83920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920F EOR
    cpu.logicXor(0x7Fu);
    goto L_839212;
L_839212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839212 INC
    cpu.inc('A');
    goto L_839213;
L_839213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839213 AND
    cpu.logicAnd(0x7Fu);
    goto L_839216;
L_839216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839216 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839218;
L_839218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839218 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921A;
L_83921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921A ASL
    cpu.aslA();
    goto L_83921B;
L_83921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921B TAY
    cpu.transfer("TAY");
    goto L_83921C;
L_83921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 5u + 1u, 3u, cpu.address("absy", 0xD665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921F;
L_83921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_839221;
L_839221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839221 TAY
    cpu.transfer("TAY");
    goto L_839222;
L_839222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839222 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_839224;
L_839224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839224 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_839226;
L_839226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839226 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839228;
L_839228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839228 LSR
    cpu.lsrA();
    goto L_839229;
L_839229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839229 DEC
    cpu.decReg('A');
    goto L_83922A;
L_83922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922A BNE -> $839231
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839231; }
    goto L_83922C;
L_83922C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922C LDA
    cpu.setA(0xFFFEu, 16);
    goto L_83922F;
L_83922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_839231;
L_839231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839231 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839234;
L_839234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839234 XBA
    cpu.xba();
    goto L_839235;
L_839235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839235 AND
    cpu.logicAnd(0xFFu);
    goto L_839238;
L_839238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839238 CLC
    cpu.setFlag('C', false);
    goto L_839239;
L_839239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 5u + 1u, 3u, cpu.address("absy", 0xD61Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839239 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD61Fu), cpu.m8?8:16));
    goto L_83923C;
L_83923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83923E;
L_83923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9240u,0x83923Eu); return;
}

void sub_8390E9_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8390E7u: goto L_8390E7;
    case 0x8390E8u: goto L_8390E8;
    case 0x8390E9u: goto L_8390E9;
    case 0x8390ECu: goto L_8390EC;
    case 0x8390EFu: goto L_8390EF;
    case 0x8390F1u: goto L_8390F1;
    case 0x8390F4u: goto L_8390F4;
    case 0x8390F6u: goto L_8390F6;
    case 0x8390F9u: goto L_8390F9;
    case 0x8390FBu: goto L_8390FB;
    case 0x8390FEu: goto L_8390FE;
    case 0x839100u: goto L_839100;
    case 0x839103u: goto L_839103;
    case 0x839105u: goto L_839105;
    case 0x839106u: goto L_839106;
    case 0x839108u: goto L_839108;
    case 0x83910Bu: goto L_83910B;
    case 0x83910Cu: goto L_83910C;
    case 0x83910Fu: goto L_83910F;
    case 0x839110u: goto L_839110;
    case 0x839112u: goto L_839112;
    case 0x839115u: goto L_839115;
    case 0x839118u: goto L_839118;
    case 0x83911Au: goto L_83911A;
    case 0x83911Du: goto L_83911D;
    case 0x839120u: goto L_839120;
    case 0x839122u: goto L_839122;
    case 0x839125u: goto L_839125;
    case 0x839127u: goto L_839127;
    case 0x83912Au: goto L_83912A;
    case 0x83912Cu: goto L_83912C;
    case 0x83912Fu: goto L_83912F;
    case 0x839130u: goto L_839130;
    case 0x839133u: goto L_839133;
    case 0x839135u: goto L_839135;
    case 0x839138u: goto L_839138;
    case 0x83913Au: goto L_83913A;
    case 0x83913Bu: goto L_83913B;
    case 0x83913Eu: goto L_83913E;
    case 0x839141u: goto L_839141;
    case 0x839143u: goto L_839143;
    case 0x839146u: goto L_839146;
    case 0x839149u: goto L_839149;
    case 0x83914Bu: goto L_83914B;
    case 0x83914Du: goto L_83914D;
    case 0x83914Eu: goto L_83914E;
    case 0x83914Fu: goto L_83914F;
    case 0x839150u: goto L_839150;
    case 0x839152u: goto L_839152;
    case 0x839155u: goto L_839155;
    case 0x839158u: goto L_839158;
    case 0x83915Bu: goto L_83915B;
    case 0x83915Du: goto L_83915D;
    case 0x83915Fu: goto L_83915F;
    case 0x839161u: goto L_839161;
    case 0x839164u: goto L_839164;
    case 0x839167u: goto L_839167;
    case 0x839169u: goto L_839169;
    case 0x83916Bu: goto L_83916B;
    case 0x83916Cu: goto L_83916C;
    case 0x83916Fu: goto L_83916F;
    case 0x839171u: goto L_839171;
    case 0x839173u: goto L_839173;
    case 0x839174u: goto L_839174;
    case 0x839177u: goto L_839177;
    case 0x839179u: goto L_839179;
    case 0x83917Bu: goto L_83917B;
    case 0x83917Eu: goto L_83917E;
    case 0x839180u: goto L_839180;
    case 0x839183u: goto L_839183;
    case 0x839184u: goto L_839184;
    case 0x839187u: goto L_839187;
    case 0x839189u: goto L_839189;
    case 0x83918Bu: goto L_83918B;
    case 0x83918Du: goto L_83918D;
    case 0x83918Fu: goto L_83918F;
    case 0x839192u: goto L_839192;
    case 0x839194u: goto L_839194;
    case 0x839196u: goto L_839196;
    case 0x839198u: goto L_839198;
    case 0x83919Au: goto L_83919A;
    case 0x83919Cu: goto L_83919C;
    case 0x83919Du: goto L_83919D;
    case 0x8391A0u: goto L_8391A0;
    case 0x8391A2u: goto L_8391A2;
    case 0x8391A5u: goto L_8391A5;
    case 0x8391A8u: goto L_8391A8;
    case 0x8391AAu: goto L_8391AA;
    case 0x8391ADu: goto L_8391AD;
    case 0x8391B0u: goto L_8391B0;
    case 0x8391B1u: goto L_8391B1;
    case 0x8391B3u: goto L_8391B3;
    case 0x8391B6u: goto L_8391B6;
    case 0x8391B8u: goto L_8391B8;
    case 0x8391BBu: goto L_8391BB;
    case 0x8391BCu: goto L_8391BC;
    case 0x8391BFu: goto L_8391BF;
    case 0x8391C1u: goto L_8391C1;
    case 0x8391C4u: goto L_8391C4;
    case 0x8391C7u: goto L_8391C7;
    case 0x8391C9u: goto L_8391C9;
    case 0x8391CCu: goto L_8391CC;
    case 0x8391CFu: goto L_8391CF;
    case 0x8391D0u: goto L_8391D0;
    case 0x8391D2u: goto L_8391D2;
    case 0x8391D5u: goto L_8391D5;
    case 0x8391D7u: goto L_8391D7;
    case 0x8391DAu: goto L_8391DA;
    case 0x8391DDu: goto L_8391DD;
    case 0x8391DFu: goto L_8391DF;
    case 0x8391E2u: goto L_8391E2;
    case 0x8391E3u: goto L_8391E3;
    case 0x8391E6u: goto L_8391E6;
    case 0x8391E8u: goto L_8391E8;
    case 0x8391EBu: goto L_8391EB;
    case 0x8391EEu: goto L_8391EE;
    case 0x8391F0u: goto L_8391F0;
    case 0x8391F3u: goto L_8391F3;
    case 0x8391F6u: goto L_8391F6;
    case 0x8391F8u: goto L_8391F8;
    case 0x8391FAu: goto L_8391FA;
    case 0x8391FDu: goto L_8391FD;
    case 0x8391FEu: goto L_8391FE;
    case 0x839201u: goto L_839201;
    case 0x839203u: goto L_839203;
    case 0x839204u: goto L_839204;
    case 0x839207u: goto L_839207;
    case 0x839209u: goto L_839209;
    case 0x83920Au: goto L_83920A;
    case 0x83920Du: goto L_83920D;
    case 0x83920Fu: goto L_83920F;
    case 0x839212u: goto L_839212;
    case 0x839213u: goto L_839213;
    case 0x839216u: goto L_839216;
    case 0x839218u: goto L_839218;
    case 0x83921Au: goto L_83921A;
    case 0x83921Bu: goto L_83921B;
    case 0x83921Cu: goto L_83921C;
    case 0x83921Fu: goto L_83921F;
    case 0x839221u: goto L_839221;
    case 0x839222u: goto L_839222;
    case 0x839224u: goto L_839224;
    case 0x839226u: goto L_839226;
    case 0x839228u: goto L_839228;
    case 0x839229u: goto L_839229;
    case 0x83922Au: goto L_83922A;
    case 0x83922Cu: goto L_83922C;
    case 0x83922Fu: goto L_83922F;
    case 0x839231u: goto L_839231;
    case 0x839234u: goto L_839234;
    case 0x839235u: goto L_839235;
    case 0x839238u: goto L_839238;
    case 0x839239u: goto L_839239;
    case 0x83923Cu: goto L_83923C;
    case 0x83923Eu: goto L_83923E;
    case 0x839240u: goto L_839240;
    case 0x839243u: goto L_839243;
    case 0x839246u: goto L_839246;
    case 0x839248u: goto L_839248;
    case 0x83924Au: goto L_83924A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8390E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E7 CLC
    cpu.setFlag('C', false);
    goto L_8390E8;
L_8390E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8390E8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8390E8u);return;} hw.unresolvedReturn(0x8390E8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_8390E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E9u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390E9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390EC;
L_8390EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90ECu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EC ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16));
    goto L_8390EF;
L_8390EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390EF BNE -> $8390E7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8390E7; }
    goto L_8390F1;
L_8390F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F1u, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F4;
L_8390F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F4 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390F6;
L_8390F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8390F9;
L_8390F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390F9 BMI -> $839130
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_8390FB;
L_8390FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FB CMP
    cpu.compareA(0x300u);
    goto L_8390FE;
L_8390FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8390FE BCC -> $839130
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839100;
L_839100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9100u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839100 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839103;
L_839103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9103u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839103 BMI -> $839108
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839108; }
    goto L_839105;
L_839105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9105u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839105 DEC
    cpu.decReg('A');
    goto L_839106;
L_839106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9106u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839106 BNE -> $839130
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_839108;
L_839108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9108u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839108 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83910B;
L_83910B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910B CLC
    cpu.setFlag('C', false);
    goto L_83910C;
L_83910C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910C ADC
    cpu.adc(0x90u);
    goto L_83910F;
L_83910F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x910Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x910Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83910F SEC
    cpu.setFlag('C', true);
    goto L_839110;
L_839110:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9110u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9110u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839110 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_839112;
L_839112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9112u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839112 AND
    cpu.logicAnd(0xF0u);
    goto L_839115;
L_839115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9115u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839115 CMP
    cpu.compareA(0x20u);
    goto L_839118;
L_839118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9118u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839118 BCS -> $839130
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839130; }
    goto L_83911A;
L_83911A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911A CMP
    cpu.compareA(0x10u);
    goto L_83911D;
L_83911D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x911Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x911Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83911D LDA
    cpu.setA(0x10u, 16);
    goto L_839120;
L_839120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9120u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839120 BCS -> $839125
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839125; }
    goto L_839122;
L_839122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839122 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_839125;
L_839125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9125u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839125 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_839127;
L_839127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9127u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839127 LDA
    cpu.setA(0x4u, 16);
    goto L_83912A;
L_83912A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912A STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_83912C;
L_83912C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Cu, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83912C STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_83912F;
L_83912F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x912Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x912Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83912F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83912Fu);return;} hw.unresolvedReturn(0x83912Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9130u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839130 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839133;
L_839133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9133u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839133 BPL -> $839138
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839138; }
    goto L_839135;
L_839135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9135u, 3u, 3u, cpu.address("abs", 0x933Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839135 JMP -> $83933F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x933Fu),0x839135u); return;
L_839138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9138u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839138 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83913A;
L_83913A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913A SEC
    cpu.setFlag('C', true);
    goto L_83913B;
L_83913B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913B SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_83913E;
L_83913E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x913Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x913Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83913E AND
    cpu.logicAnd(0xFFu);
    goto L_839141;
L_839141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9141u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839141 BNE -> $839146
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839146; }
    goto L_839143;
L_839143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9143u, 3u, 3u, cpu.address("abs", 0x91DAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839143 JMP -> $8391DA
    goto L_8391DA;
L_839146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9146u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839146 AND
    cpu.logicAnd(0x80u);
    goto L_839149;
L_839149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839149 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83914B;
L_83914B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83914D;
L_83914D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914D ASL
    cpu.aslA();
    goto L_83914E;
L_83914E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914E ASL
    cpu.aslA();
    goto L_83914F;
L_83914F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x914Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x914Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83914F TAY
    cpu.transfer("TAY");
    goto L_839150;
L_839150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9150u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839150 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_839152;
L_839152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9152u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839152 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839155;
L_839155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9155u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839155 AND
    cpu.logicAnd(0xFF00u);
    goto L_839158;
L_839158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9158u, 5u + 1u, 3u, cpu.address("absy", 0xD5CFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839158 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5CFu), cpu.m8?8:16));
    goto L_83915B;
L_83915B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83915D;
L_83915D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915D BPL -> $839161
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839161; }
    goto L_83915F;
L_83915F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x915Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x915Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83915F DEC
    cpu.decMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_839161;
L_839161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9161u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839161 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839164;
L_839164:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9164u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9164u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839164 AND
    cpu.logicAnd(0x8000u);
    goto L_839167;
L_839167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9167u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839167 BNE -> $839171
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839171; }
    goto L_839169;
L_839169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9169u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839169 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83916B;
L_83916B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916B ASL
    cpu.aslA();
    goto L_83916C;
L_83916C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916C ADC
    cpu.adc(0x54u);
    goto L_83916F;
L_83916F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x916Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x916Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83916F BRA -> $839183
    goto L_839183;
L_839171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9171u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839171 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839173;
L_839173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9173u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839173 ASL
    cpu.aslA();
    goto L_839174;
L_839174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9174u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839174 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839177;
L_839177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9177u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839177 BMI -> $839180
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839180; }
    goto L_839179;
L_839179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9179u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839179 BEQ -> $839183
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839183; }
    goto L_83917B;
L_83917B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917B ADC
    cpu.adc(0x38u);
    goto L_83917E;
L_83917E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x917Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x917Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83917E BRA -> $839183
    goto L_839183;
L_839180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9180u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839180 ADC
    cpu.adc(0x1Cu);
    goto L_839183;
L_839183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839183 TAY
    cpu.transfer("TAY");
    goto L_839184;
L_839184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9184u, 5u + 1u, 3u, cpu.address("absy", 0xD561u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839184 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD561u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839187;
L_839187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839187 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_839189;
L_839189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9189u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839189 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83918B;
L_83918B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918B STZ
    hw.write(cpu.address("dp", 0x20u), 0, cpu.m8?8:16);
    goto L_83918D;
L_83918D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918D ROL
    cpu.rolMem(hw, cpu.address("dp", 0x20u), cpu.m8?8:16);
    goto L_83918F;
L_83918F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x918Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x918Fu, 5u + 1u, 3u, cpu.address("absy", 0xD55Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83918F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD55Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839192;
L_839192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9192u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839192 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_839194;
L_839194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839194 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839196;
L_839196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9196u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839196 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839198;
L_839198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9198u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839198 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83919A;
L_83919A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919A BEQ -> $8391BB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391BB; }
    goto L_83919C;
L_83919C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919C SEC
    cpu.setFlag('C', true);
    goto L_83919D;
L_83919D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x919Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x919Du, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83919D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A0;
L_8391A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A0 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391A2;
L_8391A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A2u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A2 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391A5;
L_8391A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A5u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391A8;
L_8391A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391AA;
L_8391AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91AAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AA AND
    cpu.logicAnd(0xFFu);
    goto L_8391AD;
L_8391AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91ADu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391AD STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391B0;
L_8391B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B0 SEC
    cpu.setFlag('C', true);
    goto L_8391B1;
L_8391B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B1 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391B3;
L_8391B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B3 BIT
    cpu.bit(0x80u, true);
    goto L_8391B6;
L_8391B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B6 BEQ -> $8391DA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391B8;
L_8391B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91B8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391B8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391B8u); return;
L_8391BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BB CLC
    cpu.setFlag('C', false);
    goto L_8391BC;
L_8391BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BCu, 5u + 1u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391BF;
L_8391BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91BFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391BF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_8391C1;
L_8391C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C1u, 6u, 3u, cpu.address("absx", 0x10A4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C1 STA
    hw.write(cpu.address("absx", 0x10A4u), cpu.a, cpu.m8?8:16);
    goto L_8391C4;
L_8391C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C4u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391C7;
L_8391C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C7 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_8391C9;
L_8391C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391C9 AND
    cpu.logicAnd(0xFFu);
    goto L_8391CC;
L_8391CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CCu, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CC STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_8391CF;
L_8391CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391CF SEC
    cpu.setFlag('C', true);
    goto L_8391D0;
L_8391D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D0 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16));
    goto L_8391D2;
L_8391D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D2 BIT
    cpu.bit(0x80u, true);
    goto L_8391D5;
L_8391D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D5 BNE -> $8391DA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8391DA; }
    goto L_8391D7;
L_8391D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91D7u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391D7 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391D7u); return;
L_8391DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DAu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391DD;
L_8391DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DD BPL -> $8391E3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8391E3; }
    goto L_8391DF;
L_8391DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391DF EOR
    cpu.logicXor(0xFFFFu);
    goto L_8391E2;
L_8391E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E2 INC
    cpu.inc('A');
    goto L_8391E3;
L_8391E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E3 CMP
    cpu.compareA(0x40u);
    goto L_8391E6;
L_8391E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E6 BCS -> $8391EB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8391EB; }
    goto L_8391E8;
L_8391E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91E8u, 3u, 3u, cpu.address("abs", 0x92A0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391E8 JMP -> $8392A0
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x92A0u),0x8391E8u); return;
L_8391EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EBu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391EE;
L_8391EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91EEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391EE BNE -> $83925F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Fu,0x8391EEu); return; }
    goto L_8391F0;
L_8391F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F0u, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391F3;
L_8391F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F3 CMP
    cpu.compareA(0x6u);
    goto L_8391F6;
L_8391F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F6 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x8391F6u); return; }
    goto L_8391F8;
L_8391F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91F8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391F8 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8391FA;
L_8391FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FAu, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FA STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_8391FD;
L_8391FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FD SEC
    cpu.setFlag('C', true);
    goto L_8391FE;
L_8391FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x91FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x91FEu, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8391FE SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_839201;
L_839201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9201u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839201 BEQ -> $83925E
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83925Eu,0x839201u); return; }
    goto L_839203;
L_839203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9203u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839203 TAY
    cpu.transfer("TAY");
    goto L_839204;
L_839204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9204u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9204u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839204 AND
    cpu.logicAnd(0x80u);
    goto L_839207;
L_839207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9207u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839207 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_839209;
L_839209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9209u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839209 TYA
    cpu.transfer("TYA");
    goto L_83920A;
L_83920A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920A BIT
    cpu.bit(0x80u, true);
    goto L_83920D;
L_83920D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920D BEQ -> $839213
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839213; }
    goto L_83920F;
L_83920F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x920Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x920Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83920F EOR
    cpu.logicXor(0x7Fu);
    goto L_839212;
L_839212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9212u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839212 INC
    cpu.inc('A');
    goto L_839213;
L_839213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9213u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839213 AND
    cpu.logicAnd(0x7Fu);
    goto L_839216;
L_839216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9216u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839216 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839218;
L_839218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9218u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839218 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921A;
L_83921A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921A ASL
    cpu.aslA();
    goto L_83921B;
L_83921B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921B TAY
    cpu.transfer("TAY");
    goto L_83921C;
L_83921C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Cu, 5u + 1u, 3u, cpu.address("absy", 0xD665u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD665u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83921F;
L_83921F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x921Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x921Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83921F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_839221;
L_839221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839221 TAY
    cpu.transfer("TAY");
    goto L_839222;
L_839222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9222u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839222 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_839224;
L_839224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839224 STZ
    hw.write(cpu.address("dp", 0xEu), 0, cpu.m8?8:16);
    goto L_839226;
L_839226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9226u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839226 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839228;
L_839228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839228 LSR
    cpu.lsrA();
    goto L_839229;
L_839229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839229 DEC
    cpu.decReg('A');
    goto L_83922A;
L_83922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922A BNE -> $839231
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839231; }
    goto L_83922C;
L_83922C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922C LDA
    cpu.setA(0xFFFEu, 16);
    goto L_83922F;
L_83922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83922F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_839231;
L_839231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9231u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839231 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839234;
L_839234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839234 XBA
    cpu.xba();
    goto L_839235;
L_839235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9235u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839235 AND
    cpu.logicAnd(0xFFu);
    goto L_839238;
L_839238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9238u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839238 CLC
    cpu.setFlag('C', false);
    goto L_839239;
L_839239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 5u + 1u, 3u, cpu.address("absy", 0xD61Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839239 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD61Fu), cpu.m8?8:16));
    goto L_83923C;
L_83923C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923C ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83923E;
L_83923E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83923E ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_839240;
L_839240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9240u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839240 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839243;
L_839243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9243u, 5u + 1u, 3u, cpu.address("absy", 0xD806u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839243 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD806u), cpu.m8?8:16));
    goto L_839246;
L_839246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839246 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839248;
L_839248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839248 BCS -> $839252
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x839252u,0x839248u); return; }
    goto L_83924A;
L_83924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83924A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1092u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x924Du,0x83924Au); return;
}

void sub_839C0F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C0Fu: goto L_839C0F;
    case 0x839C12u: goto L_839C12;
    case 0x839C15u: goto L_839C15;
    case 0x839C18u: goto L_839C18;
    case 0x839C1Au: goto L_839C1A;
    case 0x839C1Du: goto L_839C1D;
    case 0x839C1Fu: goto L_839C1F;
    case 0x839C22u: goto L_839C22;
    case 0x839C24u: goto L_839C24;
    case 0x839C27u: goto L_839C27;
    case 0x839C2Au: goto L_839C2A;
    case 0x839C2Cu: goto L_839C2C;
    case 0x839C2Fu: goto L_839C2F;
    case 0x839C32u: goto L_839C32;
    case 0x839C34u: goto L_839C34;
    case 0x839C37u: goto L_839C37;
    case 0x839C39u: goto L_839C39;
    case 0x839C3Au: goto L_839C3A;
    case 0x839C3Bu: goto L_839C3B;
    case 0x839C3Cu: goto L_839C3C;
    case 0x839C3Fu: goto L_839C3F;
    case 0x839C40u: goto L_839C40;
    case 0x839C41u: goto L_839C41;
    case 0x839C43u: goto L_839C43;
    case 0x839C44u: goto L_839C44;
    case 0x839C47u: goto L_839C47;
    case 0x839C49u: goto L_839C49;
    case 0x839C4Cu: goto L_839C4C;
    case 0x839C4Du: goto L_839C4D;
    case 0x839C4Eu: goto L_839C4E;
    case 0x839C50u: goto L_839C50;
    case 0x839C51u: goto L_839C51;
    case 0x839C54u: goto L_839C54;
    case 0x839C55u: goto L_839C55;
    case 0x839C58u: goto L_839C58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C0F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C12;
L_839C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C12 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C15;
L_839C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C15 BIT
    cpu.bit(0x40u, true);
    goto L_839C18;
L_839C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C18 BNE -> $839C40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C40; }
    goto L_839C1A;
L_839C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1A BIT
    cpu.bit(0x8000u, true);
    goto L_839C1D;
L_839C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1D BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C1F;
L_839C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C22;
L_839C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C22 BNE -> $839C34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C34; }
    goto L_839C24;
L_839C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C24 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C27;
L_839C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C27 AND
    cpu.logicAnd(0x400u);
    goto L_839C2A;
L_839C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2A BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C2C;
L_839C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C2F;
L_839C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2F CMP
    cpu.compareA(0x400u);
    goto L_839C32;
L_839C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C32 BCC -> $839C4D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C34;
L_839C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C34u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C34 CPY
    cpu.compareY(0x20u);
    goto L_839C37;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C34 CPY
    cpu.compareY(0x20u);
    goto L_839C37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C34u,0x839C34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C37 BCS -> $839C58
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C39;
L_839C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C39 TYA
    cpu.transfer("TYA");
    goto L_839C3A;
L_839C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3A INC
    cpu.inc('A');
    goto L_839C3B;
L_839C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3B INC
    cpu.inc('A');
    goto L_839C3C;
L_839C3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C3F;
L_839C3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C3F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C3Fu);return;} hw.unresolvedReturn(0x839C3Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C40 TYA
    cpu.transfer("TYA");
    goto L_839C41;
L_839C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C41 BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C43;
L_839C43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C43 SEC
    cpu.setFlag('C', true);
    goto L_839C44;
L_839C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C44 SBC
    cpu.sbc(0x4u);
    goto L_839C47;
L_839C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C47 BCC -> $839C55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C55; }
    goto L_839C49;
L_839C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C49 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C4C;
L_839C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C4Cu);return;} hw.unresolvedReturn(0x839C4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4D TYA
    cpu.transfer("TYA");
    goto L_839C4E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4D TYA
    cpu.transfer("TYA");
    goto L_839C4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C4Du,0x839C4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4E BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C50;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4E BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,0x839C4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C50u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C50 DEC
    cpu.decReg('A');
    goto L_839C51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C50 DEC
    cpu.decReg('A');
    goto L_839C51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C50u,0x839C50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C51 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C51 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C51u,0x839C51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C54 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C54u);return;} hw.unresolvedReturn(0x839C54u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C54 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C54u);return;} hw.unresolvedReturn(0x839C54u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C54u,0x839C54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C55 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_839C58;
L_839C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C58u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C58u);return;} hw.unresolvedReturn(0x839C58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C58u);return;} hw.unresolvedReturn(0x839C58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C58u,0x839C58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_839C0F_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C0Fu: goto L_839C0F;
    case 0x839C12u: goto L_839C12;
    case 0x839C15u: goto L_839C15;
    case 0x839C18u: goto L_839C18;
    case 0x839C1Au: goto L_839C1A;
    case 0x839C1Du: goto L_839C1D;
    case 0x839C1Fu: goto L_839C1F;
    case 0x839C22u: goto L_839C22;
    case 0x839C24u: goto L_839C24;
    case 0x839C27u: goto L_839C27;
    case 0x839C2Au: goto L_839C2A;
    case 0x839C2Cu: goto L_839C2C;
    case 0x839C2Fu: goto L_839C2F;
    case 0x839C32u: goto L_839C32;
    case 0x839C34u: goto L_839C34;
    case 0x839C37u: goto L_839C37;
    case 0x839C39u: goto L_839C39;
    case 0x839C3Au: goto L_839C3A;
    case 0x839C3Bu: goto L_839C3B;
    case 0x839C3Cu: goto L_839C3C;
    case 0x839C3Fu: goto L_839C3F;
    case 0x839C40u: goto L_839C40;
    case 0x839C41u: goto L_839C41;
    case 0x839C43u: goto L_839C43;
    case 0x839C44u: goto L_839C44;
    case 0x839C47u: goto L_839C47;
    case 0x839C49u: goto L_839C49;
    case 0x839C4Cu: goto L_839C4C;
    case 0x839C4Du: goto L_839C4D;
    case 0x839C4Eu: goto L_839C4E;
    case 0x839C50u: goto L_839C50;
    case 0x839C51u: goto L_839C51;
    case 0x839C54u: goto L_839C54;
    case 0x839C55u: goto L_839C55;
    case 0x839C58u: goto L_839C58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C0F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C12;
L_839C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C12 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C15;
L_839C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C15 BIT
    cpu.bit(0x40u, true);
    goto L_839C18;
L_839C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C18 BNE -> $839C40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C40; }
    goto L_839C1A;
L_839C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1A BIT
    cpu.bit(0x8000u, true);
    goto L_839C1D;
L_839C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1D BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C1F;
L_839C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C22;
L_839C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C22 BNE -> $839C34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C34; }
    goto L_839C24;
L_839C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C24 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C27;
L_839C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C27 AND
    cpu.logicAnd(0x400u);
    goto L_839C2A;
L_839C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2A BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C2C;
L_839C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C2F;
L_839C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2F CMP
    cpu.compareA(0x400u);
    goto L_839C32;
L_839C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C32 BCC -> $839C4D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C34;
L_839C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C34u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C34 CPY
    cpu.compareY(0x20u);
    goto L_839C37;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C34 CPY
    cpu.compareY(0x20u);
    goto L_839C37;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C34u,0x839C34u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C37 BCS -> $839C58
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C39;
L_839C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C39 TYA
    cpu.transfer("TYA");
    goto L_839C3A;
L_839C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3A INC
    cpu.inc('A');
    goto L_839C3B;
L_839C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3B INC
    cpu.inc('A');
    goto L_839C3C;
L_839C3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C3F;
L_839C3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C3F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C3Fu);return;} hw.unresolvedReturn(0x839C3Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C40 TYA
    cpu.transfer("TYA");
    goto L_839C41;
L_839C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C41 BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C43;
L_839C43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C43 SEC
    cpu.setFlag('C', true);
    goto L_839C44;
L_839C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C44 SBC
    cpu.sbc(0x4u);
    goto L_839C47;
L_839C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C47 BCC -> $839C55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C55; }
    goto L_839C49;
L_839C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C49 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C4C;
L_839C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C4Cu);return;} hw.unresolvedReturn(0x839C4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4D TYA
    cpu.transfer("TYA");
    goto L_839C4E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4D TYA
    cpu.transfer("TYA");
    goto L_839C4E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C4Du,0x839C4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4E BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C50;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4E BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C50;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,0x839C4Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C50u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C50 DEC
    cpu.decReg('A');
    goto L_839C51;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C50 DEC
    cpu.decReg('A');
    goto L_839C51;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C50u,0x839C50u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C51u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C51 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C54;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C51 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C51u,0x839C51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C54u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C54 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C54u);return;} hw.unresolvedReturn(0x839C54u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C54 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C54u);return;} hw.unresolvedReturn(0x839C54u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C54u,0x839C54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C55 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_839C58;
L_839C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C58u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C58u);return;} hw.unresolvedReturn(0x839C58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C58u);return;} hw.unresolvedReturn(0x839C58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9C58u,0x839C58u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_839C0F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839C0Fu: goto L_839C0F;
    case 0x839C12u: goto L_839C12;
    case 0x839C15u: goto L_839C15;
    case 0x839C18u: goto L_839C18;
    case 0x839C1Au: goto L_839C1A;
    case 0x839C1Du: goto L_839C1D;
    case 0x839C1Fu: goto L_839C1F;
    case 0x839C22u: goto L_839C22;
    case 0x839C24u: goto L_839C24;
    case 0x839C27u: goto L_839C27;
    case 0x839C2Au: goto L_839C2A;
    case 0x839C2Cu: goto L_839C2C;
    case 0x839C2Fu: goto L_839C2F;
    case 0x839C32u: goto L_839C32;
    case 0x839C34u: goto L_839C34;
    case 0x839C37u: goto L_839C37;
    case 0x839C39u: goto L_839C39;
    case 0x839C3Au: goto L_839C3A;
    case 0x839C3Bu: goto L_839C3B;
    case 0x839C3Cu: goto L_839C3C;
    case 0x839C3Fu: goto L_839C3F;
    case 0x839C40u: goto L_839C40;
    case 0x839C41u: goto L_839C41;
    case 0x839C43u: goto L_839C43;
    case 0x839C44u: goto L_839C44;
    case 0x839C47u: goto L_839C47;
    case 0x839C49u: goto L_839C49;
    case 0x839C4Cu: goto L_839C4C;
    case 0x839C4Du: goto L_839C4D;
    case 0x839C4Eu: goto L_839C4E;
    case 0x839C50u: goto L_839C50;
    case 0x839C51u: goto L_839C51;
    case 0x839C54u: goto L_839C54;
    case 0x839C55u: goto L_839C55;
    case 0x839C58u: goto L_839C58;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839C0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C0Fu, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C0F LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10CAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839C12;
L_839C12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C12u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C12 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C15;
L_839C15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C15u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C15u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C15 BIT
    cpu.bit(0x40u, true);
    goto L_839C18;
L_839C18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C18 BNE -> $839C40
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C40; }
    goto L_839C1A;
L_839C1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1A BIT
    cpu.bit(0x8000u, true);
    goto L_839C1D;
L_839C1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1D BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C1F;
L_839C1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C1Fu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C1F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C22;
L_839C22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C22u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C22 BNE -> $839C34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C34; }
    goto L_839C24;
L_839C24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C24u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C24 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C27;
L_839C27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C27u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C27 AND
    cpu.logicAnd(0x400u);
    goto L_839C2A;
L_839C2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2A BEQ -> $839C4D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C2C;
L_839C2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839C2F;
L_839C2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C2F CMP
    cpu.compareA(0x400u);
    goto L_839C32;
L_839C32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C32 BCC -> $839C4D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C4D; }
    goto L_839C34;
L_839C34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C34 CPY
    cpu.compareY(0x20u);
    goto L_839C37;
L_839C37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C37 BCS -> $839C58
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C39;
L_839C39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C39 TYA
    cpu.transfer("TYA");
    goto L_839C3A;
L_839C3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3A INC
    cpu.inc('A');
    goto L_839C3B;
L_839C3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3B INC
    cpu.inc('A');
    goto L_839C3C;
L_839C3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Cu, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C3C STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C3F;
L_839C3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C3Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C3F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C3Fu);return;} hw.unresolvedReturn(0x839C3Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C40 TYA
    cpu.transfer("TYA");
    goto L_839C41;
L_839C41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C41 BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C43;
L_839C43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C43 SEC
    cpu.setFlag('C', true);
    goto L_839C44;
L_839C44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C44 SBC
    cpu.sbc(0x4u);
    goto L_839C47;
L_839C47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C47 BCC -> $839C55
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839C55; }
    goto L_839C49;
L_839C49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C49u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C49 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C4C;
L_839C4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C4C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C4Cu);return;} hw.unresolvedReturn(0x839C4Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4D TYA
    cpu.transfer("TYA");
    goto L_839C4E;
L_839C4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C4E BEQ -> $839C58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839C58; }
    goto L_839C50;
L_839C50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C50u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C50 DEC
    cpu.decReg('A');
    goto L_839C51;
L_839C51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C51u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C51 STA
    hw.write(cpu.address("absx", 0x10CAu), cpu.a, cpu.m8?8:16);
    goto L_839C54;
L_839C54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C54u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C54 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C54u);return;} hw.unresolvedReturn(0x839C54u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839C55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C55u, 6u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839C55 STZ
    hw.write(cpu.address("absx", 0x10CAu), 0, cpu.m8?8:16);
    goto L_839C58;
L_839C58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9C58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9C58u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839C58 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839C58u);return;} hw.unresolvedReturn(0x839C58u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A600_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A600u: goto L_83A600;
    case 0x83A603u: goto L_83A603;
    case 0x83A605u: goto L_83A605;
    case 0x83A608u: goto L_83A608;
    case 0x83A609u: goto L_83A609;
    case 0x83A60Au: goto L_83A60A;
    case 0x83A60Bu: goto L_83A60B;
    case 0x83A60Eu: goto L_83A60E;
    case 0x83A610u: goto L_83A610;
    case 0x83A613u: goto L_83A613;
    case 0x83A616u: goto L_83A616;
    case 0x83A619u: goto L_83A619;
    case 0x83A61Bu: goto L_83A61B;
    case 0x83A61Eu: goto L_83A61E;
    case 0x83A61Fu: goto L_83A61F;
    case 0x83A620u: goto L_83A620;
    case 0x83A621u: goto L_83A621;
    case 0x83A622u: goto L_83A622;
    case 0x83A625u: goto L_83A625;
    case 0x83A626u: goto L_83A626;
    case 0x83A629u: goto L_83A629;
    case 0x83A62Bu: goto L_83A62B;
    case 0x83A62Eu: goto L_83A62E;
    case 0x83A630u: goto L_83A630;
    case 0x83A632u: goto L_83A632;
    case 0x83A634u: goto L_83A634;
    case 0x83A638u: goto L_83A638;
    case 0x83A63Au: goto L_83A63A;
    case 0x83A63Cu: goto L_83A63C;
    case 0x83A63Fu: goto L_83A63F;
    case 0x83A641u: goto L_83A641;
    case 0x83A643u: goto L_83A643;
    case 0x83A646u: goto L_83A646;
    case 0x83A649u: goto L_83A649;
    case 0x83A64Bu: goto L_83A64B;
    case 0x83A64Eu: goto L_83A64E;
    case 0x83A650u: goto L_83A650;
    case 0x83A652u: goto L_83A652;
    case 0x83A654u: goto L_83A654;
    case 0x83A656u: goto L_83A656;
    case 0x83A658u: goto L_83A658;
    case 0x83A65Bu: goto L_83A65B;
    case 0x83A65Cu: goto L_83A65C;
    case 0x83A65Eu: goto L_83A65E;
    case 0x83A660u: goto L_83A660;
    case 0x83A663u: goto L_83A663;
    case 0x83A665u: goto L_83A665;
    case 0x83A667u: goto L_83A667;
    case 0x83A669u: goto L_83A669;
    case 0x83A66Au: goto L_83A66A;
    case 0x83A66Du: goto L_83A66D;
    case 0x83A66Fu: goto L_83A66F;
    case 0x83A671u: goto L_83A671;
    case 0x83A673u: goto L_83A673;
    case 0x83A676u: goto L_83A676;
    case 0x83A678u: goto L_83A678;
    case 0x83A67Au: goto L_83A67A;
    case 0x83A67Cu: goto L_83A67C;
    case 0x83A67Eu: goto L_83A67E;
    case 0x83A682u: goto L_83A682;
    case 0x83A684u: goto L_83A684;
    case 0x83A686u: goto L_83A686;
    case 0x83A689u: goto L_83A689;
    case 0x83A68Bu: goto L_83A68B;
    case 0x83A68Du: goto L_83A68D;
    case 0x83A690u: goto L_83A690;
    case 0x83A693u: goto L_83A693;
    case 0x83A695u: goto L_83A695;
    case 0x83A697u: goto L_83A697;
    case 0x83A699u: goto L_83A699;
    case 0x83A69Bu: goto L_83A69B;
    case 0x83A69Du: goto L_83A69D;
    case 0x83A6A0u: goto L_83A6A0;
    case 0x83A6A1u: goto L_83A6A1;
    case 0x83A6A3u: goto L_83A6A3;
    case 0x83A6A5u: goto L_83A6A5;
    case 0x83A6A8u: goto L_83A6A8;
    case 0x83A6AAu: goto L_83A6AA;
    case 0x83A6ACu: goto L_83A6AC;
    case 0x83A6AEu: goto L_83A6AE;
    case 0x83A6AFu: goto L_83A6AF;
    case 0x83A6B2u: goto L_83A6B2;
    case 0x83A6B4u: goto L_83A6B4;
    case 0x83A6B6u: goto L_83A6B6;
    case 0x83A6B8u: goto L_83A6B8;
    case 0x83A6BBu: goto L_83A6BB;
    case 0x83A6BDu: goto L_83A6BD;
    case 0x83A6BFu: goto L_83A6BF;
    case 0x83A6C2u: goto L_83A6C2;
    case 0x83A6C3u: goto L_83A6C3;
    case 0x83A6C5u: goto L_83A6C5;
    case 0x83A6C7u: goto L_83A6C7;
    case 0x83A6CAu: goto L_83A6CA;
    case 0x83A6CCu: goto L_83A6CC;
    case 0x83A6CFu: goto L_83A6CF;
    case 0x83A6D1u: goto L_83A6D1;
    case 0x83A6D3u: goto L_83A6D3;
    case 0x83A6D4u: goto L_83A6D4;
    case 0x83A6D5u: goto L_83A6D5;
    case 0x83A6D7u: goto L_83A6D7;
    case 0x83A6D9u: goto L_83A6D9;
    case 0x83A6DAu: goto L_83A6DA;
    case 0x83A6DBu: goto L_83A6DB;
    case 0x83A6DDu: goto L_83A6DD;
    case 0x83A6DFu: goto L_83A6DF;
    case 0x83A6E0u: goto L_83A6E0;
    case 0x83A6E2u: goto L_83A6E2;
    case 0x83A6E4u: goto L_83A6E4;
    case 0x83A6E5u: goto L_83A6E5;
    case 0x83A6E7u: goto L_83A6E7;
    case 0x83A6E9u: goto L_83A6E9;
    case 0x83A6EBu: goto L_83A6EB;
    case 0x83A6EDu: goto L_83A6ED;
    case 0x83A6EFu: goto L_83A6EF;
    case 0x83A6F1u: goto L_83A6F1;
    case 0x83A6F3u: goto L_83A6F3;
    case 0x83A6F5u: goto L_83A6F5;
    case 0x83A6F6u: goto L_83A6F6;
    case 0x83A6F7u: goto L_83A6F7;
    case 0x83A6F9u: goto L_83A6F9;
    case 0x83A6FBu: goto L_83A6FB;
    case 0x83A6FCu: goto L_83A6FC;
    case 0x83A6FDu: goto L_83A6FD;
    case 0x83A6FFu: goto L_83A6FF;
    case 0x83A701u: goto L_83A701;
    case 0x83A702u: goto L_83A702;
    case 0x83A704u: goto L_83A704;
    case 0x83A706u: goto L_83A706;
    case 0x83A707u: goto L_83A707;
    case 0x83A709u: goto L_83A709;
    case 0x83A70Bu: goto L_83A70B;
    case 0x83A70Du: goto L_83A70D;
    case 0x83A70Fu: goto L_83A70F;
    case 0x83A711u: goto L_83A711;
    case 0x83A713u: goto L_83A713;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A600 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A603;
L_83A603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A603 BPL -> $83A609
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A609; }
    goto L_83A605;
L_83A605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A605 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A608;
L_83A608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A608 INC
    cpu.inc('A');
    goto L_83A609;
L_83A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A609 ASL
    cpu.aslA();
    goto L_83A60A;
L_83A60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60A XBA
    cpu.xba();
    goto L_83A60B;
L_83A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60B AND
    cpu.logicAnd(0xFFu);
    goto L_83A60E;
L_83A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83A610;
L_83A610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A610 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A613;
L_83A613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A613 AND
    cpu.logicAnd(0xF0u);
    goto L_83A616;
L_83A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A616 BIT
    cpu.bit(0x80u, true);
    goto L_83A619;
L_83A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A619 BEQ -> $83A61F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A61F; }
    goto L_83A61B;
L_83A61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61B EOR
    cpu.logicXor(0x7Fu);
    goto L_83A61E;
L_83A61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61E INC
    cpu.inc('A');
    goto L_83A61F;
L_83A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61F LSR
    cpu.lsrA();
    goto L_83A620;
L_83A620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A620 LSR
    cpu.lsrA();
    goto L_83A621;
L_83A621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A621 LSR
    cpu.lsrA();
    goto L_83A622;
L_83A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A622 AND
    cpu.logicAnd(0xEu);
    goto L_83A625;
L_83A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A625 TAY
    cpu.transfer("TAY");
    goto L_83A626;
L_83A626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u, 5u + 1u, 3u, cpu.address("absy", 0xF974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A626 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF974u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A629;
L_83A629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A629 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83A62B;
L_83A62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu, 5u + 1u, 3u, cpu.address("absy", 0xF97Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF97Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A62E;
L_83A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A630;
L_83A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A630 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A632;
L_83A632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A632 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A634;
L_83A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A634 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA637u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA638u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A634u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A638;
L_83A638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA638u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA638u,0x83A638u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A638 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A63A;
L_83A63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63A STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A63C;
L_83A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A63F;
L_83A63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63F BPL -> $83A643
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A643; }
    goto L_83A641;
L_83A641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A641 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A643;
L_83A643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A643 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A646;
L_83A646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A646 CPY
    cpu.compareY(0xC0u);
    goto L_83A649;
L_83A649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A649 BCS -> $83A652
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A64B;
L_83A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64B CPY
    cpu.compareY(0x40u);
    goto L_83A64E;
L_83A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64E BCC -> $83A652
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A650;
L_83A650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A650 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A652;
L_83A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A652 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A654;
L_83A654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A654 BCC -> $83A669
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A669; }
    goto L_83A656;
L_83A656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A656 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A658;
L_83A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A658 LDA
    cpu.setA(0x0u, 16);
    goto L_83A65B;
L_83A65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65B SEC
    cpu.setFlag('C', true);
    goto L_83A65C;
L_83A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A65E;
L_83A65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A660;
L_83A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A660 LDA
    cpu.setA(0x0u, 16);
    goto L_83A663;
L_83A663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A663 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A665;
L_83A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A665 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A667;
L_83A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A667 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A669;
L_83A669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A669 CLC
    cpu.setFlag('C', false);
    goto L_83A66A;
L_83A66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66A ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD4u), cpu.m8?8:16));
    goto L_83A66D;
L_83A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66D STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A66F;
L_83A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66F STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A671;
L_83A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A671 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A673;
L_83A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A673 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD2u), cpu.m8?8:16));
    goto L_83A676;
L_83A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A676 STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A678;
L_83A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A678 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A67A;
L_83A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A67C;
L_83A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A67E;
L_83A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A67E JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA681u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA682u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A67Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A682;
L_83A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA682u,0x83A682u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A682 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A684;
L_83A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A684 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A686;
L_83A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A686 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A689;
L_83A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A689 BPL -> $83A68D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A68D; }
    goto L_83A68B;
L_83A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68B INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A68D;
L_83A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A690;
L_83A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A690 CPY
    cpu.compareY(0x80u);
    goto L_83A693;
L_83A693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A693 BCC -> $83A697
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A697; }
    goto L_83A695;
L_83A695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A695 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A697;
L_83A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A697 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A699;
L_83A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A699 BCC -> $83A6AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A6AE; }
    goto L_83A69B;
L_83A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A69D;
L_83A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69D LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A0;
L_83A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A0 SEC
    cpu.setFlag('C', true);
    goto L_83A6A1;
L_83A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A6A3;
L_83A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A3 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A6A5;
L_83A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A5 LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A8;
L_83A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A6AA;
L_83A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A6AC;
L_83A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6AE;
L_83A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AE CLC
    cpu.setFlag('C', false);
    goto L_83A6AF;
L_83A6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AF ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD8u), cpu.m8?8:16));
    goto L_83A6B2;
L_83A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B2 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A6B4;
L_83A6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B4 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A6B6;
L_83A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6B8;
L_83A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B8 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD6u), cpu.m8?8:16));
    goto L_83A6BB;
L_83A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BB STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BD;
L_83A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BD STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BF;
L_83A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C2;
L_83A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C2 LSR
    cpu.lsrA();
    goto L_83A6C3;
L_83A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C3 BNE -> $83A713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6C5;
L_83A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C7;
L_83A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C7 CMP
    cpu.compareA(0x8u);
    goto L_83A6CA;
L_83A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CA BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6CC;
L_83A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CC AND
    cpu.logicAnd(0x1u);
    goto L_83A6CF;
L_83A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CF BNE -> $83A6F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A6F3; }
    goto L_83A6D1;
L_83A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6D3;
L_83A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D3 ASL
    cpu.aslA();
    goto L_83A6D4;
L_83A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D4 PHP
    cpu.push("PHP", hw);
    goto L_83A6D5;
L_83A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D5 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6D7;
L_83A6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6D9;
L_83A6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D9 PLP
    cpu.pop("PLP", hw);
    goto L_83A6DA;
L_83A6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6DAu,0x83A6DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DA PHP
    cpu.push("PHP", hw);
    goto L_83A6DB;
L_83A6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DB ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6DD;
L_83A6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6DF;
L_83A6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DF PLP
    cpu.pop("PLP", hw);
    goto L_83A6E0;
L_83A6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6E0u,0x83A6E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E0 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6E2;
L_83A6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E2 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6E4;
L_83A6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E4 SEC
    cpu.setFlag('C', true);
    goto L_83A6E5;
L_83A6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6E7;
L_83A6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_83A6E9;
L_83A6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E9 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A6EB;
L_83A6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6ED;
L_83A6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6ED SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_83A6EF;
L_83A6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EF STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A6F1;
L_83A6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F1 BRA -> $83A713
    goto L_83A713;
L_83A6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6F5;
L_83A6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F5 ASL
    cpu.aslA();
    goto L_83A6F6;
L_83A6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6F6 PHP
    cpu.push("PHP", hw);
    goto L_83A6F7;
L_83A6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6F9;
L_83A6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F9 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A6FB;
L_83A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FB PLP
    cpu.pop("PLP", hw);
    goto L_83A6FC;
L_83A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6FCu,0x83A6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FC PHP
    cpu.push("PHP", hw);
    goto L_83A6FD;
L_83A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6FF;
L_83A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FF ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A701;
L_83A701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A701 PLP
    cpu.pop("PLP", hw);
    goto L_83A702;
L_83A702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA702u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA702u,0x83A702u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A702 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A704;
L_83A704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A704 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A706;
L_83A706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A706 SEC
    cpu.setFlag('C', true);
    goto L_83A707;
L_83A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A707 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A709;
L_83A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A709 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_83A70B;
L_83A70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70B STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A70D;
L_83A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A70F;
L_83A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_83A711;
L_83A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A711 STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A713;
L_83A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A600_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A600u: goto L_83A600;
    case 0x83A603u: goto L_83A603;
    case 0x83A605u: goto L_83A605;
    case 0x83A608u: goto L_83A608;
    case 0x83A609u: goto L_83A609;
    case 0x83A60Au: goto L_83A60A;
    case 0x83A60Bu: goto L_83A60B;
    case 0x83A60Eu: goto L_83A60E;
    case 0x83A610u: goto L_83A610;
    case 0x83A613u: goto L_83A613;
    case 0x83A616u: goto L_83A616;
    case 0x83A619u: goto L_83A619;
    case 0x83A61Bu: goto L_83A61B;
    case 0x83A61Eu: goto L_83A61E;
    case 0x83A61Fu: goto L_83A61F;
    case 0x83A620u: goto L_83A620;
    case 0x83A621u: goto L_83A621;
    case 0x83A622u: goto L_83A622;
    case 0x83A625u: goto L_83A625;
    case 0x83A626u: goto L_83A626;
    case 0x83A629u: goto L_83A629;
    case 0x83A62Bu: goto L_83A62B;
    case 0x83A62Eu: goto L_83A62E;
    case 0x83A630u: goto L_83A630;
    case 0x83A632u: goto L_83A632;
    case 0x83A634u: goto L_83A634;
    case 0x83A638u: goto L_83A638;
    case 0x83A63Au: goto L_83A63A;
    case 0x83A63Cu: goto L_83A63C;
    case 0x83A63Fu: goto L_83A63F;
    case 0x83A641u: goto L_83A641;
    case 0x83A643u: goto L_83A643;
    case 0x83A646u: goto L_83A646;
    case 0x83A649u: goto L_83A649;
    case 0x83A64Bu: goto L_83A64B;
    case 0x83A64Eu: goto L_83A64E;
    case 0x83A650u: goto L_83A650;
    case 0x83A652u: goto L_83A652;
    case 0x83A654u: goto L_83A654;
    case 0x83A656u: goto L_83A656;
    case 0x83A658u: goto L_83A658;
    case 0x83A65Bu: goto L_83A65B;
    case 0x83A65Cu: goto L_83A65C;
    case 0x83A65Eu: goto L_83A65E;
    case 0x83A660u: goto L_83A660;
    case 0x83A663u: goto L_83A663;
    case 0x83A665u: goto L_83A665;
    case 0x83A667u: goto L_83A667;
    case 0x83A669u: goto L_83A669;
    case 0x83A66Au: goto L_83A66A;
    case 0x83A66Du: goto L_83A66D;
    case 0x83A66Fu: goto L_83A66F;
    case 0x83A671u: goto L_83A671;
    case 0x83A673u: goto L_83A673;
    case 0x83A676u: goto L_83A676;
    case 0x83A678u: goto L_83A678;
    case 0x83A67Au: goto L_83A67A;
    case 0x83A67Cu: goto L_83A67C;
    case 0x83A67Eu: goto L_83A67E;
    case 0x83A682u: goto L_83A682;
    case 0x83A684u: goto L_83A684;
    case 0x83A686u: goto L_83A686;
    case 0x83A689u: goto L_83A689;
    case 0x83A68Bu: goto L_83A68B;
    case 0x83A68Du: goto L_83A68D;
    case 0x83A690u: goto L_83A690;
    case 0x83A693u: goto L_83A693;
    case 0x83A695u: goto L_83A695;
    case 0x83A697u: goto L_83A697;
    case 0x83A699u: goto L_83A699;
    case 0x83A69Bu: goto L_83A69B;
    case 0x83A69Du: goto L_83A69D;
    case 0x83A6A0u: goto L_83A6A0;
    case 0x83A6A1u: goto L_83A6A1;
    case 0x83A6A3u: goto L_83A6A3;
    case 0x83A6A5u: goto L_83A6A5;
    case 0x83A6A8u: goto L_83A6A8;
    case 0x83A6AAu: goto L_83A6AA;
    case 0x83A6ACu: goto L_83A6AC;
    case 0x83A6AEu: goto L_83A6AE;
    case 0x83A6AFu: goto L_83A6AF;
    case 0x83A6B2u: goto L_83A6B2;
    case 0x83A6B4u: goto L_83A6B4;
    case 0x83A6B6u: goto L_83A6B6;
    case 0x83A6B8u: goto L_83A6B8;
    case 0x83A6BBu: goto L_83A6BB;
    case 0x83A6BDu: goto L_83A6BD;
    case 0x83A6BFu: goto L_83A6BF;
    case 0x83A6C2u: goto L_83A6C2;
    case 0x83A6C3u: goto L_83A6C3;
    case 0x83A6C5u: goto L_83A6C5;
    case 0x83A6C7u: goto L_83A6C7;
    case 0x83A6CAu: goto L_83A6CA;
    case 0x83A6CCu: goto L_83A6CC;
    case 0x83A6CFu: goto L_83A6CF;
    case 0x83A6D1u: goto L_83A6D1;
    case 0x83A6D3u: goto L_83A6D3;
    case 0x83A6D4u: goto L_83A6D4;
    case 0x83A6D5u: goto L_83A6D5;
    case 0x83A6D7u: goto L_83A6D7;
    case 0x83A6D9u: goto L_83A6D9;
    case 0x83A6DAu: goto L_83A6DA;
    case 0x83A6DBu: goto L_83A6DB;
    case 0x83A6DDu: goto L_83A6DD;
    case 0x83A6DFu: goto L_83A6DF;
    case 0x83A6E0u: goto L_83A6E0;
    case 0x83A6E2u: goto L_83A6E2;
    case 0x83A6E4u: goto L_83A6E4;
    case 0x83A6E5u: goto L_83A6E5;
    case 0x83A6E7u: goto L_83A6E7;
    case 0x83A6E9u: goto L_83A6E9;
    case 0x83A6EBu: goto L_83A6EB;
    case 0x83A6EDu: goto L_83A6ED;
    case 0x83A6EFu: goto L_83A6EF;
    case 0x83A6F1u: goto L_83A6F1;
    case 0x83A6F3u: goto L_83A6F3;
    case 0x83A6F5u: goto L_83A6F5;
    case 0x83A6F6u: goto L_83A6F6;
    case 0x83A6F7u: goto L_83A6F7;
    case 0x83A6F9u: goto L_83A6F9;
    case 0x83A6FBu: goto L_83A6FB;
    case 0x83A6FCu: goto L_83A6FC;
    case 0x83A6FDu: goto L_83A6FD;
    case 0x83A6FFu: goto L_83A6FF;
    case 0x83A701u: goto L_83A701;
    case 0x83A702u: goto L_83A702;
    case 0x83A704u: goto L_83A704;
    case 0x83A706u: goto L_83A706;
    case 0x83A707u: goto L_83A707;
    case 0x83A709u: goto L_83A709;
    case 0x83A70Bu: goto L_83A70B;
    case 0x83A70Du: goto L_83A70D;
    case 0x83A70Fu: goto L_83A70F;
    case 0x83A711u: goto L_83A711;
    case 0x83A713u: goto L_83A713;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA600u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A600 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A603;
L_83A603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA603u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A603 BPL -> $83A609
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A609; }
    goto L_83A605;
L_83A605:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA605u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA605u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A605 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A608;
L_83A608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA608u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A608 INC
    cpu.inc('A');
    goto L_83A609;
L_83A609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA609u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A609 ASL
    cpu.aslA();
    goto L_83A60A;
L_83A60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Au, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60A XBA
    cpu.xba();
    goto L_83A60B;
L_83A60B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60B AND
    cpu.logicAnd(0xFFu);
    goto L_83A60E;
L_83A60E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA60Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA60Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A60E STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83A610;
L_83A610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA610u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A610 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1098u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A613;
L_83A613:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA613u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA613u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A613 AND
    cpu.logicAnd(0xF0u);
    goto L_83A616;
L_83A616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA616u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A616 BIT
    cpu.bit(0x80u, true);
    goto L_83A619;
L_83A619:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA619u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA619u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A619 BEQ -> $83A61F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A61F; }
    goto L_83A61B;
L_83A61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61B EOR
    cpu.logicXor(0x7Fu);
    goto L_83A61E;
L_83A61E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61E INC
    cpu.inc('A');
    goto L_83A61F;
L_83A61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA61Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A61F LSR
    cpu.lsrA();
    goto L_83A620;
L_83A620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA620u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A620 LSR
    cpu.lsrA();
    goto L_83A621;
L_83A621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A621 LSR
    cpu.lsrA();
    goto L_83A622;
L_83A622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA622u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A622 AND
    cpu.logicAnd(0xEu);
    goto L_83A625;
L_83A625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA625u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A625 TAY
    cpu.transfer("TAY");
    goto L_83A626;
L_83A626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA626u, 5u + 1u, 3u, cpu.address("absy", 0xF974u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A626 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF974u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A629;
L_83A629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA629u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A629 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_83A62B;
L_83A62B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Bu, 5u + 1u, 3u, cpu.address("absy", 0xF97Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62B LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xF97Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A62E;
L_83A62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A62E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A630;
L_83A630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A630 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A632;
L_83A632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A632 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A634;
L_83A634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA634u, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A634 JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA637u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA638u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A634u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A638;
L_83A638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA638u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA638u,0x83A638u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA638u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A638 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A63A;
L_83A63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63A STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A63C;
L_83A63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Cu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A63F;
L_83A63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA63Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A63F BPL -> $83A643
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A643; }
    goto L_83A641;
L_83A641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA641u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A641 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A643;
L_83A643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA643u, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A643 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A646;
L_83A646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA646u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A646 CPY
    cpu.compareY(0xC0u);
    goto L_83A649;
L_83A649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA649u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A649 BCS -> $83A652
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A64B;
L_83A64B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64B CPY
    cpu.compareY(0x40u);
    goto L_83A64E;
L_83A64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA64Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A64E BCC -> $83A652
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A652; }
    goto L_83A650;
L_83A650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA650u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A650 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A652;
L_83A652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA652u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A652 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A654;
L_83A654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA654u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A654 BCC -> $83A669
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A669; }
    goto L_83A656;
L_83A656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A656 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A658;
L_83A658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA658u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A658 LDA
    cpu.setA(0x0u, 16);
    goto L_83A65B;
L_83A65B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65B SEC
    cpu.setFlag('C', true);
    goto L_83A65C;
L_83A65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65C SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A65E;
L_83A65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA65Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A65E STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A660;
L_83A660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA660u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A660 LDA
    cpu.setA(0x0u, 16);
    goto L_83A663;
L_83A663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA663u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A663 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A665;
L_83A665:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA665u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA665u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A665 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A667;
L_83A667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA667u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A667 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A669;
L_83A669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA669u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A669 CLC
    cpu.setFlag('C', false);
    goto L_83A66A;
L_83A66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Au, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66A ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD4u), cpu.m8?8:16));
    goto L_83A66D;
L_83A66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66D STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A66F;
L_83A66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA66Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A66F STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A671;
L_83A671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA671u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A671 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A673;
L_83A673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA673u, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A673 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD2u), cpu.m8?8:16));
    goto L_83A676;
L_83A676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA676u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A676 STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A678;
L_83A678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA678u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A678 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A67A;
L_83A67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67A LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A67C;
L_83A67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A67C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A67E;
L_83A67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA67Eu, 8u, 4u, 0x808D32u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83A67E JSL -> $808D32 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA681u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA682u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D32u, 0x83A67Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A682;
L_83A682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA682u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA682u,0x83A682u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA682u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A682 STY
    hw.write(cpu.address("dp", 0xAu), cpu.y, cpu.x8?8:16);
    goto L_83A684;
L_83A684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA684u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A684 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_83A686;
L_83A686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA686u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A686 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1090u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A689;
L_83A689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA689u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A689 BPL -> $83A68D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A68D; }
    goto L_83A68B;
L_83A68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68B INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A68D;
L_83A68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA68Du, 5u + 1u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A68D LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1098u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A690;
L_83A690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA690u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A690 CPY
    cpu.compareY(0x80u);
    goto L_83A693;
L_83A693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA693u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A693 BCC -> $83A697
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A697; }
    goto L_83A695;
L_83A695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA695u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A695 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A697;
L_83A697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA697u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A697 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_83A699;
L_83A699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA699u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A699 BCC -> $83A6AE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A6AE; }
    goto L_83A69B;
L_83A69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A69D;
L_83A69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA69Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA69Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A69D LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A0;
L_83A6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A0 SEC
    cpu.setFlag('C', true);
    goto L_83A6A1;
L_83A6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A6A3;
L_83A6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A3 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A6A5;
L_83A6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A5 LDA
    cpu.setA(0x0u, 16);
    goto L_83A6A8;
L_83A6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A6AA;
L_83A6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A6AC;
L_83A6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6AE;
L_83A6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AE CLC
    cpu.setFlag('C', false);
    goto L_83A6AF;
L_83A6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6AFu, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6AF ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD8u), cpu.m8?8:16));
    goto L_83A6B2;
L_83A6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B2 STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A6B4;
L_83A6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B4 STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_83A6B6;
L_83A6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6B8;
L_83A6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6B8u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6B8 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BD6u), cpu.m8?8:16));
    goto L_83A6BB;
L_83A6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BB STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BD;
L_83A6BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BD STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A6BF;
L_83A6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6BFu, 5u + 1u, 3u, cpu.address("absx", 0x0024u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6BF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C2;
L_83A6C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C2 LSR
    cpu.lsrA();
    goto L_83A6C3;
L_83A6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C3 BNE -> $83A713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6C5;
L_83A6C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6C7;
L_83A6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6C7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6C7 CMP
    cpu.compareA(0x8u);
    goto L_83A6CA;
L_83A6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CA BCC -> $83A713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A713; }
    goto L_83A6CC;
L_83A6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CC AND
    cpu.logicAnd(0x1u);
    goto L_83A6CF;
L_83A6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6CF BNE -> $83A6F3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A6F3; }
    goto L_83A6D1;
L_83A6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6D3;
L_83A6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D3 ASL
    cpu.aslA();
    goto L_83A6D4;
L_83A6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D4 PHP
    cpu.push("PHP", hw);
    goto L_83A6D5;
L_83A6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D5 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6D7;
L_83A6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6D7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6D9;
L_83A6D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6D9u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6D9 PLP
    cpu.pop("PLP", hw);
    goto L_83A6DA;
L_83A6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6DAu,0x83A6DAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DAu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DA PHP
    cpu.push("PHP", hw);
    goto L_83A6DB;
L_83A6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DBu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DB ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6DD;
L_83A6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6DD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6DF;
L_83A6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6DFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6DF PLP
    cpu.pop("PLP", hw);
    goto L_83A6E0;
L_83A6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6E0u,0x83A6E0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E0u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E0 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x18u), cpu.m8?8:16);
    goto L_83A6E2;
L_83A6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E2 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Au), cpu.m8?8:16);
    goto L_83A6E4;
L_83A6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E4 SEC
    cpu.setFlag('C', true);
    goto L_83A6E5;
L_83A6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6E7;
L_83A6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E7 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16));
    goto L_83A6E9;
L_83A6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6E9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6E9 STA
    hw.write(cpu.address("dpx", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83A6EB;
L_83A6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6ED;
L_83A6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6ED SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16));
    goto L_83A6EF;
L_83A6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6EFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6EF STA
    hw.write(cpu.address("dpx", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_83A6F1;
L_83A6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F1 BRA -> $83A713
    goto L_83A713;
L_83A6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A6F5;
L_83A6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F5 ASL
    cpu.aslA();
    goto L_83A6F6;
L_83A6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6F6 PHP
    cpu.push("PHP", hw);
    goto L_83A6F7;
L_83A6F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F7u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F7 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6F9;
L_83A6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6F9u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6F9 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A6FB;
L_83A6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FB PLP
    cpu.pop("PLP", hw);
    goto L_83A6FC;
L_83A6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA6FCu,0x83A6FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FCu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A6FC PHP
    cpu.push("PHP", hw);
    goto L_83A6FD;
L_83A6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FDu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FD ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A6FF;
L_83A6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA6FFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A6FF ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A701;
L_83A701:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA701u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA701u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $83A701 PLP
    cpu.pop("PLP", hw);
    goto L_83A702;
L_83A702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA702u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA702u,0x83A702u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA702u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A702 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_83A704;
L_83A704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA704u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A704 ROR
    cpu.rorMem(hw, cpu.address("dp", 0x1Eu), cpu.m8?8:16);
    goto L_83A706;
L_83A706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA706u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA706u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A706 SEC
    cpu.setFlag('C', true);
    goto L_83A707;
L_83A707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA707u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A707 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A709;
L_83A709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA709u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A709 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Eu), cpu.m8?8:16));
    goto L_83A70B;
L_83A70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70B STA
    hw.write(cpu.address("dpx", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_83A70D;
L_83A70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A70F;
L_83A70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA70Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A70F SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16));
    goto L_83A711;
L_83A711:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA711u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA711u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A711 STA
    hw.write(cpu.address("dpx", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_83A713;
L_83A713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A713u);return;} hw.unresolvedReturn(0x83A713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83C685_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C684u: goto L_83C684;
    case 0x83C685u: goto L_83C685;
    case 0x83C687u: goto L_83C687;
    case 0x83C68Au: goto L_83C68A;
    case 0x83C68Cu: goto L_83C68C;
    case 0x83C690u: goto L_83C690;
    case 0x83C693u: goto L_83C693;
    case 0x83C694u: goto L_83C694;
    case 0x83C697u: goto L_83C697;
    case 0x83C699u: goto L_83C699;
    case 0x83C69Du: goto L_83C69D;
    case 0x83C69Eu: goto L_83C69E;
    case 0x83C6A0u: goto L_83C6A0;
    case 0x83C6A3u: goto L_83C6A3;
    case 0x83C6A5u: goto L_83C6A5;
    case 0x83C6A6u: goto L_83C6A6;
    case 0x83C6A8u: goto L_83C6A8;
    case 0x83C6ABu: goto L_83C6AB;
    case 0x83C6ADu: goto L_83C6AD;
    case 0x83C6AFu: goto L_83C6AF;
    case 0x83C6B2u: goto L_83C6B2;
    case 0x83C6B4u: goto L_83C6B4;
    case 0x83C6B7u: goto L_83C6B7;
    case 0x83C6B9u: goto L_83C6B9;
    case 0x83C6BBu: goto L_83C6BB;
    case 0x83C6BCu: goto L_83C6BC;
    case 0x83C6BFu: goto L_83C6BF;
    case 0x83C6C1u: goto L_83C6C1;
    case 0x83C6C4u: goto L_83C6C4;
    case 0x83C6C6u: goto L_83C6C6;
    case 0x83C6C9u: goto L_83C6C9;
    case 0x83C6CAu: goto L_83C6CA;
    case 0x83C6CCu: goto L_83C6CC;
    case 0x83C6CFu: goto L_83C6CF;
    case 0x83C6D1u: goto L_83C6D1;
    case 0x83C6D3u: goto L_83C6D3;
    case 0x83C6D4u: goto L_83C6D4;
    case 0x83C6D5u: goto L_83C6D5;
    case 0x83C6D8u: goto L_83C6D8;
    case 0x83C6DAu: goto L_83C6DA;
    case 0x83C6DDu: goto L_83C6DD;
    case 0x83C6DFu: goto L_83C6DF;
    case 0x83C6E2u: goto L_83C6E2;
    case 0x83C6E5u: goto L_83C6E5;
    case 0x83C6E6u: goto L_83C6E6;
    case 0x83C6E7u: goto L_83C6E7;
    case 0x83C6E8u: goto L_83C6E8;
    case 0x83C6EAu: goto L_83C6EA;
    case 0x83C6EDu: goto L_83C6ED;
    case 0x83C6EFu: goto L_83C6EF;
    case 0x83C6F0u: goto L_83C6F0;
    case 0x83C6F1u: goto L_83C6F1;
    case 0x83C6F4u: goto L_83C6F4;
    case 0x83C6F5u: goto L_83C6F5;
    case 0x83C6F8u: goto L_83C6F8;
    case 0x83C6FAu: goto L_83C6FA;
    case 0x83C6FDu: goto L_83C6FD;
    case 0x83C6FFu: goto L_83C6FF;
    case 0x83C702u: goto L_83C702;
    case 0x83C704u: goto L_83C704;
    case 0x83C707u: goto L_83C707;
    case 0x83C709u: goto L_83C709;
    case 0x83C70Cu: goto L_83C70C;
    case 0x83C70Fu: goto L_83C70F;
    case 0x83C712u: goto L_83C712;
    case 0x83C715u: goto L_83C715;
    case 0x83C718u: goto L_83C718;
    case 0x83C71Au: goto L_83C71A;
    case 0x83C71Eu: goto L_83C71E;
    case 0x83C721u: goto L_83C721;
    case 0x83C723u: goto L_83C723;
    case 0x83C725u: goto L_83C725;
    case 0x83C728u: goto L_83C728;
    case 0x83C72Au: goto L_83C72A;
    case 0x83C72Du: goto L_83C72D;
    case 0x83C72Eu: goto L_83C72E;
    case 0x83C731u: goto L_83C731;
    case 0x83C734u: goto L_83C734;
    case 0x83C736u: goto L_83C736;
    case 0x83C739u: goto L_83C739;
    case 0x83C73Au: goto L_83C73A;
    case 0x83C73Cu: goto L_83C73C;
    case 0x83C73Eu: goto L_83C73E;
    case 0x83C741u: goto L_83C741;
    case 0x83C744u: goto L_83C744;
    case 0x83C746u: goto L_83C746;
    case 0x83C749u: goto L_83C749;
    case 0x83C74Bu: goto L_83C74B;
    case 0x83C74Eu: goto L_83C74E;
    case 0x83C750u: goto L_83C750;
    case 0x83C752u: goto L_83C752;
    case 0x83C754u: goto L_83C754;
    case 0x83C756u: goto L_83C756;
    case 0x83C759u: goto L_83C759;
    case 0x83C75Bu: goto L_83C75B;
    case 0x83C75Eu: goto L_83C75E;
    case 0x83C760u: goto L_83C760;
    case 0x83C763u: goto L_83C763;
    case 0x83C765u: goto L_83C765;
    case 0x83C768u: goto L_83C768;
    case 0x83C76Bu: goto L_83C76B;
    case 0x83C76Eu: goto L_83C76E;
    case 0x83C771u: goto L_83C771;
    case 0x83C773u: goto L_83C773;
    case 0x83C776u: goto L_83C776;
    case 0x83C778u: goto L_83C778;
    case 0x83C77Bu: goto L_83C77B;
    case 0x83C77Cu: goto L_83C77C;
    case 0x83C77Du: goto L_83C77D;
    case 0x83C780u: goto L_83C780;
    case 0x83C783u: goto L_83C783;
    case 0x83C786u: goto L_83C786;
    case 0x83C789u: goto L_83C789;
    case 0x83C78Cu: goto L_83C78C;
    case 0x83C78Du: goto L_83C78D;
    case 0x83C78Fu: goto L_83C78F;
    case 0x83C792u: goto L_83C792;
    case 0x83C795u: goto L_83C795;
    case 0x83C798u: goto L_83C798;
    case 0x83C79Bu: goto L_83C79B;
    case 0x83C79Du: goto L_83C79D;
    case 0x83C79Fu: goto L_83C79F;
    case 0x83C7A2u: goto L_83C7A2;
    case 0x83C7A4u: goto L_83C7A4;
    case 0x83C7A7u: goto L_83C7A7;
    case 0x83C7AAu: goto L_83C7AA;
    case 0x83C7ADu: goto L_83C7AD;
    case 0x83C7AEu: goto L_83C7AE;
    case 0x83C7B0u: goto L_83C7B0;
    case 0x83C7B3u: goto L_83C7B3;
    case 0x83C7B5u: goto L_83C7B5;
    case 0x83C7B7u: goto L_83C7B7;
    case 0x83C7B8u: goto L_83C7B8;
    case 0x83C7B9u: goto L_83C7B9;
    case 0x83C7BCu: goto L_83C7BC;
    case 0x83C7BDu: goto L_83C7BD;
    case 0x83C7BFu: goto L_83C7BF;
    case 0x83C7C1u: goto L_83C7C1;
    case 0x83C7C4u: goto L_83C7C4;
    case 0x83C7C6u: goto L_83C7C6;
    case 0x83C7C8u: goto L_83C7C8;
    case 0x83C7CAu: goto L_83C7CA;
    case 0x83C7CBu: goto L_83C7CB;
    case 0x83C7CCu: goto L_83C7CC;
    case 0x83C7CEu: goto L_83C7CE;
    case 0x83C7D0u: goto L_83C7D0;
    case 0x83C7D3u: goto L_83C7D3;
    case 0x83C7D4u: goto L_83C7D4;
    case 0x83C7D5u: goto L_83C7D5;
    case 0x83C7D6u: goto L_83C7D6;
    case 0x83C7D7u: goto L_83C7D7;
    case 0x83C7D8u: goto L_83C7D8;
    case 0x83C7D9u: goto L_83C7D9;
    case 0x83C7DCu: goto L_83C7DC;
    case 0x83C7DFu: goto L_83C7DF;
    case 0x83C7E2u: goto L_83C7E2;
    case 0x83C7E4u: goto L_83C7E4;
    case 0x83C7E6u: goto L_83C7E6;
    case 0x83C7E9u: goto L_83C7E9;
    case 0x83C7ECu: goto L_83C7EC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC684u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC684u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C684 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C684u);return;} hw.unresolvedReturn(0x83C684u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC685u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC685u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C685 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C687;
L_83C687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC687u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC687u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C687 CMP
    cpu.compareA(0x9u);
    goto L_83C68A;
L_83C68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C68A BCS -> $83C684
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C684; }
    goto L_83C68C;
L_83C68C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC68Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC68Cu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C68C JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC68Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC690u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x83C68Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C690;
L_83C690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC690u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC690u,0x83C690u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC690u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC690u, 5u, 3u, cpu.address("abs", 0x1BA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C690 STA
    hw.write(cpu.address("abs", 0x1BA6u), cpu.a, cpu.m8?8:16);
    goto L_83C693;
L_83C693:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC693u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC693u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC693u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C693 ROR
    cpu.rorA();
    goto L_83C694;
L_83C694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC694u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC694u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C694 STA
    hw.write(cpu.address("abs", 0x1BA8u), cpu.a, cpu.m8?8:16);
    goto L_83C697;
L_83C697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC697u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C697 BMI -> $83C684
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C684; }
    goto L_83C699;
L_83C699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC699u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC699u, 8u, 4u, 0x848702u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C699 JSL -> $848702 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC69Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC69Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848702u, 0x83C699u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C69D;
L_83C69D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC69Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC69Du,0x83C69Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC69Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC69Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C69D TAY
    cpu.transfer("TAY");
    goto L_83C69E;
L_83C69E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC69Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC69Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC69Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C69E BNE -> $83C6A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C6A3; }
    goto L_83C6A0;
L_83C6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A0u, 3u, 3u, cpu.address("abs", 0xC684u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6A0 JMP -> $83C684
    goto L_83C684;
L_83C6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A3u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6A3 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_83C6A5;
L_83C6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A5u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6A5 TYA
    cpu.transfer("TYA");
    goto L_83C6A6;
L_83C6A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A6u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6A6 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xDEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C6A8;
L_83C6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6A8 CPY
    cpu.compareY(0x3u);
    goto L_83C6AB;
L_83C6AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6AB BEQ -> $83C6B4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C6B4; }
    goto L_83C6AD;
L_83C6AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ADu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6ADu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6AD SEP
    cpu.sep(0x20u);
    goto L_83C6AF;
L_83C6AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6AFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6AFu, 5u, 3u, cpu.address("absx", 0x0227u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6AF STA
    hw.write(cpu.address("absx", 0x227u), cpu.a, cpu.m8?8:16);
    goto L_83C6B2;
L_83C6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6B2 REP
    cpu.rep(0x20u);
    goto L_83C6B4;
L_83C6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B4u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6B7;
L_83C6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B7u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6B7 BMI -> $83C684
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C684; }
    goto L_83C6B9;
L_83C6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B9u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6B9 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C6BB;
L_83C6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6BB TYA
    cpu.transfer("TYA");
    goto L_83C6BC;
L_83C6BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BCu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BCu, 5u + 1u, 3u, cpu.address("absx", 0x10B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6BC CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x10B0u), cpu.m8?8:16));
    goto L_83C6BF;
L_83C6BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BFu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6BF BEQ -> $83C684
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C684; }
    goto L_83C6C1;
L_83C6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C1u, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6C1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6C4;
L_83C6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6C4 BNE -> $83C6C9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C6C9; }
    goto L_83C6C6;
L_83C6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C6u, 3u, 3u, cpu.address("abs", 0xC7AEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6C6 JMP -> $83C7AE
    goto L_83C7AE;
L_83C6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6C9 LSR
    cpu.lsrA();
    goto L_83C6CA;
L_83C6CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6CA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83C6CC;
L_83C6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CCu, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6CC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6CF;
L_83C6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6CF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83C6D1;
L_83C6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6D1 BEQ -> $83C684
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C684; }
    goto L_83C6D3;
L_83C6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6D3 TYA
    cpu.transfer("TYA");
    goto L_83C6D4;
L_83C6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6D4 SEC
    cpu.setFlag('C', true);
    goto L_83C6D5;
L_83C6D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D5u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D5u, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6D5 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16));
    goto L_83C6D8;
L_83C6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6D8 BCC -> $83C6E5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C6E5; }
    goto L_83C6DA;
L_83C6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6DA CMP
    cpu.compareA(0xCu);
    goto L_83C6DD;
L_83C6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6DD BCC -> $83C6E2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C6E2; }
    goto L_83C6DF;
L_83C6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6DFu, 3u, 3u, cpu.address("abs", 0xC7A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6DF JMP -> $83C7A2
    goto L_83C7A2;
L_83C6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E2u, 3u, 3u, cpu.address("abs", 0xC79Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6E2 JMP -> $83C79D
    goto L_83C79D;
L_83C6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E5u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6E5 TYA
    cpu.transfer("TYA");
    goto L_83C6E6;
L_83C6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6E6 LSR
    cpu.lsrA();
    goto L_83C6E7;
L_83C6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6E7 DEC
    cpu.decReg('A');
    goto L_83C6E8;
L_83C6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6E8 BEQ -> $83C6ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C6ED; }
    goto L_83C6EA;
L_83C6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EAu, 3u, 3u, cpu.address("abs", 0xC7A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6EA JMP -> $83C7A2
    goto L_83C7A2;
L_83C6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6ED LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6EF;
L_83C6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6EF ASL
    cpu.aslA();
    goto L_83C6F0;
L_83C6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6F0 TAY
    cpu.transfer("TAY");
    goto L_83C6F1;
L_83C6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F1u, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6F4;
L_83C6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F4u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6F4 LSR
    cpu.lsrA();
    goto L_83C6F5;
L_83C6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F5u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F5u, 5u + 1u, 3u, cpu.address("absy", 0xDD1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6F5 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xDD1Cu), cpu.m8?8:16));
    goto L_83C6F8;
L_83C6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6F8 BEQ -> $83C6FD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C6FD; }
    goto L_83C6FA;
L_83C6FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FAu, 3u, 3u, cpu.address("abs", 0xC7A2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6FA JMP -> $83C7A2
    goto L_83C7A2;
L_83C6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C6FF;
L_83C6FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC6FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC6FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C6FF CMP
    cpu.compareA(0x6u);
    goto L_83C702;
L_83C702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC702u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC702u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C702 BNE -> $83C70F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C70F; }
    goto L_83C704;
L_83C704:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC704u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC704u, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C704 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C707;
L_83C707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC707u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C707 BNE -> $83C70F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C70F; }
    goto L_83C709;
L_83C709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC709u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC709u, 9u, 3u, cpu.address("absx", 0x10B2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C709 INC
    cpu.incMem(hw, cpu.address("absx", 0x10B2u), cpu.m8?8:16);
    goto L_83C70C;
L_83C70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Cu, 3u, 3u, cpu.address("abs", 0xC798u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C70C JMP -> $83C798
    goto L_83C798;
L_83C70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC70Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Fu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC70Fu, 9u, 3u, cpu.address("absx", 0x10B2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C70F INC
    cpu.incMem(hw, cpu.address("absx", 0x10B2u), cpu.m8?8:16);
    goto L_83C712;
L_83C712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC712u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC712u, 9u, 3u, cpu.address("absx", 0x10D2u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C712 INC
    cpu.incMem(hw, cpu.address("absx", 0x10D2u), cpu.m8?8:16);
    goto L_83C715;
L_83C715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC715u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC715u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C715 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C718;
L_83C718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC718u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC718u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C718 BMI -> $83C71E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C71E; }
    goto L_83C71A;
L_83C71A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Au, 8u, 4u, 0x829C77u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C71A JSL -> $829C77 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC71Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC71Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829C77u, 0x83C71Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C71E;
L_83C71E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC71Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC71Eu,0x83C71Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC71Eu, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C71E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C721;
L_83C721:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC721u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC721u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C721 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xA6u), cpu.m8?8:16));
    goto L_83C723;
L_83C723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C723 BCC -> $83C72E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C72E; }
    goto L_83C725;
L_83C725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC725u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC725u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C725 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C728;
L_83C728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC728u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C728 BNE -> $83C72D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C72D; }
    goto L_83C72A;
L_83C72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Au,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Au, 3u, 3u, cpu.address("abs", 0xC8B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C72A JMP -> $83C8B5
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xC8B5u),0x83C72Au); return;
L_83C72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C72D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C72Du);return;} hw.unresolvedReturn(0x83C72Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC72Eu, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C72E STZ
    hw.write(cpu.address("abs", 0x1BA4u), 0, cpu.m8?8:16);
    goto L_83C731;
L_83C731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC731u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C731 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C734;
L_83C734:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC734u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC734u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C734 BPL -> $83C746
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C746; }
    goto L_83C736;
L_83C736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC736u, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C736 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C739;
L_83C739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC739u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C739 INC
    cpu.inc('A');
    goto L_83C73A;
L_83C73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C73A CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xA6u), cpu.m8?8:16));
    goto L_83C73C;
L_83C73C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C73C BCC -> $83C76E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C76E; }
    goto L_83C73E;
L_83C73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC73Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC73Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C73E LDA
    cpu.setA(0x2u, 16);
    goto L_83C741;
L_83C741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC741u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C741 STA
    hw.write(cpu.address("abs", 0x1BA4u), cpu.a, cpu.m8?8:16);
    goto L_83C744;
L_83C744:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC744u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC744u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C744 BRA -> $83C76E
    goto L_83C76E;
L_83C746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC746u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC746u, 6u, 3u, cpu.address("abs", 0xC888u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C746 JSR -> $83C888 stack real
    { cpu.push16Value(hw,0xC748u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC749u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC888u), 0x83C746u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C749;
L_83C749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC749u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC749u,0x83C749u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC749u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC749u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C749 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C74B;
L_83C74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C74B CMP
    cpu.compareA(0x2u);
    goto L_83C74E;
L_83C74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C74E BNE -> $83C756
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C756; }
    goto L_83C750;
L_83C750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC750u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C750 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C752;
L_83C752:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC752u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC752u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C752 BEQ -> $83C78F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C78F; }
    goto L_83C754;
L_83C754:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC754u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC754u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C754 BNE -> $83C76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C76E; }
    goto L_83C756;
L_83C756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC756u, 5u + 1u, 3u, cpu.address("absx", 0x10CEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C756 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C759;
L_83C759:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC759u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC759u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C759 BEQ -> $83C760
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C760; }
    goto L_83C75B;
L_83C75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C75B CMP
    cpu.compareA(0x5u);
    goto L_83C75E;
L_83C75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC75Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C75E BNE -> $83C76E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C76E; }
    goto L_83C760;
L_83C760:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC760u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC760u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C760 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C763;
L_83C763:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC763u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC763u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC763u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C763 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C765;
L_83C765:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC765u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC765u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC765u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C765 AND
    cpu.logicAnd(0x1Fu);
    goto L_83C768;
L_83C768:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC768u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC768u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C768 ORA
    cpu.logicOr(0xB4u);
    goto L_83C76B;
L_83C76B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Bu, 6u, 3u, cpu.address("absy", 0x1B38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C76B STA
    hw.write(cpu.address("absy", 0x1B38u), cpu.a, cpu.m8?8:16);
    goto L_83C76E;
L_83C76E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC76Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC76Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C76E LDA
    cpu.setA(0x5u, 16);
    goto L_83C771;
L_83C771:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC771u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC771u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC771u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C771 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x96u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C773;
L_83C773:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC773u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC773u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C773 CPY
    cpu.compareY(0x1u);
    goto L_83C776;
L_83C776:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC776u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC776u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C776 BEQ -> $83C77C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C77C; }
    goto L_83C778;
L_83C778:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC778u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC778u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC778u, 5u + 1u, 3u, cpu.address("absx", 0x109Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C778 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C77B;
L_83C77B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C77B XBA
    cpu.xba();
    goto L_83C77C;
L_83C77C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C77C CLC
    cpu.setFlag('C', false);
    goto L_83C77D;
L_83C77D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC77Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC77Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C77D ADC
    cpu.adc(0x3u);
    goto L_83C780;
L_83C780:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC780u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC780u,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC780u, 5u, 3u, cpu.address("abs", 0x1BA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C780 ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x1BA4u), cpu.m8?8:16));
    goto L_83C783;
L_83C783:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC783u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC783u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C783 AND
    cpu.logicAnd(0xFFu);
    goto L_83C786;
L_83C786:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC786u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC786u, 6u, 3u, cpu.address("absx", 0x10C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C786 STA
    hw.write(cpu.address("absx", 0x10C6u), cpu.a, cpu.m8?8:16);
    goto L_83C789;
L_83C789:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC789u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC789u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC789u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C789 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10BAu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C78C;
L_83C78C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C78C TYA
    cpu.transfer("TYA");
    goto L_83C78D;
L_83C78D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C78D BMI -> $83C798
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83C798; }
    goto L_83C78F;
L_83C78F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC78Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC78Fu, 5u + 1u, 3u, cpu.address("absy", 0x00C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C78F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xC4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C792;
L_83C792:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC792u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC792u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC792u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C792 ORA
    cpu.logicOr(0xAu);
    goto L_83C795;
L_83C795:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC795u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC795u, 6u, 3u, cpu.address("absy", 0x00C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C795 STA
    hw.write(cpu.address("absy", 0xC4u), cpu.a, cpu.m8?8:16);
    goto L_83C798;
L_83C798:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC798u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC798u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C798 LDA
    cpu.setA(0x1u, 16);
    goto L_83C79B;
L_83C79B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C79B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83C79D;
L_83C79D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C79D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C79F;
L_83C79F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC79Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC79Fu, 6u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C79F STA
    hw.write(cpu.address("absx", 0x10AEu), cpu.a, cpu.m8?8:16);
    goto L_83C7A2;
L_83C7A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7A4;
L_83C7A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A4u, 6u, 3u, cpu.address("absx", 0x10B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7A4 STA
    hw.write(cpu.address("absx", 0x10B0u), cpu.a, cpu.m8?8:16);
    goto L_83C7A7;
L_83C7A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7A7u, 6u, 3u, cpu.address("abs", 0xC7D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C7A7 JSR -> $83C7D0 stack real
    { cpu.push16Value(hw,0xC7A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC7AAu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC7D0u), 0x83C7A7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C7AA;
L_83C7AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7AAu,0x83C7AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AAu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7AA LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C7AD;
L_83C7AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C7AD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C7ADu);return;} hw.unresolvedReturn(0x83C7ADu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83C7AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7AE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7B0;
L_83C7B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B0 CMP
    cpu.compareA(0x3u);
    goto L_83C7B3;
L_83C7B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B3 BNE -> $83C7C8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C7C8; }
    goto L_83C7B5;
L_83C7B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7B7;
L_83C7B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B7 ASL
    cpu.aslA();
    goto L_83C7B8;
L_83C7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B8 TAY
    cpu.transfer("TAY");
    goto L_83C7B9;
L_83C7B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7B9u, 5u + 1u, 3u, cpu.address("absy", 0xDD1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7B9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDD1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7BC;
L_83C7BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7BC ASL
    cpu.aslA();
    goto L_83C7BD;
L_83C7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7BD SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83C7BF;
L_83C7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7BFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7BF BCC -> $83C7AA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C7AA; }
    goto L_83C7C1;
L_83C7C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7C1 CMP
    cpu.compareA(0x5u);
    goto L_83C7C4;
L_83C7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7C4 BCC -> $83C7AA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C7AA; }
    goto L_83C7C6;
L_83C7C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7C6 BCS -> $83C79D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C79D; }
    goto L_83C7C8;
L_83C7C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7C8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7CA;
L_83C7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7CA LSR
    cpu.lsrA();
    goto L_83C7CB;
L_83C7CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CBu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7CB DEC
    cpu.decReg('A');
    goto L_83C7CC;
L_83C7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7CC BEQ -> $83C79D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C79D; }
    goto L_83C7CE;
L_83C7CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7CEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7CE BNE -> $83C7AA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83C7AA; }
    goto L_83C7D0;
L_83C7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D0u, 5u + 1u, 3u, cpu.address("absx", 0x10B2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7D3;
L_83C7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D3 INC
    cpu.inc('A');
    goto L_83C7D4;
L_83C7D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D4u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D4 XBA
    cpu.xba();
    goto L_83C7D5;
L_83C7D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D5 ASL
    cpu.aslA();
    goto L_83C7D6;
L_83C7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D6 ASL
    cpu.aslA();
    goto L_83C7D7;
L_83C7D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D7 ASL
    cpu.aslA();
    goto L_83C7D8;
L_83C7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D8 ASL
    cpu.aslA();
    goto L_83C7D9;
L_83C7D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7D9u, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7D9 STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    goto L_83C7DC;
L_83C7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DCu, 5u + 1u, 3u, cpu.address("absx", 0x10AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7DF;
L_83C7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DFu,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7DFu, 5u + 1u, 3u, cpu.address("absx", 0x10B0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7DF CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x10B0u), cpu.m8?8:16));
    goto L_83C7E2;
L_83C7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E2 BEQ -> $83C7F2
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83C7F2u,0x83C7E2u); return; }
    goto L_83C7E4;
L_83C7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E4 BCS -> $83C7EF
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83C7EFu,0x83C7E4u); return; }
    goto L_83C7E6;
L_83C7E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E6u, 5u + 1u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C7E9;
L_83C7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7E9 SBC
    cpu.sbc(0xFFFu);
    goto L_83C7EC;
L_83C7EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC7ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC7ECu, 6u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C7EC STA
    hw.write(cpu.address("absx", 0x10B4u), cpu.a, cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC7EFu,0x83C7ECu); return;
}

void sub_83CD30_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CD30u: goto L_83CD30;
    case 0x83CD31u: goto L_83CD31;
    case 0x83CD32u: goto L_83CD32;
    case 0x83CD33u: goto L_83CD33;
    case 0x83CD36u: goto L_83CD36;
    case 0x83CD38u: goto L_83CD38;
    case 0x83CD39u: goto L_83CD39;
    case 0x83CD3Au: goto L_83CD3A;
    case 0x83CD47u: goto L_83CD47;
    case 0x83CD48u: goto L_83CD48;
    case 0x83CD49u: goto L_83CD49;
    case 0x83CD4Au: goto L_83CD4A;
    case 0x83CD4Du: goto L_83CD4D;
    case 0x83CD4Fu: goto L_83CD4F;
    case 0x83CD50u: goto L_83CD50;
    case 0x83CD54u: goto L_83CD54;
    case 0x83CD55u: goto L_83CD55;
    case 0x83CD56u: goto L_83CD56;
    case 0x83CD57u: goto L_83CD57;
    case 0x83CD59u: goto L_83CD59;
    case 0x83CD5Cu: goto L_83CD5C;
    case 0x83CD5Eu: goto L_83CD5E;
    case 0x83CD5Fu: goto L_83CD5F;
    case 0x83CD61u: goto L_83CD61;
    case 0x83CD62u: goto L_83CD62;
    case 0x83CD64u: goto L_83CD64;
    case 0x83CD67u: goto L_83CD67;
    case 0x83CD69u: goto L_83CD69;
    case 0x83CD6Cu: goto L_83CD6C;
    case 0x83CD6Du: goto L_83CD6D;
    case 0x83CD6Eu: goto L_83CD6E;
    case 0x83CD6Fu: goto L_83CD6F;
    case 0x83CD72u: goto L_83CD72;
    case 0x83CD74u: goto L_83CD74;
    case 0x83CD75u: goto L_83CD75;
    case 0x83CD76u: goto L_83CD76;
    case 0x83CD79u: goto L_83CD79;
    case 0x83CD7Cu: goto L_83CD7C;
    case 0x83CD7Eu: goto L_83CD7E;
    case 0x83CD7Fu: goto L_83CD7F;
    case 0x83CD80u: goto L_83CD80;
    case 0x83CD81u: goto L_83CD81;
    case 0x83CD82u: goto L_83CD82;
    case 0x83CD85u: goto L_83CD85;
    case 0x83CD87u: goto L_83CD87;
    case 0x83CD8Au: goto L_83CD8A;
    case 0x83CD8Cu: goto L_83CD8C;
    case 0x83CD8Du: goto L_83CD8D;
    case 0x83CD8Fu: goto L_83CD8F;
    case 0x83CD90u: goto L_83CD90;
    case 0x83CD93u: goto L_83CD93;
    case 0x83CD95u: goto L_83CD95;
    case 0x83CD98u: goto L_83CD98;
    case 0x83CD9Bu: goto L_83CD9B;
    case 0x83CD9Du: goto L_83CD9D;
    case 0x83CD9Eu: goto L_83CD9E;
    case 0x83CDA1u: goto L_83CDA1;
    case 0x83CDA4u: goto L_83CDA4;
    case 0x83CDA6u: goto L_83CDA6;
    case 0x83CDA8u: goto L_83CDA8;
    case 0x83CDA9u: goto L_83CDA9;
    case 0x83CDACu: goto L_83CDAC;
    case 0x83CDAEu: goto L_83CDAE;
    case 0x83CDAFu: goto L_83CDAF;
    case 0x83CDB1u: goto L_83CDB1;
    case 0x83CDB2u: goto L_83CDB2;
    case 0x83CDB5u: goto L_83CDB5;
    case 0x83CDB7u: goto L_83CDB7;
    case 0x83CDBAu: goto L_83CDBA;
    case 0x83CDBDu: goto L_83CDBD;
    case 0x83CDBFu: goto L_83CDBF;
    case 0x83CDC0u: goto L_83CDC0;
    case 0x83CDC1u: goto L_83CDC1;
    case 0x83CDC4u: goto L_83CDC4;
    case 0x83CDC7u: goto L_83CDC7;
    case 0x83CDC9u: goto L_83CDC9;
    case 0x83CDCAu: goto L_83CDCA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CD30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD30u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CD30 PHA
    cpu.push("PHA", hw);
    goto L_83CD31;
L_83CD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD31u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD31 TYA
    cpu.transfer("TYA");
    goto L_83CD32;
L_83CD32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD32u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD32 LSR
    cpu.lsrA();
    goto L_83CD33;
L_83CD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD33u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD33 AND
    cpu.logicAnd(0x3E0u);
    goto L_83CD36;
L_83CD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD36 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CD38;
L_83CD38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD38u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CD38 PLA
    cpu.pop("PLA", hw);
    goto L_83CD39;
L_83CD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD39u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD39 TXY
    cpu.transfer("TXY");
    goto L_83CD3A;
L_83CD3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD3Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD3A BRA -> $83CD47
    goto L_83CD47;
L_83CD47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD47u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD47 ASL
    cpu.aslA();
    goto L_83CD48;
L_83CD48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD48 ASL
    cpu.aslA();
    goto L_83CD49;
L_83CD49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD49u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD49u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD49 XBA
    cpu.xba();
    goto L_83CD4A;
L_83CD4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD4A AND
    cpu.logicAnd(0x1Fu);
    goto L_83CD4D;
L_83CD4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Du,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD4D ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83CD4F;
L_83CD4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD4Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD4F TAX
    cpu.transfer("TAX");
    goto L_83CD50;
L_83CD50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD50u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD50u, 6u, 4u, ((0x7E37FFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD50 LDA
    cpu.loadA(hw.readW(((0x7E37FFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD54;
L_83CD54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD54 ASL
    cpu.aslA();
    goto L_83CD55;
L_83CD55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD55u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD55u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD55 XBA
    cpu.xba();
    goto L_83CD56;
L_83CD56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD56 TYX
    cpu.transfer("TYX");
    goto L_83CD57;
L_83CD57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD57u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD57u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD57 BCC -> $83CD82
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CD82; }
    goto L_83CD59;
L_83CD59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD59u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD59 AND
    cpu.logicAnd(0xFCu);
    goto L_83CD5C;
L_83CD5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD5C BEQ -> $83CD80
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CD80; }
    goto L_83CD5E;
L_83CD5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD5E ASL
    cpu.aslA();
    goto L_83CD5F;
L_83CD5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD5Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD5F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xDCu), cpu.m8?8:16));
    goto L_83CD61;
L_83CD61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD61u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD61 TAY
    cpu.transfer("TAY");
    goto L_83CD62;
L_83CD62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD62u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD62 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD64;
L_83CD64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD64u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD64 CMP
    cpu.compareA(0x70u);
    goto L_83CD67;
L_83CD67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD67u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD67 BCC -> $83CD76
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CD76; }
    goto L_83CD69;
L_83CD69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD69u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD69u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD69 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD6C;
L_83CD6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD6C ASL
    cpu.aslA();
    goto L_83CD6D;
L_83CD6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD6D ASL
    cpu.aslA();
    goto L_83CD6E;
L_83CD6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD6E ASL
    cpu.aslA();
    goto L_83CD6F;
L_83CD6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD6Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD6F AND
    cpu.logicAnd(0xF0u);
    goto L_83CD72;
L_83CD72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD72u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD72 SEP
    cpu.sep(0x3u);
    goto L_83CD74;
L_83CD74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD74 CLV
    cpu.setFlag('V', false);
    goto L_83CD75;
L_83CD75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD75u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CD75 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CD75u);return;} hw.unresolvedReturn(0x83CD75u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CD76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD76u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD76 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD79;
L_83CD79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD79 AND
    cpu.logicAnd(0xFFu);
    goto L_83CD7C;
L_83CD7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD7C SEP
    cpu.sep(0x3u);
    goto L_83CD7E;
L_83CD7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Eu,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD7E CLV
    cpu.setFlag('V', false);
    goto L_83CD7F;
L_83CD7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD7Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CD7F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CD7Fu);return;} hw.unresolvedReturn(0x83CD7Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CD80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD80u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD80 CLC
    cpu.setFlag('C', false);
    goto L_83CD81;
L_83CD81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD81u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CD81 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CD81u);return;} hw.unresolvedReturn(0x83CD81u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD81u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CD81 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CD81u);return;} hw.unresolvedReturn(0x83CD81u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCD81u,0x83CD81u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CD82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD82u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD82u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD82 BIT
    cpu.bit(0x2u, true);
    goto L_83CD85;
L_83CD85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD85u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD85 BEQ -> $83CDA9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CDA9; }
    goto L_83CD87;
L_83CD87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD87u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD87 AND
    cpu.logicAnd(0xFCu);
    goto L_83CD8A;
L_83CD8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD8A BEQ -> $83CD81
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CD81; }
    goto L_83CD8C;
L_83CD8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD8C ASL
    cpu.aslA();
    goto L_83CD8D;
L_83CD8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD8D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xDCu), cpu.m8?8:16));
    goto L_83CD8F;
L_83CD8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD8F TAY
    cpu.transfer("TAY");
    goto L_83CD90;
L_83CD90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD90u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD90u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD90 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD93;
L_83CD93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD93 BMI -> $83CD9E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CD9E; }
    goto L_83CD95;
L_83CD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD95u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD95u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD95 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CD98;
L_83CD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD98u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD98u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD98 AND
    cpu.logicAnd(0xFFu);
    goto L_83CD9B;
L_83CD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD9B SEP
    cpu.sep(0x43u);
    goto L_83CD9D;
L_83CD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CD9D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CD9Du);return;} hw.unresolvedReturn(0x83CD9Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CD9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCD9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCD9Eu, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CD9E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CDA1;
L_83CDA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA1u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDA1 AND
    cpu.logicAnd(0xFFu);
    goto L_83CDA4;
L_83CDA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDA4 REP
    cpu.rep(0x2u);
    goto L_83CDA6;
L_83CDA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDA6 SEP
    cpu.sep(0x41u);
    goto L_83CDA8;
L_83CDA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CDA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CDA8u);return;} hw.unresolvedReturn(0x83CDA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CDA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDA9 AND
    cpu.logicAnd(0xFCu);
    goto L_83CDAC;
L_83CDAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDAC BEQ -> $83CD81
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CD81; }
    goto L_83CDAE;
L_83CDAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDAE ASL
    cpu.aslA();
    goto L_83CDAF;
L_83CDAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDAFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDAF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xDCu), cpu.m8?8:16));
    goto L_83CDB1;
L_83CDB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDB1 TAY
    cpu.transfer("TAY");
    goto L_83CDB2;
L_83CDB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB2u, 5u + 1u, 3u, cpu.address("absy", 0x0006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDB2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CDB5;
L_83CDB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDB5 BMI -> $83CDC1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CDC1; }
    goto L_83CDB7;
L_83CDB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB7u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDB7u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDB7 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CDBA;
L_83CDBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDBA AND
    cpu.logicAnd(0xFFu);
    goto L_83CDBD;
L_83CDBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDBD SEP
    cpu.sep(0x3u);
    goto L_83CDBF;
L_83CDBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu,cpu,0xB8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDBFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDBF CLV
    cpu.setFlag('V', false);
    goto L_83CDC0;
L_83CDC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CDC0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CDC0u);return;} hw.unresolvedReturn(0x83CDC0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CDC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC1u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDC1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CDC4;
L_83CDC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDC4 AND
    cpu.logicAnd(0xFFu);
    goto L_83CDC7;
L_83CDC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDC7 REP
    cpu.rep(0x42u);
    goto L_83CDC9;
L_83CDC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CDC9 SEC
    cpu.setFlag('C', true);
    goto L_83CDCA;
L_83CDCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCDCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCDCAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CDCA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CDCAu);return;} hw.unresolvedReturn(0x83CDCAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83FCD0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83FC71u: goto L_83FC71;
    case 0x83FC74u: goto L_83FC74;
    case 0x83FC76u: goto L_83FC76;
    case 0x83FC78u: goto L_83FC78;
    case 0x83FC7Bu: goto L_83FC7B;
    case 0x83FC7Du: goto L_83FC7D;
    case 0x83FC7Fu: goto L_83FC7F;
    case 0x83FC81u: goto L_83FC81;
    case 0x83FC84u: goto L_83FC84;
    case 0x83FC86u: goto L_83FC86;
    case 0x83FC89u: goto L_83FC89;
    case 0x83FC8Bu: goto L_83FC8B;
    case 0x83FC8Eu: goto L_83FC8E;
    case 0x83FC91u: goto L_83FC91;
    case 0x83FC94u: goto L_83FC94;
    case 0x83FC97u: goto L_83FC97;
    case 0x83FC9Au: goto L_83FC9A;
    case 0x83FC9Eu: goto L_83FC9E;
    case 0x83FC9Fu: goto L_83FC9F;
    case 0x83FCA2u: goto L_83FCA2;
    case 0x83FCA3u: goto L_83FCA3;
    case 0x83FCA6u: goto L_83FCA6;
    case 0x83FCA8u: goto L_83FCA8;
    case 0x83FCABu: goto L_83FCAB;
    case 0x83FCADu: goto L_83FCAD;
    case 0x83FCAFu: goto L_83FCAF;
    case 0x83FCB2u: goto L_83FCB2;
    case 0x83FCB4u: goto L_83FCB4;
    case 0x83FCB6u: goto L_83FCB6;
    case 0x83FCB8u: goto L_83FCB8;
    case 0x83FCBBu: goto L_83FCBB;
    case 0x83FCBDu: goto L_83FCBD;
    case 0x83FCC0u: goto L_83FCC0;
    case 0x83FCC2u: goto L_83FCC2;
    case 0x83FCC5u: goto L_83FCC5;
    case 0x83FCC8u: goto L_83FCC8;
    case 0x83FCCBu: goto L_83FCCB;
    case 0x83FCCFu: goto L_83FCCF;
    case 0x83FCD0u: goto L_83FCD0;
    case 0x83FCD3u: goto L_83FCD3;
    case 0x83FCD5u: goto L_83FCD5;
    case 0x83FCD8u: goto L_83FCD8;
    case 0x83FCDBu: goto L_83FCDB;
    case 0x83FCDEu: goto L_83FCDE;
    case 0x83FCE0u: goto L_83FCE0;
    case 0x83FCE2u: goto L_83FCE2;
    case 0x83FCE4u: goto L_83FCE4;
    case 0x83FCE6u: goto L_83FCE6;
    case 0x83FCE8u: goto L_83FCE8;
    case 0x83FCEBu: goto L_83FCEB;
    case 0x83FCECu: goto L_83FCEC;
    case 0x83FCEFu: goto L_83FCEF;
    case 0x83FCF1u: goto L_83FCF1;
    case 0x83FCF4u: goto L_83FCF4;
    case 0x83FCF6u: goto L_83FCF6;
    case 0x83FCF8u: goto L_83FCF8;
    case 0x83FCFBu: goto L_83FCFB;
    case 0x83FCFDu: goto L_83FCFD;
    case 0x83FCFFu: goto L_83FCFF;
    case 0x83FD01u: goto L_83FD01;
    case 0x83FD04u: goto L_83FD04;
    case 0x83FD06u: goto L_83FD06;
    case 0x83FD09u: goto L_83FD09;
    case 0x83FD0Bu: goto L_83FD0B;
    case 0x83FD0Eu: goto L_83FD0E;
    case 0x83FD11u: goto L_83FD11;
    case 0x83FD14u: goto L_83FD14;
    case 0x83FD18u: goto L_83FD18;
    case 0x83FD19u: goto L_83FD19;
    case 0x83FD1Cu: goto L_83FD1C;
    case 0x83FD1Eu: goto L_83FD1E;
    case 0x83FD20u: goto L_83FD20;
    case 0x83FD23u: goto L_83FD23;
    case 0x83FD25u: goto L_83FD25;
    case 0x83FD27u: goto L_83FD27;
    case 0x83FD29u: goto L_83FD29;
    case 0x83FD2Cu: goto L_83FD2C;
    case 0x83FD2Eu: goto L_83FD2E;
    case 0x83FD31u: goto L_83FD31;
    case 0x83FD33u: goto L_83FD33;
    case 0x83FD36u: goto L_83FD36;
    case 0x83FD39u: goto L_83FD39;
    case 0x83FD3Cu: goto L_83FD3C;
    case 0x83FD3Fu: goto L_83FD3F;
    case 0x83FD42u: goto L_83FD42;
    case 0x83FD46u: goto L_83FD46;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83FC71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC71u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC71 CMP
    cpu.compareA(0xFFFEu);
    goto L_83FC74;
L_83FC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC74u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC74 BCC -> $83FCCF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FC76;
L_83FC76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC76u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC76u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC76 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FC78;
L_83FC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC78u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC78u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC78 CMP
    cpu.compareA(0x8u);
    goto L_83FC7B;
L_83FC7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC7B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FC7D;
L_83FC7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC7D BEQ -> $83FCCF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FC7F;
L_83FC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC7F BCS -> $83FC86
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FC86; }
    goto L_83FC81;
L_83FC81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC81 CMP
    cpu.compareA(0x3u);
    goto L_83FC84;
L_83FC84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC84u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC84 BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FC86;
L_83FC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC86u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC86u, 6u, 3u, cpu.address("abs", 0xCEC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FC86 JSR -> $83CEC0 stack real
    { cpu.push16Value(hw,0xFC88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFC89u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCEC0u), 0x83FC86u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FC89;
L_83FC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC89u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC89 BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FC8B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC89 BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FC8B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC89u,0x83FC89u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC8B STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FC8E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Bu, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC8B STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FC8E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC8Bu,0x83FC8Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC8Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC8E LDA
    cpu.setA(0x4000u, 16);
    goto L_83FC91;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC8Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC8E LDA
    cpu.setA(0x4000u, 16);
    goto L_83FC91;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC8Eu,0x83FC8Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC91u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC91 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FC94;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC91u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC91 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FC94;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC91u,0x83FC91u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC94u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC94 LDA
    cpu.setA(0x400u, 16);
    goto L_83FC97;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC94u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC94 LDA
    cpu.setA(0x400u, 16);
    goto L_83FC97;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC94u,0x83FC94u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC97u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC97u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC97 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FC9A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC97u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC97u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC97 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FC9A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC97u,0x83FC97u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FC9A JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFC9Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFC9Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FC9Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FC9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Au, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FC9A JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFC9Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFC9Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FC9Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FC9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC9Au,0x83FC9Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FC9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFC9Eu,0x83FC9Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FC9E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FC9Eu);return;} hw.unresolvedReturn(0x83FC9Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83FC9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFC9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFC9Fu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FC9F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCA2;
L_83FCA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCA2 SEC
    cpu.setFlag('C', true);
    goto L_83FCA3;
L_83FCA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA3u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA3u, 5u, 3u, cpu.address("abs", 0x0978u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCA3 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x978u), cpu.m8?8:16));
    goto L_83FCA6;
L_83FCA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA6u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCA6 BMI -> $83FC71
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FC71; }
    goto L_83FCA8;
L_83FCA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCA8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCA8 CMP
    cpu.compareA(0x2u);
    goto L_83FCAB;
L_83FCAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCABu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCAB BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FCAD;
L_83FCAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCAD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCAF;
L_83FCAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCAF CMP
    cpu.compareA(0x8u);
    goto L_83FCB2;
L_83FCB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCB2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCB4;
L_83FCB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCB4 BEQ -> $83FCCF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FCB6;
L_83FCB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCB6 BCS -> $83FCBD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCBD; }
    goto L_83FCB8;
L_83FCB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCB8 CMP
    cpu.compareA(0x3u);
    goto L_83FCBB;
L_83FCBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCBB BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FCBD;
L_83FCBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCBDu, 6u, 3u, cpu.address("abs", 0xCE24u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FCBD JSR -> $83CE24 stack real
    { cpu.push16Value(hw,0xFCBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFCC0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE24u), 0x83FCBDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FCC0;
L_83FCC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC0 BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FCC2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC0 BCS -> $83FCCF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FCCF; }
    goto L_83FCC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCC0u,0x83FCC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC2 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FCC5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC2u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC2 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FCC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCC2u,0x83FCC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC5 LDA
    cpu.setA(0x4000u, 16);
    goto L_83FCC8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC5 LDA
    cpu.setA(0x4000u, 16);
    goto L_83FCC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCC5u,0x83FCC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC8 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FCCB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCC8u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCC8 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FCCB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCC8u,0x83FCC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCCBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FCCB JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFCCEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFCCFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FCCBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FCCF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCBu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FCCB JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFCCEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFCCFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FCCBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FCCF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCCBu,0x83FCCBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCCFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FCCF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FCCFu);return;} hw.unresolvedReturn(0x83FCCFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCCFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FCCF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FCCFu);return;} hw.unresolvedReturn(0x83FCCFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCCFu,0x83FCCFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FCD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD0u, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCD0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCD3;
L_83FCD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCD3 BNE -> $83FD18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FCD5;
L_83FCD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCD5 LDA
    cpu.setA(0x5u, 16);
    goto L_83FCD8;
L_83FCD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCD8u, 6u, 3u, cpu.address("abs", 0xCC41u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FCD8 JSR -> $83CC41 stack real
    { cpu.push16Value(hw,0xFCDAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFCDBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC41u), 0x83FCD8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FCDB;
L_83FCDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFCDBu,0x83FCDBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDBu, 5u + 1u, 3u, cpu.address("absx", 0x10C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCDB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCDE;
L_83FCDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCDEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCDE BEQ -> $83FD18
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FCE0;
L_83FCE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCE0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCE2;
L_83FCE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCE2 BNE -> $83FD18
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FCE4;
L_83FCE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCE4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCE6;
L_83FCE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCE6 BNE -> $83FC9F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FC9F; }
    goto L_83FCE8;
L_83FCE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCE8u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCE8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCEB;
L_83FCEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCEB SEC
    cpu.setFlag('C', true);
    goto L_83FCEC;
L_83FCEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCECu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCECu, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCEC SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83FCEF;
L_83FCEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCEF BMI -> $83FD19
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83FD19; }
    goto L_83FCF1;
L_83FCF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCF1 CMP
    cpu.compareA(0x2u);
    goto L_83FCF4;
L_83FCF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCF4 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FCF6;
L_83FCF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCF6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCF8;
L_83FCF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCF8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCF8 CMP
    cpu.compareA(0x8u);
    goto L_83FCFB;
L_83FCFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCFB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FCFD;
L_83FCFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFDu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCFD BEQ -> $83FD18
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FCFF;
L_83FCFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFCFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFCFFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FCFF BCS -> $83FD06
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD06; }
    goto L_83FD01;
L_83FD01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD01u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD01 CMP
    cpu.compareA(0x3u);
    goto L_83FD04;
L_83FD04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD04u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD04u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD04 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD06;
L_83FD06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD06u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD06u, 6u, 3u, cpu.address("abs", 0xCE24u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FD06 JSR -> $83CE24 stack real
    { cpu.push16Value(hw,0xFD08u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD09u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE24u), 0x83FD06u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD09;
L_83FD09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD09u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD09 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD0B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD09 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD0B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD09u,0x83FD09u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD0B STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FD0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Bu, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD0B STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FD0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Bu,0x83FD0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD0E LDA
    cpu.setA(0x4000u, 16);
    goto L_83FD11;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD0E LDA
    cpu.setA(0x4000u, 16);
    goto L_83FD11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD0Eu,0x83FD0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD11 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FD14;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD11u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD11 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FD14;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD11u,0x83FD11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD14u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD14u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD14u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FD14 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFD17u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD18u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FD14u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD18;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD14u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD14u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FD14 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFD17u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD18u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FD14u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD18;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD14u,0x83FD14u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD18u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD18u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD18u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FD18 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FD18u);return;} hw.unresolvedReturn(0x83FD18u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD18u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD18u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FD18 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FD18u);return;} hw.unresolvedReturn(0x83FD18u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD18u,0x83FD18u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD19 CMP
    cpu.compareA(0xFFFEu);
    goto L_83FD1C;
L_83FD1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD1C BCC -> $83FD18
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD1E;
L_83FD1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x98u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD1E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x98u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FD20;
L_83FD20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD20u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD20 CMP
    cpu.compareA(0x8u);
    goto L_83FD23;
L_83FD23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD23u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD23 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83FD25;
L_83FD25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD25u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD25u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD25 BEQ -> $83FD18
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD27;
L_83FD27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD27u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD27u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD27 BCS -> $83FD2E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD2E; }
    goto L_83FD29;
L_83FD29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD29u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD29 CMP
    cpu.compareA(0x3u);
    goto L_83FD2C;
L_83FD2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD2C BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD2E;
L_83FD2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD2Eu, 6u, 3u, cpu.address("abs", 0xCEC0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FD2E JSR -> $83CEC0 stack real
    { cpu.push16Value(hw,0xFD30u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD31u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCEC0u), 0x83FD2Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD31;
L_83FD31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD31u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD31 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD33;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD31 BCS -> $83FD18
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83FD18; }
    goto L_83FD33;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD31u,0x83FD31u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD33u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD33 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FD36;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD33u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD33 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83FD36;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD33u,0x83FD33u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD36u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD36 LDA
    cpu.setA(0x4000u, 16);
    goto L_83FD39;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD36u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD36 LDA
    cpu.setA(0x4000u, 16);
    goto L_83FD39;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD36u,0x83FD36u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD39u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD39 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FD3C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD39u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD39 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83FD3C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD39u,0x83FD39u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD3Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD3C LDA
    cpu.setA(0x400u, 16);
    goto L_83FD3F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD3C LDA
    cpu.setA(0x400u, 16);
    goto L_83FD3F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Cu,0x83FD3Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD3Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Fu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD3F STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FD42;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Fu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD3Fu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83FD3F STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83FD42;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD3Fu,0x83FD3Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD42u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD42u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD42u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FD42 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFD45u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD46u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FD42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD46;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD42u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD42u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83FD42 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xFD45u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xFD46u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83FD42u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83FD46;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD42u,0x83FD42u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83FD46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xFD46u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xFD46u,0x83FD46u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xFD46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xFD46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83FD46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83FD46u);return;} hw.unresolvedReturn(0x83FD46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8492FB_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8492FAu: goto L_8492FA;
    case 0x8492FBu: goto L_8492FB;
    case 0x8492FCu: goto L_8492FC;
    case 0x8492FEu: goto L_8492FE;
    case 0x8492FFu: goto L_8492FF;
    case 0x849300u: goto L_849300;
    case 0x849304u: goto L_849304;
    case 0x849305u: goto L_849305;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8492FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492FA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492FAu);return;} hw.unresolvedReturn(0x8492FAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8492FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FB TYA
    cpu.transfer("TYA");
    goto L_8492FC;
L_8492FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FC BEQ -> $8492FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8492FA; }
    goto L_8492FE;
L_8492FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8492FE PHX
    cpu.push("PHX", hw);
    goto L_8492FF;
L_8492FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FF TYX
    cpu.transfer("TYX");
    goto L_849300;
L_849300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u, 8u, 4u, 0x808E22u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849300 JSL -> $808E22 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9303u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9304u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E22u, 0x849300u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849304;
L_849304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9304u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9304u,0x849304u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849304 PLX
    cpu.pop("PLX", hw);
    goto L_849305;
L_849305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849305u);return;} hw.unresolvedReturn(0x849305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8492FB_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8492FAu: goto L_8492FA;
    case 0x8492FBu: goto L_8492FB;
    case 0x8492FCu: goto L_8492FC;
    case 0x8492FEu: goto L_8492FE;
    case 0x8492FFu: goto L_8492FF;
    case 0x849300u: goto L_849300;
    case 0x849304u: goto L_849304;
    case 0x849305u: goto L_849305;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8492FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8492FA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8492FAu);return;} hw.unresolvedReturn(0x8492FAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8492FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FB TYA
    cpu.transfer("TYA");
    goto L_8492FC;
L_8492FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FC BEQ -> $8492FA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8492FA; }
    goto L_8492FE;
L_8492FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FEu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8492FE PHX
    cpu.push("PHX", hw);
    goto L_8492FF;
L_8492FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8492FF TYX
    cpu.transfer("TYX");
    goto L_849300;
L_849300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9300u, 8u, 4u, 0x808E22u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849300 JSL -> $808E22 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9303u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9304u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E22u, 0x849300u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849304;
L_849304:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9304u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9304u,0x849304u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9304u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849304 PLX
    cpu.pop("PLX", hw);
    goto L_849305;
L_849305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9305u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849305 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x849305u);return;} hw.unresolvedReturn(0x849305u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

