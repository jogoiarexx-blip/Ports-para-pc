#include "generated.hpp"
void sub_8080A6_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8080A6u: goto L_8080A6;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080ABu: goto L_8080AB;
    case 0x8080AEu: goto L_8080AE;
    case 0x8080B2u: goto L_8080B2;
    case 0x8080B6u: goto L_8080B6;
    case 0x8080B9u: goto L_8080B9;
    case 0x8080BDu: goto L_8080BD;
    case 0x8080C1u: goto L_8080C1;
    case 0x8080C5u: goto L_8080C5;
    case 0x8080C9u: goto L_8080C9;
    case 0x8080CDu: goto L_8080CD;
    case 0x8080CFu: goto L_8080CF;
    case 0x8080D2u: goto L_8080D2;
    case 0x8080D4u: goto L_8080D4;
    case 0x8080D7u: goto L_8080D7;
    case 0x8080D9u: goto L_8080D9;
    case 0x8080DCu: goto L_8080DC;
    case 0x8080DEu: goto L_8080DE;
    case 0x8080E2u: goto L_8080E2;
    case 0x8080E4u: goto L_8080E4;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E8u: goto L_8080E8;
    case 0x8080ECu: goto L_8080EC;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F7u: goto L_8080F7;
    case 0x8080F8u: goto L_8080F8;
    case 0x8080FBu: goto L_8080FB;
    case 0x8080FCu: goto L_8080FC;
    case 0x808100u: goto L_808100;
    case 0x808104u: goto L_808104;
    case 0x808108u: goto L_808108;
    case 0x80810Cu: goto L_80810C;
    case 0x80810Du: goto L_80810D;
    case 0x808111u: goto L_808111;
    case 0x808115u: goto L_808115;
    case 0x808116u: goto L_808116;
    case 0x80811Au: goto L_80811A;
    case 0x80811Bu: goto L_80811B;
    case 0x80811Eu: goto L_80811E;
    case 0x80811Fu: goto L_80811F;
    case 0x808121u: goto L_808121;
    case 0x808123u: goto L_808123;
    case 0x808125u: goto L_808125;
    case 0x808127u: goto L_808127;
    case 0x808128u: goto L_808128;
    case 0x80812Au: goto L_80812A;
    case 0x80812Eu: goto L_80812E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080AA;
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AA LSR
    cpu.lsrA();
    goto L_8080AB;
L_8080AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 5u, 3u, cpu.address("abs", 0x1FF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AB STA
    hw.write(cpu.address("abs", 0x1FF4u), cpu.a, cpu.m8?8:16);
    goto L_8080AE;
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 8u, 4u, 0x809496u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AE JSL -> $809496 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80B1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809496u, 0x8080AEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080B2;
L_8080B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B2u,0x8080B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B2 LDA
    cpu.loadA(hw.readW(0x7EFE84u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080B6;
L_8080B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 5u, 3u, cpu.address("abs", 0x1FE8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B6 STA
    hw.write(cpu.address("abs", 0x1FE8u), cpu.a, cpu.m8?8:16);
    goto L_8080B9;
L_8080B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080B9 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80BCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x8080B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080BD;
L_8080BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BDu,0x8080BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 8u, 4u, 0x808992u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080BD JSL -> $808992 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808992u, 0x8080BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C1;
L_8080C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C1u,0x8080C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 8u, 4u, 0x808AC5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C1 JSL -> $808AC5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808AC5u, 0x8080C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C5;
L_8080C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C5u,0x8080C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C5 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x8080C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C9;
L_8080C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C9u,0x8080C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 8u, 4u, 0x808B3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C9 JSL -> $808B3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B3Bu, 0x8080C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080CD;
L_8080CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CDu,0x8080CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CD REP
    cpu.rep(0x20u);
    goto L_8080CF;
L_8080CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CF LDA
    cpu.setA(0x1C80u, 16);
    goto L_8080D2;
L_8080D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D2 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8080D4;
L_8080D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D4 LDA
    cpu.setA(0x3200u, 16);
    goto L_8080D7;
L_8080D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D7 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8080D9;
L_8080D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D9 LDA
    cpu.setA(0x2E00u, 16);
    goto L_8080DC;
L_8080DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DC STA
    hw.write(cpu.address("dp", 0x4Au), cpu.a, cpu.m8?8:16);
    goto L_8080DE;
L_8080DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 8u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080DE JSL -> $8083B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8083B6u, 0x8080DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080E2;
L_8080E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E2u,0x8080E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E2 REP
    cpu.rep(0x30u);
    goto L_8080E4;
L_8080E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080E4 PHB
    cpu.push("PHB", hw);
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E5 LDA
    cpu.setA(0x0u, 16);
    goto L_8080E8;
L_8080E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, 0x7EFE00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E8 STA
    hw.write(0x7EFE00u, cpu.a, cpu.m8?8:16);
    goto L_8080EC;
L_8080EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EC LDA
    cpu.setA(0x7Du, 16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF LDX
    cpu.setX(0xFE01u, 16);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F2 TXY
    cpu.transfer("TXY");
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F3 INY
    cpu.inc('Y');
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x80F4u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $8080F4 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_8080F7;
L_8080F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F7 PLB
    cpu.pop("PLB", hw);
    goto L_8080F8;
L_8080F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F8 LDA
    cpu.setA(0x0u, 16);
    goto L_8080FB;
L_8080FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080FB INC
    cpu.inc('A');
    goto L_8080FC;
L_8080FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080FC STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_808100;
L_808100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808100 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_808104;
L_808104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808104 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_808108;
L_808108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808108 LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80810C;
L_80810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80810C LSR
    cpu.lsrA();
    goto L_80810D;
L_80810D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du, 6u, 4u, 0x7EFE4Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80810D STA
    hw.write(0x7EFE4Eu, cpu.a, cpu.m8?8:16);
    goto L_808111;
L_808111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808111 LDA
    cpu.loadA(hw.readW(0x7EFE8Cu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_808115;
L_808115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808115 LSR
    cpu.lsrA();
    goto L_808116;
L_808116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 6u, 4u, 0x7EFE50u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808116 STA
    hw.write(0x7EFE50u, cpu.a, cpu.m8?8:16);
    goto L_80811A;
L_80811A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811A CLI
    cpu.setFlag('I', false);
    goto L_80811B;
L_80811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811B LDA
    cpu.setA(0x0u, 16);
    goto L_80811E;
L_80811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811E TCD
    cpu.tcd();
    goto L_80811F;
L_80811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808121;
L_808121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808121 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16));
    goto L_808123;
L_808123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808123 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_808125;
L_808125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808125 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808127;
L_808127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808127 LSR
    cpu.lsrA();
    goto L_808128;
L_808128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808128 BCC -> $80811B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80811B; }
    goto L_80812A;
L_80812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 8u, 4u, 0x82ECD1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80812A JSL -> $82ECD1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x812Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x812Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ECD1u, 0x80812Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80812E;
L_80812E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x812Eu,0x80812Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812E BRA -> $80811B
    goto L_80811B;
}

void sub_808B3B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808B3Bu: goto L_808B3B;
    case 0x808B3Du: goto L_808B3D;
    case 0x808B3Eu: goto L_808B3E;
    case 0x808B41u: goto L_808B41;
    case 0x808B45u: goto L_808B45;
    case 0x808B48u: goto L_808B48;
    case 0x808B4Bu: goto L_808B4B;
    case 0x808B4Cu: goto L_808B4C;
    case 0x808B4Du: goto L_808B4D;
    case 0x808B50u: goto L_808B50;
    case 0x808B51u: goto L_808B51;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808B3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B3B REP
    cpu.rep(0x30u);
    goto L_808B3D;
L_808B3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Du,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B3D PHB
    cpu.push("PHB", hw);
    goto L_808B3E;
L_808B3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B3E LDA
    cpu.setA(0x0u, 16);
    goto L_808B41;
L_808B41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B41u, 6u, 4u, 0x001C00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B41 STA
    hw.write(0x1C00u, cpu.a, cpu.m8?8:16);
    goto L_808B45;
L_808B45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B45 LDA
    cpu.setA(0x7Du, 16);
    goto L_808B48;
L_808B48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B48u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B48u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B48 LDX
    cpu.setX(0x1C01u, 16);
    goto L_808B4B;
L_808B4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B4B TXY
    cpu.transfer("TXY");
    goto L_808B4C;
L_808B4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808B4C INY
    cpu.inc('Y');
    goto L_808B4D;
L_808B4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B4Du,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8B4Du, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808B4D MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808B50;
L_808B50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B50u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B50u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808B50 PLB
    cpu.pop("PLB", hw);
    goto L_808B51;
L_808B51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8B51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8B51u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808B51 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808B51u);return;} hw.unresolvedReturn(0x808B51u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AB81_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB59u: goto L_80AB59;
    case 0x80AB5Cu: goto L_80AB5C;
    case 0x80AB5Fu: goto L_80AB5F;
    case 0x80AB62u: goto L_80AB62;
    case 0x80AB81u: goto L_80AB81;
    case 0x80AB84u: goto L_80AB84;
    case 0x80AB86u: goto L_80AB86;
    case 0x80AB89u: goto L_80AB89;
    case 0x80AB8Bu: goto L_80AB8B;
    case 0x80AB8Eu: goto L_80AB8E;
    case 0x80AB92u: goto L_80AB92;
    case 0x80AB95u: goto L_80AB95;
    case 0x80AB98u: goto L_80AB98;
    case 0x80AB9Bu: goto L_80AB9B;
    case 0x80AB9Eu: goto L_80AB9E;
    case 0x80ABA0u: goto L_80ABA0;
    case 0x80ABA3u: goto L_80ABA3;
    case 0x80ABA6u: goto L_80ABA6;
    case 0x80ABA9u: goto L_80ABA9;
    case 0x80ABACu: goto L_80ABAC;
    case 0x80ABAFu: goto L_80ABAF;
    case 0x80ABB0u: goto L_80ABB0;
    case 0x80ABB3u: goto L_80ABB3;
    case 0x80ABB5u: goto L_80ABB5;
    case 0x80ABB8u: goto L_80ABB8;
    case 0x80ABBAu: goto L_80ABBA;
    case 0x80ABBDu: goto L_80ABBD;
    case 0x80ABC1u: goto L_80ABC1;
    case 0x80ABC4u: goto L_80ABC4;
    case 0x80ABC6u: goto L_80ABC6;
    case 0x80ABC8u: goto L_80ABC8;
    case 0x80ABCBu: goto L_80ABCB;
    case 0x80ABCDu: goto L_80ABCD;
    case 0x80ABD0u: goto L_80ABD0;
    case 0x80ABD3u: goto L_80ABD3;
    case 0x80ABD6u: goto L_80ABD6;
    case 0x80B6D7u: goto L_80B6D7;
    case 0x80B6DAu: goto L_80B6DA;
    case 0x80B6DDu: goto L_80B6DD;
    case 0x80B6DFu: goto L_80B6DF;
    case 0x80B6E2u: goto L_80B6E2;
    case 0x80B6E4u: goto L_80B6E4;
    case 0x80B6E7u: goto L_80B6E7;
    case 0x80B6E9u: goto L_80B6E9;
    case 0x80B6EAu: goto L_80B6EA;
    case 0x80B6EDu: goto L_80B6ED;
    case 0x80B6EFu: goto L_80B6EF;
    case 0x80B6F2u: goto L_80B6F2;
    case 0x80B6F4u: goto L_80B6F4;
    case 0x80B6F5u: goto L_80B6F5;
    case 0x80B6F8u: goto L_80B6F8;
    case 0x80B6FBu: goto L_80B6FB;
    case 0x80B6FDu: goto L_80B6FD;
    case 0x80B700u: goto L_80B700;
    case 0x80B703u: goto L_80B703;
    case 0x80B705u: goto L_80B705;
    case 0x80B708u: goto L_80B708;
    case 0x80B70Bu: goto L_80B70B;
    case 0x80B70Du: goto L_80B70D;
    case 0x80B710u: goto L_80B710;
    case 0x80B713u: goto L_80B713;
    case 0x80B715u: goto L_80B715;
    case 0x80B718u: goto L_80B718;
    case 0x80B71Bu: goto L_80B71B;
    case 0x80B71Du: goto L_80B71D;
    case 0x80B720u: goto L_80B720;
    case 0x80B723u: goto L_80B723;
    case 0x80B725u: goto L_80B725;
    case 0x80B728u: goto L_80B728;
    case 0x80B72Bu: goto L_80B72B;
    case 0x80B72Du: goto L_80B72D;
    case 0x80B730u: goto L_80B730;
    case 0x80B733u: goto L_80B733;
    case 0x80B735u: goto L_80B735;
    case 0x80B738u: goto L_80B738;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB59u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB59 LDA
    cpu.setA(0x1u, 16);
    goto L_80AB5C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB59 LDA
    cpu.setA(0x1u, 16);
    goto L_80AB5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB59u,0x80AB59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5C STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80AB5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5C STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80AB5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,0x80AB5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5F INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AB62;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5F INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AB62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,0x80AB5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB62u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB62 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB62u);return;} hw.unresolvedReturn(0x80AB62u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB62 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB62u);return;} hw.unresolvedReturn(0x80AB62u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB62u,0x80AB62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u, 5u, 3u, cpu.address("abs", 0x0074u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB81 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB84;
L_80AB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB84 BEQ -> $80AB9B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB9B; }
    goto L_80AB86;
L_80AB86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB86u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB86 CMP
    cpu.compareA(0xAu);
    goto L_80AB89;
L_80AB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB89 BNE -> $80AB92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB92; }
    goto L_80AB8B;
L_80AB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB8B LDY
    cpu.setY(0x8B84u, 16);
    goto L_80AB8E;
L_80AB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB8E JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AB8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB92;
L_80AB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB92u,0x80AB92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u, 8u, 3u, cpu.address("abs", 0x0074u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB92 DEC
    cpu.decMem(hw, cpu.address("abs", 0x74u), cpu.m8?8:16);
    goto L_80AB95;
L_80AB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB95 LDX
    cpu.setX(0x2E2Cu, 16);
    goto L_80AB98;
L_80AB98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB98u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB98 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xAB9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80AB98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB9B;
L_80AB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB9E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB9E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,0x80AB9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9E BMI -> $80ABB0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80ABB0; }
    goto L_80ABA0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9E BMI -> $80ABB0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80ABB0; }
    goto L_80ABA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB9Eu,0x80AB9Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA0 LDX
    cpu.setX(0x2E4Cu, 16);
    goto L_80ABA3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA0 LDX
    cpu.setX(0x2E4Cu, 16);
    goto L_80ABA3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA0u,0x80ABA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABA3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABA6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABA3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABA6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA3u,0x80ABA3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u, 8u, 3u, cpu.address("abs", 0x0076u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x76u), cpu.m8?8:16);
    goto L_80ABA9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u, 8u, 3u, cpu.address("abs", 0x0076u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x76u), cpu.m8?8:16);
    goto L_80ABA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA6u,0x80ABA6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA9 LDA
    cpu.setA(0x3u, 16);
    goto L_80ABAC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA9 LDA
    cpu.setA(0x3u, 16);
    goto L_80ABAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA9u,0x80ABA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABAC STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80ABAF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABAC STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80ABAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABACu,0x80ABACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABAFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABAF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABAFu);return;} hw.unresolvedReturn(0x80ABAFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABAF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABAFu);return;} hw.unresolvedReturn(0x80ABAFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABAFu,0x80ABAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABB0u,0x80ABB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB3 BEQ -> $80ABC1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABC1; }
    goto L_80ABB5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB3 BEQ -> $80ABC1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABC1; }
    goto L_80ABB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABB3u,0x80ABB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u, 8u, 3u, cpu.address("abs", 0x007Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x7Au), cpu.m8?8:16);
    goto L_80ABB8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u, 8u, 3u, cpu.address("abs", 0x007Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x7Au), cpu.m8?8:16);
    goto L_80ABB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABB5u,0x80ABB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB8 BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABBA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB8 BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABB8u,0x80ABB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBA LDY
    cpu.setY(0x8B7Eu, 16);
    goto L_80ABBD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBA LDY
    cpu.setY(0x8B7Eu, 16);
    goto L_80ABBD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABBAu,0x80ABBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu, 4u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBD JML -> $80B6D7
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80B6D7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu, 4u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBD JML -> $80B6D7
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80B6D7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABBDu,0x80ABBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u, 5u, 3u, cpu.address("abs", 0x0078u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u, 5u, 3u, cpu.address("abs", 0x0078u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABC1u,0x80ABC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC4 BMI -> $80AB59
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AB59; }
    goto L_80ABC6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC4 BMI -> $80AB59
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AB59; }
    goto L_80ABC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABC4u,0x80ABC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABC6u,0x80ABC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC8 AND
    cpu.logicAnd(0x1u);
    goto L_80ABCB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC8 AND
    cpu.logicAnd(0x1u);
    goto L_80ABCB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABC8u,0x80ABC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCB BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABCD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCB BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABCD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABCBu,0x80ABCBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu, 8u, 3u, cpu.address("abs", 0x0078u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCD DEC
    cpu.decMem(hw, cpu.address("abs", 0x78u), cpu.m8?8:16);
    goto L_80ABD0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu, 8u, 3u, cpu.address("abs", 0x0078u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCD DEC
    cpu.decMem(hw, cpu.address("abs", 0x78u), cpu.m8?8:16);
    goto L_80ABD0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABCDu,0x80ABCDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABD0 LDX
    cpu.setX(0x2E0Au, 16);
    goto L_80ABD3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABD0 LDX
    cpu.setX(0x2E0Au, 16);
    goto L_80ABD3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABD0u,0x80ABD0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABD3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABD5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABD6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABD3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABD6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABD3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABD5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABD6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABD3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABD6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABD3u,0x80ABD3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ABD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABD6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABD6u);return;} hw.unresolvedReturn(0x80ABD6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABD6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABD6u);return;} hw.unresolvedReturn(0x80ABD6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABD6u,0x80ABD6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D7 LDX
    cpu.setX(0x1F50u, 16);
    goto L_80B6DA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D7 LDX
    cpu.setX(0x1F50u, 16);
    goto L_80B6DA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6D7u,0x80B6D7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu, 6u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6DA JSR -> $80B6AC stack real
    { cpu.push16Value(hw,0xB6DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6ACu), 0x80B6DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B6DD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu, 6u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6DA JSR -> $80B6AC stack real
    { cpu.push16Value(hw,0xB6DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6ACu), 0x80B6DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B6DD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DAu,0x80B6DAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DD STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80B6DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DD STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80B6DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DDu,0x80B6DDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DF CPY
    cpu.compareY(0x8BCFu);
    goto L_80B6E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DF CPY
    cpu.compareY(0x8BCFu);
    goto L_80B6E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DFu,0x80B6DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E2 BCS -> $80B6EA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6EA; }
    goto L_80B6E4;
L_80B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E4 LDA
    cpu.setA(0xB75Au, 16);
    goto L_80B6E7;
L_80B6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6E9;
L_80B6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6E9u);return;} hw.unresolvedReturn(0x80B6E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EA CPY
    cpu.compareY(0x8D6Bu);
    goto L_80B6ED;
L_80B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6ED BCS -> $80B6F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F5; }
    goto L_80B6EF;
L_80B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EF LDA
    cpu.setA(0xB761u, 16);
    goto L_80B6F2;
L_80B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F2 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6F4;
L_80B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6F4u);return;} hw.unresolvedReturn(0x80B6F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F5 LDA
    cpu.setA(0xB7D9u, 16);
    goto L_80B6F8;
L_80B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F8 CPY
    cpu.compareY(0x8D88u);
    goto L_80B6FB;
L_80B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FB BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B6FD;
L_80B6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FD LDA
    cpu.setA(0xB7D4u, 16);
    goto L_80B700;
L_80B700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B700 CPY
    cpu.compareY(0x8DEEu);
    goto L_80B703;
L_80B703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B703 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B705;
L_80B705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B705 LDA
    cpu.setA(0xB834u, 16);
    goto L_80B708;
L_80B708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B708 CPY
    cpu.compareY(0x8DFDu);
    goto L_80B70B;
L_80B70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B70D;
L_80B70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70D LDA
    cpu.setA(0xB8A1u, 16);
    goto L_80B710;
L_80B710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B710 CPY
    cpu.compareY(0x8E37u);
    goto L_80B713;
L_80B713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B713 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B715;
L_80B715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B715 LDA
    cpu.setA(0xB89Du, 16);
    goto L_80B718;
L_80B718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B718 CPY
    cpu.compareY(0x8E37u);
    goto L_80B71B;
L_80B71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B71D;
L_80B71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71D LDA
    cpu.setA(0xB96Cu, 16);
    goto L_80B720;
L_80B720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B720 CPY
    cpu.compareY(0x8E3Eu);
    goto L_80B723;
L_80B723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B723 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B725;
L_80B725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B725 LDA
    cpu.setA(0xB9F2u, 16);
    goto L_80B728;
L_80B728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B728 CPY
    cpu.compareY(0x8E48u);
    goto L_80B72B;
L_80B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B72D;
L_80B72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72D LDA
    cpu.setA(0xBA4Cu, 16);
    goto L_80B730;
L_80B730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B730 CPY
    cpu.compareY(0x8E78u);
    goto L_80B733;
L_80B733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B733 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B735;
L_80B735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B735 LDA
    cpu.setA(0xB7A0u, 16);
    goto L_80B738;
L_80B738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B738 BRA -> $80B6F2
    goto L_80B6F2;
}

void sub_80AB81_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AB59u: goto L_80AB59;
    case 0x80AB5Cu: goto L_80AB5C;
    case 0x80AB5Fu: goto L_80AB5F;
    case 0x80AB62u: goto L_80AB62;
    case 0x80AB81u: goto L_80AB81;
    case 0x80AB84u: goto L_80AB84;
    case 0x80AB86u: goto L_80AB86;
    case 0x80AB89u: goto L_80AB89;
    case 0x80AB8Bu: goto L_80AB8B;
    case 0x80AB8Eu: goto L_80AB8E;
    case 0x80AB92u: goto L_80AB92;
    case 0x80AB95u: goto L_80AB95;
    case 0x80AB98u: goto L_80AB98;
    case 0x80AB9Bu: goto L_80AB9B;
    case 0x80AB9Eu: goto L_80AB9E;
    case 0x80ABA0u: goto L_80ABA0;
    case 0x80ABA3u: goto L_80ABA3;
    case 0x80ABA6u: goto L_80ABA6;
    case 0x80ABA9u: goto L_80ABA9;
    case 0x80ABACu: goto L_80ABAC;
    case 0x80ABAFu: goto L_80ABAF;
    case 0x80ABB0u: goto L_80ABB0;
    case 0x80ABB3u: goto L_80ABB3;
    case 0x80ABB5u: goto L_80ABB5;
    case 0x80ABB8u: goto L_80ABB8;
    case 0x80ABBAu: goto L_80ABBA;
    case 0x80ABBDu: goto L_80ABBD;
    case 0x80ABC1u: goto L_80ABC1;
    case 0x80ABC4u: goto L_80ABC4;
    case 0x80ABC6u: goto L_80ABC6;
    case 0x80ABC8u: goto L_80ABC8;
    case 0x80ABCBu: goto L_80ABCB;
    case 0x80ABCDu: goto L_80ABCD;
    case 0x80ABD0u: goto L_80ABD0;
    case 0x80ABD3u: goto L_80ABD3;
    case 0x80ABD6u: goto L_80ABD6;
    case 0x80B6D7u: goto L_80B6D7;
    case 0x80B6DAu: goto L_80B6DA;
    case 0x80B6DDu: goto L_80B6DD;
    case 0x80B6DFu: goto L_80B6DF;
    case 0x80B6E2u: goto L_80B6E2;
    case 0x80B6E4u: goto L_80B6E4;
    case 0x80B6E7u: goto L_80B6E7;
    case 0x80B6E9u: goto L_80B6E9;
    case 0x80B6EAu: goto L_80B6EA;
    case 0x80B6EDu: goto L_80B6ED;
    case 0x80B6EFu: goto L_80B6EF;
    case 0x80B6F2u: goto L_80B6F2;
    case 0x80B6F4u: goto L_80B6F4;
    case 0x80B6F5u: goto L_80B6F5;
    case 0x80B6F8u: goto L_80B6F8;
    case 0x80B6FBu: goto L_80B6FB;
    case 0x80B6FDu: goto L_80B6FD;
    case 0x80B700u: goto L_80B700;
    case 0x80B703u: goto L_80B703;
    case 0x80B705u: goto L_80B705;
    case 0x80B708u: goto L_80B708;
    case 0x80B70Bu: goto L_80B70B;
    case 0x80B70Du: goto L_80B70D;
    case 0x80B710u: goto L_80B710;
    case 0x80B713u: goto L_80B713;
    case 0x80B715u: goto L_80B715;
    case 0x80B718u: goto L_80B718;
    case 0x80B71Bu: goto L_80B71B;
    case 0x80B71Du: goto L_80B71D;
    case 0x80B720u: goto L_80B720;
    case 0x80B723u: goto L_80B723;
    case 0x80B725u: goto L_80B725;
    case 0x80B728u: goto L_80B728;
    case 0x80B72Bu: goto L_80B72B;
    case 0x80B72Du: goto L_80B72D;
    case 0x80B730u: goto L_80B730;
    case 0x80B733u: goto L_80B733;
    case 0x80B735u: goto L_80B735;
    case 0x80B738u: goto L_80B738;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB59 LDA
    cpu.setA(0x1u, 16);
    goto L_80AB5C;
L_80AB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Cu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5C STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80AB5F;
L_80AB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB5Fu, 8u, 3u, cpu.address("abs", 0x0070u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB5F INC
    cpu.incMem(hw, cpu.address("abs", 0x70u), cpu.m8?8:16);
    goto L_80AB62;
L_80AB62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB62u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB62 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AB62u);return;} hw.unresolvedReturn(0x80AB62u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80AB81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB81u, 5u, 3u, cpu.address("abs", 0x0074u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB81 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x74u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB84;
L_80AB84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB84 BEQ -> $80AB9B
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB9B; }
    goto L_80AB86;
L_80AB86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB86u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB86 CMP
    cpu.compareA(0xAu);
    goto L_80AB89;
L_80AB89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB89 BNE -> $80AB92
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AB92; }
    goto L_80AB8B;
L_80AB8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB8B LDY
    cpu.setY(0x8B84u, 16);
    goto L_80AB8E;
L_80AB8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB8Eu, 8u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AB8E JSL -> $80B6D7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAB91u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB92u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6D7u, 0x80AB8Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB92;
L_80AB92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB92u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB92u,0x80AB92u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB92u, 8u, 3u, cpu.address("abs", 0x0074u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB92 DEC
    cpu.decMem(hw, cpu.address("abs", 0x74u), cpu.m8?8:16);
    goto L_80AB95;
L_80AB95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB95 LDX
    cpu.setX(0x2E2Cu, 16);
    goto L_80AB98;
L_80AB98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB98u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB98u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AB98 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xAB9Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80AB98u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AB9B;
L_80AB9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,0x80AB9Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Bu, 5u, 3u, cpu.address("abs", 0x0076u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x76u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AB9E;
L_80AB9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAB9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAB9Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AB9E BMI -> $80ABB0
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80ABB0; }
    goto L_80ABA0;
L_80ABA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA0 LDX
    cpu.setX(0x2E4Cu, 16);
    goto L_80ABA3;
L_80ABA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABA3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABA5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABA6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABA3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABA6;
L_80ABA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABA6u,0x80ABA6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA6u, 8u, 3u, cpu.address("abs", 0x0076u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA6 DEC
    cpu.decMem(hw, cpu.address("abs", 0x76u), cpu.m8?8:16);
    goto L_80ABA9;
L_80ABA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABA9 LDA
    cpu.setA(0x3u, 16);
    goto L_80ABAC;
L_80ABAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABACu, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABAC STA
    hw.write(cpu.address("abs", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_80ABAF;
L_80ABAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABAFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABAF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABAFu);return;} hw.unresolvedReturn(0x80ABAFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80ABB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB0u, 5u, 3u, cpu.address("abs", 0x007Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x7Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABB3;
L_80ABB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB3 BEQ -> $80ABC1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABC1; }
    goto L_80ABB5;
L_80ABB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB5u, 8u, 3u, cpu.address("abs", 0x007Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB5 DEC
    cpu.decMem(hw, cpu.address("abs", 0x7Au), cpu.m8?8:16);
    goto L_80ABB8;
L_80ABB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABB8 BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABBA;
L_80ABBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBA LDY
    cpu.setY(0x8B7Eu, 16);
    goto L_80ABBD;
L_80ABBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABBDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABBDu, 4u, 4u, 0x80B6D7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABBD JML -> $80B6D7
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_80B6D7;
L_80ABC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC1u, 5u, 3u, cpu.address("abs", 0x0078u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC4;
L_80ABC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC4 BMI -> $80AB59
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AB59; }
    goto L_80ABC6;
L_80ABC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ABC8;
L_80ABC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABC8 AND
    cpu.logicAnd(0x1u);
    goto L_80ABCB;
L_80ABCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCB BNE -> $80ABD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ABD6; }
    goto L_80ABCD;
L_80ABCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABCDu, 8u, 3u, cpu.address("abs", 0x0078u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABCD DEC
    cpu.decMem(hw, cpu.address("abs", 0x78u), cpu.m8?8:16);
    goto L_80ABD0;
L_80ABD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ABD0 LDX
    cpu.setX(0x2E0Au, 16);
    goto L_80ABD3;
L_80ABD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD3u, 6u, 3u, cpu.address("abs", 0xAC16u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ABD3 JSR -> $80AC16 stack real
    { cpu.push16Value(hw,0xABD5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xABD6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAC16u), 0x80ABD3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ABD6;
L_80ABD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABD6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xABD6u,0x80ABD6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABD6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ABD6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80ABD6u);return;} hw.unresolvedReturn(0x80ABD6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6D7 LDX
    cpu.setX(0x1F50u, 16);
    goto L_80B6DA;
L_80B6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DAu, 6u, 3u, cpu.address("abs", 0xB6ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B6DA JSR -> $80B6AC stack real
    { cpu.push16Value(hw,0xB6DCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB6DDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB6ACu), 0x80B6DAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B6DD;
L_80B6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB6DDu,0x80B6DDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DDu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DD STY
    hw.write(cpu.address("dpx", 0x2u), cpu.y, cpu.x8?8:16);
    goto L_80B6DF;
L_80B6DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6DF CPY
    cpu.compareY(0x8BCFu);
    goto L_80B6E2;
L_80B6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E2 BCS -> $80B6EA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6EA; }
    goto L_80B6E4;
L_80B6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E4 LDA
    cpu.setA(0xB75Au, 16);
    goto L_80B6E7;
L_80B6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6E7 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6E9;
L_80B6E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6E9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6E9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6E9u);return;} hw.unresolvedReturn(0x80B6E9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EA CPY
    cpu.compareY(0x8D6Bu);
    goto L_80B6ED;
L_80B6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6ED BCS -> $80B6F5
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F5; }
    goto L_80B6EF;
L_80B6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6EF LDA
    cpu.setA(0xB761u, 16);
    goto L_80B6F2;
L_80B6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F2 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B6F4;
L_80B6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B6F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80B6F4u);return;} hw.unresolvedReturn(0x80B6F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80B6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F5 LDA
    cpu.setA(0xB7D9u, 16);
    goto L_80B6F8;
L_80B6F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6F8 CPY
    cpu.compareY(0x8D88u);
    goto L_80B6FB;
L_80B6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FB BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B6FD;
L_80B6FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB6FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB6FDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B6FD LDA
    cpu.setA(0xB7D4u, 16);
    goto L_80B700;
L_80B700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB700u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B700 CPY
    cpu.compareY(0x8DEEu);
    goto L_80B703;
L_80B703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB703u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB703u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B703 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B705;
L_80B705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB705u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B705 LDA
    cpu.setA(0xB834u, 16);
    goto L_80B708;
L_80B708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB708u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B708 CPY
    cpu.compareY(0x8DFDu);
    goto L_80B70B;
L_80B70B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B70D;
L_80B70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB70Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B70D LDA
    cpu.setA(0xB8A1u, 16);
    goto L_80B710;
L_80B710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB710u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B710 CPY
    cpu.compareY(0x8E37u);
    goto L_80B713;
L_80B713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB713u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB713u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B713 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B715;
L_80B715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB715u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B715 LDA
    cpu.setA(0xB89Du, 16);
    goto L_80B718;
L_80B718:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB718u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB718u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B718 CPY
    cpu.compareY(0x8E37u);
    goto L_80B71B;
L_80B71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B71D;
L_80B71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB71Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B71D LDA
    cpu.setA(0xB96Cu, 16);
    goto L_80B720;
L_80B720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB720u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B720 CPY
    cpu.compareY(0x8E3Eu);
    goto L_80B723;
L_80B723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB723u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB723u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B723 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B725;
L_80B725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB725u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B725 LDA
    cpu.setA(0xB9F2u, 16);
    goto L_80B728;
L_80B728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB728u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B728 CPY
    cpu.compareY(0x8E48u);
    goto L_80B72B;
L_80B72B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72B BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B72D;
L_80B72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB72Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB72Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B72D LDA
    cpu.setA(0xBA4Cu, 16);
    goto L_80B730;
L_80B730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB730u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B730 CPY
    cpu.compareY(0x8E78u);
    goto L_80B733;
L_80B733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB733u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B733 BCC -> $80B6F2
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B6F2; }
    goto L_80B735;
L_80B735:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB735u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB735u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B735 LDA
    cpu.setA(0xB7A0u, 16);
    goto L_80B738;
L_80B738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB738u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B738 BRA -> $80B6F2
    goto L_80B6F2;
}

void sub_80B87A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B87Au: goto L_80B87A;
    case 0x80B87Du: goto L_80B87D;
    case 0x80B880u: goto L_80B880;
    case 0x80B884u: goto L_80B884;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Au, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B87A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B87D;
L_80B87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Du, 6u, 3u, cpu.address("abs", 0xB885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B87D JSR -> $80B885 stack real
    { cpu.push16Value(hw,0xB87Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB880u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB885u), 0x80B87Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B880;
L_80B880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB880u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B880 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB883u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB884u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x80B880u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B884;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B880 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB883u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB884u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x80B880u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B884;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB880u,0x80B880u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB884u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB884u,0x80B884u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B884 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B884u);return;} hw.unresolvedReturn(0x80B884u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B87A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B87Au: goto L_80B87A;
    case 0x80B87Du: goto L_80B87D;
    case 0x80B880u: goto L_80B880;
    case 0x80B884u: goto L_80B884;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B87A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Au, 5u, 3u, cpu.address("abs", 0x1FE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B87A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1FE0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B87D;
L_80B87D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB87Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB87Du, 6u, 3u, cpu.address("abs", 0xB885u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B87D JSR -> $80B885 stack real
    { cpu.push16Value(hw,0xB87Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB880u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB885u), 0x80B87Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B880;
L_80B880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB880u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B880 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB883u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB884u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x80B880u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B884;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB880u, 8u, 4u, 0x808C38u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B880 JSL -> $808C38 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB883u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB884u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808C38u, 0x80B880u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B884;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB880u,0x80B880u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB884u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB884u,0x80B884u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB884u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B884 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B884u);return;} hw.unresolvedReturn(0x80B884u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C24C_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C24Cu: goto L_80C24C;
    case 0x80C24Du: goto L_80C24D;
    case 0x80C24Eu: goto L_80C24E;
    case 0x80C250u: goto L_80C250;
    case 0x80C251u: goto L_80C251;
    case 0x80C252u: goto L_80C252;
    case 0x80C254u: goto L_80C254;
    case 0x80C257u: goto L_80C257;
    case 0x80C25Au: goto L_80C25A;
    case 0x80C25Cu: goto L_80C25C;
    case 0x80C25Fu: goto L_80C25F;
    case 0x80C261u: goto L_80C261;
    case 0x80C264u: goto L_80C264;
    case 0x80C268u: goto L_80C268;
    case 0x80C26Bu: goto L_80C26B;
    case 0x80C26Eu: goto L_80C26E;
    case 0x80C26Fu: goto L_80C26F;
    case 0x80C271u: goto L_80C271;
    case 0x80C274u: goto L_80C274;
    case 0x80C277u: goto L_80C277;
    case 0x80C278u: goto L_80C278;
    case 0x80C27Bu: goto L_80C27B;
    case 0x80C27Eu: goto L_80C27E;
    case 0x80C281u: goto L_80C281;
    case 0x80C284u: goto L_80C284;
    case 0x80C287u: goto L_80C287;
    case 0x80C28Bu: goto L_80C28B;
    case 0x80C28Du: goto L_80C28D;
    case 0x80C290u: goto L_80C290;
    case 0x80C292u: goto L_80C292;
    case 0x80C295u: goto L_80C295;
    case 0x80C297u: goto L_80C297;
    case 0x80C299u: goto L_80C299;
    case 0x80C29Bu: goto L_80C29B;
    case 0x80C29Cu: goto L_80C29C;
    case 0x80C29Eu: goto L_80C29E;
    case 0x80C2A2u: goto L_80C2A2;
    case 0x80C2A6u: goto L_80C2A6;
    case 0x80C2AAu: goto L_80C2AA;
    case 0x80C2AEu: goto L_80C2AE;
    case 0x8296C9u: goto L_8296C9;
    case 0x8296CCu: goto L_8296CC;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C24C PHA
    cpu.push("PHA", hw);
    goto L_80C24D;
L_80C24D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Du,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C24D PHY
    cpu.push("PHY", hw);
    goto L_80C24E;
L_80C24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC24Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C24E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C250;
L_80C250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC250u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC250u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C250 LSR
    cpu.lsrA();
    goto L_80C251;
L_80C251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC251u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C251 LSR
    cpu.lsrA();
    goto L_80C252;
L_80C252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC252u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC252u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C252 BCC -> $80C25C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C25C; }
    goto L_80C254;
L_80C254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC254u, 5u, 3u, cpu.address("abs", 0x1ADCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C254 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ADCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C257;
L_80C257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC257u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC257u, 5u, 3u, cpu.address("abs", 0x1ADEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C257 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1ADEu), cpu.m8?8:16));
    goto L_80C25A;
L_80C25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25A BEQ -> $80C268
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C268; }
    goto L_80C25C;
L_80C25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25C LDA
    cpu.setA(0x1u, 16);
    goto L_80C25F;
L_80C25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC25Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C25F STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80C261;
L_80C261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC261u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C261 LDA
    cpu.setA(0xEDu, 16);
    goto L_80C264;
L_80C264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC264u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C264 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC267u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC268u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x80C264u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C268;
L_80C268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC268u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC268u,0x80C268u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC268u, 5u, 3u, cpu.address("abs", 0x1B94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C268 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1B94u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C26B;
L_80C26B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C26B LDX
    cpu.setX(0x700u, 16);
    goto L_80C26E;
L_80C26E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Eu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C26E PLY
    cpu.pop("PLY", hw);
    goto L_80C26F;
L_80C26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC26Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C26F BEQ -> $80C274
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C274; }
    goto L_80C271;
L_80C271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC271u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC271u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C271 LDX
    cpu.setX(0x750u, 16);
    goto L_80C274;
L_80C274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC274u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC274u, 6u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C274 STA
    hw.write(cpu.address("absx", 0x228u), cpu.a, cpu.m8?8:16);
    goto L_80C277;
L_80C277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC277u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC277u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C277 PLA
    cpu.pop("PLA", hw);
    goto L_80C278;
L_80C278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC278u, 6u, 3u, cpu.address("absy", 0x1ADCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C278 STA
    hw.write(cpu.address("absy", 0x1ADCu), cpu.a, cpu.m8?8:16);
    goto L_80C27B;
L_80C27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C27B LDA
    cpu.setA(0x8000u, 16);
    goto L_80C27E;
L_80C27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC27Eu, 6u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C27E STA
    hw.write(cpu.address("absx", 0x10C4u), cpu.a, cpu.m8?8:16);
    goto L_80C281;
L_80C281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC281u, 6u, 3u, cpu.address("absx", 0x10DEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C281 STZ
    hw.write(cpu.address("absx", 0x10DEu), 0, cpu.m8?8:16);
    goto L_80C284;
L_80C284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC284u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC284u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C284 LDA
    cpu.setA(0x9u, 16);
    goto L_80C287;
L_80C287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC287u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC287u, 8u, 4u, 0x809287u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C287 JSL -> $809287 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC28Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC28Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809287u, 0x80C287u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C28B;
L_80C28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC28Bu,0x80C28Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C28B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C28D;
L_80C28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC28Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C28D CMP
    cpu.compareA(0x2u);
    goto L_80C290;
L_80C290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC290u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C290 BCC -> $80C29B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C29B; }
    goto L_80C292;
L_80C292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC292u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC292u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C292 LDA
    cpu.setA(0x1u, 16);
    goto L_80C295;
L_80C295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC295u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC295u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x76u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C295 STA
    hw.write(cpu.address("dp", 0x76u), cpu.a, cpu.m8?8:16);
    goto L_80C297;
L_80C297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC297u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC297u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C297 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C299;
L_80C299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC299u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC299u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C299 BEQ -> $80C2AE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2AE; }
    goto L_80C29B;
L_80C29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C29B TYA
    cpu.transfer("TYA");
    goto L_80C29C;
L_80C29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C29C BNE -> $80C2A6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80C2A6; }
    goto L_80C29E;
L_80C29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC29Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC29Eu, 8u, 4u, 0x8294F4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C29E JSL -> $8294F4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2A2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8294F4u, 0x80C29Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C2A2;
L_80C2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2A2u,0x80C2A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A2u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A2u, 4u, 4u, 0x8296C9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2A2 JML -> $8296C9
    cpu.pb=0x82u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8296C9;
L_80C2A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2A6u, 8u, 4u, 0x82957Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C2A6 JSL -> $82957B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xC2A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC2AAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82957Bu, 0x80C2A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80C2AA;
L_80C2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC2AAu,0x80C2AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AAu, 4u, 4u, 0x8296C9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C2AA JML -> $8296C9
    cpu.pb=0x82u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8296C9;
L_80C2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC2AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C2AE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C2AEu);return;} hw.unresolvedReturn(0x80C2AEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_8296C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C9u, 6u, 3u, cpu.address("abs", 0x96A5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8296C9 JSR -> $8296A5 stack real
    { cpu.push16Value(hw,0x96CBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96CCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96A5u), 0x8296C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8296CC;
L_8296CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96CCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96CCu,0x8296CCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96CCu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8296CC RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8296CCu);return;} hw.unresolvedReturn(0x8296CCu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C6FE_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C82Eu: goto L_80C82E;
    case 0x80C82Fu: goto L_80C82F;
    case 0x80C832u: goto L_80C832;
    case 0x80C835u: goto L_80C835;
    case 0x80C837u: goto L_80C837;
    case 0x80C838u: goto L_80C838;
    case 0x80C839u: goto L_80C839;
    case 0x80C83Au: goto L_80C83A;
    case 0x80C83Cu: goto L_80C83C;
    case 0x80C83Eu: goto L_80C83E;
    case 0x80C83Fu: goto L_80C83F;
    case 0x80C840u: goto L_80C840;
    case 0x80C842u: goto L_80C842;
    case 0x80C844u: goto L_80C844;
    case 0x80C846u: goto L_80C846;
    case 0x80C848u: goto L_80C848;
    case 0x80C84Bu: goto L_80C84B;
    case 0x80C84Du: goto L_80C84D;
    case 0x80C84Fu: goto L_80C84F;
    case 0x80C850u: goto L_80C850;
    case 0x80C853u: goto L_80C853;
    case 0x80C855u: goto L_80C855;
    case 0x80C858u: goto L_80C858;
    case 0x80C85Bu: goto L_80C85B;
    case 0x80C85Du: goto L_80C85D;
    case 0x80C85Eu: goto L_80C85E;
    case 0x80C85Fu: goto L_80C85F;
    case 0x80C860u: goto L_80C860;
    case 0x80C862u: goto L_80C862;
    case 0x80C864u: goto L_80C864;
    case 0x80C865u: goto L_80C865;
    case 0x80C866u: goto L_80C866;
    case 0x80C868u: goto L_80C868;
    case 0x80C86Au: goto L_80C86A;
    case 0x80C86Cu: goto L_80C86C;
    case 0x80C86Eu: goto L_80C86E;
    case 0x80C871u: goto L_80C871;
    case 0x80C873u: goto L_80C873;
    case 0x80C875u: goto L_80C875;
    case 0x80C876u: goto L_80C876;
    case 0x80C879u: goto L_80C879;
    case 0x80C87Bu: goto L_80C87B;
    case 0x80C87Cu: goto L_80C87C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C82E PLB
    cpu.pop("PLB", hw);
    goto L_80C82F;
L_80C82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C82F LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C832;
L_80C832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C832 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C835;
L_80C835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C835 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_80C837;
L_80C837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C837 TDC
    cpu.tdc();
    goto L_80C838;
L_80C838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C838 TAY
    cpu.transfer("TAY");
    goto L_80C839;
L_80C839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC839u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC839u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C839 CLC
    cpu.setFlag('C', false);
    goto L_80C83A;
L_80C83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C83C;
L_80C83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83C BCC -> $80C844
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C844; }
    goto L_80C83E;
L_80C83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83E DEX
    cpu.decReg('X');
    goto L_80C83F;
L_80C83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83F DEX
    cpu.decReg('X');
    goto L_80C840;
L_80C840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC840u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC840u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C840 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C842;
L_80C842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC842u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC842u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C842 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C844;
L_80C844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC844u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC844u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C844 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C846;
L_80C846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C846 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C848;
L_80C848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC848u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC848u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C848 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C84B;
L_80C84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C84D;
L_80C84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84D INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C84F;
L_80C84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84F INY
    cpu.inc('Y');
    goto L_80C850;
L_80C850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC850u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC850u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C850 CPY
    cpu.compareY(0x70u);
    goto L_80C853;
L_80C853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C853 BCC -> $80C839
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C839; }
    goto L_80C855;
L_80C855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C855 LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C858;
L_80C858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC858u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC858u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C858 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C85B;
L_80C85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85B STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_80C85D;
L_80C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85D TDC
    cpu.tdc();
    goto L_80C85E;
L_80C85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85E TAY
    cpu.transfer("TAY");
    goto L_80C85F;
L_80C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F CLC
    cpu.setFlag('C', false);
    goto L_80C860;
L_80C860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC860u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC860u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C860 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C862;
L_80C862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 BCC -> $80C86A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C86A; }
    goto L_80C864;
L_80C864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 INX
    cpu.inc('X');
    goto L_80C865;
L_80C865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C865 INX
    cpu.inc('X');
    goto L_80C866;
L_80C866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC866u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC866u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C866 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C868;
L_80C868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C868 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C86A;
L_80C86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C86C;
L_80C86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C86E;
L_80C86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86E STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C871;
L_80C871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C871 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C873;
L_80C873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC873u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC873u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C873 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C875;
L_80C875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC875u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC875u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C875 DEY
    cpu.decReg('Y');
    goto L_80C876;
L_80C876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C876 CPY
    cpu.compareY(0xFF90u);
    goto L_80C879;
L_80C879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C879 BCS -> $80C85F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C87B;
L_80C87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C87B PLB
    cpu.pop("PLB", hw);
    goto L_80C87C;
L_80C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C87C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C87Cu);return;} hw.unresolvedReturn(0x80C87Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80C6FE_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C82Eu: goto L_80C82E;
    case 0x80C82Fu: goto L_80C82F;
    case 0x80C832u: goto L_80C832;
    case 0x80C835u: goto L_80C835;
    case 0x80C837u: goto L_80C837;
    case 0x80C838u: goto L_80C838;
    case 0x80C839u: goto L_80C839;
    case 0x80C83Au: goto L_80C83A;
    case 0x80C83Cu: goto L_80C83C;
    case 0x80C83Eu: goto L_80C83E;
    case 0x80C83Fu: goto L_80C83F;
    case 0x80C840u: goto L_80C840;
    case 0x80C842u: goto L_80C842;
    case 0x80C844u: goto L_80C844;
    case 0x80C846u: goto L_80C846;
    case 0x80C848u: goto L_80C848;
    case 0x80C84Bu: goto L_80C84B;
    case 0x80C84Du: goto L_80C84D;
    case 0x80C84Fu: goto L_80C84F;
    case 0x80C850u: goto L_80C850;
    case 0x80C853u: goto L_80C853;
    case 0x80C855u: goto L_80C855;
    case 0x80C858u: goto L_80C858;
    case 0x80C85Bu: goto L_80C85B;
    case 0x80C85Du: goto L_80C85D;
    case 0x80C85Eu: goto L_80C85E;
    case 0x80C85Fu: goto L_80C85F;
    case 0x80C860u: goto L_80C860;
    case 0x80C862u: goto L_80C862;
    case 0x80C864u: goto L_80C864;
    case 0x80C865u: goto L_80C865;
    case 0x80C866u: goto L_80C866;
    case 0x80C868u: goto L_80C868;
    case 0x80C86Au: goto L_80C86A;
    case 0x80C86Cu: goto L_80C86C;
    case 0x80C86Eu: goto L_80C86E;
    case 0x80C871u: goto L_80C871;
    case 0x80C873u: goto L_80C873;
    case 0x80C875u: goto L_80C875;
    case 0x80C876u: goto L_80C876;
    case 0x80C879u: goto L_80C879;
    case 0x80C87Bu: goto L_80C87B;
    case 0x80C87Cu: goto L_80C87C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C82E PLB
    cpu.pop("PLB", hw);
    goto L_80C82F;
L_80C82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC82Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C82F LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C832;
L_80C832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC832u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C832 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C835;
L_80C835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC835u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C835 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_80C837;
L_80C837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC837u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C837 TDC
    cpu.tdc();
    goto L_80C838;
L_80C838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC838u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C838 TAY
    cpu.transfer("TAY");
    goto L_80C839;
L_80C839:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC839u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC839u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC839u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C839 CLC
    cpu.setFlag('C', false);
    goto L_80C83A;
L_80C83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C83C;
L_80C83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83C BCC -> $80C844
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C844; }
    goto L_80C83E;
L_80C83E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Eu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83E DEX
    cpu.decReg('X');
    goto L_80C83F;
L_80C83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC83Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C83F DEX
    cpu.decReg('X');
    goto L_80C840;
L_80C840:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC840u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC840u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC840u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C840 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C842;
L_80C842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC842u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC842u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C842 INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C844;
L_80C844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC844u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC844u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C844 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C846;
L_80C846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC846u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C846 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C848;
L_80C848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC848u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC848u, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C848 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C84B;
L_80C84B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C84D;
L_80C84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Du,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Du, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84D INC
    cpu.incMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C84F;
L_80C84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC84Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C84F INY
    cpu.inc('Y');
    goto L_80C850;
L_80C850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC850u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC850u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C850 CPY
    cpu.compareY(0x70u);
    goto L_80C853;
L_80C853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC853u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C853 BCC -> $80C839
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C839; }
    goto L_80C855;
L_80C855:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC855u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC855u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C855 LDX
    cpu.setX(0xB8E0u, 16);
    goto L_80C858;
L_80C858:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC858u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC858u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC858u, 5u, 3u, cpu.address("abs", 0x1C02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C858 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1C02u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C85B;
L_80C85B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85B STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_80C85D;
L_80C85D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85D TDC
    cpu.tdc();
    goto L_80C85E;
L_80C85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85E TAY
    cpu.transfer("TAY");
    goto L_80C85F;
L_80C85F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC85Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC85Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C85F CLC
    cpu.setFlag('C', false);
    goto L_80C860;
L_80C860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC860u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC860u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C860 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80C862;
L_80C862:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC862u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC862u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C862 BCC -> $80C86A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C86A; }
    goto L_80C864;
L_80C864:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC864u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC864u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C864 INX
    cpu.inc('X');
    goto L_80C865;
L_80C865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC865u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C865 INX
    cpu.inc('X');
    goto L_80C866;
L_80C866:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC866u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC866u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC866u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C866 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C868;
L_80C868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC868u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC868u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C868 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C86A;
L_80C86A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86A STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80C86C;
L_80C86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C86E;
L_80C86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC86Eu, 6u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C86E STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C871;
L_80C871:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC871u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC871u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C871 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C873;
L_80C873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC873u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC873u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C873 DEC
    cpu.decMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_80C875;
L_80C875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC875u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC875u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C875 DEY
    cpu.decReg('Y');
    goto L_80C876;
L_80C876:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC876u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC876u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C876 CPY
    cpu.compareY(0xFF90u);
    goto L_80C879;
L_80C879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC879u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC879u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C879 BCS -> $80C85F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80C85F; }
    goto L_80C87B;
L_80C87B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Bu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C87B PLB
    cpu.pop("PLB", hw);
    goto L_80C87C;
L_80C87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC87Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80C87C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80C87Cu);return;} hw.unresolvedReturn(0x80C87Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D314_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D314u: goto L_80D314;
    case 0x80D315u: goto L_80D315;
    case 0x80D316u: goto L_80D316;
    case 0x80D319u: goto L_80D319;
    case 0x80D31Bu: goto L_80D31B;
    case 0x80D31Eu: goto L_80D31E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD314u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D314 INY
    cpu.inc('Y');
    goto L_80D315;
L_80D315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD315u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D315 INY
    cpu.inc('Y');
    goto L_80D316;
L_80D316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D316 CPY
    cpu.compareY(0xCu);
    goto L_80D319;
L_80D319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D319 BCC -> $80D31E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D31E; }
    goto L_80D31B;
L_80D31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D31B LDY
    cpu.setY(0x0u, 16);
    goto L_80D31E;
L_80D31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D31E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D31Eu);return;} hw.unresolvedReturn(0x80D31Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D314_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D314u: goto L_80D314;
    case 0x80D315u: goto L_80D315;
    case 0x80D316u: goto L_80D316;
    case 0x80D319u: goto L_80D319;
    case 0x80D31Bu: goto L_80D31B;
    case 0x80D31Eu: goto L_80D31E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD314u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD314u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D314 INY
    cpu.inc('Y');
    goto L_80D315;
L_80D315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD315u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D315 INY
    cpu.inc('Y');
    goto L_80D316;
L_80D316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD316u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D316 CPY
    cpu.compareY(0xCu);
    goto L_80D319;
L_80D319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD319u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D319 BCC -> $80D31E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D31E; }
    goto L_80D31B;
L_80D31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D31B LDY
    cpu.setY(0x0u, 16);
    goto L_80D31E;
L_80D31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD31Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D31E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D31Eu);return;} hw.unresolvedReturn(0x80D31Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_828015_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828015u: goto L_828015;
    case 0x828018u: goto L_828018;
    case 0x82801Bu: goto L_82801B;
    case 0x82801Eu: goto L_82801E;
    case 0x828021u: goto L_828021;
    case 0x828024u: goto L_828024;
    case 0x828027u: goto L_828027;
    case 0x82802Au: goto L_82802A;
    case 0x82802Du: goto L_82802D;
    case 0x828030u: goto L_828030;
    case 0x828033u: goto L_828033;
    case 0x828036u: goto L_828036;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828015 LDA
    cpu.setA(0x1u, 16);
    goto L_828018;
L_828018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u, 5u, 3u, cpu.address("abs", 0x1A60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828018 STA
    hw.write(cpu.address("abs", 0x1A60u), cpu.a, cpu.m8?8:16);
    goto L_82801B;
L_82801B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Bu, 5u, 3u, cpu.address("abs", 0x1A62u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82801B STZ
    hw.write(cpu.address("abs", 0x1A62u), 0, cpu.m8?8:16);
    goto L_82801E;
L_82801E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82801E LDA
    cpu.setA(0xFu, 16);
    goto L_828021;
L_828021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828021 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_828024;
L_828024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u, 5u, 3u, cpu.address("abs", 0x1FDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828024 STZ
    hw.write(cpu.address("abs", 0x1FDAu), 0, cpu.m8?8:16);
    goto L_828027;
L_828027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u, 5u, 3u, cpu.address("abs", 0x1FD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828027 STZ
    hw.write(cpu.address("abs", 0x1FD4u), 0, cpu.m8?8:16);
    goto L_82802A;
L_82802A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82802A STZ
    hw.write(cpu.address("abs", 0x1A6Eu), 0, cpu.m8?8:16);
    goto L_82802D;
L_82802D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82802D STZ
    hw.write(cpu.address("abs", 0x1A70u), 0, cpu.m8?8:16);
    goto L_828030;
L_828030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828030 LDA
    cpu.setA(0x80u, 16);
    goto L_828033;
L_828033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 5u, 3u, cpu.address("abs", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828033 STA
    hw.write(cpu.address("abs", 0x1FC6u), cpu.a, cpu.m8?8:16);
    goto L_828036;
L_828036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828036 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x828036u);return;} hw.unresolvedReturn(0x828036u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_828015_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828015u: goto L_828015;
    case 0x828018u: goto L_828018;
    case 0x82801Bu: goto L_82801B;
    case 0x82801Eu: goto L_82801E;
    case 0x828021u: goto L_828021;
    case 0x828024u: goto L_828024;
    case 0x828027u: goto L_828027;
    case 0x82802Au: goto L_82802A;
    case 0x82802Du: goto L_82802D;
    case 0x828030u: goto L_828030;
    case 0x828033u: goto L_828033;
    case 0x828036u: goto L_828036;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8015u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828015 LDA
    cpu.setA(0x1u, 16);
    goto L_828018;
L_828018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8018u, 5u, 3u, cpu.address("abs", 0x1A60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828018 STA
    hw.write(cpu.address("abs", 0x1A60u), cpu.a, cpu.m8?8:16);
    goto L_82801B;
L_82801B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Bu, 5u, 3u, cpu.address("abs", 0x1A62u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82801B STZ
    hw.write(cpu.address("abs", 0x1A62u), 0, cpu.m8?8:16);
    goto L_82801E;
L_82801E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x801Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x801Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82801E LDA
    cpu.setA(0xFu, 16);
    goto L_828021;
L_828021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8021u, 5u, 3u, cpu.address("abs", 0x1FA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828021 STA
    hw.write(cpu.address("abs", 0x1FA4u), cpu.a, cpu.m8?8:16);
    goto L_828024;
L_828024:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8024u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8024u, 5u, 3u, cpu.address("abs", 0x1FDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828024 STZ
    hw.write(cpu.address("abs", 0x1FDAu), 0, cpu.m8?8:16);
    goto L_828027;
L_828027:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8027u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8027u, 5u, 3u, cpu.address("abs", 0x1FD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828027 STZ
    hw.write(cpu.address("abs", 0x1FD4u), 0, cpu.m8?8:16);
    goto L_82802A;
L_82802A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Au, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82802A STZ
    hw.write(cpu.address("abs", 0x1A6Eu), 0, cpu.m8?8:16);
    goto L_82802D;
L_82802D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x802Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x802Du, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82802D STZ
    hw.write(cpu.address("abs", 0x1A70u), 0, cpu.m8?8:16);
    goto L_828030;
L_828030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8030u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8030u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828030 LDA
    cpu.setA(0x80u, 16);
    goto L_828033;
L_828033:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8033u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8033u, 5u, 3u, cpu.address("abs", 0x1FC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828033 STA
    hw.write(cpu.address("abs", 0x1FC6u), cpu.a, cpu.m8?8:16);
    goto L_828036;
L_828036:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8036u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8036u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828036 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x828036u);return;} hw.unresolvedReturn(0x828036u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82870F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B9u: goto L_8083B9;
    case 0x8083BCu: goto L_8083BC;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C3u: goto L_8083C3;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C9u: goto L_8083C9;
    case 0x8083CBu: goto L_8083CB;
    case 0x8083CDu: goto L_8083CD;
    case 0x8083CFu: goto L_8083CF;
    case 0x8083D0u: goto L_8083D0;
    case 0x82870Fu: goto L_82870F;
    case 0x828712u: goto L_828712;
    case 0x828715u: goto L_828715;
    case 0x828719u: goto L_828719;
    case 0x82871Cu: goto L_82871C;
    case 0x82871Fu: goto L_82871F;
    case 0x828723u: goto L_828723;
    case 0x828725u: goto L_828725;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083B6 PHP
    cpu.push("PHP", hw);
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B7 SEP
    cpu.sep(0x20u);
    goto L_8083B9;
L_8083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BC;
L_8083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BC LDA
    cpu.setA(0xFu, 8);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 4u, 3u, cpu.address("abs", 0x1FA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BE STA
    hw.write(cpu.address("abs", 0x1FA0u), cpu.a, cpu.m8?8:16);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.setA(0x81u, 8);
    goto L_8083C3;
L_8083C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C3 STA
    hw.write(cpu.address("abs", 0x1FA2u), cpu.a, cpu.m8?8:16);
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C6 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C9 LDA
    cpu.setA(0x4u, 8);
    goto L_8083CB;
L_8083CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CB STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8083CD;
L_8083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CD REP
    cpu.rep(0x20u);
    goto L_8083CF;
L_8083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083CF PLP
    cpu.pop("PLP", hw);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D0u,0x8083D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083D0u);return;} hw.unresolvedReturn(0x8083D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82870F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82870F LDY
    cpu.setY(0x8BCCu, 16);
    goto L_828712;
L_828712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828712 LDX
    cpu.setX(0x1F50u, 16);
    goto L_828715;
L_828715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828715 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8718u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8719u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x828715u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828719;
L_828719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8719u,0x828719u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828719 LDY
    cpu.setY(0x8E64u, 16);
    goto L_82871C;
L_82871C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82871C LDX
    cpu.setX(0x1F90u, 16);
    goto L_82871F;
L_82871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82871F JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8722u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8723u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82871Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828723;
L_828723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8723u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8723u,0x828723u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828723 BRA -> $828725
    goto L_828725;
L_828725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u, 4u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828725 JML -> $8083B6
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8083B6;
}

void sub_82870F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B9u: goto L_8083B9;
    case 0x8083BCu: goto L_8083BC;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C3u: goto L_8083C3;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C9u: goto L_8083C9;
    case 0x8083CBu: goto L_8083CB;
    case 0x8083CDu: goto L_8083CD;
    case 0x8083CFu: goto L_8083CF;
    case 0x8083D0u: goto L_8083D0;
    case 0x82870Fu: goto L_82870F;
    case 0x828712u: goto L_828712;
    case 0x828715u: goto L_828715;
    case 0x828719u: goto L_828719;
    case 0x82871Cu: goto L_82871C;
    case 0x82871Fu: goto L_82871F;
    case 0x828723u: goto L_828723;
    case 0x828725u: goto L_828725;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083B6 PHP
    cpu.push("PHP", hw);
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B7 SEP
    cpu.sep(0x20u);
    goto L_8083B9;
L_8083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BC;
L_8083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BC LDA
    cpu.setA(0xFu, 8);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 4u, 3u, cpu.address("abs", 0x1FA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BE STA
    hw.write(cpu.address("abs", 0x1FA0u), cpu.a, cpu.m8?8:16);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.setA(0x81u, 8);
    goto L_8083C3;
L_8083C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C3 STA
    hw.write(cpu.address("abs", 0x1FA2u), cpu.a, cpu.m8?8:16);
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C6 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C9 LDA
    cpu.setA(0x4u, 8);
    goto L_8083CB;
L_8083CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CB STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8083CD;
L_8083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CD REP
    cpu.rep(0x20u);
    goto L_8083CF;
L_8083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083CF PLP
    cpu.pop("PLP", hw);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D0u,0x8083D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083D0u);return;} hw.unresolvedReturn(0x8083D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82870F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x870Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x870Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82870F LDY
    cpu.setY(0x8BCCu, 16);
    goto L_828712;
L_828712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8712u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828712 LDX
    cpu.setX(0x1F50u, 16);
    goto L_828715;
L_828715:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8715u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8715u, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $828715 JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8718u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8719u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x828715u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828719;
L_828719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8719u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8719u,0x828719u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8719u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828719 LDY
    cpu.setY(0x8E64u, 16);
    goto L_82871C;
L_82871C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82871C LDX
    cpu.setX(0x1F90u, 16);
    goto L_82871F;
L_82871F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x871Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x871Fu, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82871F JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8722u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8723u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82871Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828723;
L_828723:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8723u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8723u,0x828723u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8723u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828723 BRA -> $828725
    goto L_828725;
L_828725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u, 4u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828725 JML -> $8083B6
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8083B6;
}

void sub_829689_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829689u: goto L_829689;
    case 0x82968Bu: goto L_82968B;
    case 0x82968Cu: goto L_82968C;
    case 0x82968Eu: goto L_82968E;
    case 0x829690u: goto L_829690;
    case 0x829692u: goto L_829692;
    case 0x829695u: goto L_829695;
    case 0x829698u: goto L_829698;
    case 0x82969Bu: goto L_82969B;
    case 0x82969Eu: goto L_82969E;
    case 0x8296A1u: goto L_8296A1;
    case 0x8296A3u: goto L_8296A3;
    case 0x8296A5u: goto L_8296A5;
    case 0x8296A8u: goto L_8296A8;
    case 0x8296AAu: goto L_8296AA;
    case 0x8296ACu: goto L_8296AC;
    case 0x8296AFu: goto L_8296AF;
    case 0x8296B0u: goto L_8296B0;
    case 0x8296B2u: goto L_8296B2;
    case 0x8296B4u: goto L_8296B4;
    case 0x8296B7u: goto L_8296B7;
    case 0x8296B8u: goto L_8296B8;
    case 0x8296BAu: goto L_8296BA;
    case 0x8296BCu: goto L_8296BC;
    case 0x8296BFu: goto L_8296BF;
    case 0x8296C1u: goto L_8296C1;
    case 0x8296C2u: goto L_8296C2;
    case 0x8296C3u: goto L_8296C3;
    case 0x8296C6u: goto L_8296C6;
    case 0x8296C8u: goto L_8296C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9689u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9689u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829689 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82968B;
L_82968B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82968B LSR
    cpu.lsrA();
    goto L_82968C;
L_82968C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82968C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82968E;
L_82968E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x968Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x968Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82968E STX
    hw.write(cpu.address("dp", 0x14u), cpu.x, cpu.x8?8:16);
    goto L_829690;
L_829690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9690u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829690 STX
    hw.write(cpu.address("dp", 0x16u), cpu.x, cpu.x8?8:16);
    goto L_829692;
L_829692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9692u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9692u, 6u, 3u, cpu.address("abs", 0x96CDu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829692 JSR -> $8296CD stack real
    { cpu.push16Value(hw,0x9694u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9695u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96CDu), 0x829692u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829695;
L_829695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9695u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9695u,0x829695u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9695u, 6u, 3u, cpu.address("abs", 0x9765u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829695 JSR -> $829765 stack real
    { cpu.push16Value(hw,0x9697u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9698u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9765u), 0x829695u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829698;
L_829698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9698u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9698u,0x829698u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9698u, 6u, 3u, cpu.address("abs", 0x97ACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829698 JSR -> $8297AC stack real
    { cpu.push16Value(hw,0x969Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x969Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97ACu), 0x829698u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82969B;
L_82969B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x969Bu,0x82969Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Bu, 6u, 3u, cpu.address("abs", 0x97D0u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82969B JSR -> $8297D0 stack real
    { cpu.push16Value(hw,0x969Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x969Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x97D0u), 0x82969Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82969E;
L_82969E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x969Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x969Eu,0x82969Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x969Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x969Eu, 6u, 3u, cpu.address("abs", 0x9815u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82969E JSR -> $829815 stack real
    { cpu.push16Value(hw,0x96A0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x96A1u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9815u), 0x82969Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8296A1;
L_8296A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x96A1u,0x8296A1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x16u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8296A3;
L_8296A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296A3 BEQ -> $8296C8
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8296C8; }
    goto L_8296A5;
L_8296A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296A5 LDA
    cpu.setA(0x5Eu, 16);
    goto L_8296A8;
L_8296A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296A8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8296AA;
L_8296AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296AA STA
    hw.write(cpu.address("dpx", 0x6u), cpu.a, cpu.m8?8:16);
    goto L_8296AC;
L_8296AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296AC LDA
    cpu.setA(0xB00Au, 16);
    goto L_8296AF;
L_8296AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296AF CLC
    cpu.setFlag('C', false);
    goto L_8296B0;
L_8296B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B0 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_8296B2;
L_8296B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B2 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_8296B4;
L_8296B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B4 LDA
    cpu.setA(0x5C05u, 16);
    goto L_8296B7;
L_8296B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B7 CLC
    cpu.setFlag('C', false);
    goto L_8296B8;
L_8296B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96B8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296B8 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_8296BA;
L_8296BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296BA STA
    hw.write(cpu.address("dpx", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_8296BC;
L_8296BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296BC LDA
    cpu.setA(0x7E80u, 16);
    goto L_8296BF;
L_8296BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96BFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296BF STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_8296C1;
L_8296C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C1 TXA
    cpu.transfer("TXA");
    goto L_8296C2;
L_8296C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C2 CLC
    cpu.setFlag('C', false);
    goto L_8296C3;
L_8296C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C3 ADC
    cpu.adc(0x8u);
    goto L_8296C6;
L_8296C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8296C6 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8296C8;
L_8296C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x96C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x96C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8296C8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x8296C8u);return;} hw.unresolvedReturn(0x8296C8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_829941_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829941u: goto L_829941;
    case 0x829944u: goto L_829944;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829941:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9941u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9941u, 6u, 3u, cpu.address("abs", 0x9945u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $829941 JSR -> $829945 stack real
    { cpu.push16Value(hw,0x9943u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9944u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9945u), 0x829941u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_829944;
L_829944:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9944u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9944u,0x829944u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9944u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9944u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829944 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829944u);return;} hw.unresolvedReturn(0x829944u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829FCF_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A0EBu: goto L_82A0EB;
    case 0x82A0EDu: goto L_82A0ED;
    case 0x82A0F0u: goto L_82A0F0;
    case 0x82A0F1u: goto L_82A0F1;
    case 0x82A0F3u: goto L_82A0F3;
    case 0x82A0F6u: goto L_82A0F6;
    case 0x82A0F7u: goto L_82A0F7;
    case 0x82A0F9u: goto L_82A0F9;
    case 0x82A0FBu: goto L_82A0FB;
    case 0x82A0FDu: goto L_82A0FD;
    case 0x82A101u: goto L_82A101;
    case 0x82A103u: goto L_82A103;
    case 0x82A106u: goto L_82A106;
    case 0x82A107u: goto L_82A107;
    case 0x82A108u: goto L_82A108;
    case 0x82A109u: goto L_82A109;
    case 0x82A10Au: goto L_82A10A;
    case 0x82A10Bu: goto L_82A10B;
    case 0x82A10Cu: goto L_82A10C;
    case 0x82A10Eu: goto L_82A10E;
    case 0x82A111u: goto L_82A111;
    case 0x82A112u: goto L_82A112;
    case 0x82A114u: goto L_82A114;
    case 0x82A117u: goto L_82A117;
    case 0x82A118u: goto L_82A118;
    case 0x82A11Au: goto L_82A11A;
    case 0x82A11Du: goto L_82A11D;
    case 0x82A11Eu: goto L_82A11E;
    case 0x82A120u: goto L_82A120;
    case 0x82A122u: goto L_82A122;
    case 0x82A124u: goto L_82A124;
    case 0x82A128u: goto L_82A128;
    case 0x82A12Au: goto L_82A12A;
    case 0x82A12Du: goto L_82A12D;
    case 0x82A12Eu: goto L_82A12E;
    case 0x82A12Fu: goto L_82A12F;
    case 0x82A130u: goto L_82A130;
    case 0x82A131u: goto L_82A131;
    case 0x82A132u: goto L_82A132;
    case 0x82A133u: goto L_82A133;
    case 0x82A135u: goto L_82A135;
    case 0x82A138u: goto L_82A138;
    case 0x82A139u: goto L_82A139;
    case 0x82A13Bu: goto L_82A13B;
    case 0x82A13Eu: goto L_82A13E;
    case 0x82A13Fu: goto L_82A13F;
    case 0x82A141u: goto L_82A141;
    case 0x82A144u: goto L_82A144;
    case 0x82A145u: goto L_82A145;
    case 0x82A147u: goto L_82A147;
    case 0x82A149u: goto L_82A149;
    case 0x82A14Bu: goto L_82A14B;
    case 0x82A14Fu: goto L_82A14F;
    case 0x82A151u: goto L_82A151;
    case 0x82A154u: goto L_82A154;
    case 0x82A155u: goto L_82A155;
    case 0x82A156u: goto L_82A156;
    case 0x82A157u: goto L_82A157;
    case 0x82A158u: goto L_82A158;
    case 0x82A159u: goto L_82A159;
    case 0x82A15Au: goto L_82A15A;
    case 0x82A15Cu: goto L_82A15C;
    case 0x82A15Fu: goto L_82A15F;
    case 0x82A160u: goto L_82A160;
    case 0x82A162u: goto L_82A162;
    case 0x82A165u: goto L_82A165;
    case 0x82A166u: goto L_82A166;
    case 0x82A168u: goto L_82A168;
    case 0x82A16Bu: goto L_82A16B;
    case 0x82A16Cu: goto L_82A16C;
    case 0x82A16Eu: goto L_82A16E;
    case 0x82A170u: goto L_82A170;
    case 0x82A172u: goto L_82A172;
    case 0x82A175u: goto L_82A175;
    case 0x82A177u: goto L_82A177;
    case 0x82A179u: goto L_82A179;
    case 0x82A17Bu: goto L_82A17B;
    case 0x82A17Cu: goto L_82A17C;
    case 0x82A17Du: goto L_82A17D;
    case 0x82A17Fu: goto L_82A17F;
    case 0x82A181u: goto L_82A181;
    case 0x82A182u: goto L_82A182;
    case 0x82A183u: goto L_82A183;
    case 0x82A185u: goto L_82A185;
    case 0x82A187u: goto L_82A187;
    case 0x82A188u: goto L_82A188;
    case 0x82A189u: goto L_82A189;
    case 0x82A18Bu: goto L_82A18B;
    case 0x82A18Du: goto L_82A18D;
    case 0x82A18Eu: goto L_82A18E;
    case 0x82A18Fu: goto L_82A18F;
    case 0x82A191u: goto L_82A191;
    case 0x82A193u: goto L_82A193;
    case 0x82A194u: goto L_82A194;
    case 0x82A195u: goto L_82A195;
    case 0x82A197u: goto L_82A197;
    case 0x82A199u: goto L_82A199;
    case 0x82A19Au: goto L_82A19A;
    case 0x82A19Bu: goto L_82A19B;
    case 0x82A19Du: goto L_82A19D;
    case 0x82A19Fu: goto L_82A19F;
    case 0x82A1A2u: goto L_82A1A2;
    case 0x82A1A3u: goto L_82A1A3;
    case 0x82A1A7u: goto L_82A1A7;
    case 0x82A1A9u: goto L_82A1A9;
    case 0x82A1ACu: goto L_82A1AC;
    case 0x82A1ADu: goto L_82A1AD;
    case 0x82A1AEu: goto L_82A1AE;
    case 0x82A1AFu: goto L_82A1AF;
    case 0x82A1B0u: goto L_82A1B0;
    case 0x82A1B1u: goto L_82A1B1;
    case 0x82A1B2u: goto L_82A1B2;
    case 0x82A1B4u: goto L_82A1B4;
    case 0x82A1B7u: goto L_82A1B7;
    case 0x82A1B8u: goto L_82A1B8;
    case 0x82A1BAu: goto L_82A1BA;
    case 0x82A1BDu: goto L_82A1BD;
    case 0x82A1BEu: goto L_82A1BE;
    case 0x82A1C0u: goto L_82A1C0;
    case 0x82A1C3u: goto L_82A1C3;
    case 0x82A1C4u: goto L_82A1C4;
    case 0x82A1C6u: goto L_82A1C6;
    case 0x82A1C8u: goto L_82A1C8;
    case 0x82A1CAu: goto L_82A1CA;
    case 0x82A1CEu: goto L_82A1CE;
    case 0x82A1D0u: goto L_82A1D0;
    case 0x82A1D3u: goto L_82A1D3;
    case 0x82A1D4u: goto L_82A1D4;
    case 0x82A1D5u: goto L_82A1D5;
    case 0x82A1D6u: goto L_82A1D6;
    case 0x82A1D7u: goto L_82A1D7;
    case 0x82A1D8u: goto L_82A1D8;
    case 0x82A1D9u: goto L_82A1D9;
    case 0x82A1DBu: goto L_82A1DB;
    case 0x82A1DEu: goto L_82A1DE;
    case 0x82A1DFu: goto L_82A1DF;
    case 0x82A1E1u: goto L_82A1E1;
    case 0x82A1E4u: goto L_82A1E4;
    case 0x82A1E5u: goto L_82A1E5;
    case 0x82A1E7u: goto L_82A1E7;
    case 0x82A1EAu: goto L_82A1EA;
    case 0x82A1EBu: goto L_82A1EB;
    case 0x82A1EDu: goto L_82A1ED;
    case 0x82A1EFu: goto L_82A1EF;
    case 0x82A1F1u: goto L_82A1F1;
    case 0x82A1F5u: goto L_82A1F5;
    case 0x82A1F7u: goto L_82A1F7;
    case 0x82A1FAu: goto L_82A1FA;
    case 0x82A1FBu: goto L_82A1FB;
    case 0x82A1FCu: goto L_82A1FC;
    case 0x82A1FDu: goto L_82A1FD;
    case 0x82A1FEu: goto L_82A1FE;
    case 0x82A1FFu: goto L_82A1FF;
    case 0x82A200u: goto L_82A200;
    case 0x82A202u: goto L_82A202;
    case 0x82A205u: goto L_82A205;
    case 0x82A206u: goto L_82A206;
    case 0x82A208u: goto L_82A208;
    case 0x82A20Bu: goto L_82A20B;
    case 0x82A20Cu: goto L_82A20C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A0EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EBu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0EB ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A0ED;
L_82A0ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EDu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0EDu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0ED LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A0F0;
L_82A0F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F0 ASL
    cpu.aslA();
    goto L_82A0F1;
L_82A0F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F1 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A0F3;
L_82A0F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F3u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A0F6;
L_82A0F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F6 ASL
    cpu.aslA();
    goto L_82A0F7;
L_82A0F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F7 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A0F9;
L_82A0F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0F9 REP
    cpu.rep(0x20u);
    goto L_82A0FB;
L_82A0FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0FB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A0FD;
L_82A0FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA0FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA0FDu, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A0FD LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A101;
L_82A101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA101u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A101 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A103;
L_82A103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA103u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA103u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A103 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A106;
L_82A106:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA106u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA106u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A106 ASL
    cpu.aslA();
    goto L_82A107;
L_82A107:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA107u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA107u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A107 ASL
    cpu.aslA();
    goto L_82A108;
L_82A108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA108u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A108 ASL
    cpu.aslA();
    goto L_82A109;
L_82A109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA109u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A109 ASL
    cpu.aslA();
    goto L_82A10A;
L_82A10A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A10A ASL
    cpu.aslA();
    goto L_82A10B;
L_82A10B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A10B TAX
    cpu.transfer("TAX");
    goto L_82A10C;
L_82A10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A10C SEP
    cpu.sep(0x20u);
    goto L_82A10E;
L_82A10E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA10Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA10Eu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A10E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A111;
L_82A111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA111u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A111 ASL
    cpu.aslA();
    goto L_82A112;
L_82A112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA112u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A112 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A114;
L_82A114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA114u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA114u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A114 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A117;
L_82A117:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA117u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA117u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A117 ASL
    cpu.aslA();
    goto L_82A118;
L_82A118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA118u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A118 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A11A;
L_82A11A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Au, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A11A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A11D;
L_82A11D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A11D ASL
    cpu.aslA();
    goto L_82A11E;
L_82A11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Eu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA11Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A11E ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A120;
L_82A120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA120u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A120 REP
    cpu.rep(0x20u);
    goto L_82A122;
L_82A122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA122u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA122u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A122 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A124;
L_82A124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA124u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA124u, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A124 LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A128;
L_82A128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA128u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A128 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A12A;
L_82A12A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A12A AND
    cpu.logicAnd(0x3FFu);
    goto L_82A12D;
L_82A12D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A12D ASL
    cpu.aslA();
    goto L_82A12E;
L_82A12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A12E ASL
    cpu.aslA();
    goto L_82A12F;
L_82A12F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA12Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA12Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A12F ASL
    cpu.aslA();
    goto L_82A130;
L_82A130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA130u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A130 ASL
    cpu.aslA();
    goto L_82A131;
L_82A131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA131u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A131 ASL
    cpu.aslA();
    goto L_82A132;
L_82A132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA132u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A132 TAX
    cpu.transfer("TAX");
    goto L_82A133;
L_82A133:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA133u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA133u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA133u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A133 SEP
    cpu.sep(0x20u);
    goto L_82A135;
L_82A135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA135u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA135u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A135 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A138;
L_82A138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA138u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA138u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A138 ASL
    cpu.aslA();
    goto L_82A139;
L_82A139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA139u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A139 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A13B;
L_82A13B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Bu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A13B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A13E;
L_82A13E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A13E ASL
    cpu.aslA();
    goto L_82A13F;
L_82A13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Fu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A13F ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A141;
L_82A141:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA141u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA141u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA141u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A141 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A144;
L_82A144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA144u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A144 ASL
    cpu.aslA();
    goto L_82A145;
L_82A145:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA145u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA145u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA145u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A145 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A147;
L_82A147:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA147u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA147u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A147 REP
    cpu.rep(0x20u);
    goto L_82A149;
L_82A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A149 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A14B;
L_82A14B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Bu, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A14B LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A14F;
L_82A14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A14F STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A151;
L_82A151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA151u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A151 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A154;
L_82A154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA154u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A154 ASL
    cpu.aslA();
    goto L_82A155;
L_82A155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA155u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A155 ASL
    cpu.aslA();
    goto L_82A156;
L_82A156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA156u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A156 ASL
    cpu.aslA();
    goto L_82A157;
L_82A157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A157 ASL
    cpu.aslA();
    goto L_82A158;
L_82A158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA158u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA158u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A158 ASL
    cpu.aslA();
    goto L_82A159;
L_82A159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA159u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A159 TAX
    cpu.transfer("TAX");
    goto L_82A15A;
L_82A15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A15A SEP
    cpu.sep(0x20u);
    goto L_82A15C;
L_82A15C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Cu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A15C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A15F;
L_82A15F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A15F ASL
    cpu.aslA();
    goto L_82A160;
L_82A160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA160u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA160u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A160 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A162;
L_82A162:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA162u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA162u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A162 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A165;
L_82A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A165 ASL
    cpu.aslA();
    goto L_82A166;
L_82A166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA166u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA166u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A166 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A168;
L_82A168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A168 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A16B;
L_82A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A16B ASL
    cpu.aslA();
    goto L_82A16C;
L_82A16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A16C ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A16E;
L_82A16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A16E REP
    cpu.rep(0x20u);
    goto L_82A170;
L_82A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A170 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A172;
L_82A172:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA172u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA172u, 5u + 1u, 3u, cpu.address("absy", 0x8004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A172 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8004u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A175;
L_82A175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA175u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A175 BNE -> $82A1A2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A1A2; }
    goto L_82A177;
L_82A177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA177u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA177u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A177 SEP
    cpu.sep(0x20u);
    goto L_82A179;
L_82A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A179 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A17B;
L_82A17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17B ASL
    cpu.aslA();
    goto L_82A17C;
L_82A17C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17C ASL
    cpu.aslA();
    goto L_82A17D;
L_82A17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17D STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82A17F;
L_82A17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A17F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A181;
L_82A181:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA181u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA181u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A181 ASL
    cpu.aslA();
    goto L_82A182;
L_82A182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A182 ASL
    cpu.aslA();
    goto L_82A183;
L_82A183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA183u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A183 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_82A185;
L_82A185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA185u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A185 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A187;
L_82A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A187 ASL
    cpu.aslA();
    goto L_82A188;
L_82A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A188 ASL
    cpu.aslA();
    goto L_82A189;
L_82A189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA189u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A189 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A18B;
L_82A18B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A18D;
L_82A18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18D ASL
    cpu.aslA();
    goto L_82A18E;
L_82A18E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18E ASL
    cpu.aslA();
    goto L_82A18F;
L_82A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A18F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82A191;
L_82A191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A191 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A193;
L_82A193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA193u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA193u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A193 ASL
    cpu.aslA();
    goto L_82A194;
L_82A194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA194u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A194 ASL
    cpu.aslA();
    goto L_82A195;
L_82A195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA195u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA195u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A195 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_82A197;
L_82A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A197 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A199;
L_82A199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A199 ASL
    cpu.aslA();
    goto L_82A19A;
L_82A19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19A ASL
    cpu.aslA();
    goto L_82A19B;
L_82A19B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19B STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A19D;
L_82A19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19D REP
    cpu.rep(0x20u);
    goto L_82A19F;
L_82A19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Fu, 3u, 3u, cpu.address("abs", 0xA23Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A19F JMP -> $82A23F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xA23Fu),0x82A19Fu); return;
L_82A1A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A2 TAX
    cpu.transfer("TAX");
    goto L_82A1A3;
L_82A1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A3u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A3 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1A7;
L_82A1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A7 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A1A9;
L_82A1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1A9 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A1AC;
L_82A1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AC ASL
    cpu.aslA();
    goto L_82A1AD;
L_82A1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AD ASL
    cpu.aslA();
    goto L_82A1AE;
L_82A1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AE ASL
    cpu.aslA();
    goto L_82A1AF;
L_82A1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1AF ASL
    cpu.aslA();
    goto L_82A1B0;
L_82A1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B0 ASL
    cpu.aslA();
    goto L_82A1B1;
L_82A1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B1 TAX
    cpu.transfer("TAX");
    goto L_82A1B2;
L_82A1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B2 SEP
    cpu.sep(0x20u);
    goto L_82A1B4;
L_82A1B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B4u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1B7;
L_82A1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B7 ASL
    cpu.aslA();
    goto L_82A1B8;
L_82A1B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1B8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A1BA;
L_82A1BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BAu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1BD;
L_82A1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BD ASL
    cpu.aslA();
    goto L_82A1BE;
L_82A1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BEu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1BE ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A1C0;
L_82A1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C0u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1C3;
L_82A1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C3 ASL
    cpu.aslA();
    goto L_82A1C4;
L_82A1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C4 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A1C6;
L_82A1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C6 REP
    cpu.rep(0x20u);
    goto L_82A1C8;
L_82A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1C8 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1CA;
L_82A1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CAu, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CA LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1CE;
L_82A1CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1CE STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A1D0;
L_82A1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D0u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D0 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A1D3;
L_82A1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D3 ASL
    cpu.aslA();
    goto L_82A1D4;
L_82A1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D4 ASL
    cpu.aslA();
    goto L_82A1D5;
L_82A1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D5 ASL
    cpu.aslA();
    goto L_82A1D6;
L_82A1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D6 ASL
    cpu.aslA();
    goto L_82A1D7;
L_82A1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D7 ASL
    cpu.aslA();
    goto L_82A1D8;
L_82A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D8 TAX
    cpu.transfer("TAX");
    goto L_82A1D9;
L_82A1D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1D9 SEP
    cpu.sep(0x20u);
    goto L_82A1DB;
L_82A1DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DBu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1DE;
L_82A1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DE ASL
    cpu.aslA();
    goto L_82A1DF;
L_82A1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1DF ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A1E1;
L_82A1E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E1u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1E4;
L_82A1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E4 ASL
    cpu.aslA();
    goto L_82A1E5;
L_82A1E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E5 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A1E7;
L_82A1E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E7u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1E7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1EA;
L_82A1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EA ASL
    cpu.aslA();
    goto L_82A1EB;
L_82A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EB ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A1ED;
L_82A1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1ED REP
    cpu.rep(0x20u);
    goto L_82A1EF;
L_82A1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1EF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A1F1;
L_82A1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F1 LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A1F5;
L_82A1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F5 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A1F7;
L_82A1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1F7 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A1FA;
L_82A1FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FA ASL
    cpu.aslA();
    goto L_82A1FB;
L_82A1FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FB ASL
    cpu.aslA();
    goto L_82A1FC;
L_82A1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FC ASL
    cpu.aslA();
    goto L_82A1FD;
L_82A1FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FD ASL
    cpu.aslA();
    goto L_82A1FE;
L_82A1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FE ASL
    cpu.aslA();
    goto L_82A1FF;
L_82A1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A1FF TAX
    cpu.transfer("TAX");
    goto L_82A200;
L_82A200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA200u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA200u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A200 SEP
    cpu.sep(0x20u);
    goto L_82A202;
L_82A202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA202u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A202 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A205;
L_82A205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA205u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A205 ASL
    cpu.aslA();
    goto L_82A206;
L_82A206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA206u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A206 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A208;
L_82A208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA208u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA208u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A208 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A20B;
L_82A20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A20B ASL
    cpu.aslA();
    goto L_82A20C;
L_82A20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A20C ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA20Eu,0x82A20Cu); return;
}

void sub_82B4DF_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB50Cu,0x82B50Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
}

void sub_82B4DF_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B4B4u: goto L_82B4B4;
    case 0x82B4B7u: goto L_82B4B7;
    case 0x82B4BAu: goto L_82B4BA;
    case 0x82B4BDu: goto L_82B4BD;
    case 0x82B4BEu: goto L_82B4BE;
    case 0x82B4C1u: goto L_82B4C1;
    case 0x82B4C4u: goto L_82B4C4;
    case 0x82B4C7u: goto L_82B4C7;
    case 0x82B4DFu: goto L_82B4DF;
    case 0x82B4E2u: goto L_82B4E2;
    case 0x82B4E4u: goto L_82B4E4;
    case 0x82B4E7u: goto L_82B4E7;
    case 0x82B4E8u: goto L_82B4E8;
    case 0x82B4E9u: goto L_82B4E9;
    case 0x82B4ECu: goto L_82B4EC;
    case 0x82B4EFu: goto L_82B4EF;
    case 0x82B4F0u: goto L_82B4F0;
    case 0x82B4F3u: goto L_82B4F3;
    case 0x82B4F5u: goto L_82B4F5;
    case 0x82B4F6u: goto L_82B4F6;
    case 0x82B4F9u: goto L_82B4F9;
    case 0x82B4FCu: goto L_82B4FC;
    case 0x82B4FFu: goto L_82B4FF;
    case 0x82B500u: goto L_82B500;
    case 0x82B501u: goto L_82B501;
    case 0x82B504u: goto L_82B504;
    case 0x82B506u: goto L_82B506;
    case 0x82B509u: goto L_82B509;
    case 0x82B50Cu: goto L_82B50C;
    case 0x82B50Du: goto L_82B50D;
    case 0x82B50Fu: goto L_82B50F;
    case 0x82B512u: goto L_82B512;
    case 0x82B514u: goto L_82B514;
    case 0x82B517u: goto L_82B517;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B4B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B4u, 6u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B4 STZ
    hw.write(cpu.address("absx", 0x1C58u), 0, cpu.m8?8:16);
    goto L_82B4B7;
L_82B4B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4B7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4B7 LDY
    cpu.setY(0x3u, 16);
    goto L_82B4BA;
L_82B4BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BAu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BA STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4BD;
L_82B4BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BD TYA
    cpu.transfer("TYA");
    goto L_82B4BE;
L_82B4BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4BEu, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4BE STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B4C1;
L_82B4C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C1u, 6u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C1 STA
    hw.write(cpu.address("absx", 0x1C5Cu), cpu.a, cpu.m8?8:16);
    goto L_82B4C4;
L_82B4C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C4u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4C4 INC
    cpu.incMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B4C7;
L_82B4C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4C7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4C7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B4C7u);return;} hw.unresolvedReturn(0x82B4C7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B4DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4DFu, 9u, 3u, cpu.address("absx", 0x1C54u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4DF DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C54u), cpu.m8?8:16);
    goto L_82B4E2;
L_82B4E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E2 BNE -> $82B50C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50C; }
    goto L_82B4E4;
L_82B4E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E4u, 5u + 1u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C48u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4E7;
L_82B4E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E7 TAY
    cpu.transfer("TAY");
    goto L_82B4E8;
L_82B4E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E8 CLC
    cpu.setFlag('C', false);
    goto L_82B4E9;
L_82B4E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4E9 ADC
    cpu.adc(0x6u);
    goto L_82B4EC;
L_82B4EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4ECu, 6u, 3u, cpu.address("absx", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EC STA
    hw.write(cpu.address("absx", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B4EF;
L_82B4EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4EF TYX
    cpu.transfer("TYX");
    goto L_82B4F0;
L_82B4F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F0u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F0 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4F3;
L_82B4F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F3 BEQ -> $82B50D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B50D; }
    goto L_82B4F5;
L_82B4F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F5u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F5 PHA
    cpu.push("PHA", hw);
    goto L_82B4F6;
L_82B4F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F6u, 5u + 1u, 3u, cpu.address("absx", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4F6 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x2u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B4F9;
L_82B4F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4F9u, 6u, 3u, cpu.address("abs", 0xB47Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B4F9 JSR -> $82B47D stack real
    { cpu.push16Value(hw,0xB4FBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB4FCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB47Du), 0x82B4F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B4FC;
L_82B4FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB4FCu,0x82B4FCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FCu, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B4FF;
L_82B4FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB4FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB4FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B4FF TAX
    cpu.transfer("TAX");
    goto L_82B500;
L_82B500:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB500u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB500u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B500 PLA
    cpu.pop("PLA", hw);
    goto L_82B501;
L_82B501:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB501u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB501u, 6u, 3u, cpu.address("abs", 0xB800u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B501 JSR -> $82B800 stack real
    { cpu.push16Value(hw,0xB503u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB504u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB800u), 0x82B501u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B504;
L_82B504:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB504u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB504u,0x82B504u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB504u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B504 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B506;
L_82B506:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB506u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB506u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B506 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B509;
L_82B509:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB509u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB509u, 6u, 3u, cpu.address("absx", 0x1C54u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B509 STA
    hw.write(cpu.address("absx", 0x1C54u), cpu.a, cpu.m8?8:16);
    goto L_82B50C;
L_82B50C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B50C RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B50Cu);return;} hw.unresolvedReturn(0x82B50Cu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82B50D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B50F;
L_82B50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB50Fu, 5u + 1u, 3u, cpu.address("absx", 0x1C58u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B50F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1C58u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B512;
L_82B512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B512 BEQ -> $82B4C4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B4C4; }
    goto L_82B514;
L_82B514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB514u, 9u, 3u, cpu.address("absx", 0x1C24u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B514 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1C24u), cpu.m8?8:16);
    goto L_82B517;
L_82B517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB517u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B517 BRA -> $82B4B4
    goto L_82B4B4;
}

void sub_82F08F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82F08Fu: goto L_82F08F;
    case 0x82F092u: goto L_82F092;
    case 0x82F094u: goto L_82F094;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82F08F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF08Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF08Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F08F LDA
    cpu.setA(0x1u, 16);
    goto L_82F092;
L_82F092:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF092u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF092u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF092u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82F092 STA
    hw.write(cpu.address("dp", 0xD4u), cpu.a, cpu.m8?8:16);
    goto L_82F094;
L_82F094:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF094u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF094u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF094u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82F094 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82F094u);return;} hw.unresolvedReturn(0x82F094u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83A50F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A50Eu: goto L_83A50E;
    case 0x83A50Fu: goto L_83A50F;
    case 0x83A512u: goto L_83A512;
    case 0x83A514u: goto L_83A514;
    case 0x83A517u: goto L_83A517;
    case 0x83A519u: goto L_83A519;
    case 0x83A51Cu: goto L_83A51C;
    case 0x83A51Fu: goto L_83A51F;
    case 0x83A521u: goto L_83A521;
    case 0x83A524u: goto L_83A524;
    case 0x83A526u: goto L_83A526;
    case 0x83A529u: goto L_83A529;
    case 0x83A52Cu: goto L_83A52C;
    case 0x83A52Fu: goto L_83A52F;
    case 0x83A531u: goto L_83A531;
    case 0x83A534u: goto L_83A534;
    case 0x83A537u: goto L_83A537;
    case 0x83A539u: goto L_83A539;
    case 0x83A53Au: goto L_83A53A;
    case 0x83A53Du: goto L_83A53D;
    case 0x83A53Fu: goto L_83A53F;
    case 0x83A540u: goto L_83A540;
    case 0x83A543u: goto L_83A543;
    case 0x83A544u: goto L_83A544;
    case 0x83A547u: goto L_83A547;
    case 0x83A549u: goto L_83A549;
    case 0x83A54Cu: goto L_83A54C;
    case 0x83A54Fu: goto L_83A54F;
    case 0x83A551u: goto L_83A551;
    case 0x83A554u: goto L_83A554;
    case 0x83A557u: goto L_83A557;
    case 0x83A55Au: goto L_83A55A;
    case 0x83A55Cu: goto L_83A55C;
    case 0x83A55Fu: goto L_83A55F;
    case 0x83A562u: goto L_83A562;
    case 0x83A564u: goto L_83A564;
    case 0x83A567u: goto L_83A567;
    case 0x83A569u: goto L_83A569;
    case 0x83A56Cu: goto L_83A56C;
    case 0x83A56Eu: goto L_83A56E;
    case 0x83A570u: goto L_83A570;
    case 0x83A573u: goto L_83A573;
    case 0x83A575u: goto L_83A575;
    case 0x83A578u: goto L_83A578;
    case 0x83A57Au: goto L_83A57A;
    case 0x83A57Du: goto L_83A57D;
    case 0x83A57Eu: goto L_83A57E;
    case 0x83A581u: goto L_83A581;
    case 0x83A584u: goto L_83A584;
    case 0x83A586u: goto L_83A586;
    case 0x83A589u: goto L_83A589;
    case 0x83A58Cu: goto L_83A58C;
    case 0x83A58Fu: goto L_83A58F;
    case 0x83A591u: goto L_83A591;
    case 0x83A593u: goto L_83A593;
    case 0x83A596u: goto L_83A596;
    case 0x83A597u: goto L_83A597;
    case 0x83A599u: goto L_83A599;
    case 0x83A59Cu: goto L_83A59C;
    case 0x83A59Fu: goto L_83A59F;
    case 0x83A5A2u: goto L_83A5A2;
    case 0x83A5A4u: goto L_83A5A4;
    case 0x83A5A6u: goto L_83A5A6;
    case 0x83A5A8u: goto L_83A5A8;
    case 0x83A5ABu: goto L_83A5AB;
    case 0x83A5AEu: goto L_83A5AE;
    case 0x83A5B1u: goto L_83A5B1;
    case 0x83A5B3u: goto L_83A5B3;
    case 0x83A5B6u: goto L_83A5B6;
    case 0x83A5B9u: goto L_83A5B9;
    case 0x83A5BBu: goto L_83A5BB;
    case 0x83A5BEu: goto L_83A5BE;
    case 0x83A5C0u: goto L_83A5C0;
    case 0x83A5C3u: goto L_83A5C3;
    case 0x83A5C4u: goto L_83A5C4;
    case 0x83A5C7u: goto L_83A5C7;
    case 0x83A5C9u: goto L_83A5C9;
    case 0x83A5CCu: goto L_83A5CC;
    case 0x83A5CDu: goto L_83A5CD;
    case 0x83A5D0u: goto L_83A5D0;
    case 0x83A5D2u: goto L_83A5D2;
    case 0x83A5D3u: goto L_83A5D3;
    case 0x83A5D5u: goto L_83A5D5;
    case 0x83A5D8u: goto L_83A5D8;
    case 0x83A5DBu: goto L_83A5DB;
    case 0x83ABF7u: goto L_83ABF7;
    case 0x83ABF9u: goto L_83ABF9;
    case 0x83ABFCu: goto L_83ABFC;
    case 0x83ABFEu: goto L_83ABFE;
    case 0x83ABFFu: goto L_83ABFF;
    case 0x83AC01u: goto L_83AC01;
    case 0x83AC03u: goto L_83AC03;
    case 0x83AC05u: goto L_83AC05;
    case 0x83AC06u: goto L_83AC06;
    case 0x83AC08u: goto L_83AC08;
    case 0x83AC0Au: goto L_83AC0A;
    case 0x83AC0Du: goto L_83AC0D;
    case 0x83AC0Eu: goto L_83AC0E;
    case 0x83AC11u: goto L_83AC11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A50E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A50Eu);return;} hw.unresolvedReturn(0x83A50Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A50E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A50Eu);return;} hw.unresolvedReturn(0x83A50Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA50Eu,0x83A50Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 5u, 3u, cpu.address("abs", 0x1BCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A50F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A512;
L_83A512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A512 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A514;
L_83A514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A514 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_83A517;
L_83A517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A517 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A519;
L_83A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A519 JMP -> $83A5C4
    goto L_83A5C4;
L_83A51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A51F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A51F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA51Cu,0x83A51Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51F BNE -> $83A50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A50E; }
    goto L_83A521;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51F BNE -> $83A50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A50E; }
    goto L_83A521;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA51Fu,0x83A51Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA521u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A521 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A524;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A521 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A524;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA521u,0x83A521u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA524u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A524 BEQ -> $83A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A526;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A524 BEQ -> $83A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A526;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA524u,0x83A524u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA526u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A526 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_83A529;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A526 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_83A529;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA526u,0x83A526u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA529u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A529 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A52C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A529 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A52C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA529u,0x83A529u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52C AND
    cpu.logicAnd(0xFFu);
    goto L_83A52F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52C AND
    cpu.logicAnd(0xFFu);
    goto L_83A52F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA52Cu,0x83A52Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52F BNE -> $83A534
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52F BNE -> $83A534
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA52Fu,0x83A52Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A531 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_83A534;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A531 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_83A534;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA531u,0x83A531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA534u,0x83A534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA537u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A537 BEQ -> $83A543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A543; }
    goto L_83A539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A537 BEQ -> $83A543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A543; }
    goto L_83A539;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA537u,0x83A537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA539u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A539 SEC
    cpu.setFlag('C', true);
    goto L_83A53A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A539 SEC
    cpu.setFlag('C', true);
    goto L_83A53A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA539u,0x83A539u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53A SBC
    cpu.sbc(0x18u);
    goto L_83A53D;
L_83A53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53D BCS -> $83A540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A540; }
    goto L_83A53F;
L_83A53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53F TDC
    cpu.tdc();
    goto L_83A540;
L_83A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A540 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A543;
L_83A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A543 CLC
    cpu.setFlag('C', false);
    goto L_83A544;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A543 CLC
    cpu.setFlag('C', false);
    goto L_83A544;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA543u,0x83A543u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u, 5u + 1u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A544 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x212u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A547;
L_83A547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A547 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A549;
L_83A549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u, 5u + 1u, 3u, cpu.address("absy", 0xD603u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A549 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD603u), cpu.m8?8:16));
    goto L_83A54C;
L_83A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54C STA
    hw.write(cpu.address("absx", 0x212u), cpu.a, cpu.m8?8:16);
    goto L_83A54F;
L_83A54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54F BCC -> $83A55F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A551;
L_83A551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A551 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A554;
L_83A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A554 AND
    cpu.logicAnd(0xFFu);
    goto L_83A557;
L_83A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 5u + 1u, 3u, cpu.address("absy", 0xD611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A557 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD611u), cpu.m8?8:16));
    goto L_83A55A;
L_83A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55A BCS -> $83A55F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A55C;
L_83A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 9u, 3u, cpu.address("absx", 0x0210u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55C INC
    cpu.incMem(hw, cpu.address("absx", 0x210u), cpu.m8?8:16);
    goto L_83A55F;
L_83A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A562;
L_83A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A562 BEQ -> $83A575
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A575; }
    goto L_83A564;
L_83A564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A564 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA566u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA567u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A564u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A567;
L_83A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA567u,0x83A567u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA569u,0x83A569u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Cu,0x83A56Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Eu,0x83A56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA570u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA570u,0x83A570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A573 BEQ -> $83A5C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A575;
L_83A575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A575 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA577u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA578u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A575u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A578;
L_83A578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA578u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA578u,0x83A578u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Au,0x83A57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Du,0x83A57Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_83A581;
L_83A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A581 CMP
    cpu.compareA(0x900u);
    goto L_83A584;
L_83A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A584 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A586;
L_83A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A586 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A589;
L_83A589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA589u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA589u,0x83A589u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Cu,0x83A58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Fu,0x83A58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA591u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA591u,0x83A591u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA593u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA593u,0x83A593u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA596u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA596u,0x83A596u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A597 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A599;
L_83A599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A599 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A59C;
L_83A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59C AND
    cpu.logicAnd(0xFFu);
    goto L_83A59F;
L_83A59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5D9u), cpu.m8?8:16));
    goto L_83A5A2;
L_83A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A5A4;
L_83A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A4 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A5A6;
L_83A5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A6 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A5A8;
L_83A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83A5AB;
L_83A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AB LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5AE;
L_83A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AE CPY
    cpu.compareY(0x6u);
    goto L_83A5B1;
L_83A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B1 BNE -> $83A5C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C0; }
    goto L_83A5B3;
L_83A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5B6;
L_83A5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B6 AND
    cpu.logicAnd(0x300u);
    goto L_83A5B9;
L_83A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B9 BNE -> $83A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5BB;
L_83A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5BB JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0xA5BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x83A5BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A5BE;
L_83A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BEu,0x83A5BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C0;
L_83A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C0 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83A5C3;
L_83A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C3u,0x83A5C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C7;
L_83A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C7 BPL -> $83A5CD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5CD; }
    goto L_83A5C9;
L_83A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C9 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A5CC;
L_83A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CC INC
    cpu.inc('A');
    goto L_83A5CD;
L_83A5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CD CMP
    cpu.compareA(0x400u);
    goto L_83A5D0;
L_83A5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D0 BCC -> $83A5C3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5D2;
L_83A5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D2 CLC
    cpu.setFlag('C', false);
    goto L_83A5D3;
L_83A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D3 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5D5;
L_83A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5D8;
L_83A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D8 ADC
    cpu.adc(0x18u);
    goto L_83A5DB;
L_83A5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5DB JMP -> $83ABF7
    goto L_83ABF7;
L_83ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83ABF9;
L_83ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ABFC;
L_83ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFC BMI -> $83AC05
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AC05; }
    goto L_83ABFE;
L_83ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFE SEC
    cpu.setFlag('C', true);
    goto L_83ABFF;
L_83ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC01;
L_83AC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC01 BCS -> $83AC0E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC03;
L_83AC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC03 BCC -> $83AC0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0A; }
    goto L_83AC05;
L_83AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC05 CLC
    cpu.setFlag('C', false);
    goto L_83AC06;
L_83AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC06 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC08;
L_83AC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC08 BCC -> $83AC0E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC0A;
L_83AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0A STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83AC0D;
L_83AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC0Du);return;} hw.unresolvedReturn(0x83AC0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AC11;
L_83AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC11u);return;} hw.unresolvedReturn(0x83AC11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A50F_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A50Eu: goto L_83A50E;
    case 0x83A50Fu: goto L_83A50F;
    case 0x83A512u: goto L_83A512;
    case 0x83A514u: goto L_83A514;
    case 0x83A517u: goto L_83A517;
    case 0x83A519u: goto L_83A519;
    case 0x83A51Cu: goto L_83A51C;
    case 0x83A51Fu: goto L_83A51F;
    case 0x83A521u: goto L_83A521;
    case 0x83A524u: goto L_83A524;
    case 0x83A526u: goto L_83A526;
    case 0x83A529u: goto L_83A529;
    case 0x83A52Cu: goto L_83A52C;
    case 0x83A52Fu: goto L_83A52F;
    case 0x83A531u: goto L_83A531;
    case 0x83A534u: goto L_83A534;
    case 0x83A537u: goto L_83A537;
    case 0x83A539u: goto L_83A539;
    case 0x83A53Au: goto L_83A53A;
    case 0x83A53Du: goto L_83A53D;
    case 0x83A53Fu: goto L_83A53F;
    case 0x83A540u: goto L_83A540;
    case 0x83A543u: goto L_83A543;
    case 0x83A544u: goto L_83A544;
    case 0x83A547u: goto L_83A547;
    case 0x83A549u: goto L_83A549;
    case 0x83A54Cu: goto L_83A54C;
    case 0x83A54Fu: goto L_83A54F;
    case 0x83A551u: goto L_83A551;
    case 0x83A554u: goto L_83A554;
    case 0x83A557u: goto L_83A557;
    case 0x83A55Au: goto L_83A55A;
    case 0x83A55Cu: goto L_83A55C;
    case 0x83A55Fu: goto L_83A55F;
    case 0x83A562u: goto L_83A562;
    case 0x83A564u: goto L_83A564;
    case 0x83A567u: goto L_83A567;
    case 0x83A569u: goto L_83A569;
    case 0x83A56Cu: goto L_83A56C;
    case 0x83A56Eu: goto L_83A56E;
    case 0x83A570u: goto L_83A570;
    case 0x83A573u: goto L_83A573;
    case 0x83A575u: goto L_83A575;
    case 0x83A578u: goto L_83A578;
    case 0x83A57Au: goto L_83A57A;
    case 0x83A57Du: goto L_83A57D;
    case 0x83A57Eu: goto L_83A57E;
    case 0x83A581u: goto L_83A581;
    case 0x83A584u: goto L_83A584;
    case 0x83A586u: goto L_83A586;
    case 0x83A589u: goto L_83A589;
    case 0x83A58Cu: goto L_83A58C;
    case 0x83A58Fu: goto L_83A58F;
    case 0x83A591u: goto L_83A591;
    case 0x83A593u: goto L_83A593;
    case 0x83A596u: goto L_83A596;
    case 0x83A597u: goto L_83A597;
    case 0x83A599u: goto L_83A599;
    case 0x83A59Cu: goto L_83A59C;
    case 0x83A59Fu: goto L_83A59F;
    case 0x83A5A2u: goto L_83A5A2;
    case 0x83A5A4u: goto L_83A5A4;
    case 0x83A5A6u: goto L_83A5A6;
    case 0x83A5A8u: goto L_83A5A8;
    case 0x83A5ABu: goto L_83A5AB;
    case 0x83A5AEu: goto L_83A5AE;
    case 0x83A5B1u: goto L_83A5B1;
    case 0x83A5B3u: goto L_83A5B3;
    case 0x83A5B6u: goto L_83A5B6;
    case 0x83A5B9u: goto L_83A5B9;
    case 0x83A5BBu: goto L_83A5BB;
    case 0x83A5BEu: goto L_83A5BE;
    case 0x83A5C0u: goto L_83A5C0;
    case 0x83A5C3u: goto L_83A5C3;
    case 0x83A5C4u: goto L_83A5C4;
    case 0x83A5C7u: goto L_83A5C7;
    case 0x83A5C9u: goto L_83A5C9;
    case 0x83A5CCu: goto L_83A5CC;
    case 0x83A5CDu: goto L_83A5CD;
    case 0x83A5D0u: goto L_83A5D0;
    case 0x83A5D2u: goto L_83A5D2;
    case 0x83A5D3u: goto L_83A5D3;
    case 0x83A5D5u: goto L_83A5D5;
    case 0x83A5D8u: goto L_83A5D8;
    case 0x83A5DBu: goto L_83A5DB;
    case 0x83ABF7u: goto L_83ABF7;
    case 0x83ABF9u: goto L_83ABF9;
    case 0x83ABFCu: goto L_83ABFC;
    case 0x83ABFEu: goto L_83ABFE;
    case 0x83ABFFu: goto L_83ABFF;
    case 0x83AC01u: goto L_83AC01;
    case 0x83AC03u: goto L_83AC03;
    case 0x83AC05u: goto L_83AC05;
    case 0x83AC06u: goto L_83AC06;
    case 0x83AC08u: goto L_83AC08;
    case 0x83AC0Au: goto L_83AC0A;
    case 0x83AC0Du: goto L_83AC0D;
    case 0x83AC0Eu: goto L_83AC0E;
    case 0x83AC11u: goto L_83AC11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A50E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A50Eu);return;} hw.unresolvedReturn(0x83A50Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A50E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A50Eu);return;} hw.unresolvedReturn(0x83A50Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA50Eu,0x83A50Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 5u, 3u, cpu.address("abs", 0x1BCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A50F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A512;
L_83A512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A512 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A514;
L_83A514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A514 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_83A517;
L_83A517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A517 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A519;
L_83A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A519 JMP -> $83A5C4
    goto L_83A5C4;
L_83A51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A51F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A51F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA51Cu,0x83A51Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51F BNE -> $83A50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A50E; }
    goto L_83A521;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51F BNE -> $83A50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A50E; }
    goto L_83A521;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA51Fu,0x83A51Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA521u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A521 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A524;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A521 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A524;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA521u,0x83A521u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA524u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A524 BEQ -> $83A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A526;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A524 BEQ -> $83A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A526;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA524u,0x83A524u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA526u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A526 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_83A529;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A526 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_83A529;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA526u,0x83A526u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA529u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A529 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A52C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A529 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A52C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA529u,0x83A529u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52C AND
    cpu.logicAnd(0xFFu);
    goto L_83A52F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52C AND
    cpu.logicAnd(0xFFu);
    goto L_83A52F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA52Cu,0x83A52Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52F BNE -> $83A534
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A531;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52F BNE -> $83A534
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A531;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA52Fu,0x83A52Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A531 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_83A534;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A531 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_83A534;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA531u,0x83A531u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A537;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A537;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA534u,0x83A534u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA537u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A537 BEQ -> $83A543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A543; }
    goto L_83A539;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A537 BEQ -> $83A543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A543; }
    goto L_83A539;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA537u,0x83A537u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA539u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A539 SEC
    cpu.setFlag('C', true);
    goto L_83A53A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A539 SEC
    cpu.setFlag('C', true);
    goto L_83A53A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA539u,0x83A539u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53A SBC
    cpu.sbc(0x18u);
    goto L_83A53D;
L_83A53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53D BCS -> $83A540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A540; }
    goto L_83A53F;
L_83A53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53F TDC
    cpu.tdc();
    goto L_83A540;
L_83A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A540 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A543;
L_83A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A543 CLC
    cpu.setFlag('C', false);
    goto L_83A544;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A543 CLC
    cpu.setFlag('C', false);
    goto L_83A544;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA543u,0x83A543u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u, 5u + 1u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A544 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x212u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A547;
L_83A547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A547 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A549;
L_83A549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u, 5u + 1u, 3u, cpu.address("absy", 0xD603u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A549 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD603u), cpu.m8?8:16));
    goto L_83A54C;
L_83A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54C STA
    hw.write(cpu.address("absx", 0x212u), cpu.a, cpu.m8?8:16);
    goto L_83A54F;
L_83A54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54F BCC -> $83A55F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A551;
L_83A551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A551 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A554;
L_83A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A554 AND
    cpu.logicAnd(0xFFu);
    goto L_83A557;
L_83A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 5u + 1u, 3u, cpu.address("absy", 0xD611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A557 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD611u), cpu.m8?8:16));
    goto L_83A55A;
L_83A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55A BCS -> $83A55F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A55C;
L_83A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 9u, 3u, cpu.address("absx", 0x0210u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55C INC
    cpu.incMem(hw, cpu.address("absx", 0x210u), cpu.m8?8:16);
    goto L_83A55F;
L_83A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A562;
L_83A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A562 BEQ -> $83A575
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A575; }
    goto L_83A564;
L_83A564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A564 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA566u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA567u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A564u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A567;
L_83A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA567u,0x83A567u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA569u,0x83A569u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Cu,0x83A56Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Eu,0x83A56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA570u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA570u,0x83A570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A573 BEQ -> $83A5C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A575;
L_83A575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A575 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA577u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA578u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A575u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A578;
L_83A578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA578u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA578u,0x83A578u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Au,0x83A57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Du,0x83A57Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_83A581;
L_83A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A581 CMP
    cpu.compareA(0x900u);
    goto L_83A584;
L_83A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A584 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A586;
L_83A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A586 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A589;
L_83A589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA589u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA589u,0x83A589u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Cu,0x83A58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Fu,0x83A58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA591u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA591u,0x83A591u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA593u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA593u,0x83A593u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA596u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA596u,0x83A596u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A597 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A599;
L_83A599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A599 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A59C;
L_83A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59C AND
    cpu.logicAnd(0xFFu);
    goto L_83A59F;
L_83A59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5D9u), cpu.m8?8:16));
    goto L_83A5A2;
L_83A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A5A4;
L_83A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A4 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A5A6;
L_83A5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A6 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A5A8;
L_83A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83A5AB;
L_83A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AB LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5AE;
L_83A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AE CPY
    cpu.compareY(0x6u);
    goto L_83A5B1;
L_83A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B1 BNE -> $83A5C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C0; }
    goto L_83A5B3;
L_83A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5B6;
L_83A5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B6 AND
    cpu.logicAnd(0x300u);
    goto L_83A5B9;
L_83A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B9 BNE -> $83A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5BB;
L_83A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5BB JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0xA5BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x83A5BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A5BE;
L_83A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BEu,0x83A5BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C0;
L_83A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C0 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83A5C3;
L_83A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C3u,0x83A5C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C7;
L_83A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C7 BPL -> $83A5CD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5CD; }
    goto L_83A5C9;
L_83A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C9 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A5CC;
L_83A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CC INC
    cpu.inc('A');
    goto L_83A5CD;
L_83A5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CD CMP
    cpu.compareA(0x400u);
    goto L_83A5D0;
L_83A5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D0 BCC -> $83A5C3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5D2;
L_83A5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D2 CLC
    cpu.setFlag('C', false);
    goto L_83A5D3;
L_83A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D3 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5D5;
L_83A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5D8;
L_83A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D8 ADC
    cpu.adc(0x18u);
    goto L_83A5DB;
L_83A5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5DB JMP -> $83ABF7
    goto L_83ABF7;
L_83ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83ABF9;
L_83ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ABFC;
L_83ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFC BMI -> $83AC05
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AC05; }
    goto L_83ABFE;
L_83ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFE SEC
    cpu.setFlag('C', true);
    goto L_83ABFF;
L_83ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC01;
L_83AC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC01 BCS -> $83AC0E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC03;
L_83AC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC03 BCC -> $83AC0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0A; }
    goto L_83AC05;
L_83AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC05 CLC
    cpu.setFlag('C', false);
    goto L_83AC06;
L_83AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC06 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC08;
L_83AC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC08 BCC -> $83AC0E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC0A;
L_83AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0A STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83AC0D;
L_83AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC0Du);return;} hw.unresolvedReturn(0x83AC0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AC11;
L_83AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC11u);return;} hw.unresolvedReturn(0x83AC11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83A50F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83A50Eu: goto L_83A50E;
    case 0x83A50Fu: goto L_83A50F;
    case 0x83A512u: goto L_83A512;
    case 0x83A514u: goto L_83A514;
    case 0x83A517u: goto L_83A517;
    case 0x83A519u: goto L_83A519;
    case 0x83A51Cu: goto L_83A51C;
    case 0x83A51Fu: goto L_83A51F;
    case 0x83A521u: goto L_83A521;
    case 0x83A524u: goto L_83A524;
    case 0x83A526u: goto L_83A526;
    case 0x83A529u: goto L_83A529;
    case 0x83A52Cu: goto L_83A52C;
    case 0x83A52Fu: goto L_83A52F;
    case 0x83A531u: goto L_83A531;
    case 0x83A534u: goto L_83A534;
    case 0x83A537u: goto L_83A537;
    case 0x83A539u: goto L_83A539;
    case 0x83A53Au: goto L_83A53A;
    case 0x83A53Du: goto L_83A53D;
    case 0x83A53Fu: goto L_83A53F;
    case 0x83A540u: goto L_83A540;
    case 0x83A543u: goto L_83A543;
    case 0x83A544u: goto L_83A544;
    case 0x83A547u: goto L_83A547;
    case 0x83A549u: goto L_83A549;
    case 0x83A54Cu: goto L_83A54C;
    case 0x83A54Fu: goto L_83A54F;
    case 0x83A551u: goto L_83A551;
    case 0x83A554u: goto L_83A554;
    case 0x83A557u: goto L_83A557;
    case 0x83A55Au: goto L_83A55A;
    case 0x83A55Cu: goto L_83A55C;
    case 0x83A55Fu: goto L_83A55F;
    case 0x83A562u: goto L_83A562;
    case 0x83A564u: goto L_83A564;
    case 0x83A567u: goto L_83A567;
    case 0x83A569u: goto L_83A569;
    case 0x83A56Cu: goto L_83A56C;
    case 0x83A56Eu: goto L_83A56E;
    case 0x83A570u: goto L_83A570;
    case 0x83A573u: goto L_83A573;
    case 0x83A575u: goto L_83A575;
    case 0x83A578u: goto L_83A578;
    case 0x83A57Au: goto L_83A57A;
    case 0x83A57Du: goto L_83A57D;
    case 0x83A57Eu: goto L_83A57E;
    case 0x83A581u: goto L_83A581;
    case 0x83A584u: goto L_83A584;
    case 0x83A586u: goto L_83A586;
    case 0x83A589u: goto L_83A589;
    case 0x83A58Cu: goto L_83A58C;
    case 0x83A58Fu: goto L_83A58F;
    case 0x83A591u: goto L_83A591;
    case 0x83A593u: goto L_83A593;
    case 0x83A596u: goto L_83A596;
    case 0x83A597u: goto L_83A597;
    case 0x83A599u: goto L_83A599;
    case 0x83A59Cu: goto L_83A59C;
    case 0x83A59Fu: goto L_83A59F;
    case 0x83A5A2u: goto L_83A5A2;
    case 0x83A5A4u: goto L_83A5A4;
    case 0x83A5A6u: goto L_83A5A6;
    case 0x83A5A8u: goto L_83A5A8;
    case 0x83A5ABu: goto L_83A5AB;
    case 0x83A5AEu: goto L_83A5AE;
    case 0x83A5B1u: goto L_83A5B1;
    case 0x83A5B3u: goto L_83A5B3;
    case 0x83A5B6u: goto L_83A5B6;
    case 0x83A5B9u: goto L_83A5B9;
    case 0x83A5BBu: goto L_83A5BB;
    case 0x83A5BEu: goto L_83A5BE;
    case 0x83A5C0u: goto L_83A5C0;
    case 0x83A5C3u: goto L_83A5C3;
    case 0x83A5C4u: goto L_83A5C4;
    case 0x83A5C7u: goto L_83A5C7;
    case 0x83A5C9u: goto L_83A5C9;
    case 0x83A5CCu: goto L_83A5CC;
    case 0x83A5CDu: goto L_83A5CD;
    case 0x83A5D0u: goto L_83A5D0;
    case 0x83A5D2u: goto L_83A5D2;
    case 0x83A5D3u: goto L_83A5D3;
    case 0x83A5D5u: goto L_83A5D5;
    case 0x83A5D8u: goto L_83A5D8;
    case 0x83A5DBu: goto L_83A5DB;
    case 0x83ABF7u: goto L_83ABF7;
    case 0x83ABF9u: goto L_83ABF9;
    case 0x83ABFCu: goto L_83ABFC;
    case 0x83ABFEu: goto L_83ABFE;
    case 0x83ABFFu: goto L_83ABFF;
    case 0x83AC01u: goto L_83AC01;
    case 0x83AC03u: goto L_83AC03;
    case 0x83AC05u: goto L_83AC05;
    case 0x83AC06u: goto L_83AC06;
    case 0x83AC08u: goto L_83AC08;
    case 0x83AC0Au: goto L_83AC0A;
    case 0x83AC0Du: goto L_83AC0D;
    case 0x83AC0Eu: goto L_83AC0E;
    case 0x83AC11u: goto L_83AC11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83A50E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A50E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A50Eu);return;} hw.unresolvedReturn(0x83A50Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83A50F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA50Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA50Fu, 5u, 3u, cpu.address("abs", 0x1BCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A50F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A512;
L_83A512:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA512u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA512u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A512 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A514;
L_83A514:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA514u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA514u, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A514 CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_83A517;
L_83A517:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA517u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA517u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A517 BEQ -> $83A51C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A51C; }
    goto L_83A519;
L_83A519:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA519u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA519u, 3u, 3u, cpu.address("abs", 0xA5C4u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A519 JMP -> $83A5C4
    goto L_83A5C4;
L_83A51C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Cu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A51F;
L_83A51F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA51Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA51Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A51F BNE -> $83A50E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A50E; }
    goto L_83A521;
L_83A521:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA521u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA521u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A521 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A524;
L_83A524:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA524u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA524u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A524 BEQ -> $83A534
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A526;
L_83A526:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA526u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA526u, 9u, 3u, cpu.address("absx", 0x10C0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A526 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10C0u), cpu.m8?8:16);
    goto L_83A529;
L_83A529:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA529u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA529u, 5u + 1u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A529 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A52C;
L_83A52C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52C AND
    cpu.logicAnd(0xFFu);
    goto L_83A52F;
L_83A52F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA52Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA52Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A52F BNE -> $83A534
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A534; }
    goto L_83A531;
L_83A531:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA531u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA531u, 6u, 3u, cpu.address("absx", 0x10C0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A531 STA
    hw.write(cpu.address("absx", 0x10C0u), cpu.a, cpu.m8?8:16);
    goto L_83A534;
L_83A534:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA534u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA534u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A534 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A537;
L_83A537:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA537u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA537u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A537 BEQ -> $83A543
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A543; }
    goto L_83A539;
L_83A539:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA539u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA539u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A539 SEC
    cpu.setFlag('C', true);
    goto L_83A53A;
L_83A53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53A SBC
    cpu.sbc(0x18u);
    goto L_83A53D;
L_83A53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53D BCS -> $83A540
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A540; }
    goto L_83A53F;
L_83A53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA53Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A53F TDC
    cpu.tdc();
    goto L_83A540;
L_83A540:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA540u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA540u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A540 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A543;
L_83A543:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA543u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA543u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A543 CLC
    cpu.setFlag('C', false);
    goto L_83A544;
L_83A544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA544u, 5u + 1u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A544 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x212u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A547;
L_83A547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA547u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A547 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A549;
L_83A549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA549u, 5u + 1u, 3u, cpu.address("absy", 0xD603u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A549 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD603u), cpu.m8?8:16));
    goto L_83A54C;
L_83A54C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Cu, 6u, 3u, cpu.address("absx", 0x0212u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54C STA
    hw.write(cpu.address("absx", 0x212u), cpu.a, cpu.m8?8:16);
    goto L_83A54F;
L_83A54F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA54Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA54Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A54F BCC -> $83A55F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A551;
L_83A551:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA551u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA551u, 5u + 1u, 3u, cpu.address("absx", 0x0210u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A551 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A554;
L_83A554:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA554u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA554u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A554 AND
    cpu.logicAnd(0xFFu);
    goto L_83A557;
L_83A557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u,cpu,0xD9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA557u, 5u + 1u, 3u, cpu.address("absy", 0xD611u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A557 CMP
    cpu.compareA(hw.readW(cpu.address("absy", 0xD611u), cpu.m8?8:16));
    goto L_83A55A;
L_83A55A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55A BCS -> $83A55F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A55F; }
    goto L_83A55C;
L_83A55C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu,cpu,0xFEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Cu, 9u, 3u, cpu.address("absx", 0x0210u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55C INC
    cpu.incMem(hw, cpu.address("absx", 0x210u), cpu.m8?8:16);
    goto L_83A55F;
L_83A55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA55Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA55Fu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A55F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A562;
L_83A562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA562u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A562 BEQ -> $83A575
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A575; }
    goto L_83A564;
L_83A564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA564u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A564 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA566u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA567u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A564u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A567;
L_83A567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA567u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA567u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A567 BCC -> $83A57A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A57A; }
    goto L_83A569;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA567u,0x83A567u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA569u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA569u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A569 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A56C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA569u,0x83A569u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56C BPL -> $83A5C3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A56E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Cu,0x83A56Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA56Eu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA56Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A56E LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A570;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA56Eu,0x83A56Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA570u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA570u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A570 CPY
    cpu.compareY(0x8u);
    goto L_83A573;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA570u,0x83A570u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA573u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A573 BEQ -> $83A5C3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A575;
L_83A575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA575u, 6u, 3u, cpu.address("abs", 0xA5DEu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A575 JSR -> $83A5DE stack real
    { cpu.push16Value(hw,0xA577u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA578u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xA5DEu), 0x83A575u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A578;
L_83A578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA578u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA578u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A578 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A57A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA578u,0x83A578u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Au))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57A LDA
    cpu.setA(0x90u, 16);
    goto L_83A57D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Au,0x83A57Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57D CLC
    cpu.setFlag('C', false);
    goto L_83A57E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA57Du,0x83A57Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A57E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA57Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA57Eu, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A57E ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16));
    goto L_83A581;
L_83A581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA581u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A581 CMP
    cpu.compareA(0x900u);
    goto L_83A584;
L_83A584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA584u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A584 BCS -> $83A589
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A589; }
    goto L_83A586;
L_83A586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA586u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A586 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83A589;
L_83A589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA589u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA589u, 5u + 1u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A589 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x222u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A58C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA589u,0x83A589u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Cu, 5u + 1u, 3u, cpu.address("absy", 0xD848u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD848u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A58F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Cu,0x83A58Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA58Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA58Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A58F STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A591;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA58Fu,0x83A58Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA591u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA591u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A591 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A593;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA591u,0x83A591u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA593u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA593u, 5u + 1u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A593 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10AAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A596;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA593u,0x83A593u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA596u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A596 LSR
    cpu.lsrA();
    goto L_83A597;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA596u,0x83A596u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA597u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A597 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83A599;
L_83A599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA599u, 5u + 1u, 3u, cpu.address("absx", 0x109Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A599 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x109Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A59C;
L_83A59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59C AND
    cpu.logicAnd(0xFFu);
    goto L_83A59F;
L_83A59F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA59Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA59Fu, 5u + 1u, 3u, cpu.address("absy", 0xD5D9u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A59F ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xD5D9u), cpu.m8?8:16));
    goto L_83A5A2;
L_83A5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A2 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83A5A4;
L_83A5A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A4 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83A5A6;
L_83A5A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A6 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83A5A8;
L_83A5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5A8u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5A8 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16));
    goto L_83A5AB;
L_83A5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5ABu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AB LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5AE;
L_83A5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5AE CPY
    cpu.compareY(0x6u);
    goto L_83A5B1;
L_83A5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B1 BNE -> $83A5C0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C0; }
    goto L_83A5B3;
L_83A5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B3u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5B6;
L_83A5B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B6 AND
    cpu.logicAnd(0x300u);
    goto L_83A5B9;
L_83A5B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5B9 BNE -> $83A5C3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5BB;
L_83A5BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BBu, 6u, 3u, cpu.address("abs", 0xB2E5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5BB JSR -> $83B2E5 stack real
    { cpu.push16Value(hw,0xA5BDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA5BEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB2E5u), 0x83A5BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83A5BE;
L_83A5BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5BEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5BEu,0x83A5BEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5BEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5BE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C0;
L_83A5C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C0u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C0 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83A5C3;
L_83A5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C3u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83A5C3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83A5C3u);return;} hw.unresolvedReturn(0x83A5C3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA5C3u,0x83A5C3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83A5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C4u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5C7;
L_83A5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C7 BPL -> $83A5CD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83A5CD; }
    goto L_83A5C9;
L_83A5C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5C9 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83A5CC;
L_83A5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CC INC
    cpu.inc('A');
    goto L_83A5CD;
L_83A5CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5CD CMP
    cpu.compareA(0x400u);
    goto L_83A5D0;
L_83A5D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D0 BCC -> $83A5C3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83A5C3; }
    goto L_83A5D2;
L_83A5D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D2 CLC
    cpu.setFlag('C', false);
    goto L_83A5D3;
L_83A5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D3 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83A5D5;
L_83A5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D5u, 5u + 1u, 3u, cpu.address("absy", 0xD5E7u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD5E7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83A5D8;
L_83A5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5D8 ADC
    cpu.adc(0x18u);
    goto L_83A5DB;
L_83A5DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA5DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA5DBu, 3u, 3u, cpu.address("abs", 0xABF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83A5DB JMP -> $83ABF7
    goto L_83ABF7;
L_83ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83ABF9;
L_83ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ABFC;
L_83ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFC BMI -> $83AC05
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AC05; }
    goto L_83ABFE;
L_83ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFE SEC
    cpu.setFlag('C', true);
    goto L_83ABFF;
L_83ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC01;
L_83AC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC01 BCS -> $83AC0E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC03;
L_83AC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC03 BCC -> $83AC0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0A; }
    goto L_83AC05;
L_83AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC05 CLC
    cpu.setFlag('C', false);
    goto L_83AC06;
L_83AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC06 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC08;
L_83AC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC08 BCC -> $83AC0E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC0A;
L_83AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0A STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83AC0D;
L_83AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC0Du);return;} hw.unresolvedReturn(0x83AC0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AC11;
L_83AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC11u);return;} hw.unresolvedReturn(0x83AC11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83F094_E0M0X0C1_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F10Cu: goto L_83F10C;
    case 0x83F10Fu: goto L_83F10F;
    case 0x83F112u: goto L_83F112;
    case 0x83F113u: goto L_83F113;
    case 0x83F115u: goto L_83F115;
    case 0x83F118u: goto L_83F118;
    case 0x83F11Bu: goto L_83F11B;
    case 0x83F11Eu: goto L_83F11E;
    case 0x83F120u: goto L_83F120;
    case 0x83F122u: goto L_83F122;
    case 0x83F125u: goto L_83F125;
    case 0x83F127u: goto L_83F127;
    case 0x83F129u: goto L_83F129;
    case 0x83F12Cu: goto L_83F12C;
    case 0x83F12Eu: goto L_83F12E;
    case 0x83F131u: goto L_83F131;
    case 0x83F134u: goto L_83F134;
    case 0x83F136u: goto L_83F136;
    case 0x83F137u: goto L_83F137;
    case 0x83F13Au: goto L_83F13A;
    case 0x83F13Du: goto L_83F13D;
    case 0x83F140u: goto L_83F140;
    case 0x83F142u: goto L_83F142;
    case 0x83F144u: goto L_83F144;
    case 0x83F146u: goto L_83F146;
    case 0x83F148u: goto L_83F148;
    case 0x83F149u: goto L_83F149;
    case 0x83F14Cu: goto L_83F14C;
    case 0x83F14Eu: goto L_83F14E;
    case 0x83F14Fu: goto L_83F14F;
    case 0x83F151u: goto L_83F151;
    case 0x83F153u: goto L_83F153;
    case 0x83F155u: goto L_83F155;
    case 0x83F158u: goto L_83F158;
    case 0x83F15Au: goto L_83F15A;
    case 0x83F15Du: goto L_83F15D;
    case 0x83F15Eu: goto L_83F15E;
    case 0x83F161u: goto L_83F161;
    case 0x83F163u: goto L_83F163;
    case 0x83F165u: goto L_83F165;
    case 0x83F168u: goto L_83F168;
    case 0x83F16Au: goto L_83F16A;
    case 0x83F16Eu: goto L_83F16E;
    case 0x83F171u: goto L_83F171;
    case 0x83F173u: goto L_83F173;
    case 0x83F175u: goto L_83F175;
    case 0x83F177u: goto L_83F177;
    case 0x83F179u: goto L_83F179;
    case 0x83F17Au: goto L_83F17A;
    case 0x83F17Bu: goto L_83F17B;
    case 0x83F17Du: goto L_83F17D;
    case 0x83F17Fu: goto L_83F17F;
    case 0x83F180u: goto L_83F180;
    case 0x83F182u: goto L_83F182;
    case 0x83F184u: goto L_83F184;
    case 0x83F187u: goto L_83F187;
    case 0x83F189u: goto L_83F189;
    case 0x83F18Au: goto L_83F18A;
    case 0x83F18Cu: goto L_83F18C;
    case 0x83F18Fu: goto L_83F18F;
    case 0x83F191u: goto L_83F191;
    case 0x83F192u: goto L_83F192;
    case 0x83F194u: goto L_83F194;
    case 0x83F196u: goto L_83F196;
    case 0x83F197u: goto L_83F197;
    case 0x83F198u: goto L_83F198;
    case 0x83F19Au: goto L_83F19A;
    case 0x83F19Cu: goto L_83F19C;
    case 0x83F19Du: goto L_83F19D;
    case 0x83F19Fu: goto L_83F19F;
    case 0x83F1A1u: goto L_83F1A1;
    case 0x83F1A4u: goto L_83F1A4;
    case 0x83F1A6u: goto L_83F1A6;
    case 0x83F1A7u: goto L_83F1A7;
    case 0x83F1A9u: goto L_83F1A9;
    case 0x83F1ACu: goto L_83F1AC;
    case 0x83F1AEu: goto L_83F1AE;
    case 0x83F1AFu: goto L_83F1AF;
    case 0x83F1B0u: goto L_83F1B0;
    case 0x83F1B2u: goto L_83F1B2;
    case 0x83F1B3u: goto L_83F1B3;
    case 0x83F1B6u: goto L_83F1B6;
    case 0x83F1B7u: goto L_83F1B7;
    case 0x83F1B9u: goto L_83F1B9;
    case 0x83F1BBu: goto L_83F1BB;
    case 0x83F1BDu: goto L_83F1BD;
    case 0x83F1BEu: goto L_83F1BE;
    case 0x83F1C1u: goto L_83F1C1;
    case 0x83F1C3u: goto L_83F1C3;
    case 0x83F1C4u: goto L_83F1C4;
    case 0x83F1C6u: goto L_83F1C6;
    case 0x83F1C8u: goto L_83F1C8;
    case 0x83F1CAu: goto L_83F1CA;
    case 0x83F1CDu: goto L_83F1CD;
    case 0x83F1CFu: goto L_83F1CF;
    case 0x83F1D2u: goto L_83F1D2;
    case 0x83F1D3u: goto L_83F1D3;
    case 0x83F1D6u: goto L_83F1D6;
    case 0x83F1D8u: goto L_83F1D8;
    case 0x83F1DAu: goto L_83F1DA;
    case 0x83F1DDu: goto L_83F1DD;
    case 0x83F1DFu: goto L_83F1DF;
    case 0x83F1E3u: goto L_83F1E3;
    case 0x83F1E6u: goto L_83F1E6;
    case 0x83F1E8u: goto L_83F1E8;
    case 0x83F1EAu: goto L_83F1EA;
    case 0x83F1ECu: goto L_83F1EC;
    case 0x83F1EEu: goto L_83F1EE;
    case 0x83F1EFu: goto L_83F1EF;
    case 0x83F1F0u: goto L_83F1F0;
    case 0x83F1F2u: goto L_83F1F2;
    case 0x83F1F4u: goto L_83F1F4;
    case 0x83F1F5u: goto L_83F1F5;
    case 0x83F1F7u: goto L_83F1F7;
    case 0x83F1F9u: goto L_83F1F9;
    case 0x83F1FCu: goto L_83F1FC;
    case 0x83F1FEu: goto L_83F1FE;
    case 0x83F1FFu: goto L_83F1FF;
    case 0x83F201u: goto L_83F201;
    case 0x83F204u: goto L_83F204;
    case 0x83F206u: goto L_83F206;
    case 0x83F207u: goto L_83F207;
    case 0x83F209u: goto L_83F209;
    case 0x83F20Bu: goto L_83F20B;
    case 0x83F20Cu: goto L_83F20C;
    case 0x83F20Du: goto L_83F20D;
    case 0x83F20Fu: goto L_83F20F;
    case 0x83F211u: goto L_83F211;
    case 0x83F212u: goto L_83F212;
    case 0x83F214u: goto L_83F214;
    case 0x83F216u: goto L_83F216;
    case 0x83F219u: goto L_83F219;
    case 0x83F21Bu: goto L_83F21B;
    case 0x83F21Cu: goto L_83F21C;
    case 0x83F21Eu: goto L_83F21E;
    case 0x83F221u: goto L_83F221;
    case 0x83F223u: goto L_83F223;
    case 0x83F224u: goto L_83F224;
    case 0x83F226u: goto L_83F226;
    case 0x83F228u: goto L_83F228;
    case 0x83F229u: goto L_83F229;
    case 0x83F22Cu: goto L_83F22C;
    case 0x83F22Eu: goto L_83F22E;
    case 0x83F22Fu: goto L_83F22F;
    case 0x83F231u: goto L_83F231;
    case 0x83F233u: goto L_83F233;
    case 0x83F235u: goto L_83F235;
    case 0x83F238u: goto L_83F238;
    case 0x83F23Au: goto L_83F23A;
    case 0x83F23Du: goto L_83F23D;
    case 0x83F23Eu: goto L_83F23E;
    case 0x83F241u: goto L_83F241;
    case 0x83F243u: goto L_83F243;
    case 0x83F245u: goto L_83F245;
    case 0x83F248u: goto L_83F248;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu, 3u, 3u, cpu.address("abs", 0xF406u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F10C JMP -> $83F406
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF406u),0x83F10Cu); return;
L_83F10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F10F STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83F112;
L_83F112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF112u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF112u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F112 ASL
    cpu.aslA();
    goto L_83F113;
L_83F113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF113u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF113u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F113 BPL -> $83F118
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F118; }
    goto L_83F115;
L_83F115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF115u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF115u, 3u, 3u, cpu.address("abs", 0xF28Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F115 JMP -> $83F28F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF28Fu),0x83F115u); return;
L_83F118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF118u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF118u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F118 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F11B;
L_83F11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F11B SBC
    cpu.sbc(0x380u);
    goto L_83F11E;
L_83F11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F11E BPL -> $83F134
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F120;
L_83F120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F120 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F122;
L_83F122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F122 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F125;
L_83F125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F125 BNE -> $83F134
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F127;
L_83F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F127 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F129;
L_83F129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F129 CMP
    cpu.compareA(0x8u);
    goto L_83F12C;
L_83F12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F12C BCC -> $83F134
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F12E;
L_83F12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F12E LDA
    cpu.setA(0x600u, 16);
    goto L_83F131;
L_83F131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F131 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F134;
L_83F134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F134 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F136;
L_83F136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F136 SEC
    cpu.setFlag('C', true);
    goto L_83F137;
L_83F137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F137 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16));
    goto L_83F13A;
L_83F13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F13A ADC
    cpu.adc(0x8u);
    goto L_83F13D;
L_83F13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F13D CMP
    cpu.compareA(0x10u);
    goto L_83F140;
L_83F140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F140 BCS -> $83F1AF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1AF; }
    goto L_83F142;
L_83F142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F142 SEP
    cpu.sep(0x20u);
    goto L_83F144;
L_83F144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F144 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F146;
L_83F146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F146 AND
    cpu.logicAnd(0xF0u);
    goto L_83F148;
L_83F148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F148 SEC
    cpu.setFlag('C', true);
    goto L_83F149;
L_83F149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF149u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF149u, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F149 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F14C;
L_83F14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14C BEQ -> $83F15E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F15E; }
    goto L_83F14E;
L_83F14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14E ASL
    cpu.aslA();
    goto L_83F14F;
L_83F14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14F LDA
    cpu.setA(0x82u, 8);
    goto L_83F151;
L_83F151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF151u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF151u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F151 BCC -> $83F155
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F155; }
    goto L_83F153;
L_83F153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F153 LDA
    cpu.setA(0x81u, 8);
    goto L_83F155;
L_83F155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F155 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F158;
L_83F158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F158 REP
    cpu.rep(0x20u);
    goto L_83F15A;
L_83F15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F15A JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF15Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF15Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F15Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F15D;
L_83F15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F15D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F15Du);return;} hw.unresolvedReturn(0x83F15Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F15D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F15Du);return;} hw.unresolvedReturn(0x83F15Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF15Du,0x83F15Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F15E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F161;
L_83F161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F161 BEQ -> $83F158
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F158; }
    goto L_83F163;
L_83F163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F163 REP
    cpu.rep(0x20u);
    goto L_83F165;
L_83F165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F165 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F168;
L_83F168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F168 BNE -> $83F18F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F18F; }
    goto L_83F16A;
L_83F16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Au, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F16A JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF16Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF16Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F16Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F16E;
L_83F16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF16Eu,0x83F16Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Eu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F16E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F171;
L_83F171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F171 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F173;
L_83F173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F173 BMI -> $83F192
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F192; }
    goto L_83F175;
L_83F175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F175 SEP
    cpu.sep(0x20u);
    goto L_83F177;
L_83F177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F177 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F179;
L_83F179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F179 TAY
    cpu.transfer("TAY");
    goto L_83F17A;
L_83F17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17A SEC
    cpu.setFlag('C', true);
    goto L_83F17B;
L_83F17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17B SBC
    cpu.sbc(0x20u);
    goto L_83F17D;
L_83F17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17D CMP
    cpu.compareA(0x80u);
    goto L_83F17F;
L_83F17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17F TYA
    cpu.transfer("TYA");
    goto L_83F180;
L_83F180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F180 BCS -> $83F18A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F18A; }
    goto L_83F182;
L_83F182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F182 SBC
    cpu.sbc(0x3Fu);
    goto L_83F184;
L_83F184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F184 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F187;
L_83F187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F187 REP
    cpu.rep(0x20u);
    goto L_83F189;
L_83F189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F189 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F189u);return;} hw.unresolvedReturn(0x83F189u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18A ADC
    cpu.adc(0x3Fu);
    goto L_83F18C;
L_83F18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F18F;
L_83F18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18F REP
    cpu.rep(0x20u);
    goto L_83F191;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18F REP
    cpu.rep(0x20u);
    goto L_83F191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF18Fu,0x83F18Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F191 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F191u);return;} hw.unresolvedReturn(0x83F191u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F192 SEP
    cpu.sep(0x20u);
    goto L_83F194;
L_83F194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF194u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F194 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F196;
L_83F196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF196u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF196u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F196 TAY
    cpu.transfer("TAY");
    goto L_83F197;
L_83F197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F197 SEC
    cpu.setFlag('C', true);
    goto L_83F198;
L_83F198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF198u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF198u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F198 SBC
    cpu.sbc(0x20u);
    goto L_83F19A;
L_83F19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19A CMP
    cpu.compareA(0x80u);
    goto L_83F19C;
L_83F19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19C TYA
    cpu.transfer("TYA");
    goto L_83F19D;
L_83F19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19D BCS -> $83F1A7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1A7; }
    goto L_83F19F;
L_83F19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19F ADC
    cpu.adc(0x40u);
    goto L_83F1A1;
L_83F1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A1 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1A4;
L_83F1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A4 REP
    cpu.rep(0x20u);
    goto L_83F1A6;
L_83F1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1A6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1A6u);return;} hw.unresolvedReturn(0x83F1A6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A7 SBC
    cpu.sbc(0x40u);
    goto L_83F1A9;
L_83F1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A9u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A9 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1AC;
L_83F1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1AC REP
    cpu.rep(0x20u);
    goto L_83F1AE;
L_83F1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1AE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1AEu);return;} hw.unresolvedReturn(0x83F1AEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1AF ASL
    cpu.aslA();
    goto L_83F1B0;
L_83F1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B0 SEP
    cpu.sep(0x20u);
    goto L_83F1B2;
L_83F1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B2 ROL
    cpu.rolA();
    goto L_83F1B3;
L_83F1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B3 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F1B6;
L_83F1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B6 LSR
    cpu.lsrA();
    goto L_83F1B7;
L_83F1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B7 BCC -> $83F224
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F224; }
    goto L_83F1B9;
L_83F1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1BB;
L_83F1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BB AND
    cpu.logicAnd(0xF0u);
    goto L_83F1BD;
L_83F1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BD SEC
    cpu.setFlag('C', true);
    goto L_83F1BE;
L_83F1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BEu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F1C1;
L_83F1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C1 BEQ -> $83F1D3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F1D3; }
    goto L_83F1C3;
L_83F1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C3 ASL
    cpu.aslA();
    goto L_83F1C4;
L_83F1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C4 LDA
    cpu.setA(0x82u, 8);
    goto L_83F1C6;
L_83F1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C6 BCC -> $83F1CA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1CA; }
    goto L_83F1C8;
L_83F1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C8 LDA
    cpu.setA(0x81u, 8);
    goto L_83F1CA;
L_83F1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1CA STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F1CD;
L_83F1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1CD REP
    cpu.rep(0x20u);
    goto L_83F1CF;
L_83F1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F1CF JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF1D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F1CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F1D2;
L_83F1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1D2u);return;} hw.unresolvedReturn(0x83F1D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1D2u);return;} hw.unresolvedReturn(0x83F1D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1D2u,0x83F1D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D3u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1D6;
L_83F1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D6 BEQ -> $83F1CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F1CD; }
    goto L_83F1D8;
L_83F1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D8 REP
    cpu.rep(0x20u);
    goto L_83F1DA;
L_83F1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1DD;
L_83F1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1DD BNE -> $83F204
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F204; }
    goto L_83F1DF;
L_83F1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1DF JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF1E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1E3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F1DFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F1E3;
L_83F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1E3u,0x83F1E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1E6;
L_83F1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E6u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E6 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F1E8;
L_83F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E8 BMI -> $83F207
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F207; }
    goto L_83F1EA;
L_83F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EA SEP
    cpu.sep(0x20u);
    goto L_83F1EC;
L_83F1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1EE;
L_83F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EE TAY
    cpu.transfer("TAY");
    goto L_83F1EF;
L_83F1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EF SEC
    cpu.setFlag('C', true);
    goto L_83F1F0;
L_83F1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F0 SBC
    cpu.sbc(0x20u);
    goto L_83F1F2;
L_83F1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F2 CMP
    cpu.compareA(0x80u);
    goto L_83F1F4;
L_83F1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F4 TYA
    cpu.transfer("TYA");
    goto L_83F1F5;
L_83F1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F5 BCS -> $83F1FF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1FF; }
    goto L_83F1F7;
L_83F1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F7 SBC
    cpu.sbc(0x3Fu);
    goto L_83F1F9;
L_83F1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F9 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1FC;
L_83F1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1FC REP
    cpu.rep(0x20u);
    goto L_83F1FE;
L_83F1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1FEu);return;} hw.unresolvedReturn(0x83F1FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1FF ADC
    cpu.adc(0x3Fu);
    goto L_83F201;
L_83F201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F201 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F204;
L_83F204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF204u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F204 REP
    cpu.rep(0x20u);
    goto L_83F206;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F204 REP
    cpu.rep(0x20u);
    goto L_83F206;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF204u,0x83F204u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F206 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F206u);return;} hw.unresolvedReturn(0x83F206u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F207 SEP
    cpu.sep(0x20u);
    goto L_83F209;
L_83F209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F209 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F20B;
L_83F20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20B TAY
    cpu.transfer("TAY");
    goto L_83F20C;
L_83F20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20C SEC
    cpu.setFlag('C', true);
    goto L_83F20D;
L_83F20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20D SBC
    cpu.sbc(0x20u);
    goto L_83F20F;
L_83F20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20F CMP
    cpu.compareA(0x80u);
    goto L_83F211;
L_83F211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF211u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF211u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F211 TYA
    cpu.transfer("TYA");
    goto L_83F212;
L_83F212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F212 BCS -> $83F21C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F21C; }
    goto L_83F214;
L_83F214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF214u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF214u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F214 ADC
    cpu.adc(0x40u);
    goto L_83F216;
L_83F216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF216u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF216u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F216 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F219;
L_83F219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF219u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF219u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F219 REP
    cpu.rep(0x20u);
    goto L_83F21B;
L_83F21B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F21B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F21Bu);return;} hw.unresolvedReturn(0x83F21Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F21C SBC
    cpu.sbc(0x40u);
    goto L_83F21E;
L_83F21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F21E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F221;
L_83F221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF221u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF221u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F221 REP
    cpu.rep(0x20u);
    goto L_83F223;
L_83F223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF223u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF223u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F223 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F223u);return;} hw.unresolvedReturn(0x83F223u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F224 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F226;
L_83F226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F226 AND
    cpu.logicAnd(0xF0u);
    goto L_83F228;
L_83F228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF228u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F228 SEC
    cpu.setFlag('C', true);
    goto L_83F229;
L_83F229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F229 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83F22C;
L_83F22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22C BEQ -> $83F23E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F23E; }
    goto L_83F22E;
L_83F22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22E ASL
    cpu.aslA();
    goto L_83F22F;
L_83F22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22F LDA
    cpu.setA(0x82u, 8);
    goto L_83F231;
L_83F231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF231u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F231 BCC -> $83F235
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F235; }
    goto L_83F233;
L_83F233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF233u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF233u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F233 LDA
    cpu.setA(0x81u, 8);
    goto L_83F235;
L_83F235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF235u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF235u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F235 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F238;
L_83F238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F238 REP
    cpu.rep(0x20u);
    goto L_83F23A;
L_83F23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Au, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F23A JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF23Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF23Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F23Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F23D;
L_83F23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F23D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F23Du);return;} hw.unresolvedReturn(0x83F23Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F23D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F23Du);return;} hw.unresolvedReturn(0x83F23Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF23Du,0x83F23Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F23E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F241;
L_83F241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F241 BEQ -> $83F238
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F238; }
    goto L_83F243;
L_83F243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F243 REP
    cpu.rep(0x20u);
    goto L_83F245;
L_83F245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF245u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF245u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F245 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F248;
L_83F248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F248 BNE -> $83F26F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F26Fu,0x83F248u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF24Au,0x83F248u); return;
}

void sub_83F094_E0M0X0CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F10Cu: goto L_83F10C;
    case 0x83F10Fu: goto L_83F10F;
    case 0x83F112u: goto L_83F112;
    case 0x83F113u: goto L_83F113;
    case 0x83F115u: goto L_83F115;
    case 0x83F118u: goto L_83F118;
    case 0x83F11Bu: goto L_83F11B;
    case 0x83F11Eu: goto L_83F11E;
    case 0x83F120u: goto L_83F120;
    case 0x83F122u: goto L_83F122;
    case 0x83F125u: goto L_83F125;
    case 0x83F127u: goto L_83F127;
    case 0x83F129u: goto L_83F129;
    case 0x83F12Cu: goto L_83F12C;
    case 0x83F12Eu: goto L_83F12E;
    case 0x83F131u: goto L_83F131;
    case 0x83F134u: goto L_83F134;
    case 0x83F136u: goto L_83F136;
    case 0x83F137u: goto L_83F137;
    case 0x83F13Au: goto L_83F13A;
    case 0x83F13Du: goto L_83F13D;
    case 0x83F140u: goto L_83F140;
    case 0x83F142u: goto L_83F142;
    case 0x83F144u: goto L_83F144;
    case 0x83F146u: goto L_83F146;
    case 0x83F148u: goto L_83F148;
    case 0x83F149u: goto L_83F149;
    case 0x83F14Cu: goto L_83F14C;
    case 0x83F14Eu: goto L_83F14E;
    case 0x83F14Fu: goto L_83F14F;
    case 0x83F151u: goto L_83F151;
    case 0x83F153u: goto L_83F153;
    case 0x83F155u: goto L_83F155;
    case 0x83F158u: goto L_83F158;
    case 0x83F15Au: goto L_83F15A;
    case 0x83F15Du: goto L_83F15D;
    case 0x83F15Eu: goto L_83F15E;
    case 0x83F161u: goto L_83F161;
    case 0x83F163u: goto L_83F163;
    case 0x83F165u: goto L_83F165;
    case 0x83F168u: goto L_83F168;
    case 0x83F16Au: goto L_83F16A;
    case 0x83F16Eu: goto L_83F16E;
    case 0x83F171u: goto L_83F171;
    case 0x83F173u: goto L_83F173;
    case 0x83F175u: goto L_83F175;
    case 0x83F177u: goto L_83F177;
    case 0x83F179u: goto L_83F179;
    case 0x83F17Au: goto L_83F17A;
    case 0x83F17Bu: goto L_83F17B;
    case 0x83F17Du: goto L_83F17D;
    case 0x83F17Fu: goto L_83F17F;
    case 0x83F180u: goto L_83F180;
    case 0x83F182u: goto L_83F182;
    case 0x83F184u: goto L_83F184;
    case 0x83F187u: goto L_83F187;
    case 0x83F189u: goto L_83F189;
    case 0x83F18Au: goto L_83F18A;
    case 0x83F18Cu: goto L_83F18C;
    case 0x83F18Fu: goto L_83F18F;
    case 0x83F191u: goto L_83F191;
    case 0x83F192u: goto L_83F192;
    case 0x83F194u: goto L_83F194;
    case 0x83F196u: goto L_83F196;
    case 0x83F197u: goto L_83F197;
    case 0x83F198u: goto L_83F198;
    case 0x83F19Au: goto L_83F19A;
    case 0x83F19Cu: goto L_83F19C;
    case 0x83F19Du: goto L_83F19D;
    case 0x83F19Fu: goto L_83F19F;
    case 0x83F1A1u: goto L_83F1A1;
    case 0x83F1A4u: goto L_83F1A4;
    case 0x83F1A6u: goto L_83F1A6;
    case 0x83F1A7u: goto L_83F1A7;
    case 0x83F1A9u: goto L_83F1A9;
    case 0x83F1ACu: goto L_83F1AC;
    case 0x83F1AEu: goto L_83F1AE;
    case 0x83F1AFu: goto L_83F1AF;
    case 0x83F1B0u: goto L_83F1B0;
    case 0x83F1B2u: goto L_83F1B2;
    case 0x83F1B3u: goto L_83F1B3;
    case 0x83F1B6u: goto L_83F1B6;
    case 0x83F1B7u: goto L_83F1B7;
    case 0x83F1B9u: goto L_83F1B9;
    case 0x83F1BBu: goto L_83F1BB;
    case 0x83F1BDu: goto L_83F1BD;
    case 0x83F1BEu: goto L_83F1BE;
    case 0x83F1C1u: goto L_83F1C1;
    case 0x83F1C3u: goto L_83F1C3;
    case 0x83F1C4u: goto L_83F1C4;
    case 0x83F1C6u: goto L_83F1C6;
    case 0x83F1C8u: goto L_83F1C8;
    case 0x83F1CAu: goto L_83F1CA;
    case 0x83F1CDu: goto L_83F1CD;
    case 0x83F1CFu: goto L_83F1CF;
    case 0x83F1D2u: goto L_83F1D2;
    case 0x83F1D3u: goto L_83F1D3;
    case 0x83F1D6u: goto L_83F1D6;
    case 0x83F1D8u: goto L_83F1D8;
    case 0x83F1DAu: goto L_83F1DA;
    case 0x83F1DDu: goto L_83F1DD;
    case 0x83F1DFu: goto L_83F1DF;
    case 0x83F1E3u: goto L_83F1E3;
    case 0x83F1E6u: goto L_83F1E6;
    case 0x83F1E8u: goto L_83F1E8;
    case 0x83F1EAu: goto L_83F1EA;
    case 0x83F1ECu: goto L_83F1EC;
    case 0x83F1EEu: goto L_83F1EE;
    case 0x83F1EFu: goto L_83F1EF;
    case 0x83F1F0u: goto L_83F1F0;
    case 0x83F1F2u: goto L_83F1F2;
    case 0x83F1F4u: goto L_83F1F4;
    case 0x83F1F5u: goto L_83F1F5;
    case 0x83F1F7u: goto L_83F1F7;
    case 0x83F1F9u: goto L_83F1F9;
    case 0x83F1FCu: goto L_83F1FC;
    case 0x83F1FEu: goto L_83F1FE;
    case 0x83F1FFu: goto L_83F1FF;
    case 0x83F201u: goto L_83F201;
    case 0x83F204u: goto L_83F204;
    case 0x83F206u: goto L_83F206;
    case 0x83F207u: goto L_83F207;
    case 0x83F209u: goto L_83F209;
    case 0x83F20Bu: goto L_83F20B;
    case 0x83F20Cu: goto L_83F20C;
    case 0x83F20Du: goto L_83F20D;
    case 0x83F20Fu: goto L_83F20F;
    case 0x83F211u: goto L_83F211;
    case 0x83F212u: goto L_83F212;
    case 0x83F214u: goto L_83F214;
    case 0x83F216u: goto L_83F216;
    case 0x83F219u: goto L_83F219;
    case 0x83F21Bu: goto L_83F21B;
    case 0x83F21Cu: goto L_83F21C;
    case 0x83F21Eu: goto L_83F21E;
    case 0x83F221u: goto L_83F221;
    case 0x83F223u: goto L_83F223;
    case 0x83F224u: goto L_83F224;
    case 0x83F226u: goto L_83F226;
    case 0x83F228u: goto L_83F228;
    case 0x83F229u: goto L_83F229;
    case 0x83F22Cu: goto L_83F22C;
    case 0x83F22Eu: goto L_83F22E;
    case 0x83F22Fu: goto L_83F22F;
    case 0x83F231u: goto L_83F231;
    case 0x83F233u: goto L_83F233;
    case 0x83F235u: goto L_83F235;
    case 0x83F238u: goto L_83F238;
    case 0x83F23Au: goto L_83F23A;
    case 0x83F23Du: goto L_83F23D;
    case 0x83F23Eu: goto L_83F23E;
    case 0x83F241u: goto L_83F241;
    case 0x83F243u: goto L_83F243;
    case 0x83F245u: goto L_83F245;
    case 0x83F248u: goto L_83F248;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F10C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Cu, 3u, 3u, cpu.address("abs", 0xF406u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F10C JMP -> $83F406
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF406u),0x83F10Cu); return;
L_83F10F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF10Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF10Fu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F10F STZ
    hw.write(cpu.address("absx", 0x10DAu), 0, cpu.m8?8:16);
    goto L_83F112;
L_83F112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF112u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF112u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F112 ASL
    cpu.aslA();
    goto L_83F113;
L_83F113:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF113u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF113u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF113u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F113 BPL -> $83F118
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F118; }
    goto L_83F115;
L_83F115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF115u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF115u, 3u, 3u, cpu.address("abs", 0xF28Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F115 JMP -> $83F28F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xF28Fu),0x83F115u); return;
L_83F118:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF118u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF118u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF118u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F118 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F11B;
L_83F11B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F11B SBC
    cpu.sbc(0x380u);
    goto L_83F11E;
L_83F11E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF11Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF11Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F11E BPL -> $83F134
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F120;
L_83F120:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF120u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF120u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F120 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F122;
L_83F122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF122u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F122 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F125;
L_83F125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF125u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F125 BNE -> $83F134
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F127;
L_83F127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF127u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F127 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F129;
L_83F129:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF129u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF129u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F129 CMP
    cpu.compareA(0x8u);
    goto L_83F12C;
L_83F12C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F12C BCC -> $83F134
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F134; }
    goto L_83F12E;
L_83F12E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF12Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF12Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F12E LDA
    cpu.setA(0x600u, 16);
    goto L_83F131;
L_83F131:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF131u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF131u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F131 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F134;
L_83F134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF134u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F134 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F136;
L_83F136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF136u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F136 SEC
    cpu.setFlag('C', true);
    goto L_83F137;
L_83F137:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF137u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF137u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F137 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16));
    goto L_83F13A;
L_83F13A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F13A ADC
    cpu.adc(0x8u);
    goto L_83F13D;
L_83F13D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF13Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF13Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F13D CMP
    cpu.compareA(0x10u);
    goto L_83F140;
L_83F140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF140u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F140 BCS -> $83F1AF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1AF; }
    goto L_83F142;
L_83F142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF142u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F142 SEP
    cpu.sep(0x20u);
    goto L_83F144;
L_83F144:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF144u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF144u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F144 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F146;
L_83F146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F146 AND
    cpu.logicAnd(0xF0u);
    goto L_83F148;
L_83F148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF148u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F148 SEC
    cpu.setFlag('C', true);
    goto L_83F149;
L_83F149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF149u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF149u, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F149 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F14C;
L_83F14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14C BEQ -> $83F15E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F15E; }
    goto L_83F14E;
L_83F14E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14E ASL
    cpu.aslA();
    goto L_83F14F;
L_83F14F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF14Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF14Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F14F LDA
    cpu.setA(0x82u, 8);
    goto L_83F151;
L_83F151:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF151u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF151u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF151u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F151 BCC -> $83F155
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F155; }
    goto L_83F153;
L_83F153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF153u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F153 LDA
    cpu.setA(0x81u, 8);
    goto L_83F155;
L_83F155:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF155u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF155u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F155 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F158;
L_83F158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF158u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F158 REP
    cpu.rep(0x20u);
    goto L_83F15A;
L_83F15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Au, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F15A JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF15Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF15Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F15Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F15D;
L_83F15D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F15D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F15Du);return;} hw.unresolvedReturn(0x83F15Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F15D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F15Du);return;} hw.unresolvedReturn(0x83F15Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF15Du,0x83F15Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF15Eu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F15E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F161;
L_83F161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F161 BEQ -> $83F158
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F158; }
    goto L_83F163;
L_83F163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF163u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F163 REP
    cpu.rep(0x20u);
    goto L_83F165;
L_83F165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF165u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F165 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F168;
L_83F168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF168u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F168 BNE -> $83F18F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F18F; }
    goto L_83F16A;
L_83F16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Au, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F16A JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF16Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF16Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F16Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F16E;
L_83F16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF16Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF16Eu,0x83F16Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF16Eu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F16E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F171;
L_83F171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF171u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F171 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F173;
L_83F173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF173u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F173 BMI -> $83F192
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F192; }
    goto L_83F175;
L_83F175:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF175u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF175u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F175 SEP
    cpu.sep(0x20u);
    goto L_83F177;
L_83F177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF177u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F177 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F179;
L_83F179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF179u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F179 TAY
    cpu.transfer("TAY");
    goto L_83F17A;
L_83F17A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17A SEC
    cpu.setFlag('C', true);
    goto L_83F17B;
L_83F17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17B SBC
    cpu.sbc(0x20u);
    goto L_83F17D;
L_83F17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17D CMP
    cpu.compareA(0x80u);
    goto L_83F17F;
L_83F17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF17Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F17F TYA
    cpu.transfer("TYA");
    goto L_83F180;
L_83F180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF180u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF180u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F180 BCS -> $83F18A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F18A; }
    goto L_83F182;
L_83F182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF182u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F182 SBC
    cpu.sbc(0x3Fu);
    goto L_83F184;
L_83F184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF184u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F184 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F187;
L_83F187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF187u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F187 REP
    cpu.rep(0x20u);
    goto L_83F189;
L_83F189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF189u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F189 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F189u);return;} hw.unresolvedReturn(0x83F189u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18A ADC
    cpu.adc(0x3Fu);
    goto L_83F18C;
L_83F18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F18F;
L_83F18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF18Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18F REP
    cpu.rep(0x20u);
    goto L_83F191;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF18Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F18F REP
    cpu.rep(0x20u);
    goto L_83F191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF18Fu,0x83F18Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF191u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F191 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F191u);return;} hw.unresolvedReturn(0x83F191u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF192u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F192 SEP
    cpu.sep(0x20u);
    goto L_83F194;
L_83F194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF194u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF194u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F194 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F196;
L_83F196:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF196u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF196u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF196u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F196 TAY
    cpu.transfer("TAY");
    goto L_83F197;
L_83F197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF197u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F197 SEC
    cpu.setFlag('C', true);
    goto L_83F198;
L_83F198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF198u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF198u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F198 SBC
    cpu.sbc(0x20u);
    goto L_83F19A;
L_83F19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19A CMP
    cpu.compareA(0x80u);
    goto L_83F19C;
L_83F19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19C TYA
    cpu.transfer("TYA");
    goto L_83F19D;
L_83F19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19D BCS -> $83F1A7
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1A7; }
    goto L_83F19F;
L_83F19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF19Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F19F ADC
    cpu.adc(0x40u);
    goto L_83F1A1;
L_83F1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A1u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A1 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1A4;
L_83F1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A4u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A4 REP
    cpu.rep(0x20u);
    goto L_83F1A6;
L_83F1A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1A6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1A6u);return;} hw.unresolvedReturn(0x83F1A6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A7 SBC
    cpu.sbc(0x40u);
    goto L_83F1A9;
L_83F1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1A9u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1A9 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1AC;
L_83F1AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1AC REP
    cpu.rep(0x20u);
    goto L_83F1AE;
L_83F1AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1AE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1AEu);return;} hw.unresolvedReturn(0x83F1AEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1AF ASL
    cpu.aslA();
    goto L_83F1B0;
L_83F1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B0 SEP
    cpu.sep(0x20u);
    goto L_83F1B2;
L_83F1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B2 ROL
    cpu.rolA();
    goto L_83F1B3;
L_83F1B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B3u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B3 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F1B6;
L_83F1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B6 LSR
    cpu.lsrA();
    goto L_83F1B7;
L_83F1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B7 BCC -> $83F224
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F224; }
    goto L_83F1B9;
L_83F1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1B9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1BB;
L_83F1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BB AND
    cpu.logicAnd(0xF0u);
    goto L_83F1BD;
L_83F1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BD SEC
    cpu.setFlag('C', true);
    goto L_83F1BE;
L_83F1BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1BEu, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1BE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F1C1;
L_83F1C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C1 BEQ -> $83F1D3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F1D3; }
    goto L_83F1C3;
L_83F1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C3 ASL
    cpu.aslA();
    goto L_83F1C4;
L_83F1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C4 LDA
    cpu.setA(0x82u, 8);
    goto L_83F1C6;
L_83F1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C6 BCC -> $83F1CA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1CA; }
    goto L_83F1C8;
L_83F1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1C8 LDA
    cpu.setA(0x81u, 8);
    goto L_83F1CA;
L_83F1CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CAu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1CA STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F1CD;
L_83F1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1CD REP
    cpu.rep(0x20u);
    goto L_83F1CF;
L_83F1CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1CFu, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F1CF JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF1D1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1D2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F1CFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F1D2;
L_83F1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1D2u);return;} hw.unresolvedReturn(0x83F1D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1D2 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1D2u);return;} hw.unresolvedReturn(0x83F1D2u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1D2u,0x83F1D2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F1D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D3u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D3u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D3 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1D6;
L_83F1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D6 BEQ -> $83F1CD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F1CD; }
    goto L_83F1D8;
L_83F1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1D8 REP
    cpu.rep(0x20u);
    goto L_83F1DA;
L_83F1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DAu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1DA LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1DD;
L_83F1DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1DD BNE -> $83F204
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F204; }
    goto L_83F1DF;
L_83F1DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1DFu, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1DF JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF1E2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF1E3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F1DFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F1E3;
L_83F1E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF1E3u,0x83F1E3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E3u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1E6;
L_83F1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E6u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E6 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F1E8;
L_83F1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1E8 BMI -> $83F207
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F207; }
    goto L_83F1EA;
L_83F1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EA SEP
    cpu.sep(0x20u);
    goto L_83F1EC;
L_83F1EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EC LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F1EE;
L_83F1EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EE TAY
    cpu.transfer("TAY");
    goto L_83F1EF;
L_83F1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1EF SEC
    cpu.setFlag('C', true);
    goto L_83F1F0;
L_83F1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F0 SBC
    cpu.sbc(0x20u);
    goto L_83F1F2;
L_83F1F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F2u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F2 CMP
    cpu.compareA(0x80u);
    goto L_83F1F4;
L_83F1F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F4u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F4 TYA
    cpu.transfer("TYA");
    goto L_83F1F5;
L_83F1F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F5 BCS -> $83F1FF
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F1FF; }
    goto L_83F1F7;
L_83F1F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F7 SBC
    cpu.sbc(0x3Fu);
    goto L_83F1F9;
L_83F1F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1F9u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1F9 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F1FC;
L_83F1FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1FC REP
    cpu.rep(0x20u);
    goto L_83F1FE;
L_83F1FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F1FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F1FEu);return;} hw.unresolvedReturn(0x83F1FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F1FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF1FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF1FFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F1FF ADC
    cpu.adc(0x3Fu);
    goto L_83F201;
L_83F201:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF201u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF201u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F201 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F204;
L_83F204:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF204u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F204 REP
    cpu.rep(0x20u);
    goto L_83F206;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF204u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F204 REP
    cpu.rep(0x20u);
    goto L_83F206;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF204u,0x83F204u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F206:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF206u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF206u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F206 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F206u);return;} hw.unresolvedReturn(0x83F206u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F207:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF207u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF207u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F207 SEP
    cpu.sep(0x20u);
    goto L_83F209;
L_83F209:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF209u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF209u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F209 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F20B;
L_83F20B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20B TAY
    cpu.transfer("TAY");
    goto L_83F20C;
L_83F20C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20C SEC
    cpu.setFlag('C', true);
    goto L_83F20D;
L_83F20D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20D SBC
    cpu.sbc(0x20u);
    goto L_83F20F;
L_83F20F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF20Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF20Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F20F CMP
    cpu.compareA(0x80u);
    goto L_83F211;
L_83F211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF211u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF211u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F211 TYA
    cpu.transfer("TYA");
    goto L_83F212;
L_83F212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF212u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F212 BCS -> $83F21C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F21C; }
    goto L_83F214;
L_83F214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF214u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF214u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F214 ADC
    cpu.adc(0x40u);
    goto L_83F216;
L_83F216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF216u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF216u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F216 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F219;
L_83F219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF219u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF219u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F219 REP
    cpu.rep(0x20u);
    goto L_83F21B;
L_83F21B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F21B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F21Bu);return;} hw.unresolvedReturn(0x83F21Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F21C SBC
    cpu.sbc(0x40u);
    goto L_83F21E;
L_83F21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF21Eu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F21E STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F221;
L_83F221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF221u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF221u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F221 REP
    cpu.rep(0x20u);
    goto L_83F223;
L_83F223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF223u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF223u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F223 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F223u);return;} hw.unresolvedReturn(0x83F223u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF224u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F224 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F226;
L_83F226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF226u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F226 AND
    cpu.logicAnd(0xF0u);
    goto L_83F228;
L_83F228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF228u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF228u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F228 SEC
    cpu.setFlag('C', true);
    goto L_83F229;
L_83F229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF229u, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F229 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83F22C;
L_83F22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22C BEQ -> $83F23E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F23E; }
    goto L_83F22E;
L_83F22E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22E ASL
    cpu.aslA();
    goto L_83F22F;
L_83F22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF22Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F22F LDA
    cpu.setA(0x82u, 8);
    goto L_83F231;
L_83F231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF231u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF231u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F231 BCC -> $83F235
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F235; }
    goto L_83F233;
L_83F233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF233u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF233u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F233 LDA
    cpu.setA(0x81u, 8);
    goto L_83F235;
L_83F235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF235u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF235u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F235 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F238;
L_83F238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF238u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F238 REP
    cpu.rep(0x20u);
    goto L_83F23A;
L_83F23A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Au, 6u, 3u, cpu.address("abs", 0xF6CCu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F23A JSR -> $83F6CC stack real
    { cpu.push16Value(hw,0xF23Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF23Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF6CCu), 0x83F23Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F23D;
L_83F23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F23D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F23Du);return;} hw.unresolvedReturn(0x83F23Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F23D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F23Du);return;} hw.unresolvedReturn(0x83F23Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF23Du,0x83F23Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F23E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF23Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF23Eu, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F23E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F241;
L_83F241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF241u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F241 BEQ -> $83F238
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F238; }
    goto L_83F243;
L_83F243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF243u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F243 REP
    cpu.rep(0x20u);
    goto L_83F245;
L_83F245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF245u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF245u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F245 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F248;
L_83F248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF248u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F248 BNE -> $83F26F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F26Fu,0x83F248u); return; }
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF24Au,0x83F248u); return;
}

