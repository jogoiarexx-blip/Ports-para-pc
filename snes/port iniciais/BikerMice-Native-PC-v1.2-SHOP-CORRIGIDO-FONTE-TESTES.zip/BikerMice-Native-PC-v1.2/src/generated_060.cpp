#include "generated.hpp"
void sub_2085CE_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x2085CEu: goto L_2085CE;
    case 0x2085D1u: goto L_2085D1;
    case 0x2085D4u: goto L_2085D4;
    case 0x2085D7u: goto L_2085D7;
    case 0x2085D8u: goto L_2085D8;
    case 0x2085D9u: goto L_2085D9;
    case 0x2085DAu: goto L_2085DA;
    case 0x2085DBu: goto L_2085DB;
    case 0x2085DCu: goto L_2085DC;
    case 0x2085DFu: goto L_2085DF;
    case 0x2085E2u: goto L_2085E2;
    case 0x2085E4u: goto L_2085E4;
    case 0x2085E7u: goto L_2085E7;
    case 0x2085EAu: goto L_2085EA;
    case 0x2085EDu: goto L_2085ED;
    case 0x2085EFu: goto L_2085EF;
    case 0x2085F2u: goto L_2085F2;
    case 0x2085F5u: goto L_2085F5;
    case 0x2085F8u: goto L_2085F8;
    case 0x2085FBu: goto L_2085FB;
    case 0x2085FEu: goto L_2085FE;
    case 0x208600u: goto L_208600;
    case 0x208603u: goto L_208603;
    case 0x208606u: goto L_208606;
    case 0x208609u: goto L_208609;
    case 0x20860Cu: goto L_20860C;
    case 0x20860Fu: goto L_20860F;
    case 0x208611u: goto L_208611;
    case 0x208614u: goto L_208614;
    case 0x208617u: goto L_208617;
    case 0x20861Au: goto L_20861A;
    case 0x20861Du: goto L_20861D;
    case 0x208620u: goto L_208620;
    case 0x208622u: goto L_208622;
    case 0x208625u: goto L_208625;
    case 0x208628u: goto L_208628;
    case 0x20862Bu: goto L_20862B;
    case 0x20862Eu: goto L_20862E;
    case 0x208631u: goto L_208631;
    case 0x208633u: goto L_208633;
    case 0x208636u: goto L_208636;
    case 0x208639u: goto L_208639;
    case 0x20863Cu: goto L_20863C;
    case 0x20863Fu: goto L_20863F;
    case 0x208642u: goto L_208642;
    case 0x208644u: goto L_208644;
    case 0x208647u: goto L_208647;
    case 0x20864Au: goto L_20864A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_2085CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085CE LDX
    cpu.setX(0x61D1u, 16);
    goto L_2085D1;
L_2085D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D1u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D1u, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085D1 STX
    hw.write(cpu.address("abs", 0x101Eu), cpu.x, cpu.x8?8:16);
    goto L_2085D4;
L_2085D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D4u, 4u, 3u, cpu.address("abs", 0x101Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085D4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x101Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_2085D7;
L_2085D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085D7 ROL
    cpu.rolA();
    goto L_2085D8;
L_2085D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085D8 ROL
    cpu.rolA();
    goto L_2085D9;
L_2085D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85D9u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085D9 ROL
    cpu.rolA();
    goto L_2085DA;
L_2085DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085DA ROL
    cpu.rolA();
    goto L_2085DB;
L_2085DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085DB CLC
    cpu.setFlag('C', false);
    goto L_2085DC;
L_2085DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu,cpu,0x6Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DCu, 4u, 3u, cpu.address("abs", 0x101Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085DC ADC
    cpu.adc(hw.readW(cpu.address("abs", 0x101Eu), cpu.m8?8:16));
    goto L_2085DF;
L_2085DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85DFu, 4u, 3u, cpu.address("abs", 0x101Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085DF STA
    hw.write(cpu.address("abs", 0x101Eu), cpu.a, cpu.m8?8:16);
    goto L_2085E2;
L_2085E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085E2 BCC -> $2085E7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_2085E7; }
    goto L_2085E4;
L_2085E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E4u, 6u, 3u, cpu.address("abs", 0x101Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085E4 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Fu), cpu.m8?8:16);
    goto L_2085E7;
L_2085E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85E7u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85E7u, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085E7 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2085EA;
L_2085EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EAu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085EA STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_2085ED;
L_2085ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EDu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085ED LDA
    cpu.setA(0x20u, 8);
    goto L_2085EF;
L_2085EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85EFu, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085EF STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_2085F2;
L_2085F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F2u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085F2 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_2085F5;
L_2085F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F5u, 6u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085F5 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Eu), cpu.m8?8:16);
    goto L_2085F8;
L_2085F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85F8u, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085F8 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_2085FB;
L_2085FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FBu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FBu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085FB STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_2085FE;
L_2085FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x85FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x85FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $2085FE LDA
    cpu.setA(0x53u, 8);
    goto L_208600;
L_208600:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8600u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8600u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208600 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_208603;
L_208603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8603u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208603 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_208606;
L_208606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8606u, 6u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208606 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Eu), cpu.m8?8:16);
    goto L_208609;
L_208609:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8609u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8609u, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208609 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_20860C;
L_20860C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Cu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20860C STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_20860F;
L_20860F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x860Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x860Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20860F LDA
    cpu.setA(0x55u, 8);
    goto L_208611;
L_208611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8611u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8611u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208611 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_208614;
L_208614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8614u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208614 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_208617;
L_208617:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8617u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8617u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8617u, 6u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208617 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Eu), cpu.m8?8:16);
    goto L_20861A;
L_20861A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Au, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20861A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_20861D;
L_20861D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x861Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x861Du,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x861Du, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20861D STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208620;
L_208620:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8620u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8620u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208620 LDA
    cpu.setA(0x52u, 8);
    goto L_208622;
L_208622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8622u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208622 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_208625;
L_208625:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8625u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8625u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208625 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_208628;
L_208628:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8628u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8628u, 6u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208628 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Eu), cpu.m8?8:16);
    goto L_20862B;
L_20862B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Bu, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20862B LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_20862E;
L_20862E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Eu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20862E STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208631;
L_208631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8631u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208631 LDA
    cpu.setA(0x45u, 8);
    goto L_208633;
L_208633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8633u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208633 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_208636;
L_208636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208636 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_208639;
L_208639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 6u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208639 INC
    cpu.incMem(hw, cpu.address("abs", 0x101Eu), cpu.m8?8:16);
    goto L_20863C;
L_20863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 5u, 3u, cpu.address("abs", 0x101Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20863C LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x101Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_20863F;
L_20863F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Fu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $20863F STX
    hw.write(cpu.address("abs", 0x2116u), cpu.x, cpu.x8?8:16);
    goto L_208642;
L_208642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208642 LDA
    cpu.setA(0x20u, 8);
    goto L_208644;
L_208644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u, 4u, 3u, cpu.address("abs", 0x2118u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208644 STA
    hw.write(cpu.address("abs", 0x2118u), cpu.a, cpu.m8?8:16);
    goto L_208647;
L_208647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 4u, 3u, cpu.address("abs", 0x2119u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $208647 STZ
    hw.write(cpu.address("abs", 0x2119u), 0, cpu.m8?8:16);
    goto L_20864A;
L_20864A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $20864A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x20864Au);return;} hw.unresolvedReturn(0x20864Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808681_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808681u: goto L_808681;
    case 0x808683u: goto L_808683;
    case 0x808686u: goto L_808686;
    case 0x808688u: goto L_808688;
    case 0x80868Bu: goto L_80868B;
    case 0x80868Eu: goto L_80868E;
    case 0x808691u: goto L_808691;
    case 0x808694u: goto L_808694;
    case 0x808697u: goto L_808697;
    case 0x80869Au: goto L_80869A;
    case 0x80869Du: goto L_80869D;
    case 0x8086A0u: goto L_8086A0;
    case 0x8086A1u: goto L_8086A1;
    case 0x8086A2u: goto L_8086A2;
    case 0x8086A5u: goto L_8086A5;
    case 0x8086A7u: goto L_8086A7;
    case 0x8086A9u: goto L_8086A9;
    case 0x8086ACu: goto L_8086AC;
    case 0x8086B0u: goto L_8086B0;
    case 0x8086B4u: goto L_8086B4;
    case 0x8086B8u: goto L_8086B8;
    case 0x8086BBu: goto L_8086BB;
    case 0x8086BFu: goto L_8086BF;
    case 0x8086C1u: goto L_8086C1;
    case 0x8086C3u: goto L_8086C3;
    case 0x8086C6u: goto L_8086C6;
    case 0x8086C8u: goto L_8086C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8681u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808681 INC
    cpu.incMem(hw, cpu.address("dp", 0x44u), cpu.m8?8:16);
    goto L_808683;
L_808683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 5u, 3u, cpu.address("abs", 0x1FA2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808683 STZ
    hw.write(cpu.address("abs", 0x1FA2u), 0, cpu.m8?8:16);
    goto L_808686;
L_808686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8686u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808686 SEP
    cpu.sep(0x20u);
    goto L_808688;
L_808688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8688u, 4u, 3u, cpu.address("abs", 0x2121u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808688 STZ
    hw.write(cpu.address("abs", 0x2121u), 0, cpu.m8?8:16);
    goto L_80868B;
L_80868B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Bu, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80868B STZ
    hw.write(cpu.address("abs", 0x2122u), 0, cpu.m8?8:16);
    goto L_80868E;
L_80868E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80868E STZ
    hw.write(cpu.address("abs", 0x2122u), 0, cpu.m8?8:16);
    goto L_808691;
L_808691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808691 LDY
    cpu.setY(0x0u, 16);
    goto L_808694;
L_808694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 4u + 1u, 3u, cpu.address("absy", 0x80A7u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808694 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x80A7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808697;
L_808697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808697 STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_80869A;
L_80869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 4u + 1u, 3u, cpu.address("absy", 0x80A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80869A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x80A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80869D;
L_80869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 4u, 3u, cpu.address("abs", 0x2122u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80869D STA
    hw.write(cpu.address("abs", 0x2122u), cpu.a, cpu.m8?8:16);
    goto L_8086A0;
L_8086A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A0 INY
    cpu.inc('Y');
    goto L_8086A1;
L_8086A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A1 INY
    cpu.inc('Y');
    goto L_8086A2;
L_8086A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A2 CPY
    cpu.compareY(0x6u);
    goto L_8086A5;
L_8086A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A5 BCC -> $808694
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_808694; }
    goto L_8086A7;
L_8086A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A7 REP
    cpu.rep(0x20u);
    goto L_8086A9;
L_8086A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086A9 LDX
    cpu.setX(0xA38Bu, 16);
    goto L_8086AC;
L_8086AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ACu, 8u, 4u, 0x80AD2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086AC JSL -> $80AD2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86AFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86B0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AD2Fu, 0x8086ACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086B0;
L_8086B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086B0 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x8086B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086B4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B0u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086B0 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86B3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86B4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x8086B0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086B4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B0u,0x8086B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u, 8u, 4u, 0x80A8EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086B4 JSL -> $80A8ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86B8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8EDu, 0x8086B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B4u, 8u, 4u, 0x80A8EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086B4 JSL -> $80A8ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86B7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86B8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A8EDu, 0x8086B4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B4u,0x8086B4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 6u, 3u, cpu.address("abs", 0x86C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8086B8 JSR -> $8086C9 stack real
    { cpu.push16Value(hw,0x86BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86BBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86C9u), 0x8086B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B8u, 6u, 3u, cpu.address("abs", 0x86C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8086B8 JSR -> $8086C9 stack real
    { cpu.push16Value(hw,0x86BAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86BBu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x86C9u), 0x8086B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B8u,0x8086B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8086BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BBu,0x8086BBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BBu, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086BB JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x86BEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x86BFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x8086BBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8086BF;
L_8086BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86BFu,0x8086BFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086BF SEP
    cpu.sep(0x20u);
    goto L_8086C1;
L_8086C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C1 LDA
    cpu.setA(0xFu, 8);
    goto L_8086C3;
L_8086C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C3u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C3 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_8086C6;
L_8086C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8086C6 REP
    cpu.rep(0x20u);
    goto L_8086C8;
L_8086C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8086C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8086C8u);return;} hw.unresolvedReturn(0x8086C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808A92_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808A92u: goto L_808A92;
    case 0x808A94u: goto L_808A94;
    case 0x808A95u: goto L_808A95;
    case 0x808A98u: goto L_808A98;
    case 0x808A9Cu: goto L_808A9C;
    case 0x808A9Fu: goto L_808A9F;
    case 0x808AA2u: goto L_808AA2;
    case 0x808AA3u: goto L_808AA3;
    case 0x808AA4u: goto L_808AA4;
    case 0x808AA7u: goto L_808AA7;
    case 0x808AA8u: goto L_808AA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A92 REP
    cpu.rep(0x30u);
    goto L_808A94;
L_808A94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808A94 PHB
    cpu.push("PHB", hw);
    goto L_808A95;
L_808A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A95 LDA
    cpu.setA(0x0u, 16);
    goto L_808A98;
L_808A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 6u, 4u, 0x001F50u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A98 STA
    hw.write(0x1F50u, cpu.a, cpu.m8?8:16);
    goto L_808A9C;
L_808A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A9C LDA
    cpu.setA(0x4Du, 16);
    goto L_808A9F;
L_808A9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A9F LDX
    cpu.setX(0x1F51u, 16);
    goto L_808AA2;
L_808AA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AA2 TXY
    cpu.transfer("TXY");
    goto L_808AA3;
L_808AA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AA3 INY
    cpu.inc('Y');
    goto L_808AA4;
L_808AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8AA4u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808AA4 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808AA7;
L_808AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AA7 PLB
    cpu.pop("PLB", hw);
    goto L_808AA8;
L_808AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808AA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808AA8u);return;} hw.unresolvedReturn(0x808AA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_808A92_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808A92u: goto L_808A92;
    case 0x808A94u: goto L_808A94;
    case 0x808A95u: goto L_808A95;
    case 0x808A98u: goto L_808A98;
    case 0x808A9Cu: goto L_808A9C;
    case 0x808A9Fu: goto L_808A9F;
    case 0x808AA2u: goto L_808AA2;
    case 0x808AA3u: goto L_808AA3;
    case 0x808AA4u: goto L_808AA4;
    case 0x808AA7u: goto L_808AA7;
    case 0x808AA8u: goto L_808AA8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808A92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A92u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A92 REP
    cpu.rep(0x30u);
    goto L_808A94;
L_808A94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A94u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808A94 PHB
    cpu.push("PHB", hw);
    goto L_808A95;
L_808A95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A95u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A95 LDA
    cpu.setA(0x0u, 16);
    goto L_808A98;
L_808A98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A98u, 6u, 4u, 0x001F50u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A98 STA
    hw.write(0x1F50u, cpu.a, cpu.m8?8:16);
    goto L_808A9C;
L_808A9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A9C LDA
    cpu.setA(0x4Du, 16);
    goto L_808A9F;
L_808A9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808A9F LDX
    cpu.setX(0x1F51u, 16);
    goto L_808AA2;
L_808AA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AA2 TXY
    cpu.transfer("TXY");
    goto L_808AA3;
L_808AA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808AA3 INY
    cpu.inc('Y');
    goto L_808AA4;
L_808AA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x8AA4u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $808AA4 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_808AA7;
L_808AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $808AA7 PLB
    cpu.pop("PLB", hw);
    goto L_808AA8;
L_808AA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8AA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8AA8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808AA8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808AA8u);return;} hw.unresolvedReturn(0x808AA8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B01A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B01Au: goto L_82B01A;
    case 0x82B01Eu: goto L_82B01E;
    case 0x82B020u: goto L_82B020;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B01A JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB01Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B01Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B01E;
L_82B01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Eu,0x82B01Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B01E INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B020;
L_82B020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B020 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B020u);return;} hw.unresolvedReturn(0x82B020u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B01A_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B01Au: goto L_82B01A;
    case 0x82B01Eu: goto L_82B01E;
    case 0x82B020u: goto L_82B020;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B01A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Au, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B01A JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB01Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB01Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x82B01Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B01E;
L_82B01E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB01Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB01Eu,0x82B01Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB01Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B01E INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B020;
L_82B020:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB020u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB020u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B020 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B020u);return;} hw.unresolvedReturn(0x82B020u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82ECB9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82ECB9u: goto L_82ECB9;
    case 0x82ECBCu: goto L_82ECBC;
    case 0x82ECBFu: goto L_82ECBF;
    case 0x82ECC2u: goto L_82ECC2;
    case 0x82ECC5u: goto L_82ECC5;
    case 0x82ECC9u: goto L_82ECC9;
    case 0x82ECCAu: goto L_82ECCA;
    case 0x82ECCBu: goto L_82ECCB;
    case 0x82ECCEu: goto L_82ECCE;
    case 0x82ECD0u: goto L_82ECD0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82ECB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECB9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECB9u, 5u, 3u, cpu.address("abs", 0x0560u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECB9 STZ
    hw.write(cpu.address("abs", 0x560u), 0, cpu.m8?8:16);
    goto L_82ECBC;
L_82ECBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBCu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBCu, 5u, 3u, cpu.address("abs", 0x0562u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECBC STZ
    hw.write(cpu.address("abs", 0x562u), 0, cpu.m8?8:16);
    goto L_82ECBF;
L_82ECBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECBFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECBF LDX
    cpu.setX(0x0u, 16);
    goto L_82ECC2;
L_82ECC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECC2 LDA
    cpu.setA(0x0u, 16);
    goto L_82ECC5;
L_82ECC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC5u, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECC5 STA
    hw.write(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82ECC9;
L_82ECC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECC9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECC9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECC9 INX
    cpu.inc('X');
    goto L_82ECCA;
L_82ECCA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECCA INX
    cpu.inc('X');
    goto L_82ECCB;
L_82ECCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCBu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECCB CPX
    cpu.compareX(0x800u);
    goto L_82ECCE;
L_82ECCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82ECCE BCC -> $82ECC5
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82ECC5; }
    goto L_82ECD0;
L_82ECD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xECD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xECD0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82ECD0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82ECD0u);return;} hw.unresolvedReturn(0x82ECD0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_839E6C_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839F9Eu: goto L_839F9E;
    case 0x839F9Fu: goto L_839F9F;
    case 0x839FA2u: goto L_839FA2;
    case 0x839FA3u: goto L_839FA3;
    case 0x839FA6u: goto L_839FA6;
    case 0x839FA8u: goto L_839FA8;
    case 0x839FABu: goto L_839FAB;
    case 0x839FACu: goto L_839FAC;
    case 0x839FAFu: goto L_839FAF;
    case 0x839FB1u: goto L_839FB1;
    case 0x839FB2u: goto L_839FB2;
    case 0x839FB3u: goto L_839FB3;
    case 0x839FB5u: goto L_839FB5;
    case 0x839FB8u: goto L_839FB8;
    case 0x839FBBu: goto L_839FBB;
    case 0x839FBEu: goto L_839FBE;
    case 0x839FC1u: goto L_839FC1;
    case 0x839FC3u: goto L_839FC3;
    case 0x839FC4u: goto L_839FC4;
    case 0x839FC6u: goto L_839FC6;
    case 0x839FC9u: goto L_839FC9;
    case 0x839FCBu: goto L_839FCB;
    case 0x839FCEu: goto L_839FCE;
    case 0x839FD0u: goto L_839FD0;
    case 0x839FD3u: goto L_839FD3;
    case 0x839FD6u: goto L_839FD6;
    case 0x839FD9u: goto L_839FD9;
    case 0x839FDCu: goto L_839FDC;
    case 0x839FDFu: goto L_839FDF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9E CLC
    cpu.setFlag('C', false);
    goto L_839F9F;
L_839F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9F ADC
    cpu.adc(0x50u);
    goto L_839FA2;
L_839FA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA2u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FA2 TAX
    cpu.transfer("TAX");
    goto L_839FA3;
L_839FA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA3u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FA3 CPX
    cpu.compareX(0x8E0u);
    goto L_839FA6;
L_839FA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FA6 BCS -> $839FAB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839FAB; }
    goto L_839FA8;
L_839FA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA8u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FA8u, 3u, 3u, cpu.address("abs", 0x9E6Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FA8 JMP -> $839E6C
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E6Cu),0x839FA8u); return;
L_839FAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839FAB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x839FABu);return;} hw.unresolvedReturn(0x839FABu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_839FAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FACu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FACu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FAC STZ
    hw.write(cpu.address("abs", 0x1BB2u), 0, cpu.m8?8:16);
    goto L_839FAF;
L_839FAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FAFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FAF LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FB1;
L_839FB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FB1 LSR
    cpu.lsrA();
    goto L_839FB2;
L_839FB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB2u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FB2 DEC
    cpu.decReg('A');
    goto L_839FB3;
L_839FB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FB3 BEQ -> $839FC1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839FC1; }
    goto L_839FB5;
L_839FB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB5u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FB5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FB8;
L_839FB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FB8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FB8 AND
    cpu.logicAnd(0x7FFFu);
    goto L_839FBB;
L_839FBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBBu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FBB ORA
    cpu.logicOr(0x400u);
    goto L_839FBE;
L_839FBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FBEu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FBE STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_839FC1;
L_839FC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FC1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FC3;
L_839FC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC3u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FC3 LSR
    cpu.lsrA();
    goto L_839FC4;
L_839FC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FC4 BNE -> $839FD6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839FD6; }
    goto L_839FC6;
L_839FC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FC6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839FC9;
L_839FC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FC9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FC9 BMI -> $839FD6
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839FD6; }
    goto L_839FCB;
L_839FCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FCB CMP
    cpu.compareA(0x900u);
    goto L_839FCE;
L_839FCE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FCEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FCEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FCE BCC -> $839FD6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839FD6; }
    goto L_839FD0;
L_839FD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FD0 LDA
    cpu.setA(0x900u, 16);
    goto L_839FD3;
L_839FD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD3u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FD3 STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_839FD6;
L_839FD6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FD6 LDA
    cpu.setA(0x8000u, 16);
    goto L_839FD9;
L_839FD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD9u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FD9u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FD9 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_839FDC;
L_839FDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDCu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FDC STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_839FDF;
L_839FDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9FDFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9FDFu, 3u, 3u, cpu.address("abs", 0x9F7Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839FDF JMP -> $839F7F
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9F7Fu),0x839FDFu); return;
}

void sub_83A375_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B2CEu: goto L_83B2CE;
    case 0x83B2D1u: goto L_83B2D1;
    case 0x83B2D5u: goto L_83B2D5;
    case 0x83B2D8u: goto L_83B2D8;
    case 0x83B2D9u: goto L_83B2D9;
    case 0x83B2DCu: goto L_83B2DC;
    case 0x83B2DFu: goto L_83B2DF;
    case 0x83B2E2u: goto L_83B2E2;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B2CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2CEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2CE LDA
    cpu.setA(0xB000u, 16);
    goto L_83B2D1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2CEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2CE LDA
    cpu.setA(0xB000u, 16);
    goto L_83B2D1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2CEu,0x83B2CEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 8u, 4u, 0x809126u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B2D1 JSL -> $809126 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809126u, 0x83B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B2D5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D1u, 8u, 4u, 0x809126u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83B2D1 JSL -> $809126 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB2D4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB2D5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809126u, 0x83B2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83B2D5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D1u,0x83B2D1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D5u,0x83B2D5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2D5 LDY
    cpu.setY(0x8u, 16);
    goto L_83B2D8;
L_83B2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2D8 TYA
    cpu.transfer("TYA");
    goto L_83B2D9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2D8 TYA
    cpu.transfer("TYA");
    goto L_83B2D9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D8u,0x83B2D8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2D9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2D9 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_83B2DC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2D9u, 6u, 3u, cpu.address("absx", 0x10C8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2D9 STA
    hw.write(cpu.address("absx", 0x10C8u), cpu.a, cpu.m8?8:16);
    goto L_83B2DC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2D9u,0x83B2D9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2DC LDA
    cpu.setA(0xAu, 16);
    goto L_83B2DF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2DC LDA
    cpu.setA(0xAu, 16);
    goto L_83B2DF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2DCu,0x83B2DCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2DFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 6u, 3u, cpu.address("absx", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2DF STA
    hw.write(cpu.address("absx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B2E2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2DFu, 6u, 3u, cpu.address("absx", 0x0040u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2DF STA
    hw.write(cpu.address("absx", 0x40u), cpu.a, cpu.m8?8:16);
    goto L_83B2E2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2DFu,0x83B2DFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83B2E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2E2u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E2u, 3u, 3u, cpu.address("abs", 0xB06Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2E2 JMP -> $83B06D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB06Du),0x83B2E2u); return;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2E2u, 3u, 3u, cpu.address("abs", 0xB06Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B2E2 JMP -> $83B06D
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB06Du),0x83B2E2u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2E2u,0x83B2E2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83C93A_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CA1Cu: goto L_83CA1C;
    case 0x83CA1Fu: goto L_83CA1F;
    case 0x83CA21u: goto L_83CA21;
    case 0x83CA22u: goto L_83CA22;
    case 0x83CA24u: goto L_83CA24;
    case 0x83CA26u: goto L_83CA26;
    case 0x83CA27u: goto L_83CA27;
    case 0x83CA29u: goto L_83CA29;
    case 0x83CA2Bu: goto L_83CA2B;
    case 0x83CA2Du: goto L_83CA2D;
    case 0x83CA2Eu: goto L_83CA2E;
    case 0x83CA30u: goto L_83CA30;
    case 0x83CA31u: goto L_83CA31;
    case 0x83CA32u: goto L_83CA32;
    case 0x83CA34u: goto L_83CA34;
    case 0x83CA36u: goto L_83CA36;
    case 0x83CA38u: goto L_83CA38;
    case 0x83CA39u: goto L_83CA39;
    case 0x83CA3Bu: goto L_83CA3B;
    case 0x83CA3Du: goto L_83CA3D;
    case 0x83CA3Fu: goto L_83CA3F;
    case 0x83CA41u: goto L_83CA41;
    case 0x83CA43u: goto L_83CA43;
    case 0x83CA44u: goto L_83CA44;
    case 0x83CA47u: goto L_83CA47;
    case 0x83CA48u: goto L_83CA48;
    case 0x83CA4Au: goto L_83CA4A;
    case 0x83CA4Du: goto L_83CA4D;
    case 0x83CA4Eu: goto L_83CA4E;
    case 0x83CA50u: goto L_83CA50;
    case 0x83CA52u: goto L_83CA52;
    case 0x83CA55u: goto L_83CA55;
    case 0x83CA57u: goto L_83CA57;
    case 0x83CA5Au: goto L_83CA5A;
    case 0x83CA5Cu: goto L_83CA5C;
    case 0x83CA5Fu: goto L_83CA5F;
    case 0x83CA61u: goto L_83CA61;
    case 0x83CA64u: goto L_83CA64;
    case 0x83CA67u: goto L_83CA67;
    case 0x83CA69u: goto L_83CA69;
    case 0x83CA6Bu: goto L_83CA6B;
    case 0x83CA6Du: goto L_83CA6D;
    case 0x83CA6Fu: goto L_83CA6F;
    case 0x83CA72u: goto L_83CA72;
    case 0x83CA73u: goto L_83CA73;
    case 0x83CA75u: goto L_83CA75;
    case 0x83CA78u: goto L_83CA78;
    case 0x83CA79u: goto L_83CA79;
    case 0x83CA7Cu: goto L_83CA7C;
    case 0x83CA7Du: goto L_83CA7D;
    case 0x83CA7Fu: goto L_83CA7F;
    case 0x83CA81u: goto L_83CA81;
    case 0x83CA84u: goto L_83CA84;
    case 0x83CA86u: goto L_83CA86;
    case 0x83CA89u: goto L_83CA89;
    case 0x83CA8Bu: goto L_83CA8B;
    case 0x83CA8Eu: goto L_83CA8E;
    case 0x83CA90u: goto L_83CA90;
    case 0x83CA93u: goto L_83CA93;
    case 0x83CA96u: goto L_83CA96;
    case 0x83CA98u: goto L_83CA98;
    case 0x83CA9Au: goto L_83CA9A;
    case 0x83CA9Du: goto L_83CA9D;
    case 0x83CA9Fu: goto L_83CA9F;
    case 0x83CAA0u: goto L_83CAA0;
    case 0x83CAA2u: goto L_83CAA2;
    case 0x83CAA5u: goto L_83CAA5;
    case 0x83CAA7u: goto L_83CAA7;
    case 0x83CAA9u: goto L_83CAA9;
    case 0x83CAACu: goto L_83CAAC;
    case 0x83CAAEu: goto L_83CAAE;
    case 0x83CAB2u: goto L_83CAB2;
    case 0x83CAB4u: goto L_83CAB4;
    case 0x83CAB8u: goto L_83CAB8;
    case 0x83CABAu: goto L_83CABA;
    case 0x83CABCu: goto L_83CABC;
    case 0x83CAC0u: goto L_83CAC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,0x83CA1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,0x83CA1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA21u,0x83CA21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA24;
L_83CA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA24 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA26;
L_83CA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA26 PHA
    cpu.push("PHA", hw);
    goto L_83CA27;
L_83CA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA27 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA29;
L_83CA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA29 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA2B;
L_83CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA2D;
L_83CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2D ASL
    cpu.aslA();
    goto L_83CA2E;
L_83CA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2E ROR
    cpu.rorMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_83CA30;
L_83CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA30 PLA
    cpu.pop("PLA", hw);
    goto L_83CA31;
L_83CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA31 SEC
    cpu.setFlag('C', true);
    goto L_83CA32;
L_83CA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA34;
L_83CA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA34 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83CA36;
L_83CA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA36 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA38;
L_83CA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA38 CLC
    cpu.setFlag('C', false);
    goto L_83CA39;
L_83CA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA39 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3B;
L_83CA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA3D;
L_83CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3F;
L_83CA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA41;
L_83CA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA41 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA43;
L_83CA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA43 PLY
    cpu.pop("PLY", hw);
    goto L_83CA44;
L_83CA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA44 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA47;
L_83CA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA47 SEC
    cpu.setFlag('C', true);
    goto L_83CA48;
L_83CA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA48 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA4A;
L_83CA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_83CA4D;
L_83CA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4D SEC
    cpu.setFlag('C', true);
    goto L_83CA4E;
L_83CA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83CA50;
L_83CA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA50 BMI -> $83CA5C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA5C; }
    goto L_83CA52;
L_83CA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA52 CMP
    cpu.compareA(0x10u);
    goto L_83CA55;
L_83CA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA55 BCC -> $83CA64
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA57;
L_83CA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA57 LDA
    cpu.setA(0x10u, 16);
    goto L_83CA5A;
L_83CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5A BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA5C;
L_83CA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5C CMP
    cpu.compareA(0xFFF0u);
    goto L_83CA5F;
L_83CA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5F BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA61;
L_83CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA61 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_83CA64;
L_83CA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA64 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83CA67;
L_83CA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA67 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_83CA69;
L_83CA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA6B;
L_83CA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA6D;
L_83CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA6F;
L_83CA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA72;
L_83CA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA72 CLC
    cpu.setFlag('C', false);
    goto L_83CA73;
L_83CA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA73 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA75;
L_83CA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA75 ADC
    cpu.adc(0x400u);
    goto L_83CA78;
L_83CA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA78 SEC
    cpu.setFlag('C', true);
    goto L_83CA79;
L_83CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA79 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83CA7C;
L_83CA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7C SEC
    cpu.setFlag('C', true);
    goto L_83CA7D;
L_83CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83CA7F;
L_83CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7F BMI -> $83CA8B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA8B; }
    goto L_83CA81;
L_83CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA81 CMP
    cpu.compareA(0x8u);
    goto L_83CA84;
L_83CA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA84 BCC -> $83CA93
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA86;
L_83CA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA86 LDA
    cpu.setA(0x8u, 16);
    goto L_83CA89;
L_83CA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA89 BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA8B;
L_83CA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8B CMP
    cpu.compareA(0xFFF8u);
    goto L_83CA8E;
L_83CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8E BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA90;
L_83CA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA90 LDA
    cpu.setA(0xFFF8u, 16);
    goto L_83CA93;
L_83CA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u, 6u, 3u, cpu.address("absy", 0x0016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA93 STA
    hw.write(cpu.address("absy", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83CA96;
L_83CA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA96 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA98;
L_83CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA98 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CA9A;
L_83CA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA9D;
L_83CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA9F;
L_83CA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9F CLC
    cpu.setFlag('C', false);
    goto L_83CAA0;
L_83CAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA0 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_83CAA2;
L_83CAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA2 AND
    cpu.logicAnd(0xFu);
    goto L_83CAA5;
L_83CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA5 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAA7;
L_83CAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAA9;
L_83CAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA9 CMP
    cpu.compareA(0x3u);
    goto L_83CAAC;
L_83CAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAAC BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAAE;
L_83CAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAAE JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x83CAAEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB2;
L_83CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB2u,0x83CAB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB2 BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAB4;
L_83CAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAB4 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x83CAB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB8;
L_83CAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB8u,0x83CAB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABAu,0x83CABAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABCu,0x83CABCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAC0u,0x83CAC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83C93A_E0M0X0C1_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CA1Cu: goto L_83CA1C;
    case 0x83CA1Fu: goto L_83CA1F;
    case 0x83CA21u: goto L_83CA21;
    case 0x83CA22u: goto L_83CA22;
    case 0x83CA24u: goto L_83CA24;
    case 0x83CA26u: goto L_83CA26;
    case 0x83CA27u: goto L_83CA27;
    case 0x83CA29u: goto L_83CA29;
    case 0x83CA2Bu: goto L_83CA2B;
    case 0x83CA2Du: goto L_83CA2D;
    case 0x83CA2Eu: goto L_83CA2E;
    case 0x83CA30u: goto L_83CA30;
    case 0x83CA31u: goto L_83CA31;
    case 0x83CA32u: goto L_83CA32;
    case 0x83CA34u: goto L_83CA34;
    case 0x83CA36u: goto L_83CA36;
    case 0x83CA38u: goto L_83CA38;
    case 0x83CA39u: goto L_83CA39;
    case 0x83CA3Bu: goto L_83CA3B;
    case 0x83CA3Du: goto L_83CA3D;
    case 0x83CA3Fu: goto L_83CA3F;
    case 0x83CA41u: goto L_83CA41;
    case 0x83CA43u: goto L_83CA43;
    case 0x83CA44u: goto L_83CA44;
    case 0x83CA47u: goto L_83CA47;
    case 0x83CA48u: goto L_83CA48;
    case 0x83CA4Au: goto L_83CA4A;
    case 0x83CA4Du: goto L_83CA4D;
    case 0x83CA4Eu: goto L_83CA4E;
    case 0x83CA50u: goto L_83CA50;
    case 0x83CA52u: goto L_83CA52;
    case 0x83CA55u: goto L_83CA55;
    case 0x83CA57u: goto L_83CA57;
    case 0x83CA5Au: goto L_83CA5A;
    case 0x83CA5Cu: goto L_83CA5C;
    case 0x83CA5Fu: goto L_83CA5F;
    case 0x83CA61u: goto L_83CA61;
    case 0x83CA64u: goto L_83CA64;
    case 0x83CA67u: goto L_83CA67;
    case 0x83CA69u: goto L_83CA69;
    case 0x83CA6Bu: goto L_83CA6B;
    case 0x83CA6Du: goto L_83CA6D;
    case 0x83CA6Fu: goto L_83CA6F;
    case 0x83CA72u: goto L_83CA72;
    case 0x83CA73u: goto L_83CA73;
    case 0x83CA75u: goto L_83CA75;
    case 0x83CA78u: goto L_83CA78;
    case 0x83CA79u: goto L_83CA79;
    case 0x83CA7Cu: goto L_83CA7C;
    case 0x83CA7Du: goto L_83CA7D;
    case 0x83CA7Fu: goto L_83CA7F;
    case 0x83CA81u: goto L_83CA81;
    case 0x83CA84u: goto L_83CA84;
    case 0x83CA86u: goto L_83CA86;
    case 0x83CA89u: goto L_83CA89;
    case 0x83CA8Bu: goto L_83CA8B;
    case 0x83CA8Eu: goto L_83CA8E;
    case 0x83CA90u: goto L_83CA90;
    case 0x83CA93u: goto L_83CA93;
    case 0x83CA96u: goto L_83CA96;
    case 0x83CA98u: goto L_83CA98;
    case 0x83CA9Au: goto L_83CA9A;
    case 0x83CA9Du: goto L_83CA9D;
    case 0x83CA9Fu: goto L_83CA9F;
    case 0x83CAA0u: goto L_83CAA0;
    case 0x83CAA2u: goto L_83CAA2;
    case 0x83CAA5u: goto L_83CAA5;
    case 0x83CAA7u: goto L_83CAA7;
    case 0x83CAA9u: goto L_83CAA9;
    case 0x83CAACu: goto L_83CAAC;
    case 0x83CAAEu: goto L_83CAAE;
    case 0x83CAB2u: goto L_83CAB2;
    case 0x83CAB4u: goto L_83CAB4;
    case 0x83CAB8u: goto L_83CAB8;
    case 0x83CABAu: goto L_83CABA;
    case 0x83CABCu: goto L_83CABC;
    case 0x83CAC0u: goto L_83CAC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,0x83CA1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,0x83CA1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA21u,0x83CA21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA24;
L_83CA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA24 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA26;
L_83CA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA26 PHA
    cpu.push("PHA", hw);
    goto L_83CA27;
L_83CA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA27 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA29;
L_83CA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA29 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA2B;
L_83CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA2D;
L_83CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2D ASL
    cpu.aslA();
    goto L_83CA2E;
L_83CA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2E ROR
    cpu.rorMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_83CA30;
L_83CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA30 PLA
    cpu.pop("PLA", hw);
    goto L_83CA31;
L_83CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA31 SEC
    cpu.setFlag('C', true);
    goto L_83CA32;
L_83CA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA34;
L_83CA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA34 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83CA36;
L_83CA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA36 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA38;
L_83CA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA38 CLC
    cpu.setFlag('C', false);
    goto L_83CA39;
L_83CA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA39 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3B;
L_83CA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA3D;
L_83CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3F;
L_83CA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA41;
L_83CA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA41 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA43;
L_83CA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA43 PLY
    cpu.pop("PLY", hw);
    goto L_83CA44;
L_83CA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA44 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA47;
L_83CA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA47 SEC
    cpu.setFlag('C', true);
    goto L_83CA48;
L_83CA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA48 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA4A;
L_83CA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_83CA4D;
L_83CA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4D SEC
    cpu.setFlag('C', true);
    goto L_83CA4E;
L_83CA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83CA50;
L_83CA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA50 BMI -> $83CA5C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA5C; }
    goto L_83CA52;
L_83CA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA52 CMP
    cpu.compareA(0x10u);
    goto L_83CA55;
L_83CA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA55 BCC -> $83CA64
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA57;
L_83CA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA57 LDA
    cpu.setA(0x10u, 16);
    goto L_83CA5A;
L_83CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5A BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA5C;
L_83CA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5C CMP
    cpu.compareA(0xFFF0u);
    goto L_83CA5F;
L_83CA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5F BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA61;
L_83CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA61 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_83CA64;
L_83CA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA64 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83CA67;
L_83CA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA67 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_83CA69;
L_83CA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA6B;
L_83CA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA6D;
L_83CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA6F;
L_83CA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA72;
L_83CA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA72 CLC
    cpu.setFlag('C', false);
    goto L_83CA73;
L_83CA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA73 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA75;
L_83CA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA75 ADC
    cpu.adc(0x400u);
    goto L_83CA78;
L_83CA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA78 SEC
    cpu.setFlag('C', true);
    goto L_83CA79;
L_83CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA79 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83CA7C;
L_83CA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7C SEC
    cpu.setFlag('C', true);
    goto L_83CA7D;
L_83CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83CA7F;
L_83CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7F BMI -> $83CA8B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA8B; }
    goto L_83CA81;
L_83CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA81 CMP
    cpu.compareA(0x8u);
    goto L_83CA84;
L_83CA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA84 BCC -> $83CA93
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA86;
L_83CA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA86 LDA
    cpu.setA(0x8u, 16);
    goto L_83CA89;
L_83CA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA89 BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA8B;
L_83CA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8B CMP
    cpu.compareA(0xFFF8u);
    goto L_83CA8E;
L_83CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8E BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA90;
L_83CA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA90 LDA
    cpu.setA(0xFFF8u, 16);
    goto L_83CA93;
L_83CA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u, 6u, 3u, cpu.address("absy", 0x0016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA93 STA
    hw.write(cpu.address("absy", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83CA96;
L_83CA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA96 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA98;
L_83CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA98 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CA9A;
L_83CA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA9D;
L_83CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA9F;
L_83CA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9F CLC
    cpu.setFlag('C', false);
    goto L_83CAA0;
L_83CAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA0 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_83CAA2;
L_83CAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA2 AND
    cpu.logicAnd(0xFu);
    goto L_83CAA5;
L_83CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA5 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAA7;
L_83CAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAA9;
L_83CAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA9 CMP
    cpu.compareA(0x3u);
    goto L_83CAAC;
L_83CAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAAC BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAAE;
L_83CAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAAE JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x83CAAEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB2;
L_83CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB2u,0x83CAB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB2 BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAB4;
L_83CAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAB4 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x83CAB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB8;
L_83CAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB8u,0x83CAB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABAu,0x83CABAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABCu,0x83CABCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAC0u,0x83CAC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83C93A_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CA1Cu: goto L_83CA1C;
    case 0x83CA1Fu: goto L_83CA1F;
    case 0x83CA21u: goto L_83CA21;
    case 0x83CA22u: goto L_83CA22;
    case 0x83CA24u: goto L_83CA24;
    case 0x83CA26u: goto L_83CA26;
    case 0x83CA27u: goto L_83CA27;
    case 0x83CA29u: goto L_83CA29;
    case 0x83CA2Bu: goto L_83CA2B;
    case 0x83CA2Du: goto L_83CA2D;
    case 0x83CA2Eu: goto L_83CA2E;
    case 0x83CA30u: goto L_83CA30;
    case 0x83CA31u: goto L_83CA31;
    case 0x83CA32u: goto L_83CA32;
    case 0x83CA34u: goto L_83CA34;
    case 0x83CA36u: goto L_83CA36;
    case 0x83CA38u: goto L_83CA38;
    case 0x83CA39u: goto L_83CA39;
    case 0x83CA3Bu: goto L_83CA3B;
    case 0x83CA3Du: goto L_83CA3D;
    case 0x83CA3Fu: goto L_83CA3F;
    case 0x83CA41u: goto L_83CA41;
    case 0x83CA43u: goto L_83CA43;
    case 0x83CA44u: goto L_83CA44;
    case 0x83CA47u: goto L_83CA47;
    case 0x83CA48u: goto L_83CA48;
    case 0x83CA4Au: goto L_83CA4A;
    case 0x83CA4Du: goto L_83CA4D;
    case 0x83CA4Eu: goto L_83CA4E;
    case 0x83CA50u: goto L_83CA50;
    case 0x83CA52u: goto L_83CA52;
    case 0x83CA55u: goto L_83CA55;
    case 0x83CA57u: goto L_83CA57;
    case 0x83CA5Au: goto L_83CA5A;
    case 0x83CA5Cu: goto L_83CA5C;
    case 0x83CA5Fu: goto L_83CA5F;
    case 0x83CA61u: goto L_83CA61;
    case 0x83CA64u: goto L_83CA64;
    case 0x83CA67u: goto L_83CA67;
    case 0x83CA69u: goto L_83CA69;
    case 0x83CA6Bu: goto L_83CA6B;
    case 0x83CA6Du: goto L_83CA6D;
    case 0x83CA6Fu: goto L_83CA6F;
    case 0x83CA72u: goto L_83CA72;
    case 0x83CA73u: goto L_83CA73;
    case 0x83CA75u: goto L_83CA75;
    case 0x83CA78u: goto L_83CA78;
    case 0x83CA79u: goto L_83CA79;
    case 0x83CA7Cu: goto L_83CA7C;
    case 0x83CA7Du: goto L_83CA7D;
    case 0x83CA7Fu: goto L_83CA7F;
    case 0x83CA81u: goto L_83CA81;
    case 0x83CA84u: goto L_83CA84;
    case 0x83CA86u: goto L_83CA86;
    case 0x83CA89u: goto L_83CA89;
    case 0x83CA8Bu: goto L_83CA8B;
    case 0x83CA8Eu: goto L_83CA8E;
    case 0x83CA90u: goto L_83CA90;
    case 0x83CA93u: goto L_83CA93;
    case 0x83CA96u: goto L_83CA96;
    case 0x83CA98u: goto L_83CA98;
    case 0x83CA9Au: goto L_83CA9A;
    case 0x83CA9Du: goto L_83CA9D;
    case 0x83CA9Fu: goto L_83CA9F;
    case 0x83CAA0u: goto L_83CAA0;
    case 0x83CAA2u: goto L_83CAA2;
    case 0x83CAA5u: goto L_83CAA5;
    case 0x83CAA7u: goto L_83CAA7;
    case 0x83CAA9u: goto L_83CAA9;
    case 0x83CAACu: goto L_83CAAC;
    case 0x83CAAEu: goto L_83CAAE;
    case 0x83CAB2u: goto L_83CAB2;
    case 0x83CAB4u: goto L_83CAB4;
    case 0x83CAB8u: goto L_83CAB8;
    case 0x83CABAu: goto L_83CABA;
    case 0x83CABCu: goto L_83CABC;
    case 0x83CAC0u: goto L_83CAC0;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Cu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Cu, 5u + 1u, 3u, cpu.address("absy", 0x1BF2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1BF2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA1F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Cu,0x83CA1Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA1Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA1Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA1F STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CA21;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA1Fu,0x83CA1Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA21u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA21u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA21 SEC
    cpu.setFlag('C', true);
    goto L_83CA22;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCA21u,0x83CA21u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA22u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA22 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA24;
L_83CA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA24u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA24 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA26;
L_83CA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA26u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA26 PHA
    cpu.push("PHA", hw);
    goto L_83CA27;
L_83CA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA27u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA27 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA29;
L_83CA29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u,cpu,0xF5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA29u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA29 SBC
    cpu.sbc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA2B;
L_83CA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA2D;
L_83CA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2D ASL
    cpu.aslA();
    goto L_83CA2E;
L_83CA2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu,cpu,0x66u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA2Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA2E ROR
    cpu.rorMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_83CA30;
L_83CA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA30u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA30 PLA
    cpu.pop("PLA", hw);
    goto L_83CA31;
L_83CA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA31u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA31 SEC
    cpu.setFlag('C', true);
    goto L_83CA32;
L_83CA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA32u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA32 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA34;
L_83CA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA34u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA34 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83CA36;
L_83CA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA36 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CA38;
L_83CA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA38 CLC
    cpu.setFlag('C', false);
    goto L_83CA39;
L_83CA39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA39u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA39 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3B;
L_83CA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3B ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x8u), cpu.m8?8:16));
    goto L_83CA3D;
L_83CA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA3F;
L_83CA3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA3Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA3F ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83CA41;
L_83CA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA41 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA43;
L_83CA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA43u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CA43 PLY
    cpu.pop("PLY", hw);
    goto L_83CA44;
L_83CA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA44u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA44 LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA47;
L_83CA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA47 SEC
    cpu.setFlag('C', true);
    goto L_83CA48;
L_83CA48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA48u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA48 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA4A;
L_83CA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Au, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_83CA4D;
L_83CA4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4D SEC
    cpu.setFlag('C', true);
    goto L_83CA4E;
L_83CA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA4Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA4E SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83CA50;
L_83CA50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA50 BMI -> $83CA5C
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA5C; }
    goto L_83CA52;
L_83CA52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA52u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA52 CMP
    cpu.compareA(0x10u);
    goto L_83CA55;
L_83CA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA55 BCC -> $83CA64
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA57;
L_83CA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA57 LDA
    cpu.setA(0x10u, 16);
    goto L_83CA5A;
L_83CA5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5A BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA5C;
L_83CA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5C CMP
    cpu.compareA(0xFFF0u);
    goto L_83CA5F;
L_83CA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA5F BCS -> $83CA64
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA64; }
    goto L_83CA61;
L_83CA61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA61u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA61 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_83CA64;
L_83CA64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA64u, 6u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA64 STA
    hw.write(cpu.address("absy", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_83CA67;
L_83CA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA67u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA67 STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_83CA69;
L_83CA69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA6B;
L_83CA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6B STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CA6D;
L_83CA6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6D LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA6F;
L_83CA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA6Fu, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA6F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA72;
L_83CA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA72u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA72 CLC
    cpu.setFlag('C', false);
    goto L_83CA73;
L_83CA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA73u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA73 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA75;
L_83CA75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA75u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA75 ADC
    cpu.adc(0x400u);
    goto L_83CA78;
L_83CA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA78u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA78 SEC
    cpu.setFlag('C', true);
    goto L_83CA79;
L_83CA79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA79u, 5u + 1u, 3u, cpu.address("absy", 0x0002u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA79 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83CA7C;
L_83CA7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7C SEC
    cpu.setFlag('C', true);
    goto L_83CA7D;
L_83CA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7D SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83CA7F;
L_83CA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA7Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA7F BMI -> $83CA8B
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CA8B; }
    goto L_83CA81;
L_83CA81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA81u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA81 CMP
    cpu.compareA(0x8u);
    goto L_83CA84;
L_83CA84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA84u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA84 BCC -> $83CA93
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA86;
L_83CA86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA86 LDA
    cpu.setA(0x8u, 16);
    goto L_83CA89;
L_83CA89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA89u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA89 BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA8B;
L_83CA8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8B CMP
    cpu.compareA(0xFFF8u);
    goto L_83CA8E;
L_83CA8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA8Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA8E BCS -> $83CA93
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CA93; }
    goto L_83CA90;
L_83CA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA90 LDA
    cpu.setA(0xFFF8u, 16);
    goto L_83CA93;
L_83CA93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA93u, 6u, 3u, cpu.address("absy", 0x0016u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA93 STA
    hw.write(cpu.address("absy", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_83CA96;
L_83CA96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA96u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA96 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA98;
L_83CA98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA98u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA98u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA98 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CA9A;
L_83CA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Au, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9A LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CA9D;
L_83CA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CA9F;
L_83CA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CA9F CLC
    cpu.setFlag('C', false);
    goto L_83CAA0;
L_83CAA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u,cpu,0x75u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA0 ADC
    cpu.adc(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16));
    goto L_83CAA2;
L_83CAA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA2 AND
    cpu.logicAnd(0xFu);
    goto L_83CAA5;
L_83CAA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA5 BNE -> $83CAC0
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAA7;
L_83CAA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA7 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAA9;
L_83CAA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAA9 CMP
    cpu.compareA(0x3u);
    goto L_83CAAC;
L_83CAAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAAC BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAAE;
L_83CAAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAAEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAAEu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAAE JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x83CAAEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB2;
L_83CAB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB2u,0x83CAB2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB2 BCS -> $83CAC0
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CAB4;
L_83CAB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB4u, 8u, 4u, 0x83CD3Cu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAB4 JSL -> $83CD3C stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCAB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CD3Cu, 0x83CAB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAB8;
L_83CAB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAB8u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAB8 BCC -> $83CAC0
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CAC0; }
    goto L_83CABA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAB8u,0x83CAB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CABA STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CABC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABAu,0x83CABAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CABC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCABCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCABCu, 8u, 4u, 0x83C49Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CABC JSL -> $83C49D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCABFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83C49Du, 0x83CABCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCABCu,0x83CABCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CAC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAC0 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CAC0u);return;} hw.unresolvedReturn(0x83CAC0u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAC0u,0x83CAC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83CAC5_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CAC1u: goto L_83CAC1;
    case 0x83CAC2u: goto L_83CAC2;
    case 0x83CAC4u: goto L_83CAC4;
    case 0x83CAC5u: goto L_83CAC5;
    case 0x83CAC8u: goto L_83CAC8;
    case 0x83CAC9u: goto L_83CAC9;
    case 0x83CACBu: goto L_83CACB;
    case 0x83CACEu: goto L_83CACE;
    case 0x83CAD0u: goto L_83CAD0;
    case 0x83CAD3u: goto L_83CAD3;
    case 0x83CAD5u: goto L_83CAD5;
    case 0x83CAD7u: goto L_83CAD7;
    case 0x83CAD8u: goto L_83CAD8;
    case 0x83CAD9u: goto L_83CAD9;
    case 0x83CADCu: goto L_83CADC;
    case 0x83CADDu: goto L_83CADD;
    case 0x83CADFu: goto L_83CADF;
    case 0x83CAE2u: goto L_83CAE2;
    case 0x83CAE5u: goto L_83CAE5;
    case 0x83CAE7u: goto L_83CAE7;
    case 0x83CAE9u: goto L_83CAE9;
    case 0x83CAECu: goto L_83CAEC;
    case 0x83CAEFu: goto L_83CAEF;
    case 0x83CAF2u: goto L_83CAF2;
    case 0x83CAF3u: goto L_83CAF3;
    case 0x83CAF6u: goto L_83CAF6;
    case 0x83CAF8u: goto L_83CAF8;
    case 0x83CAF9u: goto L_83CAF9;
    case 0x83CAFBu: goto L_83CAFB;
    case 0x83CAFDu: goto L_83CAFD;
    case 0x83CB00u: goto L_83CB00;
    case 0x83CB01u: goto L_83CB01;
    case 0x83CB03u: goto L_83CB03;
    case 0x83CB04u: goto L_83CB04;
    case 0x83CB07u: goto L_83CB07;
    case 0x83CB09u: goto L_83CB09;
    case 0x83CB0Bu: goto L_83CB0B;
    case 0x83CB0Eu: goto L_83CB0E;
    case 0x83CB10u: goto L_83CB10;
    case 0x83CB11u: goto L_83CB11;
    case 0x83CB14u: goto L_83CB14;
    case 0x83CB17u: goto L_83CB17;
    case 0x83CB19u: goto L_83CB19;
    case 0x83CB1Cu: goto L_83CB1C;
    case 0x83CB1Du: goto L_83CB1D;
    case 0x83CB1Fu: goto L_83CB1F;
    case 0x83CB22u: goto L_83CB22;
    case 0x83CB24u: goto L_83CB24;
    case 0x83CB27u: goto L_83CB27;
    case 0x83CB29u: goto L_83CB29;
    case 0x83CB2Cu: goto L_83CB2C;
    case 0x83CB2Eu: goto L_83CB2E;
    case 0x83CB31u: goto L_83CB31;
    case 0x83CB33u: goto L_83CB33;
    case 0x83CB34u: goto L_83CB34;
    case 0x83CB36u: goto L_83CB36;
    case 0x83CB37u: goto L_83CB37;
    case 0x83CB38u: goto L_83CB38;
    case 0x83CB3Au: goto L_83CB3A;
    case 0x83CB3Cu: goto L_83CB3C;
    case 0x83CB3Eu: goto L_83CB3E;
    case 0x83CB3Fu: goto L_83CB3F;
    case 0x83CB41u: goto L_83CB41;
    case 0x83CB43u: goto L_83CB43;
    case 0x83CB45u: goto L_83CB45;
    case 0x83CB48u: goto L_83CB48;
    case 0x83CB49u: goto L_83CB49;
    case 0x83CB4Bu: goto L_83CB4B;
    case 0x83CB4Du: goto L_83CB4D;
    case 0x83CB4Fu: goto L_83CB4F;
    case 0x83CB52u: goto L_83CB52;
    case 0x83CB53u: goto L_83CB53;
    case 0x83CB54u: goto L_83CB54;
    case 0x83CB57u: goto L_83CB57;
    case 0x83CB59u: goto L_83CB59;
    case 0x83CB5Bu: goto L_83CB5B;
    case 0x83CB5Cu: goto L_83CB5C;
    case 0x83CB5Eu: goto L_83CB5E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CAC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAC1 TDC
    cpu.tdc();
    goto L_83CAC2;
L_83CAC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAC2 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CAC4;
L_83CAC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CAC4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CAC4u);return;} hw.unresolvedReturn(0x83CAC4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CAC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC5u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAC5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAC8;
L_83CAC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAC8 LSR
    cpu.lsrA();
    goto L_83CAC9;
L_83CAC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAC9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAC9 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16));
    goto L_83CACB;
L_83CACB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CACB AND
    cpu.logicAnd(0x3u);
    goto L_83CACE;
L_83CACE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCACEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCACEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CACE BNE -> $83CAC1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CAC1; }
    goto L_83CAD0;
L_83CAD0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD0u, 5u, 3u, cpu.address("abs", 0x1BF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BF0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAD3;
L_83CAD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD3 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_83CAD5;
L_83CAD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAD7;
L_83CAD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD7 ASL
    cpu.aslA();
    goto L_83CAD8;
L_83CAD8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD8u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD8 TAY
    cpu.transfer("TAY");
    goto L_83CAD9;
L_83CAD9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAD9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAD9u, 5u + 1u, 3u, cpu.address("absy", 0xDD1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAD9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDD1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CADC;
L_83CADC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CADC ASL
    cpu.aslA();
    goto L_83CADD;
L_83CADD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CADD STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CADF;
L_83CADF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCADFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCADFu, 5u + 1u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CADF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAE2;
L_83CAE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE2u, 6u, 3u, cpu.address("abs", 0xCB5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAE2 JSR -> $83CB5F stack real
    { cpu.push16Value(hw,0xCAE4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAE5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB5Fu), 0x83CAE2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAE5;
L_83CAE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAE5u,0x83CAE5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAE5 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83CAE7;
L_83CAE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAE7 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CAE9;
L_83CAE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAE9u, 5u + 1u, 3u, cpu.address("absy", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAE9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CAEC;
L_83CAEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAECu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAECu, 6u, 3u, cpu.address("abs", 0xCB5Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CAEC JSR -> $83CB5F stack real
    { cpu.push16Value(hw,0xCAEEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCAEFu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCB5Fu), 0x83CAECu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83CAEF;
L_83CAEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAEFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCAEFu,0x83CAEFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEFu,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAEFu, 5u, 3u, cpu.address("abs", 0x1BFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAEF LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BFEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CAF2;
L_83CAF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAF2 CLC
    cpu.setFlag('C', false);
    goto L_83CAF3;
L_83CAF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u,cpu,0x79u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF3u, 5u + 1u, 3u, cpu.address("absy", 0xDC6Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAF3 ADC
    cpu.adc(hw.readW(cpu.address("absy", 0xDC6Du), cpu.m8?8:16));
    goto L_83CAF6;
L_83CAF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAF6 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_83CAF8;
L_83CAF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAF8 SEC
    cpu.setFlag('C', true);
    goto L_83CAF9;
L_83CAF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAF9 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83CAFB;
L_83CAFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFBu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAFB BCS -> $83CB03
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CB03; }
    goto L_83CAFD;
L_83CAFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCAFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCAFDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CAFD EOR
    cpu.logicXor(0xFFFFu);
    goto L_83CB00;
L_83CB00:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB00u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB00u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB00u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB00 INC
    cpu.inc('A');
    goto L_83CB01;
L_83CB01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB01u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB01 INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_83CB03;
L_83CB03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB03u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB03 TAY
    cpu.transfer("TAY");
    goto L_83CB04;
L_83CB04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB04u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB04u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB04 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB07;
L_83CB07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB07 BPL -> $83CB29
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CB29; }
    goto L_83CB09;
L_83CB09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB09u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB09u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB09 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB0B;
L_83CB0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB0B CMP
    cpu.compareA(0x1u);
    goto L_83CB0E;
L_83CB0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB0Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB0E BEQ -> $83CB1F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CB1F; }
    goto L_83CB10;
L_83CB10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB10u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB10u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CB10 PHY
    cpu.push("PHY", hw);
    goto L_83CB11;
L_83CB11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB11u, 5u, 3u, cpu.address("abs", 0x1BA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB11 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BA0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83CB14;
L_83CB14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB14u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB14u, 5u + 1u, 3u, cpu.address("absy", 0x1B70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB14 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B70u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB17;
L_83CB17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB17u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB17 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CB19;
L_83CB19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB19u, 5u + 1u, 3u, cpu.address("absy", 0x1B7Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB19 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1B7Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB1C;
L_83CB1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CB1C PLY
    cpu.pop("PLY", hw);
    goto L_83CB1D;
L_83CB1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB1D BRA -> $83CB31
    goto L_83CB31;
L_83CB1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB1Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB1F LDA
    cpu.setA(0x30u, 16);
    goto L_83CB22;
L_83CB22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB22u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB22 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CB24;
L_83CB24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB24u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB24u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB24 LDA
    cpu.setA(0x300u, 16);
    goto L_83CB27;
L_83CB27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB27u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB27 BRA -> $83CB31
    goto L_83CB31;
L_83CB29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB29u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB29u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB29 LDA
    cpu.setA(0x18u, 16);
    goto L_83CB2C;
L_83CB2C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB2C STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83CB2E;
L_83CB2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB2E LDA
    cpu.setA(0x140u, 16);
    goto L_83CB31;
L_83CB31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB31u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB31 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_83CB33;
L_83CB33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB33 TYA
    cpu.transfer("TYA");
    goto L_83CB34;
L_83CB34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB34 BEQ -> $83CB41
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CB41; }
    goto L_83CB36;
L_83CB36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB36u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB36 TDC
    cpu.tdc();
    goto L_83CB37;
L_83CB37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB37u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB37 CLC
    cpu.setFlag('C', false);
    goto L_83CB38;
L_83CB38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB38u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB38u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB38 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83CB3A;
L_83CB3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB3A CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_83CB3C;
L_83CB3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB3C BCS -> $83CB41
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CB41; }
    goto L_83CB3E;
L_83CB3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB3E DEY
    cpu.decReg('Y');
    goto L_83CB3F;
L_83CB3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB3Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB3F BNE -> $83CB37
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CB37; }
    goto L_83CB41;
L_83CB41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB41u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB41u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB41 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_83CB43;
L_83CB43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB43u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB43 BCC -> $83CB49
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CB49; }
    goto L_83CB45;
L_83CB45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB45u,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB45u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB45 EOR
    cpu.logicXor(0xFFFFu);
    goto L_83CB48;
L_83CB48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB48u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB48 INC
    cpu.inc('A');
    goto L_83CB49;
L_83CB49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB49u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB49 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CB4B;
L_83CB4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB4B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB4D;
L_83CB4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB4D BEQ -> $83CB5C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CB5C; }
    goto L_83CB4F;
L_83CB4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB4Fu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB4F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB52;
L_83CB52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB52 ASL
    cpu.aslA();
    goto L_83CB53;
L_83CB53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB53u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB53 TAY
    cpu.transfer("TAY");
    goto L_83CB54;
L_83CB54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB54u, 5u + 1u, 3u, cpu.address("absy", 0xDC75u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB54 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xDC75u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB57;
L_83CB57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB57u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB57 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83CB59;
L_83CB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB59u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB59u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB59 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83CB5B;
L_83CB5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CB5B RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CB5Bu);return;} hw.unresolvedReturn(0x83CB5Bu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83CB5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CB5C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CB5E;
L_83CB5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCB5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCB5Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83CB5E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83CB5Eu);return;} hw.unresolvedReturn(0x83CB5Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83F094_E0M0X0C1_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F24Au: goto L_83F24A;
    case 0x83F24Eu: goto L_83F24E;
    case 0x83F251u: goto L_83F251;
    case 0x83F253u: goto L_83F253;
    case 0x83F255u: goto L_83F255;
    case 0x83F257u: goto L_83F257;
    case 0x83F259u: goto L_83F259;
    case 0x83F25Au: goto L_83F25A;
    case 0x83F25Bu: goto L_83F25B;
    case 0x83F25Du: goto L_83F25D;
    case 0x83F25Fu: goto L_83F25F;
    case 0x83F260u: goto L_83F260;
    case 0x83F262u: goto L_83F262;
    case 0x83F264u: goto L_83F264;
    case 0x83F267u: goto L_83F267;
    case 0x83F269u: goto L_83F269;
    case 0x83F26Au: goto L_83F26A;
    case 0x83F26Cu: goto L_83F26C;
    case 0x83F26Fu: goto L_83F26F;
    case 0x83F271u: goto L_83F271;
    case 0x83F272u: goto L_83F272;
    case 0x83F274u: goto L_83F274;
    case 0x83F276u: goto L_83F276;
    case 0x83F277u: goto L_83F277;
    case 0x83F278u: goto L_83F278;
    case 0x83F27Au: goto L_83F27A;
    case 0x83F27Cu: goto L_83F27C;
    case 0x83F27Du: goto L_83F27D;
    case 0x83F27Fu: goto L_83F27F;
    case 0x83F281u: goto L_83F281;
    case 0x83F284u: goto L_83F284;
    case 0x83F286u: goto L_83F286;
    case 0x83F287u: goto L_83F287;
    case 0x83F289u: goto L_83F289;
    case 0x83F28Cu: goto L_83F28C;
    case 0x83F28Eu: goto L_83F28E;
    case 0x83F28Fu: goto L_83F28F;
    case 0x83F292u: goto L_83F292;
    case 0x83F295u: goto L_83F295;
    case 0x83F297u: goto L_83F297;
    case 0x83F299u: goto L_83F299;
    case 0x83F29Cu: goto L_83F29C;
    case 0x83F29Eu: goto L_83F29E;
    case 0x83F2A0u: goto L_83F2A0;
    case 0x83F2A3u: goto L_83F2A3;
    case 0x83F2A5u: goto L_83F2A5;
    case 0x83F2A8u: goto L_83F2A8;
    case 0x83F2ABu: goto L_83F2AB;
    case 0x83F2ADu: goto L_83F2AD;
    case 0x83F2AEu: goto L_83F2AE;
    case 0x83F2B1u: goto L_83F2B1;
    case 0x83F2B4u: goto L_83F2B4;
    case 0x83F2B7u: goto L_83F2B7;
    case 0x83F2B9u: goto L_83F2B9;
    case 0x83F2BBu: goto L_83F2BB;
    case 0x83F2BDu: goto L_83F2BD;
    case 0x83F2BFu: goto L_83F2BF;
    case 0x83F2C0u: goto L_83F2C0;
    case 0x83F2C3u: goto L_83F2C3;
    case 0x83F2C5u: goto L_83F2C5;
    case 0x83F2C6u: goto L_83F2C6;
    case 0x83F2C8u: goto L_83F2C8;
    case 0x83F2CAu: goto L_83F2CA;
    case 0x83F2CCu: goto L_83F2CC;
    case 0x83F2CFu: goto L_83F2CF;
    case 0x83F2D1u: goto L_83F2D1;
    case 0x83F2D4u: goto L_83F2D4;
    case 0x83F2D5u: goto L_83F2D5;
    case 0x83F2D8u: goto L_83F2D8;
    case 0x83F2DAu: goto L_83F2DA;
    case 0x83F2DCu: goto L_83F2DC;
    case 0x83F2DFu: goto L_83F2DF;
    case 0x83F2E1u: goto L_83F2E1;
    case 0x83F2E5u: goto L_83F2E5;
    case 0x83F2E8u: goto L_83F2E8;
    case 0x83F2EAu: goto L_83F2EA;
    case 0x83F2ECu: goto L_83F2EC;
    case 0x83F2EEu: goto L_83F2EE;
    case 0x83F2F0u: goto L_83F2F0;
    case 0x83F2F1u: goto L_83F2F1;
    case 0x83F2F2u: goto L_83F2F2;
    case 0x83F2F4u: goto L_83F2F4;
    case 0x83F2F6u: goto L_83F2F6;
    case 0x83F2F7u: goto L_83F2F7;
    case 0x83F2F9u: goto L_83F2F9;
    case 0x83F2FBu: goto L_83F2FB;
    case 0x83F2FEu: goto L_83F2FE;
    case 0x83F300u: goto L_83F300;
    case 0x83F301u: goto L_83F301;
    case 0x83F303u: goto L_83F303;
    case 0x83F306u: goto L_83F306;
    case 0x83F308u: goto L_83F308;
    case 0x83F309u: goto L_83F309;
    case 0x83F30Bu: goto L_83F30B;
    case 0x83F30Du: goto L_83F30D;
    case 0x83F30Eu: goto L_83F30E;
    case 0x83F30Fu: goto L_83F30F;
    case 0x83F311u: goto L_83F311;
    case 0x83F313u: goto L_83F313;
    case 0x83F314u: goto L_83F314;
    case 0x83F316u: goto L_83F316;
    case 0x83F318u: goto L_83F318;
    case 0x83F31Bu: goto L_83F31B;
    case 0x83F31Du: goto L_83F31D;
    case 0x83F31Eu: goto L_83F31E;
    case 0x83F320u: goto L_83F320;
    case 0x83F323u: goto L_83F323;
    case 0x83F325u: goto L_83F325;
    case 0x83F326u: goto L_83F326;
    case 0x83F327u: goto L_83F327;
    case 0x83F329u: goto L_83F329;
    case 0x83F32Au: goto L_83F32A;
    case 0x83F32Du: goto L_83F32D;
    case 0x83F32Eu: goto L_83F32E;
    case 0x83F330u: goto L_83F330;
    case 0x83F332u: goto L_83F332;
    case 0x83F334u: goto L_83F334;
    case 0x83F335u: goto L_83F335;
    case 0x83F338u: goto L_83F338;
    case 0x83F33Au: goto L_83F33A;
    case 0x83F33Bu: goto L_83F33B;
    case 0x83F33Du: goto L_83F33D;
    case 0x83F33Fu: goto L_83F33F;
    case 0x83F341u: goto L_83F341;
    case 0x83F344u: goto L_83F344;
    case 0x83F346u: goto L_83F346;
    case 0x83F349u: goto L_83F349;
    case 0x83F34Au: goto L_83F34A;
    case 0x83F34Du: goto L_83F34D;
    case 0x83F34Fu: goto L_83F34F;
    case 0x83F351u: goto L_83F351;
    case 0x83F354u: goto L_83F354;
    case 0x83F356u: goto L_83F356;
    case 0x83F35Au: goto L_83F35A;
    case 0x83F35Du: goto L_83F35D;
    case 0x83F35Fu: goto L_83F35F;
    case 0x83F361u: goto L_83F361;
    case 0x83F363u: goto L_83F363;
    case 0x83F365u: goto L_83F365;
    case 0x83F366u: goto L_83F366;
    case 0x83F367u: goto L_83F367;
    case 0x83F369u: goto L_83F369;
    case 0x83F36Bu: goto L_83F36B;
    case 0x83F36Cu: goto L_83F36C;
    case 0x83F36Eu: goto L_83F36E;
    case 0x83F370u: goto L_83F370;
    case 0x83F373u: goto L_83F373;
    case 0x83F375u: goto L_83F375;
    case 0x83F376u: goto L_83F376;
    case 0x83F378u: goto L_83F378;
    case 0x83F37Bu: goto L_83F37B;
    case 0x83F37Du: goto L_83F37D;
    case 0x83F37Eu: goto L_83F37E;
    case 0x83F380u: goto L_83F380;
    case 0x83F382u: goto L_83F382;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Au, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F24A JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF24Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF24Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F24Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F24E;
L_83F24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF24Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF24Eu,0x83F24Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Eu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F24E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F251;
L_83F251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF251u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF251u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F251 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F253;
L_83F253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF253u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF253u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F253 BMI -> $83F272
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F272; }
    goto L_83F255;
L_83F255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF255u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF255u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F255 SEP
    cpu.sep(0x20u);
    goto L_83F257;
L_83F257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF257u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF257u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F257 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F259;
L_83F259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF259u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF259u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F259 TAY
    cpu.transfer("TAY");
    goto L_83F25A;
L_83F25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25A SEC
    cpu.setFlag('C', true);
    goto L_83F25B;
L_83F25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25B SBC
    cpu.sbc(0x20u);
    goto L_83F25D;
L_83F25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25D CMP
    cpu.compareA(0x80u);
    goto L_83F25F;
L_83F25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25F TYA
    cpu.transfer("TYA");
    goto L_83F260;
L_83F260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F260 BCS -> $83F26A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F26A; }
    goto L_83F262;
L_83F262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F262 SBC
    cpu.sbc(0x3Fu);
    goto L_83F264;
L_83F264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F264 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F267;
L_83F267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF267u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF267u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F267 REP
    cpu.rep(0x20u);
    goto L_83F269;
L_83F269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF269u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF269u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F269 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F269u);return;} hw.unresolvedReturn(0x83F269u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26A ADC
    cpu.adc(0x3Fu);
    goto L_83F26C;
L_83F26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F26F;
L_83F26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26F REP
    cpu.rep(0x20u);
    goto L_83F271;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26F REP
    cpu.rep(0x20u);
    goto L_83F271;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF26Fu,0x83F26Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF271u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF271u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F271 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F271u);return;} hw.unresolvedReturn(0x83F271u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF272u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF272u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F272 SEP
    cpu.sep(0x20u);
    goto L_83F274;
L_83F274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF274u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF274u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F274 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F276;
L_83F276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF276u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF276u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F276 TAY
    cpu.transfer("TAY");
    goto L_83F277;
L_83F277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF277u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF277u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F277 SEC
    cpu.setFlag('C', true);
    goto L_83F278;
L_83F278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF278u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F278 SBC
    cpu.sbc(0x20u);
    goto L_83F27A;
L_83F27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27A CMP
    cpu.compareA(0x80u);
    goto L_83F27C;
L_83F27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27C TYA
    cpu.transfer("TYA");
    goto L_83F27D;
L_83F27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27D BCS -> $83F287
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F287; }
    goto L_83F27F;
L_83F27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27F ADC
    cpu.adc(0x40u);
    goto L_83F281;
L_83F281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF281u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF281u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F281 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F284;
L_83F284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF284u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF284u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F284 REP
    cpu.rep(0x20u);
    goto L_83F286;
L_83F286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF286u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF286u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F286 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F286u);return;} hw.unresolvedReturn(0x83F286u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF287u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF287u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F287 SBC
    cpu.sbc(0x40u);
    goto L_83F289;
L_83F289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF289u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF289u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F289 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F28C;
L_83F28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F28C REP
    cpu.rep(0x20u);
    goto L_83F28E;
L_83F28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F28E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F28Eu);return;} hw.unresolvedReturn(0x83F28Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Fu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F28F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F292;
L_83F292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF292u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF292u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F292 SBC
    cpu.sbc(0x380u);
    goto L_83F295;
L_83F295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF295u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF295u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F295 BPL -> $83F2AB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F297;
L_83F297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF297u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF297u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F297 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F299;
L_83F299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF299u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F299 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F29C;
L_83F29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F29C BNE -> $83F2AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F29E;
L_83F29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF29Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F29E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2A0;
L_83F2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A0 CMP
    cpu.compareA(0x8u);
    goto L_83F2A3;
L_83F2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A3 BCC -> $83F2AB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F2A5;
L_83F2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A5 LDA
    cpu.setA(0x600u, 16);
    goto L_83F2A8;
L_83F2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A8u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A8 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F2AB;
L_83F2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ABu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2AD;
L_83F2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AD SEC
    cpu.setFlag('C', true);
    goto L_83F2AE;
L_83F2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2AEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2AEu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16));
    goto L_83F2B1;
L_83F2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B1 ADC
    cpu.adc(0x8u);
    goto L_83F2B4;
L_83F2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B4 CMP
    cpu.compareA(0x10u);
    goto L_83F2B7;
L_83F2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B7 BCS -> $83F326
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F326; }
    goto L_83F2B9;
L_83F2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B9 SEP
    cpu.sep(0x20u);
    goto L_83F2BB;
L_83F2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2BD;
L_83F2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BD AND
    cpu.logicAnd(0xF0u);
    goto L_83F2BF;
L_83F2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BF SEC
    cpu.setFlag('C', true);
    goto L_83F2C0;
L_83F2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C0u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C0u, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C0 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F2C3;
L_83F2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C3 BEQ -> $83F2D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2D5; }
    goto L_83F2C5;
L_83F2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C5 ASL
    cpu.aslA();
    goto L_83F2C6;
L_83F2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C6 LDA
    cpu.setA(0x82u, 8);
    goto L_83F2C8;
L_83F2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C8 BCC -> $83F2CC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F2CC; }
    goto L_83F2CA;
L_83F2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CA LDA
    cpu.setA(0x81u, 8);
    goto L_83F2CC;
L_83F2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CCu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CC STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F2CF;
L_83F2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CF REP
    cpu.rep(0x20u);
    goto L_83F2D1;
L_83F2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u, 6u, 3u, cpu.address("abs", 0xF606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F2D1 JSR -> $83F606 stack real
    { cpu.push16Value(hw,0xF2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF606u), 0x83F2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F2D4;
L_83F2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F2D4u);return;} hw.unresolvedReturn(0x83F2D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F2D4u);return;} hw.unresolvedReturn(0x83F2D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2D4u,0x83F2D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2D8;
L_83F2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2D8 BEQ -> $83F2CF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2CF; }
    goto L_83F2DA;
L_83F2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DA REP
    cpu.rep(0x20u);
    goto L_83F2DC;
L_83F2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DCu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2DF;
L_83F2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DF BNE -> $83F306
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F306; }
    goto L_83F2E1;
L_83F2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2E1 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F2E5;
L_83F2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2E5u,0x83F2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2E8;
L_83F2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2E8 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83F2EA;
L_83F2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EA BMI -> $83F309
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F309; }
    goto L_83F2EC;
L_83F2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ECu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EC SEP
    cpu.sep(0x20u);
    goto L_83F2EE;
L_83F2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2F0;
L_83F2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F0 TAY
    cpu.transfer("TAY");
    goto L_83F2F1;
L_83F2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F1 SEC
    cpu.setFlag('C', true);
    goto L_83F2F2;
L_83F2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F2 SBC
    cpu.sbc(0x20u);
    goto L_83F2F4;
L_83F2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F4 CMP
    cpu.compareA(0x80u);
    goto L_83F2F6;
L_83F2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F6 TYA
    cpu.transfer("TYA");
    goto L_83F2F7;
L_83F2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F7 BCS -> $83F301
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F301; }
    goto L_83F2F9;
L_83F2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F9 SBC
    cpu.sbc(0x3Fu);
    goto L_83F2FB;
L_83F2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FBu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2FB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F2FE;
L_83F2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2FE REP
    cpu.rep(0x20u);
    goto L_83F300;
L_83F300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F300 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F300u);return;} hw.unresolvedReturn(0x83F300u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F301 ADC
    cpu.adc(0x3Fu);
    goto L_83F303;
L_83F303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF303u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF303u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F303 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F306;
L_83F306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF306u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F306 REP
    cpu.rep(0x20u);
    goto L_83F308;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F306 REP
    cpu.rep(0x20u);
    goto L_83F308;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF306u,0x83F306u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F308 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F308u);return;} hw.unresolvedReturn(0x83F308u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F309 SEP
    cpu.sep(0x20u);
    goto L_83F30B;
L_83F30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F30D;
L_83F30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30D TAY
    cpu.transfer("TAY");
    goto L_83F30E;
L_83F30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30E SEC
    cpu.setFlag('C', true);
    goto L_83F30F;
L_83F30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30F SBC
    cpu.sbc(0x20u);
    goto L_83F311;
L_83F311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F311 CMP
    cpu.compareA(0x80u);
    goto L_83F313;
L_83F313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F313 TYA
    cpu.transfer("TYA");
    goto L_83F314;
L_83F314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF314u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF314u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F314 BCS -> $83F31E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F31E; }
    goto L_83F316;
L_83F316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF316u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF316u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F316 ADC
    cpu.adc(0x40u);
    goto L_83F318;
L_83F318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF318u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF318u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F318 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F31B;
L_83F31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F31B REP
    cpu.rep(0x20u);
    goto L_83F31D;
L_83F31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F31D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F31Du);return;} hw.unresolvedReturn(0x83F31Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F31E SBC
    cpu.sbc(0x40u);
    goto L_83F320;
L_83F320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF320u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF320u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F320 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F323;
L_83F323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF323u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF323u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F323 REP
    cpu.rep(0x20u);
    goto L_83F325;
L_83F325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F325 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F325u);return;} hw.unresolvedReturn(0x83F325u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF326u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF326u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F326 ASL
    cpu.aslA();
    goto L_83F327;
L_83F327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF327u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF327u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F327 SEP
    cpu.sep(0x20u);
    goto L_83F329;
L_83F329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F329 ROL
    cpu.rolA();
    goto L_83F32A;
L_83F32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Au,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Au, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32A EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F32D;
L_83F32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32D LSR
    cpu.lsrA();
    goto L_83F32E;
L_83F32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32E BCS -> $83F39B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F39Bu,0x83F32Eu); return; }
    goto L_83F330;
L_83F330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F330 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F332;
L_83F332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F332 AND
    cpu.logicAnd(0xF0u);
    goto L_83F334;
L_83F334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F334 SEC
    cpu.setFlag('C', true);
    goto L_83F335;
L_83F335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F335 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F338;
L_83F338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F338 BEQ -> $83F34A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F34A; }
    goto L_83F33A;
L_83F33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33A ASL
    cpu.aslA();
    goto L_83F33B;
L_83F33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33B LDA
    cpu.setA(0x82u, 8);
    goto L_83F33D;
L_83F33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33D BCC -> $83F341
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F341; }
    goto L_83F33F;
L_83F33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33F LDA
    cpu.setA(0x81u, 8);
    goto L_83F341;
L_83F341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F341 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F344;
L_83F344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF344u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F344 REP
    cpu.rep(0x20u);
    goto L_83F346;
L_83F346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u, 6u, 3u, cpu.address("abs", 0xF606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F346 JSR -> $83F606 stack real
    { cpu.push16Value(hw,0xF348u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF349u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF606u), 0x83F346u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F349;
L_83F349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF349u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F349u);return;} hw.unresolvedReturn(0x83F349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F349u);return;} hw.unresolvedReturn(0x83F349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF349u,0x83F349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Au, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F34D;
L_83F34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34D BEQ -> $83F344
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F344; }
    goto L_83F34F;
L_83F34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34F REP
    cpu.rep(0x20u);
    goto L_83F351;
L_83F351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F354;
L_83F354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F354 BNE -> $83F37B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F37B; }
    goto L_83F356;
L_83F356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF356u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF356u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F356 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF359u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF35Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F356u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F35A;
L_83F35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF35Au,0x83F35Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F35D;
L_83F35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35D CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83F35F;
L_83F35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35F BMI -> $83F37E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F37E; }
    goto L_83F361;
L_83F361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F361 SEP
    cpu.sep(0x20u);
    goto L_83F363;
L_83F363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F363 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F365;
L_83F365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F365 TAY
    cpu.transfer("TAY");
    goto L_83F366;
L_83F366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF366u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F366 SEC
    cpu.setFlag('C', true);
    goto L_83F367;
L_83F367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F367 SBC
    cpu.sbc(0x20u);
    goto L_83F369;
L_83F369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F369 CMP
    cpu.compareA(0x80u);
    goto L_83F36B;
L_83F36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36B TYA
    cpu.transfer("TYA");
    goto L_83F36C;
L_83F36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36C BCS -> $83F376
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F376; }
    goto L_83F36E;
L_83F36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36E SBC
    cpu.sbc(0x3Fu);
    goto L_83F370;
L_83F370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF370u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F370 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F373;
L_83F373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F373 REP
    cpu.rep(0x20u);
    goto L_83F375;
L_83F375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F375 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F375u);return;} hw.unresolvedReturn(0x83F375u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F376 ADC
    cpu.adc(0x3Fu);
    goto L_83F378;
L_83F378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF378u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF378u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F378 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F37B;
L_83F37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37B REP
    cpu.rep(0x20u);
    goto L_83F37D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37B REP
    cpu.rep(0x20u);
    goto L_83F37D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF37Bu,0x83F37Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F37D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F37Du);return;} hw.unresolvedReturn(0x83F37Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37E SEP
    cpu.sep(0x20u);
    goto L_83F380;
L_83F380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F380 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F382;
L_83F382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F382 TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF383u,0x83F382u); return;
}

void sub_83F094_E0M0X0CQ_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F24Au: goto L_83F24A;
    case 0x83F24Eu: goto L_83F24E;
    case 0x83F251u: goto L_83F251;
    case 0x83F253u: goto L_83F253;
    case 0x83F255u: goto L_83F255;
    case 0x83F257u: goto L_83F257;
    case 0x83F259u: goto L_83F259;
    case 0x83F25Au: goto L_83F25A;
    case 0x83F25Bu: goto L_83F25B;
    case 0x83F25Du: goto L_83F25D;
    case 0x83F25Fu: goto L_83F25F;
    case 0x83F260u: goto L_83F260;
    case 0x83F262u: goto L_83F262;
    case 0x83F264u: goto L_83F264;
    case 0x83F267u: goto L_83F267;
    case 0x83F269u: goto L_83F269;
    case 0x83F26Au: goto L_83F26A;
    case 0x83F26Cu: goto L_83F26C;
    case 0x83F26Fu: goto L_83F26F;
    case 0x83F271u: goto L_83F271;
    case 0x83F272u: goto L_83F272;
    case 0x83F274u: goto L_83F274;
    case 0x83F276u: goto L_83F276;
    case 0x83F277u: goto L_83F277;
    case 0x83F278u: goto L_83F278;
    case 0x83F27Au: goto L_83F27A;
    case 0x83F27Cu: goto L_83F27C;
    case 0x83F27Du: goto L_83F27D;
    case 0x83F27Fu: goto L_83F27F;
    case 0x83F281u: goto L_83F281;
    case 0x83F284u: goto L_83F284;
    case 0x83F286u: goto L_83F286;
    case 0x83F287u: goto L_83F287;
    case 0x83F289u: goto L_83F289;
    case 0x83F28Cu: goto L_83F28C;
    case 0x83F28Eu: goto L_83F28E;
    case 0x83F28Fu: goto L_83F28F;
    case 0x83F292u: goto L_83F292;
    case 0x83F295u: goto L_83F295;
    case 0x83F297u: goto L_83F297;
    case 0x83F299u: goto L_83F299;
    case 0x83F29Cu: goto L_83F29C;
    case 0x83F29Eu: goto L_83F29E;
    case 0x83F2A0u: goto L_83F2A0;
    case 0x83F2A3u: goto L_83F2A3;
    case 0x83F2A5u: goto L_83F2A5;
    case 0x83F2A8u: goto L_83F2A8;
    case 0x83F2ABu: goto L_83F2AB;
    case 0x83F2ADu: goto L_83F2AD;
    case 0x83F2AEu: goto L_83F2AE;
    case 0x83F2B1u: goto L_83F2B1;
    case 0x83F2B4u: goto L_83F2B4;
    case 0x83F2B7u: goto L_83F2B7;
    case 0x83F2B9u: goto L_83F2B9;
    case 0x83F2BBu: goto L_83F2BB;
    case 0x83F2BDu: goto L_83F2BD;
    case 0x83F2BFu: goto L_83F2BF;
    case 0x83F2C0u: goto L_83F2C0;
    case 0x83F2C3u: goto L_83F2C3;
    case 0x83F2C5u: goto L_83F2C5;
    case 0x83F2C6u: goto L_83F2C6;
    case 0x83F2C8u: goto L_83F2C8;
    case 0x83F2CAu: goto L_83F2CA;
    case 0x83F2CCu: goto L_83F2CC;
    case 0x83F2CFu: goto L_83F2CF;
    case 0x83F2D1u: goto L_83F2D1;
    case 0x83F2D4u: goto L_83F2D4;
    case 0x83F2D5u: goto L_83F2D5;
    case 0x83F2D8u: goto L_83F2D8;
    case 0x83F2DAu: goto L_83F2DA;
    case 0x83F2DCu: goto L_83F2DC;
    case 0x83F2DFu: goto L_83F2DF;
    case 0x83F2E1u: goto L_83F2E1;
    case 0x83F2E5u: goto L_83F2E5;
    case 0x83F2E8u: goto L_83F2E8;
    case 0x83F2EAu: goto L_83F2EA;
    case 0x83F2ECu: goto L_83F2EC;
    case 0x83F2EEu: goto L_83F2EE;
    case 0x83F2F0u: goto L_83F2F0;
    case 0x83F2F1u: goto L_83F2F1;
    case 0x83F2F2u: goto L_83F2F2;
    case 0x83F2F4u: goto L_83F2F4;
    case 0x83F2F6u: goto L_83F2F6;
    case 0x83F2F7u: goto L_83F2F7;
    case 0x83F2F9u: goto L_83F2F9;
    case 0x83F2FBu: goto L_83F2FB;
    case 0x83F2FEu: goto L_83F2FE;
    case 0x83F300u: goto L_83F300;
    case 0x83F301u: goto L_83F301;
    case 0x83F303u: goto L_83F303;
    case 0x83F306u: goto L_83F306;
    case 0x83F308u: goto L_83F308;
    case 0x83F309u: goto L_83F309;
    case 0x83F30Bu: goto L_83F30B;
    case 0x83F30Du: goto L_83F30D;
    case 0x83F30Eu: goto L_83F30E;
    case 0x83F30Fu: goto L_83F30F;
    case 0x83F311u: goto L_83F311;
    case 0x83F313u: goto L_83F313;
    case 0x83F314u: goto L_83F314;
    case 0x83F316u: goto L_83F316;
    case 0x83F318u: goto L_83F318;
    case 0x83F31Bu: goto L_83F31B;
    case 0x83F31Du: goto L_83F31D;
    case 0x83F31Eu: goto L_83F31E;
    case 0x83F320u: goto L_83F320;
    case 0x83F323u: goto L_83F323;
    case 0x83F325u: goto L_83F325;
    case 0x83F326u: goto L_83F326;
    case 0x83F327u: goto L_83F327;
    case 0x83F329u: goto L_83F329;
    case 0x83F32Au: goto L_83F32A;
    case 0x83F32Du: goto L_83F32D;
    case 0x83F32Eu: goto L_83F32E;
    case 0x83F330u: goto L_83F330;
    case 0x83F332u: goto L_83F332;
    case 0x83F334u: goto L_83F334;
    case 0x83F335u: goto L_83F335;
    case 0x83F338u: goto L_83F338;
    case 0x83F33Au: goto L_83F33A;
    case 0x83F33Bu: goto L_83F33B;
    case 0x83F33Du: goto L_83F33D;
    case 0x83F33Fu: goto L_83F33F;
    case 0x83F341u: goto L_83F341;
    case 0x83F344u: goto L_83F344;
    case 0x83F346u: goto L_83F346;
    case 0x83F349u: goto L_83F349;
    case 0x83F34Au: goto L_83F34A;
    case 0x83F34Du: goto L_83F34D;
    case 0x83F34Fu: goto L_83F34F;
    case 0x83F351u: goto L_83F351;
    case 0x83F354u: goto L_83F354;
    case 0x83F356u: goto L_83F356;
    case 0x83F35Au: goto L_83F35A;
    case 0x83F35Du: goto L_83F35D;
    case 0x83F35Fu: goto L_83F35F;
    case 0x83F361u: goto L_83F361;
    case 0x83F363u: goto L_83F363;
    case 0x83F365u: goto L_83F365;
    case 0x83F366u: goto L_83F366;
    case 0x83F367u: goto L_83F367;
    case 0x83F369u: goto L_83F369;
    case 0x83F36Bu: goto L_83F36B;
    case 0x83F36Cu: goto L_83F36C;
    case 0x83F36Eu: goto L_83F36E;
    case 0x83F370u: goto L_83F370;
    case 0x83F373u: goto L_83F373;
    case 0x83F375u: goto L_83F375;
    case 0x83F376u: goto L_83F376;
    case 0x83F378u: goto L_83F378;
    case 0x83F37Bu: goto L_83F37B;
    case 0x83F37Du: goto L_83F37D;
    case 0x83F37Eu: goto L_83F37E;
    case 0x83F380u: goto L_83F380;
    case 0x83F382u: goto L_83F382;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Au, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F24A JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF24Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF24Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F24Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F24E;
L_83F24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF24Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF24Eu,0x83F24Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Eu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF24Eu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F24E LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F251;
L_83F251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF251u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF251u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F251 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F253;
L_83F253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF253u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF253u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F253 BMI -> $83F272
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F272; }
    goto L_83F255;
L_83F255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF255u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF255u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F255 SEP
    cpu.sep(0x20u);
    goto L_83F257;
L_83F257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF257u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF257u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F257 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F259;
L_83F259:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF259u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF259u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF259u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F259 TAY
    cpu.transfer("TAY");
    goto L_83F25A;
L_83F25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25A SEC
    cpu.setFlag('C', true);
    goto L_83F25B;
L_83F25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Bu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25B SBC
    cpu.sbc(0x20u);
    goto L_83F25D;
L_83F25D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25D CMP
    cpu.compareA(0x80u);
    goto L_83F25F;
L_83F25F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF25Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Fu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF25Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F25F TYA
    cpu.transfer("TYA");
    goto L_83F260;
L_83F260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF260u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F260 BCS -> $83F26A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F26A; }
    goto L_83F262;
L_83F262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF262u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F262 SBC
    cpu.sbc(0x3Fu);
    goto L_83F264;
L_83F264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF264u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F264 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F267;
L_83F267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF267u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF267u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F267 REP
    cpu.rep(0x20u);
    goto L_83F269;
L_83F269:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF269u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF269u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF269u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F269 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F269u);return;} hw.unresolvedReturn(0x83F269u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26A ADC
    cpu.adc(0x3Fu);
    goto L_83F26C;
L_83F26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F26F;
L_83F26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF26Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26F REP
    cpu.rep(0x20u);
    goto L_83F271;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF26Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F26F REP
    cpu.rep(0x20u);
    goto L_83F271;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF26Fu,0x83F26Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F271:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF271u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF271u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF271u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F271 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F271u);return;} hw.unresolvedReturn(0x83F271u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF272u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF272u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F272 SEP
    cpu.sep(0x20u);
    goto L_83F274;
L_83F274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF274u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF274u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F274 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F276;
L_83F276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF276u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF276u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F276 TAY
    cpu.transfer("TAY");
    goto L_83F277;
L_83F277:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF277u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF277u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF277u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F277 SEC
    cpu.setFlag('C', true);
    goto L_83F278;
L_83F278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF278u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF278u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F278 SBC
    cpu.sbc(0x20u);
    goto L_83F27A;
L_83F27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27A CMP
    cpu.compareA(0x80u);
    goto L_83F27C;
L_83F27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Cu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27C TYA
    cpu.transfer("TYA");
    goto L_83F27D;
L_83F27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Du,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27D BCS -> $83F287
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F287; }
    goto L_83F27F;
L_83F27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF27Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F27F ADC
    cpu.adc(0x40u);
    goto L_83F281;
L_83F281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF281u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF281u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F281 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F284;
L_83F284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF284u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF284u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F284 REP
    cpu.rep(0x20u);
    goto L_83F286;
L_83F286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF286u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF286u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F286 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F286u);return;} hw.unresolvedReturn(0x83F286u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF287u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF287u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F287 SBC
    cpu.sbc(0x40u);
    goto L_83F289;
L_83F289:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF289u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF289u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF289u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F289 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F28C;
L_83F28C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F28C REP
    cpu.rep(0x20u);
    goto L_83F28E;
L_83F28E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F28E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F28Eu);return;} hw.unresolvedReturn(0x83F28Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F28F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF28Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF28Fu, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F28F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F292;
L_83F292:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF292u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF292u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF292u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F292 SBC
    cpu.sbc(0x380u);
    goto L_83F295;
L_83F295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF295u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF295u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F295 BPL -> $83F2AB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F297;
L_83F297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF297u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF297u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F297 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F299;
L_83F299:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF299u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF299u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF299u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F299 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F29C;
L_83F29C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF29Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F29C BNE -> $83F2AB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F29E;
L_83F29E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF29Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF29Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F29E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2A0;
L_83F2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A0 CMP
    cpu.compareA(0x8u);
    goto L_83F2A3;
L_83F2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A3 BCC -> $83F2AB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F2AB; }
    goto L_83F2A5;
L_83F2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A5 LDA
    cpu.setA(0x600u, 16);
    goto L_83F2A8;
L_83F2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2A8u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2A8 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F2AB;
L_83F2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ABu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2AD;
L_83F2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ADu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AD SEC
    cpu.setFlag('C', true);
    goto L_83F2AE;
L_83F2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2AEu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2AEu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2AE SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16));
    goto L_83F2B1;
L_83F2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B1 ADC
    cpu.adc(0x8u);
    goto L_83F2B4;
L_83F2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B4 CMP
    cpu.compareA(0x10u);
    goto L_83F2B7;
L_83F2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B7 BCS -> $83F326
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F326; }
    goto L_83F2B9;
L_83F2B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2B9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2B9 SEP
    cpu.sep(0x20u);
    goto L_83F2BB;
L_83F2BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2BD;
L_83F2BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BD AND
    cpu.logicAnd(0xF0u);
    goto L_83F2BF;
L_83F2BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2BF SEC
    cpu.setFlag('C', true);
    goto L_83F2C0;
L_83F2C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C0u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C0u, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C0 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F2C3;
L_83F2C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C3 BEQ -> $83F2D5
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2D5; }
    goto L_83F2C5;
L_83F2C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C5 ASL
    cpu.aslA();
    goto L_83F2C6;
L_83F2C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C6 LDA
    cpu.setA(0x82u, 8);
    goto L_83F2C8;
L_83F2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C8u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2C8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2C8 BCC -> $83F2CC
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F2CC; }
    goto L_83F2CA;
L_83F2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CA LDA
    cpu.setA(0x81u, 8);
    goto L_83F2CC;
L_83F2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CCu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CC STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F2CF;
L_83F2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2CFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2CF REP
    cpu.rep(0x20u);
    goto L_83F2D1;
L_83F2D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D1u, 6u, 3u, cpu.address("abs", 0xF606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F2D1 JSR -> $83F606 stack real
    { cpu.push16Value(hw,0xF2D3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2D4u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF606u), 0x83F2D1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F2D4;
L_83F2D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F2D4u);return;} hw.unresolvedReturn(0x83F2D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2D4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F2D4u);return;} hw.unresolvedReturn(0x83F2D4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2D4u,0x83F2D4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D5u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2D8;
L_83F2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2D8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2D8 BEQ -> $83F2CF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F2CF; }
    goto L_83F2DA;
L_83F2DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DA REP
    cpu.rep(0x20u);
    goto L_83F2DC;
L_83F2DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DCu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2DF;
L_83F2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2DFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2DF BNE -> $83F306
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F306; }
    goto L_83F2E1;
L_83F2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E1u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F2E1 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF2E4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF2E5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F2E1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F2E5;
L_83F2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF2E5u,0x83F2E5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E5u, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2E5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2E8;
L_83F2E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2E8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2E8 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83F2EA;
L_83F2EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EA BMI -> $83F309
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F309; }
    goto L_83F2EC;
L_83F2EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ECu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2ECu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EC SEP
    cpu.sep(0x20u);
    goto L_83F2EE;
L_83F2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2EE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F2F0;
L_83F2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F0 TAY
    cpu.transfer("TAY");
    goto L_83F2F1;
L_83F2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F1 SEC
    cpu.setFlag('C', true);
    goto L_83F2F2;
L_83F2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F2 SBC
    cpu.sbc(0x20u);
    goto L_83F2F4;
L_83F2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F4 CMP
    cpu.compareA(0x80u);
    goto L_83F2F6;
L_83F2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F6 TYA
    cpu.transfer("TYA");
    goto L_83F2F7;
L_83F2F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F7 BCS -> $83F301
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F301; }
    goto L_83F2F9;
L_83F2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2F9 SBC
    cpu.sbc(0x3Fu);
    goto L_83F2FB;
L_83F2FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FBu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2FB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F2FE;
L_83F2FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF2FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF2FEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F2FE REP
    cpu.rep(0x20u);
    goto L_83F300;
L_83F300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF300u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F300 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F300u);return;} hw.unresolvedReturn(0x83F300u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F301:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF301u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF301u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F301 ADC
    cpu.adc(0x3Fu);
    goto L_83F303;
L_83F303:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF303u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF303u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF303u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F303 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F306;
L_83F306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF306u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F306 REP
    cpu.rep(0x20u);
    goto L_83F308;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF306u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F306 REP
    cpu.rep(0x20u);
    goto L_83F308;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF306u,0x83F306u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF308u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F308 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F308u);return;} hw.unresolvedReturn(0x83F308u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F309:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF309u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF309u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F309 SEP
    cpu.sep(0x20u);
    goto L_83F30B;
L_83F30B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30B LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F30D;
L_83F30D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30D TAY
    cpu.transfer("TAY");
    goto L_83F30E;
L_83F30E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Eu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30E SEC
    cpu.setFlag('C', true);
    goto L_83F30F;
L_83F30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F30F SBC
    cpu.sbc(0x20u);
    goto L_83F311;
L_83F311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF311u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F311 CMP
    cpu.compareA(0x80u);
    goto L_83F313;
L_83F313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF313u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F313 TYA
    cpu.transfer("TYA");
    goto L_83F314;
L_83F314:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF314u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF314u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF314u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F314 BCS -> $83F31E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F31E; }
    goto L_83F316;
L_83F316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF316u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF316u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F316 ADC
    cpu.adc(0x40u);
    goto L_83F318;
L_83F318:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF318u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF318u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF318u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F318 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F31B;
L_83F31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F31B REP
    cpu.rep(0x20u);
    goto L_83F31D;
L_83F31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F31D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F31Du);return;} hw.unresolvedReturn(0x83F31Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F31E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF31Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF31Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F31E SBC
    cpu.sbc(0x40u);
    goto L_83F320;
L_83F320:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF320u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF320u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF320u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F320 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F323;
L_83F323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF323u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF323u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F323 REP
    cpu.rep(0x20u);
    goto L_83F325;
L_83F325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF325u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F325 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F325u);return;} hw.unresolvedReturn(0x83F325u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F326:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF326u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF326u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF326u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F326 ASL
    cpu.aslA();
    goto L_83F327;
L_83F327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF327u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF327u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F327 SEP
    cpu.sep(0x20u);
    goto L_83F329;
L_83F329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF329u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F329 ROL
    cpu.rolA();
    goto L_83F32A;
L_83F32A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Au,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Au, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32A EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F32D;
L_83F32D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32D LSR
    cpu.lsrA();
    goto L_83F32E;
L_83F32E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF32Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Eu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF32Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F32E BCS -> $83F39B
    if (cpu.c) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F39Bu,0x83F32Eu); return; }
    goto L_83F330;
L_83F330:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF330u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF330u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F330 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F332;
L_83F332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF332u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F332 AND
    cpu.logicAnd(0xF0u);
    goto L_83F334;
L_83F334:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF334u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF334u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F334 SEC
    cpu.setFlag('C', true);
    goto L_83F335;
L_83F335:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF335u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF335u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F335 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F338;
L_83F338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF338u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F338 BEQ -> $83F34A
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F34A; }
    goto L_83F33A;
L_83F33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33A ASL
    cpu.aslA();
    goto L_83F33B;
L_83F33B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33B LDA
    cpu.setA(0x82u, 8);
    goto L_83F33D;
L_83F33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33D BCC -> $83F341
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F341; }
    goto L_83F33F;
L_83F33F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF33Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF33Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F33F LDA
    cpu.setA(0x81u, 8);
    goto L_83F341;
L_83F341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF341u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F341 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F344;
L_83F344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF344u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF344u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F344 REP
    cpu.rep(0x20u);
    goto L_83F346;
L_83F346:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF346u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF346u, 6u, 3u, cpu.address("abs", 0xF606u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F346 JSR -> $83F606 stack real
    { cpu.push16Value(hw,0xF348u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF349u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xF606u), 0x83F346u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F349;
L_83F349:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF349u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F349u);return;} hw.unresolvedReturn(0x83F349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF349u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F349 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F349u);return;} hw.unresolvedReturn(0x83F349u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF349u,0x83F349u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F34A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Au,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Au, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34A LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F34D;
L_83F34D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34D BEQ -> $83F344
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F344; }
    goto L_83F34F;
L_83F34F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF34Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF34Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F34F REP
    cpu.rep(0x20u);
    goto L_83F351;
L_83F351:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF351u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF351u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F351 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F354;
L_83F354:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF354u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF354u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F354 BNE -> $83F37B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F37B; }
    goto L_83F356;
L_83F356:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF356u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF356u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF356u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F356 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF359u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF35Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F356u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F35A;
L_83F35A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF35Au,0x83F35Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Au, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F35D;
L_83F35D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35D CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83F35F;
L_83F35F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF35Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF35Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F35F BMI -> $83F37E
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F37E; }
    goto L_83F361;
L_83F361:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF361u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF361u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F361 SEP
    cpu.sep(0x20u);
    goto L_83F363;
L_83F363:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF363u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF363u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F363 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F365;
L_83F365:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF365u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF365u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F365 TAY
    cpu.transfer("TAY");
    goto L_83F366;
L_83F366:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF366u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF366u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF366u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F366 SEC
    cpu.setFlag('C', true);
    goto L_83F367;
L_83F367:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF367u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF367u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F367 SBC
    cpu.sbc(0x20u);
    goto L_83F369;
L_83F369:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF369u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF369u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F369 CMP
    cpu.compareA(0x80u);
    goto L_83F36B;
L_83F36B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36B TYA
    cpu.transfer("TYA");
    goto L_83F36C;
L_83F36C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36C BCS -> $83F376
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F376; }
    goto L_83F36E;
L_83F36E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF36Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF36Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F36E SBC
    cpu.sbc(0x3Fu);
    goto L_83F370;
L_83F370:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF370u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF370u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF370u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F370 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F373;
L_83F373:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF373u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF373u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F373 REP
    cpu.rep(0x20u);
    goto L_83F375;
L_83F375:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF375u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF375u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F375 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F375u);return;} hw.unresolvedReturn(0x83F375u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F376:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF376u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF376u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F376 ADC
    cpu.adc(0x3Fu);
    goto L_83F378;
L_83F378:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF378u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF378u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF378u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F378 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F37B;
L_83F37B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37B REP
    cpu.rep(0x20u);
    goto L_83F37D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37B REP
    cpu.rep(0x20u);
    goto L_83F37D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF37Bu,0x83F37Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F37D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F37D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F37Du);return;} hw.unresolvedReturn(0x83F37Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F37E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF37Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF37Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F37E SEP
    cpu.sep(0x20u);
    goto L_83F380;
L_83F380:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF380u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF380u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F380 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F382;
L_83F382:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF382u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF382u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F382 TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF383u,0x83F382u); return;
}

void sub_849585_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849585u: goto L_849585;
    case 0x849588u: goto L_849588;
    case 0x84958Au: goto L_84958A;
    case 0x84958Du: goto L_84958D;
    case 0x84958Fu: goto L_84958F;
    case 0x849591u: goto L_849591;
    case 0x849593u: goto L_849593;
    case 0x849596u: goto L_849596;
    case 0x849598u: goto L_849598;
    case 0x84959Au: goto L_84959A;
    case 0x84959Bu: goto L_84959B;
    case 0x84959Cu: goto L_84959C;
    case 0x84959Fu: goto L_84959F;
    case 0x8495A2u: goto L_8495A2;
    case 0x8495A5u: goto L_8495A5;
    case 0x8495A8u: goto L_8495A8;
    case 0x8495AAu: goto L_8495AA;
    case 0x8495ACu: goto L_8495AC;
    case 0x8495AFu: goto L_8495AF;
    case 0x8495B1u: goto L_8495B1;
    case 0x8495B2u: goto L_8495B2;
    case 0x8495B4u: goto L_8495B4;
    case 0x8495B6u: goto L_8495B6;
    case 0x8495B8u: goto L_8495B8;
    case 0x8495BCu: goto L_8495BC;
    case 0x8495BFu: goto L_8495BF;
    case 0x8495C2u: goto L_8495C2;
    case 0x8495C4u: goto L_8495C4;
    case 0x8495C7u: goto L_8495C7;
    case 0x8495C9u: goto L_8495C9;
    case 0x8495CCu: goto L_8495CC;
    case 0x8495CEu: goto L_8495CE;
    case 0x8495D1u: goto L_8495D1;
    case 0x8495D3u: goto L_8495D3;
    case 0x8495D6u: goto L_8495D6;
    case 0x8495D8u: goto L_8495D8;
    case 0x8495DBu: goto L_8495DB;
    case 0x8495DDu: goto L_8495DD;
    case 0x8495DEu: goto L_8495DE;
    case 0x8495DFu: goto L_8495DF;
    case 0x8495E2u: goto L_8495E2;
    case 0x8495E3u: goto L_8495E3;
    case 0x8495E4u: goto L_8495E4;
    case 0x8495E5u: goto L_8495E5;
    case 0x8495E8u: goto L_8495E8;
    case 0x8495E9u: goto L_8495E9;
    case 0x8495ECu: goto L_8495EC;
    case 0x8495EEu: goto L_8495EE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849585:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9585u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9585u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849585 LDY
    cpu.setY(0xFFu, 16);
    goto L_849588;
L_849588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849588 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84958A;
L_84958A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84958A CMP
    cpu.compareA(0x2u);
    goto L_84958D;
L_84958D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84958D BNE -> $849596
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849596; }
    goto L_84958F;
L_84958F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84958F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849591;
L_849591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849591 BNE -> $849596
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_849596; }
    goto L_849593;
L_849593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9593u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9593u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849593 LDY
    cpu.setY(0xFDu, 16);
    goto L_849596;
L_849596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849596 STY
    hw.write(cpu.address("dp", 0x26u), cpu.y, cpu.x8?8:16);
    goto L_849598;
L_849598:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9598u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9598u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849598 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84959A;
L_84959A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959A ASL
    cpu.aslA();
    goto L_84959B;
L_84959B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959B TAX
    cpu.transfer("TAX");
    goto L_84959C;
L_84959C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Cu, 5u + 1u, 3u, cpu.address("absx", 0x95EFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959C LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x95EFu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_84959F;
L_84959F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84959F LDX
    cpu.setX(0xD90u, 16);
    goto L_8495A2;
L_8495A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495A5;
L_8495A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A5 AND
    cpu.logicAnd(0xFFu);
    goto L_8495A8;
L_8495A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495A8 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16));
    goto L_8495AA;
L_8495AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495AA BEQ -> $8495EE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495EE; }
    goto L_8495AC;
L_8495AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495AC CMP
    cpu.compareA(0xFDu);
    goto L_8495AF;
L_8495AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495AF BNE -> $8495B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495B4; }
    goto L_8495B1;
L_8495B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B1 INY
    cpu.inc('Y');
    goto L_8495B2;
L_8495B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B2 BRA -> $8495A2
    goto L_8495A2;
L_8495B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495B6;
L_8495B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495B6 BNE -> $8495E3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8495E3; }
    goto L_8495B8;
L_8495B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B8u, 8u, 4u, 0x808E02u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8495B8 JSL -> $808E02 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x95BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95BCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808E02u, 0x8495B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8495BC;
L_8495BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95BCu,0x8495BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495BC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495BF;
L_8495BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495BF AND
    cpu.logicAnd(0xFFu);
    goto L_8495C2;
L_8495C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C2 STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_8495C4;
L_8495C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495C7;
L_8495C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C7 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8495C9;
L_8495C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 5u + 1u, 3u, cpu.address("absy", 0x0003u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495C9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495CC;
L_8495CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495CC STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_8495CE;
L_8495CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu, 5u + 1u, 3u, cpu.address("absy", 0x0005u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495CE LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x5u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495D1;
L_8495D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D1 STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_8495D3;
L_8495D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u, 5u + 1u, 3u, cpu.address("absy", 0x0007u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D3 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495D6;
L_8495D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D6 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_8495D8;
L_8495D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u, 5u + 1u, 3u, cpu.address("absy", 0x0009u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495D8 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8495DB;
L_8495DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DB STA
    hw.write(cpu.address("dpx", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_8495DD;
L_8495DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DD TYA
    cpu.transfer("TYA");
    goto L_8495DE;
L_8495DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DE CLC
    cpu.setFlag('C', false);
    goto L_8495DF;
L_8495DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495DF ADC
    cpu.adc(0xBu);
    goto L_8495E2;
L_8495E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E2 TAY
    cpu.transfer("TAY");
    goto L_8495E3;
L_8495E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E3 TXA
    cpu.transfer("TXA");
    goto L_8495E4;
L_8495E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E4u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E4 CLC
    cpu.setFlag('C', false);
    goto L_8495E5;
L_8495E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E5u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E5 ADC
    cpu.adc(0x50u);
    goto L_8495E8;
L_8495E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E8 TAX
    cpu.transfer("TAX");
    goto L_8495E9;
L_8495E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495E9 CPX
    cpu.compareX(0x1790u);
    goto L_8495EC;
L_8495EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8495EC BMI -> $8495A2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_8495A2; }
    goto L_8495EE;
L_8495EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95EEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8495EE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8495EEu);return;} hw.unresolvedReturn(0x8495EEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

