#include "generated.hpp"
void sub_8080A5_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808062u: goto L_808062;
    case 0x808086u: goto L_808086;
    case 0x808089u: goto L_808089;
    case 0x80808Au: goto L_80808A;
    case 0x80808Du: goto L_80808D;
    case 0x80808Eu: goto L_80808E;
    case 0x80808Fu: goto L_80808F;
    case 0x808093u: goto L_808093;
    case 0x808096u: goto L_808096;
    case 0x80809Au: goto L_80809A;
    case 0x80809Cu: goto L_80809C;
    case 0x8080A0u: goto L_8080A0;
    case 0x8080A3u: goto L_8080A3;
    case 0x8080A5u: goto L_8080A5;
    case 0x8080A6u: goto L_8080A6;
    case 0x8080A9u: goto L_8080A9;
    case 0x8080AAu: goto L_8080AA;
    case 0x8080ABu: goto L_8080AB;
    case 0x8080ACu: goto L_8080AC;
    case 0x8080AEu: goto L_8080AE;
    case 0x8080AFu: goto L_8080AF;
    case 0x8080B1u: goto L_8080B1;
    case 0x8080B2u: goto L_8080B2;
    case 0x8080B6u: goto L_8080B6;
    case 0x8080B9u: goto L_8080B9;
    case 0x8080BDu: goto L_8080BD;
    case 0x8080C1u: goto L_8080C1;
    case 0x8080C5u: goto L_8080C5;
    case 0x8080C9u: goto L_8080C9;
    case 0x8080CDu: goto L_8080CD;
    case 0x8080CFu: goto L_8080CF;
    case 0x8080D2u: goto L_8080D2;
    case 0x8080D4u: goto L_8080D4;
    case 0x8080D7u: goto L_8080D7;
    case 0x8080D9u: goto L_8080D9;
    case 0x8080DCu: goto L_8080DC;
    case 0x8080DEu: goto L_8080DE;
    case 0x8080E2u: goto L_8080E2;
    case 0x8080E4u: goto L_8080E4;
    case 0x8080E5u: goto L_8080E5;
    case 0x8080E8u: goto L_8080E8;
    case 0x8080ECu: goto L_8080EC;
    case 0x8080EFu: goto L_8080EF;
    case 0x8080F2u: goto L_8080F2;
    case 0x8080F3u: goto L_8080F3;
    case 0x8080F4u: goto L_8080F4;
    case 0x8080F7u: goto L_8080F7;
    case 0x8080F8u: goto L_8080F8;
    case 0x8080FBu: goto L_8080FB;
    case 0x8080FCu: goto L_8080FC;
    case 0x808100u: goto L_808100;
    case 0x808104u: goto L_808104;
    case 0x808108u: goto L_808108;
    case 0x80810Cu: goto L_80810C;
    case 0x80810Du: goto L_80810D;
    case 0x808111u: goto L_808111;
    case 0x808115u: goto L_808115;
    case 0x808116u: goto L_808116;
    case 0x80811Au: goto L_80811A;
    case 0x80811Bu: goto L_80811B;
    case 0x80811Eu: goto L_80811E;
    case 0x80811Fu: goto L_80811F;
    case 0x808121u: goto L_808121;
    case 0x808123u: goto L_808123;
    case 0x808125u: goto L_808125;
    case 0x808127u: goto L_808127;
    case 0x808128u: goto L_808128;
    case 0x80812Au: goto L_80812A;
    case 0x80812Eu: goto L_80812E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808062:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8062u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8062u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808062 BRA -> $808086
    goto L_808086;
L_808086:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8086u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8086u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8086u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808086 LDA
    cpu.setA(0x0u, 16);
    goto L_808089;
L_808089:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8089u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8089u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808089 TCD
    cpu.tcd();
    goto L_80808A;
L_80808A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Au,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Au, 5u, 3u, cpu.address("abs", 0x8100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80808A PEA
    cpu.push16Value(hw, 0x8100u);
    goto L_80808D;
L_80808D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Du, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80808D PLB
    cpu.pop("PLB", hw);
    goto L_80808E;
L_80808E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80808E PLB
    cpu.pop("PLB", hw);
    goto L_80808F;
L_80808F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x808Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x808Fu, 8u, 4u, 0x809448u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80808F JSL -> $809448 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8092u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8093u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809448u, 0x80808Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808093;
L_808093:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8093u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8093u,0x808093u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8093u, 5u, 3u, cpu.address("abs", 0x1FFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808093 STZ
    hw.write(cpu.address("abs", 0x1FFCu), 0, cpu.m8?8:16);
    goto L_808096;
L_808096:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8096u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8096u, 8u, 4u, 0x80D9E9u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808096 JSL -> $80D9E9 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8099u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x809Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D9E9u, 0x808096u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80809A;
L_80809A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80809A BCC -> $8080A6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8080A6; }
    goto L_80809C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80809A BCC -> $8080A6
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8080A6; }
    goto L_80809C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Au,0x80809Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80809C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu, 8u, 4u, 0x80D99Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809C JSL -> $80D99A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D99Au, 0x80809Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080A0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Cu, 8u, 4u, 0x80D99Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80809C JSL -> $80D99A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x809Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80D99Au, 0x80809Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080A0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x809Cu,0x80809Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A0 LDA
    cpu.setA(0x1234u, 16);
    goto L_8080A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A0 LDA
    cpu.setA(0x1234u, 16);
    goto L_8080A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A0u,0x8080A0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 5u, 3u, cpu.address("abs", 0x1FFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A3 STA
    hw.write(cpu.address("abs", 0x1FFEu), cpu.a, cpu.m8?8:16);
    goto L_8080A6;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 5u, 3u, cpu.address("abs", 0x1FFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A3 STA
    hw.write(cpu.address("abs", 0x1FFEu), cpu.a, cpu.m8?8:16);
    goto L_8080A6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A3u,0x8080A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u,cpu,0x1Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u, 6u, 4u, ((0xFE86AFu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A5 ORA
    cpu.logicOr(hw.readW(((0xFE86AFu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8080A9;
L_8080A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080AA;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A6 LDA
    cpu.loadA(hw.readW(0x7EFE86u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A6u,0x8080A6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u,cpu,0x7Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A9u, 9u, 3u, cpu.address("absx", 0x8D4Au), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080A9 ROR
    cpu.rorMem(hw, cpu.address("absx", 0x8D4Au), cpu.m8?8:16);
    goto L_8080AC;
L_8080AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AA LSR
    cpu.lsrA();
    goto L_8080AB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AA LSR
    cpu.lsrA();
    goto L_8080AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8080AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_8080AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 5u, 3u, cpu.address("abs", 0x1FF4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AB STA
    hw.write(cpu.address("abs", 0x1FF4u), cpu.a, cpu.m8?8:16);
    goto L_8080AE;
L_8080AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ACu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ACu, 5u, 3u, cpu.address("abs", 0x221Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8080AC PEA
    cpu.push16Value(hw, 0x221Fu);
    goto L_8080AF;
L_8080AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AEu, 8u, 4u, 0x809496u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080AE JSL -> $809496 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80B1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809496u, 0x8080AEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080B2;
L_8080AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0x96u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x94u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080AF STX
    hw.write(cpu.address("dpy", 0x94u), cpu.x, cpu.x8?8:16);
    goto L_8080B1;
L_8080B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B1 BRA -> $808062
    goto L_808062;
L_8080B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B2u,0x8080B2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B2 LDA
    cpu.loadA(hw.readW(0x7EFE84u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_8080B6;
L_8080B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B6u, 5u, 3u, cpu.address("abs", 0x1FE8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080B6 STA
    hw.write(cpu.address("abs", 0x1FE8u), cpu.a, cpu.m8?8:16);
    goto L_8080B9;
L_8080B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B9u, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080B9 JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80BCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x8080B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080BD;
L_8080BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BDu,0x8080BDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 8u, 4u, 0x808992u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080BD JSL -> $808992 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808992u, 0x8080BDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C1;
L_8080C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C1u,0x8080C1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 8u, 4u, 0x808AC5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C1 JSL -> $808AC5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808AC5u, 0x8080C1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C5;
L_8080C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C5u,0x8080C5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 8u, 4u, 0x808ADCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C5 JSL -> $808ADC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808ADCu, 0x8080C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080C9;
L_8080C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C9u,0x8080C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C9u, 8u, 4u, 0x808B3Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080C9 JSL -> $808B3B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80CCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80CDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B3Bu, 0x8080C9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080CD;
L_8080CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80CDu,0x8080CDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CD REP
    cpu.rep(0x20u);
    goto L_8080CF;
L_8080CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080CF LDA
    cpu.setA(0x1C80u, 16);
    goto L_8080D2;
L_8080D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D2 STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8080D4;
L_8080D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D4 LDA
    cpu.setA(0x3200u, 16);
    goto L_8080D7;
L_8080D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D7 STA
    hw.write(cpu.address("dp", 0x52u), cpu.a, cpu.m8?8:16);
    goto L_8080D9;
L_8080D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080D9 LDA
    cpu.setA(0x2E00u, 16);
    goto L_8080DC;
L_8080DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080DC STA
    hw.write(cpu.address("dp", 0x4Au), cpu.a, cpu.m8?8:16);
    goto L_8080DE;
L_8080DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 8u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8080DE JSL -> $8083B6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80E1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80E2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8083B6u, 0x8080DEu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8080E2;
L_8080E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80E2u,0x8080E2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E2 REP
    cpu.rep(0x30u);
    goto L_8080E4;
L_8080E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080E4 PHB
    cpu.push("PHB", hw);
    goto L_8080E5;
L_8080E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E5 LDA
    cpu.setA(0x0u, 16);
    goto L_8080E8;
L_8080E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E8u, 6u, 4u, 0x7EFE00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080E8 STA
    hw.write(0x7EFE00u, cpu.a, cpu.m8?8:16);
    goto L_8080EC;
L_8080EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EC LDA
    cpu.setA(0x7Du, 16);
    goto L_8080EF;
L_8080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080EF LDX
    cpu.setX(0xFE01u, 16);
    goto L_8080F2;
L_8080F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F2 TXY
    cpu.transfer("TXY");
    goto L_8080F3;
L_8080F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F3 INY
    cpu.inc('Y');
    goto L_8080F4;
L_8080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0x80F4u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $8080F4 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_8080F7;
L_8080F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8080F7 PLB
    cpu.pop("PLB", hw);
    goto L_8080F8;
L_8080F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080F8 LDA
    cpu.setA(0x0u, 16);
    goto L_8080FB;
L_8080FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080FB INC
    cpu.inc('A');
    goto L_8080FC;
L_8080FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8080FC STA
    hw.write(0x7EFE12u, cpu.a, cpu.m8?8:16);
    goto L_808100;
L_808100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808100 LDA
    cpu.loadA(hw.readW(0x7EFE88u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_808104;
L_808104:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8104u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8104u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808104 STA
    hw.write(0x7EFE4Au, cpu.a, cpu.m8?8:16);
    goto L_808108;
L_808108:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8108u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8108u, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808108 LDA
    cpu.loadA(hw.readW(0x7EFE8Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80810C;
L_80810C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80810C LSR
    cpu.lsrA();
    goto L_80810D;
L_80810D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Du, 6u, 4u, 0x7EFE4Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80810D STA
    hw.write(0x7EFE4Eu, cpu.a, cpu.m8?8:16);
    goto L_808111;
L_808111:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8111u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8111u, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808111 LDA
    cpu.loadA(hw.readW(0x7EFE8Cu, cpu.m8?8:16), cpu.m8?8:16);
    goto L_808115;
L_808115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808115 LSR
    cpu.lsrA();
    goto L_808116;
L_808116:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8116u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8116u, 6u, 4u, 0x7EFE50u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808116 STA
    hw.write(0x7EFE50u, cpu.a, cpu.m8?8:16);
    goto L_80811A;
L_80811A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au,cpu,0x58u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811A CLI
    cpu.setFlag('I', false);
    goto L_80811B;
L_80811B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811B LDA
    cpu.setA(0x0u, 16);
    goto L_80811E;
L_80811E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811E TCD
    cpu.tcd();
    goto L_80811F;
L_80811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80811F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808121;
L_808121:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8121u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8121u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808121 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x42u), cpu.m8?8:16));
    goto L_808123;
L_808123:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8123u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8123u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808123 STA
    hw.write(cpu.address("dp", 0x8Au), cpu.a, cpu.m8?8:16);
    goto L_808125;
L_808125:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8125u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8125u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808125 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808127;
L_808127:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8127u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8127u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808127 LSR
    cpu.lsrA();
    goto L_808128;
L_808128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808128 BCC -> $80811B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80811B; }
    goto L_80812A;
L_80812A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Au, 8u, 4u, 0x82ECD1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80812A JSL -> $82ECD1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x812Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x812Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82ECD1u, 0x80812Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80812E;
L_80812E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x812Eu,0x80812Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80812E BRA -> $80811B
    goto L_80811B;
}

void sub_809B1F_E0M0X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809BA8u: goto L_809BA8;
    case 0x809BA9u: goto L_809BA9;
    case 0x809BACu: goto L_809BAC;
    case 0x809BAEu: goto L_809BAE;
    case 0x809BAFu: goto L_809BAF;
    case 0x809BB2u: goto L_809BB2;
    case 0x809BB4u: goto L_809BB4;
    case 0x809BB6u: goto L_809BB6;
    case 0x809BB8u: goto L_809BB8;
    case 0x809BBAu: goto L_809BBA;
    case 0x809BBCu: goto L_809BBC;
    case 0x809BBEu: goto L_809BBE;
    case 0x809BC0u: goto L_809BC0;
    case 0x809BC2u: goto L_809BC2;
    case 0x809BC4u: goto L_809BC4;
    case 0x809BC6u: goto L_809BC6;
    case 0x809BC7u: goto L_809BC7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809BA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA8u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA8u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BA8 SEC
    cpu.setFlag('C', true);
    goto L_809BA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BA8u,0x809BA8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BA9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BA9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BA9 SBC
    cpu.sbc(0x4u);
    goto L_809BAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BA9u,0x809BA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BACu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BAC STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_809BAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BACu,0x809BACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BAEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BAE SEC
    cpu.setFlag('C', true);
    goto L_809BAF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BAEu,0x809BAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BAFu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BAFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BAF SBC
    cpu.sbc(0x4u);
    goto L_809BB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BAFu,0x809BAFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BB2 STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_809BB4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BB2u,0x809BB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BB4 SEP
    cpu.sep(0x20u);
    goto L_809BB6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BB4u,0x809BB4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BB6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BB6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BB6u,0x809BB6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BB8u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BB8 BMI -> $809BBC
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_809BBC; }
    goto L_809BBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BB8u,0x809BB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBAu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xECu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xECu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BBAu,0x809BBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBCu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BBC AND
    cpu.logicAnd(0x30u);
    goto L_809BBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BBCu,0x809BBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BBEu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BBEu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BBE STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_809BC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BBEu,0x809BBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC0u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BC0 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809BC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC0u,0x809BC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BC2 AND
    cpu.logicAnd(0xC0u);
    goto L_809BC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC2u,0x809BC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC4u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC4u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BC4 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_809BC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC4u,0x809BC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC6u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC6u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BC6 ASL
    cpu.aslA();
    goto L_809BC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC6u,0x809BC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809BC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9BC7u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9BC7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809BC7 REP
    cpu.rep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC9u,0x809BC7u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9BC7u,0x809BC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A135_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A135u: goto L_80A135;
    case 0x80A138u: goto L_80A138;
    case 0x80A13Cu: goto L_80A13C;
    case 0x80A13Fu: goto L_80A13F;
    case 0x80A142u: goto L_80A142;
    case 0x80A146u: goto L_80A146;
    case 0x80A149u: goto L_80A149;
    case 0x80A14Cu: goto L_80A14C;
    case 0x80A14Du: goto L_80A14D;
    case 0x80A150u: goto L_80A150;
    case 0x80A153u: goto L_80A153;
    case 0x80A157u: goto L_80A157;
    case 0x80A15Au: goto L_80A15A;
    case 0x80A15Eu: goto L_80A15E;
    case 0x80A161u: goto L_80A161;
    case 0x80A165u: goto L_80A165;
    case 0x80A168u: goto L_80A168;
    case 0x80A16Bu: goto L_80A16B;
    case 0x80A16Eu: goto L_80A16E;
    case 0x80A16Fu: goto L_80A16F;
    case 0x80A170u: goto L_80A170;
    case 0x80A173u: goto L_80A173;
    case 0x80A174u: goto L_80A174;
    case 0x80A177u: goto L_80A177;
    case 0x80A178u: goto L_80A178;
    case 0x80A179u: goto L_80A179;
    case 0x80A17Bu: goto L_80A17B;
    case 0x80A17Du: goto L_80A17D;
    case 0x80A17Fu: goto L_80A17F;
    case 0x80A180u: goto L_80A180;
    case 0x80A182u: goto L_80A182;
    case 0x80A185u: goto L_80A185;
    case 0x80A187u: goto L_80A187;
    case 0x80A188u: goto L_80A188;
    case 0x80A18Au: goto L_80A18A;
    case 0x80A18Cu: goto L_80A18C;
    case 0x80A18Fu: goto L_80A18F;
    case 0x80A191u: goto L_80A191;
    case 0x80A193u: goto L_80A193;
    case 0x80A195u: goto L_80A195;
    case 0x80A197u: goto L_80A197;
    case 0x80A199u: goto L_80A199;
    case 0x80A19Cu: goto L_80A19C;
    case 0x80A19Du: goto L_80A19D;
    case 0x80A1A0u: goto L_80A1A0;
    case 0x80A1A2u: goto L_80A1A2;
    case 0x80A1A4u: goto L_80A1A4;
    case 0x80A1A7u: goto L_80A1A7;
    case 0x80A1A9u: goto L_80A1A9;
    case 0x80A1ABu: goto L_80A1AB;
    case 0x80A1ADu: goto L_80A1AD;
    case 0x80A1AFu: goto L_80A1AF;
    case 0x80A1B2u: goto L_80A1B2;
    case 0x80A1B5u: goto L_80A1B5;
    case 0x80A1B7u: goto L_80A1B7;
    case 0x80A1B9u: goto L_80A1B9;
    case 0x80A1BCu: goto L_80A1BC;
    case 0x80A1BFu: goto L_80A1BF;
    case 0x80A1C2u: goto L_80A1C2;
    case 0x80A1C4u: goto L_80A1C4;
    case 0x80A1C6u: goto L_80A1C6;
    case 0x80A1C8u: goto L_80A1C8;
    case 0x80A1CBu: goto L_80A1CB;
    case 0x80A1CDu: goto L_80A1CD;
    case 0x80A1D0u: goto L_80A1D0;
    case 0x80A1D2u: goto L_80A1D2;
    case 0x80A1D5u: goto L_80A1D5;
    case 0x80A1D6u: goto L_80A1D6;
    case 0x80A1D7u: goto L_80A1D7;
    case 0x80A1D8u: goto L_80A1D8;
    case 0x80A1DAu: goto L_80A1DA;
    case 0x80A1DCu: goto L_80A1DC;
    case 0x80A1DEu: goto L_80A1DE;
    case 0x80A1E0u: goto L_80A1E0;
    case 0x80A1E2u: goto L_80A1E2;
    case 0x80A1E4u: goto L_80A1E4;
    case 0x80A1E6u: goto L_80A1E6;
    case 0x80A1E8u: goto L_80A1E8;
    case 0x80A1EAu: goto L_80A1EA;
    case 0x80A1EBu: goto L_80A1EB;
    case 0x80A1EDu: goto L_80A1ED;
    case 0x80A1EFu: goto L_80A1EF;
    case 0x80A1F0u: goto L_80A1F0;
    case 0x80A1F1u: goto L_80A1F1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A135:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA135u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA135u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA135u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A135 LDX
    cpu.setX(0xFFFFu, 16);
    goto L_80A138;
L_80A138:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA138u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA138u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA138u, 6u, 4u, 0x0060A2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A138 CMP
    cpu.compareA(hw.readW(0x60A2u, cpu.m8?8:16));
    goto L_80A13C;
L_80A13C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Cu, 5u, 3u, cpu.address("abs", 0x1F12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A13C STX
    hw.write(cpu.address("abs", 0x1F12u), cpu.x, cpu.x8?8:16);
    goto L_80A13F;
L_80A13F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA13Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA13Fu, 5u, 3u, cpu.address("abs", 0x1F10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A13F STY
    hw.write(cpu.address("abs", 0x1F10u), cpu.y, cpu.x8?8:16);
    goto L_80A142;
L_80A142:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA142u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA142u, 6u, 4u, 0x7EA000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A142 LDA
    cpu.loadA(hw.readW(0x7EA000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A146;
L_80A146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA146u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A146 AND
    cpu.logicAnd(0xFFu);
    goto L_80A149;
L_80A149:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA149u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA149u, 5u, 3u, cpu.address("abs", 0x1F02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A149 STA
    hw.write(cpu.address("abs", 0x1F02u), cpu.a, cpu.m8?8:16);
    goto L_80A14C;
L_80A14C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Cu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A14C CLC
    cpu.setFlag('C', false);
    goto L_80A14D;
L_80A14D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA14Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA14Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A14D ADC
    cpu.adc(0xA003u);
    goto L_80A150;
L_80A150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA150u, 5u, 3u, cpu.address("abs", 0x1F06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A150 STA
    hw.write(cpu.address("abs", 0x1F06u), cpu.a, cpu.m8?8:16);
    goto L_80A153;
L_80A153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA153u, 6u, 4u, 0x7EA001u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A153 ADC
    cpu.adc(hw.readW(0x7EA001u, cpu.m8?8:16));
    goto L_80A157;
L_80A157:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA157u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA157u, 5u, 3u, cpu.address("abs", 0x1F08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A157 STA
    hw.write(cpu.address("abs", 0x1F08u), cpu.a, cpu.m8?8:16);
    goto L_80A15A;
L_80A15A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Au, 6u, 4u, 0x7EA001u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A15A ADC
    cpu.adc(hw.readW(0x7EA001u, cpu.m8?8:16));
    goto L_80A15E;
L_80A15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA15Eu, 5u, 3u, cpu.address("abs", 0x1F0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A15E STA
    hw.write(cpu.address("abs", 0x1F0Au), cpu.a, cpu.m8?8:16);
    goto L_80A161;
L_80A161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u,cpu,0x6Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA161u, 6u, 4u, 0x7EA001u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A161 ADC
    cpu.adc(hw.readW(0x7EA001u, cpu.m8?8:16));
    goto L_80A165;
L_80A165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA165u, 5u, 3u, cpu.address("abs", 0x1F0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A165 STA
    hw.write(cpu.address("abs", 0x1F0Cu), cpu.a, cpu.m8?8:16);
    goto L_80A168;
L_80A168:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA168u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA168u, 5u, 3u, cpu.address("abs", 0x1F04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A168 STZ
    hw.write(cpu.address("abs", 0x1F04u), 0, cpu.m8?8:16);
    goto L_80A16B;
L_80A16B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Bu, 5u, 3u, cpu.address("abs", 0x1F0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A16B STZ
    hw.write(cpu.address("abs", 0x1F0Eu), 0, cpu.m8?8:16);
    goto L_80A16E;
L_80A16E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Eu,cpu,0x0Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A16E PHD
    cpu.push("PHD", hw);
    goto L_80A16F;
L_80A16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA16Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A16F PHB
    cpu.push("PHB", hw);
    goto L_80A170;
L_80A170:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA170u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA170u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A170 LDA
    cpu.setA(0x1F00u, 16);
    goto L_80A173;
L_80A173:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA173u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA173u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A173 TCD
    cpu.tcd();
    goto L_80A174;
L_80A174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA174u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA174u, 5u, 3u, cpu.address("abs", 0x7E00u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A174 PEA
    cpu.push16Value(hw, 0x7E00u);
    goto L_80A177;
L_80A177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA177u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA177u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A177 PLB
    cpu.pop("PLB", hw);
    goto L_80A178;
L_80A178:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA178u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA178u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A178 PLB
    cpu.pop("PLB", hw);
    goto L_80A179;
L_80A179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA179u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A179 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A17B;
L_80A17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A17B STZ
    hw.write(cpu.address("dp", 0x14u), 0, cpu.m8?8:16);
    goto L_80A17D;
L_80A17D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A17D SEP
    cpu.sep(0x20u);
    goto L_80A17F;
L_80A17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA17Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA17Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A17F CLC
    cpu.setFlag('C', false);
    goto L_80A180;
L_80A180:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA180u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A180 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A182;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA180u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A180 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A182;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA180u,0x80A180u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA182u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u, 4u + 1u, 3u, cpu.address("absy", 0xA003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A182 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA003u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A185;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA182u, 4u + 1u, 3u, cpu.address("absy", 0xA003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A182 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA003u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A185;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA182u,0x80A182u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A185:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA185u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A185 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A187;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA185u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A185 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A187;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA185u,0x80A185u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA187u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A187 INY
    cpu.inc('Y');
    goto L_80A188;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA187u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A187 INY
    cpu.inc('Y');
    goto L_80A188;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA187u,0x80A187u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A188:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA188u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A188 STY
    hw.write(cpu.address("dp", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_80A18A;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA188u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A188 STY
    hw.write(cpu.address("dp", 0x4u), cpu.y, cpu.x8?8:16);
    goto L_80A18A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA188u,0x80A188u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A18A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18A REP
    cpu.rep(0x20u);
    goto L_80A18C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18A REP
    cpu.rep(0x20u);
    goto L_80A18C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Au,0x80A18Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A18C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18C AND
    cpu.logicAnd(0xFFu);
    goto L_80A18F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18C AND
    cpu.logicAnd(0xFFu);
    goto L_80A18F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Cu,0x80A18Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A18F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA18Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80A191;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA18Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A18F ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16));
    goto L_80A191;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA18Fu,0x80A18Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA191u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A191 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_80A193;
L_80A193:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA193u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA193u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA193u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A193 SEP
    cpu.sep(0x20u);
    goto L_80A195;
L_80A195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA195u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA195u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A195 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A197;
L_80A197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA197u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A197 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A199;
L_80A199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA199u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A199 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A19C;
L_80A19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Cu, 5u, 4u, 0x00009Eu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A19C CMP
    cpu.compareA(hw.readW(0x9Eu, cpu.m8?8:16));
    goto L_80A1A0;
L_80A19D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA19Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA19Du, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A19D STZ
    hw.write(cpu.address("absx", 0x0u), 0, cpu.m8?8:16);
    goto L_80A1A0;
L_80A1A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A0u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Cu) & 0xFFFFu), 2u, 0u);
    // $80A1A0 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1A2;
L_80A1A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A2u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1A2 AND
    cpu.logicAnd(0xCFu);
    goto L_80A1A4;
L_80A1A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A4u, 5u, 3u, cpu.address("absx", 0x4801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1A4 STA
    hw.write(cpu.address("absx", 0x4801u), cpu.a, cpu.m8?8:16);
    goto L_80A1A7;
L_80A1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A7u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Cu) & 0xFFFFu), 2u, 0u);
    // $80A1A7 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1A9;
L_80A1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A9u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1A9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1A9 AND
    cpu.logicAnd(0x10u);
    goto L_80A1AB;
L_80A1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ABu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1AB BEQ -> $80A1AF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A1AF; }
    goto L_80A1AD;
L_80A1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1ADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1AD LDA
    cpu.setA(0xFFu, 8);
    goto L_80A1AF;
L_80A1AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1AFu, 5u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1AF STA
    hw.write(cpu.address("absx", 0x1u), cpu.a, cpu.m8?8:16);
    goto L_80A1B2;
L_80A1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B2u, 5u, 3u, cpu.address("absx", 0x1801u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1B2 STZ
    hw.write(cpu.address("absx", 0x1801u), 0, cpu.m8?8:16);
    goto L_80A1B5;
L_80A1B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B5u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x06u) & 0xFFFFu), 2u, 0u);
    // $80A1B5 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1B7;
L_80A1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B7u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1B7 BPL -> $80A1BC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80A1BC; }
    goto L_80A1B9;
L_80A1B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1B9u, 7u, 3u, cpu.address("absx", 0x1801u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1B9 DEC
    cpu.decMem(hw, cpu.address("absx", 0x1801u), cpu.m8?8:16);
    goto L_80A1BC;
L_80A1BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BCu, 5u, 3u, cpu.address("absx", 0x1800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1BC STA
    hw.write(cpu.address("absx", 0x1800u), cpu.a, cpu.m8?8:16);
    goto L_80A1BF;
L_80A1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1BFu, 5u, 3u, cpu.address("absx", 0x3001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1BF STZ
    hw.write(cpu.address("absx", 0x3001u), 0, cpu.m8?8:16);
    goto L_80A1C2;
L_80A1C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Cu) & 0xFFFFu), 2u, 0u);
    // $80A1C2 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1C4;
L_80A1C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1C4 BIT
    cpu.bit(0x20u, true);
    goto L_80A1C6;
L_80A1C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1C6 BEQ -> $80A1CB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A1CB; }
    goto L_80A1C8;
L_80A1C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1C8u, 7u, 3u, cpu.address("absx", 0x3001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1C8 DEC
    cpu.decMem(hw, cpu.address("absx", 0x3001u), cpu.m8?8:16);
    goto L_80A1CB;
L_80A1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x08u) & 0xFFFFu), 2u, 0u);
    // $80A1CB LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1CD;
L_80A1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1CDu, 5u, 3u, cpu.address("absx", 0x3000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1CD STA
    hw.write(cpu.address("absx", 0x3000u), cpu.a, cpu.m8?8:16);
    goto L_80A1D0;
L_80A1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D0u,cpu,0xB1u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u) + 1u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x0Au) & 0xFFFFu), 2u, 0u);
    // $80A1D0 LDA
    cpu.loadA(hw.readW(cpu.addressDpIndirectY(hw, 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A1D2;
L_80A1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D2u, 5u, 3u, cpu.address("absx", 0x4800u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1D2 STA
    hw.write(cpu.address("absx", 0x4800u), cpu.a, cpu.m8?8:16);
    goto L_80A1D5;
L_80A1D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1D5 INY
    cpu.inc('Y');
    goto L_80A1D6;
L_80A1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1D6 INX
    cpu.inc('X');
    goto L_80A1D7;
L_80A1D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D7u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1D7 INX
    cpu.inc('X');
    goto L_80A1D8;
L_80A1D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1D8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1D8 DEC
    cpu.decMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_80A1DA;
L_80A1DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1DA BNE -> $80A19D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A19D; }
    goto L_80A1DC;
L_80A1DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1DC STY
    hw.write(cpu.address("dp", 0xEu), cpu.y, cpu.x8?8:16);
    goto L_80A1DE;
L_80A1DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DEu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1DEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1DE DEC
    cpu.decMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_80A1E0;
L_80A1E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1E0 BEQ -> $80A1EA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A1EA; }
    goto L_80A1E2;
L_80A1E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1E2 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x14u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A1E4;
L_80A1E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u,cpu,0xC4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1E4 CPY
    cpu.compareY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16));
    goto L_80A1E6;
L_80A1E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1E6 BCC -> $80A180
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80A180; }
    goto L_80A1E8;
L_80A1E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1E8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1E8 BRA -> $80A1EB
    goto L_80A1EB;
L_80A1EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EAu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1EA CLC
    cpu.setFlag('C', false);
    goto L_80A1EB;
L_80A1EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1EB STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_80A1ED;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1EB STX
    hw.write(cpu.address("dp", 0x10u), cpu.x, cpu.x8?8:16);
    goto L_80A1ED;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EBu,0x80A1EBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A1ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1ED REP
    cpu.rep(0x20u);
    goto L_80A1EF;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A1ED REP
    cpu.rep(0x20u);
    goto L_80A1EF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EDu,0x80A1EDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A1EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1EFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A1EF PLB
    cpu.pop("PLB", hw);
    goto L_80A1F0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1EFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A1EF PLB
    cpu.pop("PLB", hw);
    goto L_80A1F0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1EFu,0x80A1EFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A1F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A1F0 PLD
    cpu.pop("PLD", hw);
    goto L_80A1F1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A1F0 PLD
    cpu.pop("PLD", hw);
    goto L_80A1F1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1F0u,0x80A1F0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A1F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA1F1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A1F1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A1F1u);return;} hw.unresolvedReturn(0x80A1F1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA1F1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A1F1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80A1F1u);return;} hw.unresolvedReturn(0x80A1F1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA1F1u,0x80A1F1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A436_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A436u: goto L_80A436;
    case 0x80A439u: goto L_80A439;
    case 0x80A43Bu: goto L_80A43B;
    case 0x80A43Eu: goto L_80A43E;
    case 0x80A440u: goto L_80A440;
    case 0x80A441u: goto L_80A441;
    case 0x80A442u: goto L_80A442;
    case 0x80A444u: goto L_80A444;
    case 0x80A447u: goto L_80A447;
    case 0x80A448u: goto L_80A448;
    case 0x80A44Bu: goto L_80A44B;
    case 0x80A44Du: goto L_80A44D;
    case 0x80A44Fu: goto L_80A44F;
    case 0x80A451u: goto L_80A451;
    case 0x80A453u: goto L_80A453;
    case 0x80A455u: goto L_80A455;
    case 0x80A456u: goto L_80A456;
    case 0x80A457u: goto L_80A457;
    case 0x80A45Au: goto L_80A45A;
    case 0x80A45Cu: goto L_80A45C;
    case 0x80A45Eu: goto L_80A45E;
    case 0x80A460u: goto L_80A460;
    case 0x80A462u: goto L_80A462;
    case 0x80A464u: goto L_80A464;
    case 0x80A465u: goto L_80A465;
    case 0x80A467u: goto L_80A467;
    case 0x80A468u: goto L_80A468;
    case 0x80A46Bu: goto L_80A46B;
    case 0x80A46Du: goto L_80A46D;
    case 0x80A46Eu: goto L_80A46E;
    case 0x80A471u: goto L_80A471;
    case 0x80A473u: goto L_80A473;
    case 0x80A476u: goto L_80A476;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A436:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA436u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA436u, 5u, 3u, cpu.address("abs", 0x1C30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A436 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C30u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A439;
L_80A439:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA439u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA439u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA439u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A439 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80A43B;
L_80A43B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Bu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Bu, 5u, 3u, cpu.address("abs", 0x1C32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A43B LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1C32u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A43E;
L_80A43E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA43Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA43Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A43E STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_80A440;
L_80A440:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA440u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA440u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A440 PHB
    cpu.push("PHB", hw);
    goto L_80A441;
L_80A441:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA441u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA441u,cpu,0x3Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA441u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A441 TSC
    cpu.tsc();
    goto L_80A442;
L_80A442:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA442u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA442u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA442u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A442 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_80A444;
L_80A444:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA444u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA444u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A444 LDA
    cpu.setA(0x6EFu, 16);
    goto L_80A447;
L_80A447:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA447u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA447u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA447u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A447 TCS
    cpu.tcs();
    goto L_80A448;
L_80A448:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA448u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA448u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A448 LDA
    cpu.setA(0x6F0u, 16);
    goto L_80A44B;
L_80A44B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A44B STA
    hw.write(cpu.address("dp", 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_80A44D;
L_80A44D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A44D SEP
    cpu.sep(0x20u);
    goto L_80A44F;
L_80A44F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA44Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA44Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A44F LDA
    cpu.setA(0x80u, 8);
    goto L_80A451;
L_80A451:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA451u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA451u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A451 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_80A453;
L_80A453:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA453u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA453u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A453 LDA
    cpu.setA(0x7Eu, 8);
    goto L_80A455;
L_80A455:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA455u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA455u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A455 PHA
    cpu.push("PHA", hw);
    goto L_80A456;
L_80A456:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA456u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA456u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA456u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80A456 PLB
    cpu.pop("PLB", hw);
    goto L_80A457;
L_80A457:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA457u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA457u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A457 LDY
    cpu.setY(0x1E00u, 16);
    goto L_80A45A;
L_80A45A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Au,cpu,0xB6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpy", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A45A LDX
    cpu.setX(hw.readW(cpu.address("dpy", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A45C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA45Au,0x80A45Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A45C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Cu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A45C BEQ -> $80A4B3
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x80A4B3u,0x80A45Cu); return; }
    goto L_80A45E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA45Cu,0x80A45Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A45E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA45Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA45Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A45E STY
    hw.write(cpu.address("dp", 0xFEu), cpu.y, cpu.x8?8:16);
    goto L_80A460;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA45Eu,0x80A45Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A460:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA460u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA460u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A460 REP
    cpu.rep(0x20u);
    goto L_80A462;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA460u,0x80A460u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A462:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA462u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA462u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A462 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A464;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA462u,0x80A462u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A464:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA464u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA464u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A464 SEC
    cpu.setFlag('C', true);
    goto L_80A465;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA464u,0x80A464u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A465:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA465u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA465u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A465 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_80A467;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA465u,0x80A465u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A467:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA467u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA467u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A467 SEC
    cpu.setFlag('C', true);
    goto L_80A468;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA467u,0x80A467u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A468:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA468u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA468u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A468 SBC
    cpu.sbc(0x8u);
    goto L_80A46B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA468u,0x80A468u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A46B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A46B STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80A46D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA46Bu,0x80A46Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A46D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A46D SEC
    cpu.setFlag('C', true);
    goto L_80A46E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA46Du,0x80A46Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A46E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA46Eu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA46Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A46E SBC
    cpu.sbc(0x8u);
    goto L_80A471;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA46Eu,0x80A46Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A471:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA471u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA471u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA471u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A471 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_80A473;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA471u,0x80A471u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A473:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA473u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA473u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A473 ADC
    cpu.adc(0x60u);
    goto L_80A476;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA473u,0x80A473u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A476:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA476u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA476u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A476 CMP
    cpu.compareA(0x1C0u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA479u,0x80A476u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA476u,0x80A476u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A9D7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A9D7u: goto L_80A9D7;
    case 0x80A9DAu: goto L_80A9DA;
    case 0x80A9DCu: goto L_80A9DC;
    case 0x80A9E0u: goto L_80A9E0;
    case 0x80A9E3u: goto L_80A9E3;
    case 0x80A9E5u: goto L_80A9E5;
    case 0x80A9E7u: goto L_80A9E7;
    case 0x80A9E9u: goto L_80A9E9;
    case 0x80A9EBu: goto L_80A9EB;
    case 0x80A9EDu: goto L_80A9ED;
    case 0x80A9F0u: goto L_80A9F0;
    case 0x80A9F2u: goto L_80A9F2;
    case 0x80A9F5u: goto L_80A9F5;
    case 0x80A9F6u: goto L_80A9F6;
    case 0x80A9F7u: goto L_80A9F7;
    case 0x80A9F9u: goto L_80A9F9;
    case 0x80A9FDu: goto L_80A9FD;
    case 0x80A9FFu: goto L_80A9FF;
    case 0x80AA01u: goto L_80AA01;
    case 0x80AA04u: goto L_80AA04;
    case 0x80AA05u: goto L_80AA05;
    case 0x80AA07u: goto L_80AA07;
    case 0x80AA0Au: goto L_80AA0A;
    case 0x80AA0Du: goto L_80AA0D;
    case 0x80AA0Fu: goto L_80AA0F;
    case 0x80AA12u: goto L_80AA12;
    case 0x80AA14u: goto L_80AA14;
    case 0x80AA17u: goto L_80AA17;
    case 0x80AA19u: goto L_80AA19;
    case 0x80AA1Cu: goto L_80AA1C;
    case 0x80AA1Eu: goto L_80AA1E;
    case 0x80AA20u: goto L_80AA20;
    case 0x80AA22u: goto L_80AA22;
    case 0x80AA25u: goto L_80AA25;
    case 0x80AA27u: goto L_80AA27;
    case 0x80AA2Bu: goto L_80AA2B;
    case 0x80AA2Du: goto L_80AA2D;
    case 0x80AA30u: goto L_80AA30;
    case 0x80AA31u: goto L_80AA31;
    case 0x80AA33u: goto L_80AA33;
    case 0x80AA35u: goto L_80AA35;
    case 0x80AA37u: goto L_80AA37;
    case 0x80AA3Bu: goto L_80AA3B;
    case 0x80AA3Du: goto L_80AA3D;
    case 0x80AA41u: goto L_80AA41;
    case 0x80AA43u: goto L_80AA43;
    case 0x80AA46u: goto L_80AA46;
    case 0x80AA49u: goto L_80AA49;
    case 0x80AA4Au: goto L_80AA4A;
    case 0x80AA4Cu: goto L_80AA4C;
    case 0x80AA4Eu: goto L_80AA4E;
    case 0x80AA4Fu: goto L_80AA4F;
    case 0x80AA51u: goto L_80AA51;
    case 0x80AA54u: goto L_80AA54;
    case 0x80AA56u: goto L_80AA56;
    case 0x80AA58u: goto L_80AA58;
    case 0x80AA5Cu: goto L_80AA5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A9D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9D7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9D7 LDA
    cpu.setA(0x1u, 16);
    goto L_80A9DA;
L_80A9DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9DA STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_80A9DC;
L_80A9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9DCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9DC BRA -> $80A9E0
    goto L_80A9E0;
L_80A9E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9E0 LDA
    cpu.setA(0x2000u, 16);
    goto L_80A9E3;
L_80A9E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9E3 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80A9E5;
L_80A9E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9E5 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9E7;
L_80A9E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80A9E9;
L_80A9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9E9 BEQ -> $80A9FF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A9FF; }
    goto L_80A9EB;
L_80A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9EB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9ED;
L_80A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9ED LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9F0;
L_80A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F0 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9F2;
L_80A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F2 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9F5;
L_80A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F5 INX
    cpu.inc('X');
    goto L_80A9F6;
L_80A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F6 INX
    cpu.inc('X');
    goto L_80A9F7;
L_80A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F7 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9F9;
L_80A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
L_80A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9FDu,0x80A9FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FD STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80A9FF;
L_80A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA01;
L_80AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA04;
L_80AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA04 INX
    cpu.inc('X');
    goto L_80AA05;
L_80AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA05 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA07;
L_80AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA07 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA0A;
L_80AA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0A CMP
    cpu.compareA(0xFFu);
    goto L_80AA0D;
L_80AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0D BEQ -> $80AA56
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA56; }
    goto L_80AA0F;
L_80AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0F CMP
    cpu.compareA(0xFEu);
    goto L_80AA12;
L_80AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA12 BEQ -> $80AA37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA37; }
    goto L_80AA14;
L_80AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA14 CMP
    cpu.compareA(0xFDu);
    goto L_80AA17;
L_80AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA17 BEQ -> $80AA2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA2D; }
    goto L_80AA19;
L_80AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA19 CMP
    cpu.compareA(0xFBu);
    goto L_80AA1C;
L_80AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1C BEQ -> $80AA3D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA3D; }
    goto L_80AA1E;
L_80AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA20;
L_80AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA20 BEQ -> $80AA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA25; }
    goto L_80AA22;
L_80AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA22 LDA
    cpu.setA(0x0u, 16);
    goto L_80AA25;
L_80AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA25 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80AA27;
L_80AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA27 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x80AA27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA2B;
L_80AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,0x80AA2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2B BRA -> $80A9FF
    goto L_80A9FF;
L_80AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA30;
L_80AA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA30 INX
    cpu.inc('X');
    goto L_80AA31;
L_80AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA31 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA33;
L_80AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA33 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_80AA35;
L_80AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA35 BRA -> $80A9FF
    goto L_80A9FF;
L_80AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA37 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA37u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA3B;
L_80AA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,0x80AA3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA3B BRA -> $80A9EB
    goto L_80A9EB;
L_80AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA3D JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA41;
L_80AA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA41u,0x80AA41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA41 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA43;
L_80AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA43 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA46;
L_80AA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA46 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA49;
L_80AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA49 CLC
    cpu.setFlag('C', false);
    goto L_80AA4A;
L_80AA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80AA4C;
L_80AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4C STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80AA4E;
L_80AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4E TAY
    cpu.transfer("TAY");
    goto L_80AA4F;
L_80AA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80AA51;
L_80AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA51 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80AA54;
L_80AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA54 BRA -> $80A9F9
    goto L_80A9F9;
L_80AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA56 STZ
    hw.write(cpu.address("dp", 0x8Cu), 0, cpu.m8?8:16);
    goto L_80AA58;
L_80AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA58 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA5C;
L_80AA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,0x80AA5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA5C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AA5Cu);return;} hw.unresolvedReturn(0x80AA5Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80BB55_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BB55u: goto L_80BB55;
    case 0x80BB59u: goto L_80BB59;
    case 0x80BB5Du: goto L_80BB5D;
    case 0x80BB5Fu: goto L_80BB5F;
    case 0x80BB61u: goto L_80BB61;
    case 0x80BB63u: goto L_80BB63;
    case 0x80BB65u: goto L_80BB65;
    case 0x80BB66u: goto L_80BB66;
    case 0x80BB67u: goto L_80BB67;
    case 0x80BB8Au: goto L_80BB8A;
    case 0x80BB8Cu: goto L_80BB8C;
    case 0x80BB8Fu: goto L_80BB8F;
    case 0x80BB91u: goto L_80BB91;
    case 0x80BB94u: goto L_80BB94;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BB55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB55u, 8u, 4u, 0x80C383u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB55 JSL -> $80C383 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB58u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB59u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C383u, 0x80BB55u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB59;
L_80BB59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB59u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB59u,0x80BB59u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB59u, 8u, 4u, 0x80C18Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB59 JSL -> $80C18B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBB5Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB5Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C18Bu, 0x80BB59u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB5D;
L_80BB5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB5Du,0x80BB5Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB5D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB5F;
L_80BB5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB5F BNE -> $80BB8A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB8A; }
    goto L_80BB61;
L_80BB61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB61u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB61 INC
    cpu.incMem(hw, cpu.address("dp", 0x88u), cpu.m8?8:16);
    goto L_80BB63;
L_80BB63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB63u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB63u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB63 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB65;
L_80BB65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB65u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB65 ASL
    cpu.aslA();
    goto L_80BB66;
L_80BB66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB66u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB66 TAX
    cpu.transfer("TAX");
    goto L_80BB67;
L_80BB67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB67u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBB6Au + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BB67 JMP (BB6A,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBB6Au+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BB67u); return; }
L_80BB8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x80u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x80u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BB8C;
L_80BB8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8C CMP
    cpu.compareA(0x8u);
    goto L_80BB8F;
L_80BB8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB8Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BB8F BNE -> $80BB94
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BB94; }
    goto L_80BB91;
L_80BB91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB91u, 6u, 3u, cpu.address("abs", 0xC22Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80BB91 JSR -> $80C22E stack real
    { cpu.push16Value(hw,0xBB93u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBB94u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC22Eu), 0x80BB91u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BB94;
L_80BB94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBB94u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBB94u,0x80BB94u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBB94u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BB94 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BB94u);return;} hw.unresolvedReturn(0x80BB94u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8290D0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8290D0u: goto L_8290D0;
    case 0x8290D3u: goto L_8290D3;
    case 0x8290D5u: goto L_8290D5;
    case 0x8290D8u: goto L_8290D8;
    case 0x8290DAu: goto L_8290DA;
    case 0x8290DCu: goto L_8290DC;
    case 0x8290DFu: goto L_8290DF;
    case 0x8290E0u: goto L_8290E0;
    case 0x8290E3u: goto L_8290E3;
    case 0x8290E5u: goto L_8290E5;
    case 0x8290E7u: goto L_8290E7;
    case 0x8290EAu: goto L_8290EA;
    case 0x8290EDu: goto L_8290ED;
    case 0x8290F0u: goto L_8290F0;
    case 0x8290F2u: goto L_8290F2;
    case 0x8290F4u: goto L_8290F4;
    case 0x8290F7u: goto L_8290F7;
    case 0x8290FAu: goto L_8290FA;
    case 0x8290FDu: goto L_8290FD;
    case 0x8290FFu: goto L_8290FF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8290D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D0 LDA
    cpu.setA(0x80u, 16);
    goto L_8290D3;
L_8290D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D3 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_8290D5;
L_8290D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D5 LDA
    cpu.setA(0xFF00u, 16);
    goto L_8290D8;
L_8290D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290D8 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_8290DA;
L_8290DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DAu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290DA BPL -> $8290DF
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8290DF; }
    goto L_8290DC;
L_8290DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290DC LDA
    cpu.setA(0xFF70u, 16);
    goto L_8290DF;
L_8290DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290DF CLC
    cpu.setFlag('C', false);
    goto L_8290E0;
L_8290E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E0 ADC
    cpu.adc(0x800u);
    goto L_8290E3;
L_8290E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E3 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_8290E5;
L_8290E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E5 STZ
    hw.write(cpu.address("dp", 0xCu), 0, cpu.m8?8:16);
    goto L_8290E7;
L_8290E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90E7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290E7 LDY
    cpu.setY(0x700u, 16);
    goto L_8290EA;
L_8290EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290EA LDX
    cpu.setX(0x1C00u, 16);
    goto L_8290ED;
L_8290ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90EDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90EDu, 6u, 3u, cpu.address("abs", 0x9100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8290ED JSR -> $829100 stack real
    { cpu.push16Value(hw,0x90EFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90F0u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9100u), 0x8290EDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8290F0;
L_8290F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90F0u,0x8290F0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F0 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_8290F2;
L_8290F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F2u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F2 BPL -> $8290FD
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8290FD; }
    goto L_8290F4;
L_8290F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F4 LDY
    cpu.setY(0x750u, 16);
    goto L_8290F7;
L_8290F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90F7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90F7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290F7 LDX
    cpu.setX(0x1C30u, 16);
    goto L_8290FA;
L_8290FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FAu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FAu, 6u, 3u, cpu.address("abs", 0x9100u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8290FA JSR -> $829100 stack real
    { cpu.push16Value(hw,0x90FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x90FDu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9100u), 0x8290FAu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8290FD;
L_8290FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x90FDu,0x8290FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8290FD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8290FF;
L_8290FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x90FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x90FFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x90FFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8290FF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8290FFu);return;} hw.unresolvedReturn(0x8290FFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829558_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829557u: goto L_829557;
    case 0x829558u: goto L_829558;
    case 0x82955Au: goto L_82955A;
    case 0x82955Cu: goto L_82955C;
    case 0x82955Fu: goto L_82955F;
    case 0x829561u: goto L_829561;
    case 0x829564u: goto L_829564;
    case 0x829566u: goto L_829566;
    case 0x829568u: goto L_829568;
    case 0x82956Bu: goto L_82956B;
    case 0x82956Eu: goto L_82956E;
    case 0x829570u: goto L_829570;
    case 0x829572u: goto L_829572;
    case 0x829575u: goto L_829575;
    case 0x829577u: goto L_829577;
    case 0x829579u: goto L_829579;
    case 0x82957Bu: goto L_82957B;
    case 0x82957Du: goto L_82957D;
    case 0x829580u: goto L_829580;
    case 0x829583u: goto L_829583;
    case 0x829586u: goto L_829586;
    case 0x829588u: goto L_829588;
    case 0x829589u: goto L_829589;
    case 0x82958Bu: goto L_82958B;
    case 0x82958Eu: goto L_82958E;
    case 0x829591u: goto L_829591;
    case 0x829593u: goto L_829593;
    case 0x829596u: goto L_829596;
    case 0x829597u: goto L_829597;
    case 0x829599u: goto L_829599;
    case 0x82959Au: goto L_82959A;
    case 0x82959Du: goto L_82959D;
    case 0x82959Fu: goto L_82959F;
    case 0x8295A2u: goto L_8295A2;
    case 0x8295A4u: goto L_8295A4;
    case 0x8295A7u: goto L_8295A7;
    case 0x8295A9u: goto L_8295A9;
    case 0x8295ACu: goto L_8295AC;
    case 0x8295ADu: goto L_8295AD;
    case 0x8295B0u: goto L_8295B0;
    case 0x8295B1u: goto L_8295B1;
    case 0x8295B4u: goto L_8295B4;
    case 0x8295B6u: goto L_8295B6;
    case 0x8295B7u: goto L_8295B7;
    case 0x8295B9u: goto L_8295B9;
    case 0x8295BCu: goto L_8295BC;
    case 0x8295BFu: goto L_8295BF;
    case 0x8295C2u: goto L_8295C2;
    case 0x8295C4u: goto L_8295C4;
    case 0x8295C7u: goto L_8295C7;
    case 0x8295C9u: goto L_8295C9;
    case 0x8295CCu: goto L_8295CC;
    case 0x8295CEu: goto L_8295CE;
    case 0x8295D0u: goto L_8295D0;
    case 0x8295D3u: goto L_8295D3;
    case 0x8295D5u: goto L_8295D5;
    case 0x8295D8u: goto L_8295D8;
    case 0x8295DAu: goto L_8295DA;
    case 0x8295DDu: goto L_8295DD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829557:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9557u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9557u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829557 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829557u);return;} hw.unresolvedReturn(0x829557u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_829558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9558u,cpu,0x24u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9558u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829558 BIT
    cpu.bit(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), false);
    goto L_82955A;
L_82955A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82955A BPL -> $829557
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_829557; }
    goto L_82955C;
L_82955C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Cu, 5u, 3u, cpu.address("abs", 0x1814u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82955C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1814u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82955F;
L_82955F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x955Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x955Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82955F BPL -> $8295BC
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_8295BC; }
    goto L_829561;
L_829561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9561u, 8u, 3u, cpu.address("abs", 0x1ACAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829561 DEC
    cpu.decMem(hw, cpu.address("abs", 0x1ACAu), cpu.m8?8:16);
    goto L_829564;
L_829564:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9564u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9564u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829564 BNE -> $82958E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82958E; }
    goto L_829566;
L_829566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9566u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9566u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829566 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xC6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829568;
L_829568:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9568u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9568u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9568u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829568 AND
    cpu.logicAnd(0x3FFFu);
    goto L_82956B;
L_82956B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82956B ORA
    cpu.logicOr(0x2u);
    goto L_82956E;
L_82956E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x956Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x956Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82956E STA
    hw.write(cpu.address("dp", 0xC6u), cpu.a, cpu.m8?8:16);
    goto L_829570;
L_829570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9570u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829570 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829572;
L_829572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9572u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9572u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829572 CMP
    cpu.compareA(0x2u);
    goto L_829575;
L_829575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9575u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9575u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829575 BCC -> $82957B
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_82957B; }
    goto L_829577;
L_829577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9577u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829577 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829579;
L_829579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9579u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829579 BEQ -> $82958E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82958E; }
    goto L_82957B;
L_82957B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82957B STZ
    hw.write(cpu.address("dp", 0x18u), 0, cpu.m8?8:16);
    goto L_82957D;
L_82957D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x957Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x957Du, 5u, 3u, cpu.address("abs", 0x1AC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82957D STZ
    hw.write(cpu.address("abs", 0x1AC6u), 0, cpu.m8?8:16);
    goto L_829580;
L_829580:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9580u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9580u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829580 LDY
    cpu.setY(0x750u, 16);
    goto L_829583;
L_829583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9583u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9583u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829583 LDA
    cpu.setA(0x380u, 16);
    goto L_829586;
L_829586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9586u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829586 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_829588;
L_829588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9588u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829588 LSR
    cpu.lsrA();
    goto L_829589;
L_829589:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9589u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9589u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829589 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82958B;
L_82958B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Bu, 6u, 3u, cpu.address("abs", 0x96D9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82958B JSR -> $8296D9 stack real
    { cpu.push16Value(hw,0x958Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x958Eu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x96D9u), 0x82958Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82958E;
L_82958E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x958Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x958Eu,0x82958Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x958Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x958Eu, 5u, 3u, cpu.address("abs", 0x1ADEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82958E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ADEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829591;
L_829591:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9591u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9591u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829591 BNE -> $8295BC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_8295BC; }
    goto L_829593;
L_829593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9593u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9593u, 5u, 3u, cpu.address("abs", 0x1ACAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829593 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ACAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_829596;
L_829596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829596 LSR
    cpu.lsrA();
    goto L_829597;
L_829597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9597u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829597 BCS -> $8295BC
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8295BC; }
    goto L_829599;
L_829599:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9599u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9599u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829599 LSR
    cpu.lsrA();
    goto L_82959A;
L_82959A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82959A LDX
    cpu.setX(0x12u, 16);
    goto L_82959D;
L_82959D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82959D BCC -> $8295B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_8295B1; }
    goto L_82959F;
L_82959F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x959Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x959Fu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x959Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82959F LDX
    cpu.setX(0x20u, 16);
    goto L_8295A2;
L_8295A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x96u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295A2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x96u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295A4;
L_8295A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295A4 CMP
    cpu.compareA(0x2u);
    goto L_8295A7;
L_8295A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295A7 BCS -> $8295B1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_8295B1; }
    goto L_8295A9;
L_8295A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95A9u, 5u, 3u, cpu.address("abs", 0x0978u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295A9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x978u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295AC;
L_8295AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ACu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295AC ASL
    cpu.aslA();
    goto L_8295AD;
L_8295AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95ADu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295AD ADC
    cpu.adc(0x14u);
    goto L_8295B0;
L_8295B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295B0 TAX
    cpu.transfer("TAX");
    goto L_8295B1;
L_8295B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295B1 LDA
    cpu.setA(0x380u, 16);
    goto L_8295B4;
L_8295B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295B4 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_8295B6;
L_8295B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295B6 LSR
    cpu.lsrA();
    goto L_8295B7;
L_8295B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295B7 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_8295B9;
L_8295B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95B9u, 6u, 3u, cpu.address("abs", 0x9647u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8295B9 JSR -> $829647 stack real
    { cpu.push16Value(hw,0x95BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95BCu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9647u), 0x8295B9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8295BC;
L_8295BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95BCu,0x8295BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295BC LDY
    cpu.setY(0x750u, 16);
    goto L_8295BF;
L_8295BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95BFu, 5u, 3u, cpu.address("abs", 0x1AC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295BF LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1AC6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295C2;
L_8295C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295C2 STA
    hw.write(cpu.address("dp", 0x18u), cpu.a, cpu.m8?8:16);
    goto L_8295C4;
L_8295C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C4u, 5u, 3u, cpu.address("abs", 0x1ACEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295C4 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1ACEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295C7;
L_8295C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295C7 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_8295C9;
L_8295C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95C9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295C9 LDA
    cpu.setA(0x380u, 16);
    goto L_8295CC;
L_8295CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295CC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xC6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8295CE;
L_8295CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95CEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295CE STZ
    hw.write(cpu.address("dp", 0xC6u), 0, cpu.m8?8:16);
    goto L_8295D0;
L_8295D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D0u, 6u, 3u, cpu.address("abs", 0x9689u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $8295D0 JSR -> $829689 stack real
    { cpu.push16Value(hw,0x95D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x95D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9689u), 0x8295D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8295D3;
L_8295D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x95D3u,0x8295D3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295D3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295D5;
L_8295D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D5u, 5u, 3u, cpu.address("abs", 0x1AC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295D5 STA
    hw.write(cpu.address("abs", 0x1AC6u), cpu.a, cpu.m8?8:16);
    goto L_8295D8;
L_8295D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95D8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295D8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8295DA;
L_8295DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DAu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DAu, 5u, 3u, cpu.address("abs", 0x1ACEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8295DA STA
    hw.write(cpu.address("abs", 0x1ACEu), cpu.a, cpu.m8?8:16);
    goto L_8295DD;
L_8295DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x95DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x95DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8295DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8295DDu);return;} hw.unresolvedReturn(0x8295DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B049_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B049u: goto L_82B049;
    case 0x82B04Bu: goto L_82B04B;
    case 0x82B04Du: goto L_82B04D;
    case 0x82B04Eu: goto L_82B04E;
    case 0x82B051u: goto L_82B051;
    case 0x82B055u: goto L_82B055;
    case 0x82B058u: goto L_82B058;
    case 0x82B05Bu: goto L_82B05B;
    case 0x82B05Du: goto L_82B05D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB049u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB049u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B049 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B04B;
L_82B04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04B BNE -> $82B04E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B04E; }
    goto L_82B04D;
L_82B04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B04D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B04Du);return;} hw.unresolvedReturn(0x82B04Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04E LDA
    cpu.setA(0x3Cu, 16);
    goto L_82B051;
L_82B051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB051u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB051u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B051 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB054u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB055u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82B051u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B055;
L_82B055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB055u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB055u,0x82B055u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B055 LDA
    cpu.setA(0xCu, 16);
    goto L_82B058;
L_82B058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u, 5u, 3u, cpu.address("abs", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B058 STA
    hw.write(cpu.address("abs", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B05B;
L_82B05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05B INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B05D;
L_82B05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B05D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B05Du);return;} hw.unresolvedReturn(0x82B05Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B049_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B049u: goto L_82B049;
    case 0x82B04Bu: goto L_82B04B;
    case 0x82B04Du: goto L_82B04D;
    case 0x82B04Eu: goto L_82B04E;
    case 0x82B051u: goto L_82B051;
    case 0x82B055u: goto L_82B055;
    case 0x82B058u: goto L_82B058;
    case 0x82B05Bu: goto L_82B05B;
    case 0x82B05Du: goto L_82B05D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB049u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB049u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B049 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B04B;
L_82B04B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04B BNE -> $82B04E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B04E; }
    goto L_82B04D;
L_82B04D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B04D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B04Du);return;} hw.unresolvedReturn(0x82B04Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82B04E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB04Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB04Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B04E LDA
    cpu.setA(0x3Cu, 16);
    goto L_82B051;
L_82B051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB051u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB051u, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B051 JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB054u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB055u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x82B051u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B055;
L_82B055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB055u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB055u,0x82B055u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB055u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B055 LDA
    cpu.setA(0xCu, 16);
    goto L_82B058;
L_82B058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB058u, 5u, 3u, cpu.address("abs", 0x1C48u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B058 STA
    hw.write(cpu.address("abs", 0x1C48u), cpu.a, cpu.m8?8:16);
    goto L_82B05B;
L_82B05B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B05B INC
    cpu.incMem(hw, cpu.address("dp", 0x82u), cpu.m8?8:16);
    goto L_82B05D;
L_82B05D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB05Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB05Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B05D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82B05Du);return;} hw.unresolvedReturn(0x82B05Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_82B325_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B325u: goto L_82B325;
    case 0x82B328u: goto L_82B328;
    case 0x82B329u: goto L_82B329;
    case 0x82B32Cu: goto L_82B32C;
    case 0x82B32Fu: goto L_82B32F;
    case 0x82B332u: goto L_82B332;
    case 0x82B336u: goto L_82B336;
    case 0x82B338u: goto L_82B338;
    case 0x82B33Au: goto L_82B33A;
    case 0x82B33Du: goto L_82B33D;
    case 0x82B341u: goto L_82B341;
    case 0x82B342u: goto L_82B342;
    case 0x82B343u: goto L_82B343;
    case 0x82B344u: goto L_82B344;
    case 0x82B345u: goto L_82B345;
    case 0x82B347u: goto L_82B347;
    case 0x82B348u: goto L_82B348;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB325u, 6u, 3u, cpu.address("abs", 0xB31Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B325 JSR -> $82B31A stack real
    { cpu.push16Value(hw,0xB327u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB328u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB31Au), 0x82B325u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B328;
L_82B328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB328u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB328u,0x82B328u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB328u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB328u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B328 PHX
    cpu.push("PHX", hw);
    goto L_82B329;
L_82B329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB329u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B329 LDX
    cpu.setX(0xCu, 16);
    goto L_82B32C;
L_82B32C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Cu, 6u, 3u, cpu.address("abs", 0xB7B5u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B32C JSR -> $82B7B5 stack real
    { cpu.push16Value(hw,0xB32Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB32Fu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB7B5u), 0x82B32Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B32F;
L_82B32F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB32Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB32Fu,0x82B32Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB32Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B32F LDA
    cpu.setA(0x2001u, 16);
    goto L_82B332;
L_82B332:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB332u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB332u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB332u, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B332 STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B336;
L_82B336:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB336u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB336u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB336u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B336 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B338;
L_82B338:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB338u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB338u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB338u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B338 BEQ -> $82B33D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B33D; }
    goto L_82B33A;
L_82B33A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B33A LDA
    cpu.setA(0x2044u, 16);
    goto L_82B33D;
L_82B33D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB33Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Du,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB33Du, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B33D STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B341;
L_82B341:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB341u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB341u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB341u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B341 INX
    cpu.inc('X');
    goto L_82B342;
L_82B342:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB342u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB342u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B342 INX
    cpu.inc('X');
    goto L_82B343;
L_82B343:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB343u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB343u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B343 INX
    cpu.inc('X');
    goto L_82B344;
L_82B344:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB344u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB344u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B344 INX
    cpu.inc('X');
    goto L_82B345;
L_82B345:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB345u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB345u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB345u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B345 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B347;
L_82B347:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB347u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB347u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B347 PLX
    cpu.pop("PLX", hw);
    goto L_82B348;
L_82B348:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB348u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB348u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B348 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B348u);return;} hw.unresolvedReturn(0x82B348u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82E37F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82E37Fu: goto L_82E37F;
    case 0x82E383u: goto L_82E383;
    case 0x82E385u: goto L_82E385;
    case 0x82E388u: goto L_82E388;
    case 0x82E38Bu: goto L_82E38B;
    case 0x82E38Eu: goto L_82E38E;
    case 0x82E391u: goto L_82E391;
    case 0x82E394u: goto L_82E394;
    case 0x82E396u: goto L_82E396;
    case 0x82E399u: goto L_82E399;
    case 0x82E39Cu: goto L_82E39C;
    case 0x82E39Fu: goto L_82E39F;
    case 0x82E3A2u: goto L_82E3A2;
    case 0x82E3A6u: goto L_82E3A6;
    case 0x82E3A9u: goto L_82E3A9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82E37F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE37Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE37Fu, 8u, 4u, 0x8084D6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E37F JSL -> $8084D6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE382u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE383u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084D6u, 0x82E37Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E383;
L_82E383:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE383u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE383u,0x82E383u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE383u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E383 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82E385;
L_82E385:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE385u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE385u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E385 LDA
    cpu.setA(0x6400u, 16);
    goto L_82E388;
L_82E388:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE388u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE388u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E388 LDX
    cpu.setX(0xE0u, 16);
    goto L_82E38B;
L_82E38B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E38B LDY
    cpu.setY(0xC7C7u, 16);
    goto L_82E38E;
L_82E38E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE38Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Eu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE38Eu, 6u, 3u, cpu.address("abs", 0xE4DBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E38E JSR -> $82E4DB stack real
    { cpu.push16Value(hw,0xE390u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE391u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE4DBu), 0x82E38Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E391;
L_82E391:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE391u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE391u,0x82E391u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE391u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE391u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E391 LDA
    cpu.setA(0x2000u, 16);
    goto L_82E394;
L_82E394:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE394u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE394u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E394 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82E396;
L_82E396:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE396u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE396u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E396 LDA
    cpu.setA(0x7200u, 16);
    goto L_82E399;
L_82E399:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE399u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE399u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E399 LDX
    cpu.setX(0x80u, 16);
    goto L_82E39C;
L_82E39C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E39C LDY
    cpu.setY(0xC8A7u, 16);
    goto L_82E39F;
L_82E39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE39Fu, 6u, 3u, cpu.address("abs", 0xE4DBu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82E39F JSR -> $82E4DB stack real
    { cpu.push16Value(hw,0xE3A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A2u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xE4DBu), 0x82E39Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E3A2;
L_82E3A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A2u,0x82E3A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A2u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A2u, 8u, 4u, 0x8084E8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E3A2 JSL -> $8084E8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE3A5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE3A6u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8084E8u, 0x82E3A2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82E3A6;
L_82E3A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A6u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE3A6u,0x82E3A6u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A6u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A6u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82E3A6 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_82E3A9;
L_82E3A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE3A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE3A9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82E3A9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82E3A9u);return;} hw.unresolvedReturn(0x82E3A9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83B94D_E0M0X0C1_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B94Du: goto L_83B94D;
    case 0x83B94Fu: goto L_83B94F;
    case 0x83B952u: goto L_83B952;
    case 0x83B954u: goto L_83B954;
    case 0x83B957u: goto L_83B957;
    case 0x83B959u: goto L_83B959;
    case 0x83B95Cu: goto L_83B95C;
    case 0x83B95Fu: goto L_83B95F;
    case 0x83B961u: goto L_83B961;
    case 0x83B964u: goto L_83B964;
    case 0x83B966u: goto L_83B966;
    case 0x83B969u: goto L_83B969;
    case 0x83B96Bu: goto L_83B96B;
    case 0x83B96Eu: goto L_83B96E;
    case 0x83B970u: goto L_83B970;
    case 0x83B972u: goto L_83B972;
    case 0x83B975u: goto L_83B975;
    case 0x83B977u: goto L_83B977;
    case 0x83B97Au: goto L_83B97A;
    case 0x83B97Cu: goto L_83B97C;
    case 0x83B97Fu: goto L_83B97F;
    case 0x83B981u: goto L_83B981;
    case 0x83B982u: goto L_83B982;
    case 0x83B984u: goto L_83B984;
    case 0x83B987u: goto L_83B987;
    case 0x83B989u: goto L_83B989;
    case 0x83B98Bu: goto L_83B98B;
    case 0x83B98Eu: goto L_83B98E;
    case 0x83B991u: goto L_83B991;
    case 0x83B994u: goto L_83B994;
    case 0x83B997u: goto L_83B997;
    case 0x83B999u: goto L_83B999;
    case 0x83B99Au: goto L_83B99A;
    case 0x83B99Bu: goto L_83B99B;
    case 0x83B99Cu: goto L_83B99C;
    case 0x83B99Du: goto L_83B99D;
    case 0x83B99Fu: goto L_83B99F;
    case 0x83B9A1u: goto L_83B9A1;
    case 0x83B9A2u: goto L_83B9A2;
    case 0x83B9A4u: goto L_83B9A4;
    case 0x83B9A7u: goto L_83B9A7;
    case 0x83B9A9u: goto L_83B9A9;
    case 0x83B9ACu: goto L_83B9AC;
    case 0x83B9AEu: goto L_83B9AE;
    case 0x83B9B1u: goto L_83B9B1;
    case 0x83B9B4u: goto L_83B9B4;
    case 0x83B9B6u: goto L_83B9B6;
    case 0x83B9B9u: goto L_83B9B9;
    case 0x83B9BBu: goto L_83B9BB;
    case 0x83B9BEu: goto L_83B9BE;
    case 0x83B9C0u: goto L_83B9C0;
    case 0x83B9C3u: goto L_83B9C3;
    case 0x83B9C6u: goto L_83B9C6;
    case 0x83B9C8u: goto L_83B9C8;
    case 0x83B9CBu: goto L_83B9CB;
    case 0x83B9CDu: goto L_83B9CD;
    case 0x83B9CFu: goto L_83B9CF;
    case 0x83B9D2u: goto L_83B9D2;
    case 0x83B9D3u: goto L_83B9D3;
    case 0x83B9D6u: goto L_83B9D6;
    case 0x83B9D8u: goto L_83B9D8;
    case 0x83B9DBu: goto L_83B9DB;
    case 0x83B9DCu: goto L_83B9DC;
    case 0x83B9DFu: goto L_83B9DF;
    case 0x83B9E1u: goto L_83B9E1;
    case 0x83B9E4u: goto L_83B9E4;
    case 0x83B9E6u: goto L_83B9E6;
    case 0x83B9E9u: goto L_83B9E9;
    case 0x83B9ECu: goto L_83B9EC;
    case 0x83B9EEu: goto L_83B9EE;
    case 0x83B9F1u: goto L_83B9F1;
    case 0x83B9F4u: goto L_83B9F4;
    case 0x83B9F6u: goto L_83B9F6;
    case 0x83B9F9u: goto L_83B9F9;
    case 0x83B9FBu: goto L_83B9FB;
    case 0x83B9FCu: goto L_83B9FC;
    case 0x83B9FFu: goto L_83B9FF;
    case 0x83BA02u: goto L_83BA02;
    case 0x83BA04u: goto L_83BA04;
    case 0x83BA07u: goto L_83BA07;
    case 0x83BA09u: goto L_83BA09;
    case 0x83BA0Bu: goto L_83BA0B;
    case 0x83BA0Eu: goto L_83BA0E;
    case 0x83BA11u: goto L_83BA11;
    case 0x83BA13u: goto L_83BA13;
    case 0x83BA15u: goto L_83BA15;
    case 0x83BA16u: goto L_83BA16;
    case 0x83BA19u: goto L_83BA19;
    case 0x83BA1Bu: goto L_83BA1B;
    case 0x83BA1Du: goto L_83BA1D;
    case 0x83BA20u: goto L_83BA20;
    case 0x83BA21u: goto L_83BA21;
    case 0x83BA24u: goto L_83BA24;
    case 0x83BA26u: goto L_83BA26;
    case 0x83BA27u: goto L_83BA27;
    case 0x83BA2Au: goto L_83BA2A;
    case 0x83BA2Du: goto L_83BA2D;
    case 0x83BA2Fu: goto L_83BA2F;
    case 0x83BA32u: goto L_83BA32;
    case 0x83BA34u: goto L_83BA34;
    case 0x83BA36u: goto L_83BA36;
    case 0x83BA38u: goto L_83BA38;
    case 0x83BA3Bu: goto L_83BA3B;
    case 0x83BA3Du: goto L_83BA3D;
    case 0x83BA3Eu: goto L_83BA3E;
    case 0x83BA41u: goto L_83BA41;
    case 0x83BA43u: goto L_83BA43;
    case 0x83BA44u: goto L_83BA44;
    case 0x83BA47u: goto L_83BA47;
    case 0x83BA4Au: goto L_83BA4A;
    case 0x83BA4Cu: goto L_83BA4C;
    case 0x83BA4Eu: goto L_83BA4E;
    case 0x83BA51u: goto L_83BA51;
    case 0x83BA53u: goto L_83BA53;
    case 0x83BA55u: goto L_83BA55;
    case 0x83BA57u: goto L_83BA57;
    case 0x83BA58u: goto L_83BA58;
    case 0x83BA5Bu: goto L_83BA5B;
    case 0x83BA5Cu: goto L_83BA5C;
    case 0x83BA5Fu: goto L_83BA5F;
    case 0x83BA60u: goto L_83BA60;
    case 0x83BA62u: goto L_83BA62;
    case 0x83BA65u: goto L_83BA65;
    case 0x83BA67u: goto L_83BA67;
    case 0x83BA68u: goto L_83BA68;
    case 0x83BA6Au: goto L_83BA6A;
    case 0x83BA6Bu: goto L_83BA6B;
    case 0x83BA6Fu: goto L_83BA6F;
    case 0x83BA70u: goto L_83BA70;
    case 0x83BA72u: goto L_83BA72;
    case 0x83BA73u: goto L_83BA73;
    case 0x83BA77u: goto L_83BA77;
    case 0x83BA78u: goto L_83BA78;
    case 0x83BA7Bu: goto L_83BA7B;
    case 0x83BA7Du: goto L_83BA7D;
    case 0x83BA7Fu: goto L_83BA7F;
    case 0x83BA82u: goto L_83BA82;
    case 0x83BA83u: goto L_83BA83;
    case 0x83BA85u: goto L_83BA85;
    case 0x83BA88u: goto L_83BA88;
    case 0x83BA8Au: goto L_83BA8A;
    case 0x83BA8Du: goto L_83BA8D;
    case 0x83BA8Fu: goto L_83BA8F;
    case 0x83BA90u: goto L_83BA90;
    case 0x83BA91u: goto L_83BA91;
    case 0x83BA94u: goto L_83BA94;
    case 0x83BA95u: goto L_83BA95;
    case 0x83BA97u: goto L_83BA97;
    case 0x83BA9Au: goto L_83BA9A;
    case 0x83BA9Bu: goto L_83BA9B;
    case 0x83BA9Cu: goto L_83BA9C;
    case 0x83BA9Du: goto L_83BA9D;
    case 0x83BA9Fu: goto L_83BA9F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B94D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B94F;
L_83B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B94F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B952;
L_83B952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB952u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB952u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB952u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B952 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83B954;
L_83B954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB954u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB954u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B954 CPY
    cpu.compareY(0x6u);
    goto L_83B957;
L_83B957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B957 BNE -> $83B95C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B95C; }
    goto L_83B959;
L_83B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 3u, 3u, cpu.address("abs", 0xBB0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B959 JMP -> $83BB0E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBB0Eu),0x83B959u); return;
L_83B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B95C CPY
    cpu.compareY(0xAu);
    goto L_83B95F;
L_83B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B95F BCC -> $83B964
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B964; }
    goto L_83B961;
L_83B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 3u, 3u, cpu.address("abs", 0xBB30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B961 JMP -> $83BB30
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBB30u),0x83B961u); return;
L_83B964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB964u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB964u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B964 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B966;
L_83B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B966 AND
    cpu.logicAnd(0x7u);
    goto L_83B969;
L_83B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B969 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B96B;
L_83B96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Bu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B96B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B96E;
L_83B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B96E BNE -> $83B991
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B970;
L_83B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B970 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B972;
L_83B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B972 CMP
    cpu.compareA(0x4u);
    goto L_83B975;
L_83B975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B975 BCS -> $83B991
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B977;
L_83B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B977 CMP
    cpu.compareA(0x2u);
    goto L_83B97A;
L_83B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97A BEQ -> $83B989
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B97C;
L_83B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B97F;
L_83B97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97F BPL -> $83B989
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B981;
L_83B981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB981u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B981 TYA
    cpu.transfer("TYA");
    goto L_83B982;
L_83B982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B982 BEQ -> $83B989
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B984;
L_83B984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B984 CPY
    cpu.compareY(0x2u);
    goto L_83B987;
L_83B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B987 BNE -> $83B991
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B989;
L_83B989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B989 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B98B;
L_83B98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B98B AND
    cpu.logicAnd(0xF0u);
    goto L_83B98E;
L_83B98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B98E STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_83B991;
L_83B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B991 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B994;
L_83B994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B994 AND
    cpu.logicAnd(0xF0u);
    goto L_83B997;
L_83B997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B997 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83B999;
L_83B999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B999 LSR
    cpu.lsrA();
    goto L_83B99A;
L_83B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99A LSR
    cpu.lsrA();
    goto L_83B99B;
L_83B99B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99B LSR
    cpu.lsrA();
    goto L_83B99C;
L_83B99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99C TAY
    cpu.transfer("TAY");
    goto L_83B99D;
L_83B99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99D STY
    hw.write(cpu.address("dp", 0xEu), cpu.y, cpu.x8?8:16);
    goto L_83B99F;
L_83B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9A1;
L_83B9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A1 LSR
    cpu.lsrA();
    goto L_83B9A2;
L_83B9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A2 BEQ -> $83B9A7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9A7; }
    goto L_83B9A4;
L_83B9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u, 3u, 3u, cpu.address("abs", 0xBAD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A4 JMP -> $83BAD8
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAD8u),0x83B9A4u); return;
L_83B9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9A9;
L_83B9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A9 CMP
    cpu.compareA(0x8u);
    goto L_83B9AC;
L_83B9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9AC BCC -> $83B9B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9B1; }
    goto L_83B9AE;
L_83B9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu, 3u, 3u, cpu.address("abs", 0xBA83u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9AE JMP -> $83BA83
    goto L_83BA83;
L_83B9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9B4;
L_83B9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B4 BEQ -> $83B9B9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9B9; }
    goto L_83B9B6;
L_83B9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u, 3u, 3u, cpu.address("abs", 0xBAB3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B6 JMP -> $83BAB3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAB3u),0x83B9B6u); return;
L_83B9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9BB;
L_83B9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9BB CMP
    cpu.compareA(0x6u);
    goto L_83B9BE;
L_83B9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9BE BCC -> $83B9C3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9C3; }
    goto L_83B9C0;
L_83B9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u, 3u, 3u, cpu.address("abs", 0xBA5Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C0 JMP -> $83BA5C
    goto L_83BA5C;
L_83B9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C3 CMP
    cpu.compareA(0x2u);
    goto L_83B9C6;
L_83B9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C6 BNE -> $83B9E1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9E1; }
    goto L_83B9C8;
L_83B9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9CB;
L_83B9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CB BEQ -> $83B9E1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9E1; }
    goto L_83B9CD;
L_83B9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9CF;
L_83B9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CF AND
    cpu.logicAnd(0x4u);
    goto L_83B9D2;
L_83B9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D2 SEC
    cpu.setFlag('C', true);
    goto L_83B9D3;
L_83B9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D3 SBC
    cpu.sbc(0x2u);
    goto L_83B9D6;
L_83B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_83B9D8;
L_83B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D8 AND
    cpu.logicAnd(0x1Eu);
    goto L_83B9DB;
L_83B9DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DB CLC
    cpu.setFlag('C', false);
    goto L_83B9DC;
L_83B9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DC ADC
    cpu.adc(0x40u);
    goto L_83B9DF;
L_83B9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DF BRA -> $83BA5B
    goto L_83BA5B;
L_83B9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u, 5u, 3u, cpu.address("abs", 0x1BDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9E4;
L_83B9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E4 BEQ -> $83B9F1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9F1; }
    goto L_83B9E6;
L_83B9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9E9;
L_83B9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E9 CMP
    cpu.compareA(0x200u);
    goto L_83B9EC;
L_83B9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9EC BCC -> $83B9F1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9F1; }
    goto L_83B9EE;
L_83B9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu, 3u, 3u, cpu.address("abs", 0xBAC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9EE JMP -> $83BAC3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAC3u),0x83B9EEu); return;
L_83B9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9F4;
L_83B9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F4 BEQ -> $83BA5C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83B9F6;
L_83B9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9F9;
L_83B9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F9 BPL -> $83BA0B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA0B; }
    goto L_83B9FB;
L_83B9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FB CLC
    cpu.setFlag('C', false);
    goto L_83B9FC;
L_83B9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9FF;
L_83B9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FF BIT
    cpu.bit(0x300u, true);
    goto L_83BA02;
L_83BA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA02 BEQ -> $83BA5C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA04;
L_83BA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA04u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA04 BIT
    cpu.bit(0x100u, true);
    goto L_83BA07;
L_83BA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA07 BNE -> $83BA3D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA3D; }
    goto L_83BA09;
L_83BA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA09 BEQ -> $83BA43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA0B;
L_83BA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,0x83BA0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16));
    goto L_83BA11;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16));
    goto L_83BA11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,0x83BA0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA11 BNE -> $83BA5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA11 BNE -> $83BA5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA11u,0x83BA11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA13 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA15;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA13 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA13u,0x83BA13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA15u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA15 SEC
    cpu.setFlag('C', true);
    goto L_83BA16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA15 SEC
    cpu.setFlag('C', true);
    goto L_83BA16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA15u,0x83BA15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA16u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA16u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA16 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_83BA19;
L_83BA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA19 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83BA1B;
L_83BA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA1B BPL -> $83BA21
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA21; }
    goto L_83BA1D;
L_83BA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA1D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83BA20;
L_83BA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA20 INC
    cpu.inc('A');
    goto L_83BA21;
L_83BA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA21 CMP
    cpu.compareA(0x5u);
    goto L_83BA24;
L_83BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA24 BCC -> $83BA5C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA26;
L_83BA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA26 CLC
    cpu.setFlag('C', false);
    goto L_83BA27;
L_83BA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA27 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA2A;
L_83BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2A BIT
    cpu.bit(0x300u, true);
    goto L_83BA2D;
L_83BA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2D BEQ -> $83BA36
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA36; }
    goto L_83BA2F;
L_83BA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2F BIT
    cpu.bit(0x100u, true);
    goto L_83BA32;
L_83BA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA32 BNE -> $83BA3D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA3D; }
    goto L_83BA34;
L_83BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA34 BEQ -> $83BA43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA36;
L_83BA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA38;
L_83BA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA38 AND
    cpu.logicAnd(0x80u);
    goto L_83BA3B;
L_83BA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3B BNE -> $83BA43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA3D;
L_83BA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3D TYA
    cpu.transfer("TYA");
    goto L_83BA3E;
L_83BA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3E ADC
    cpu.adc(0xA0u);
    goto L_83BA41;
L_83BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA41 BRA -> $83BA47
    goto L_83BA47;
L_83BA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA43 TYA
    cpu.transfer("TYA");
    goto L_83BA44;
L_83BA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA44u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA44 ADC
    cpu.adc(0xE0u);
    goto L_83BA47;
L_83BA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA47 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA4A;
L_83BA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4A BPL -> $83BA5B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA5B; }
    goto L_83BA4C;
L_83BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA4E;
L_83BA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4E CPY
    cpu.compareY(0x4u);
    goto L_83BA51;
L_83BA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA51 BNE -> $83BA57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA57; }
    goto L_83BA53;
L_83BA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA53 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA55;
L_83BA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA55 BRA -> $83BA5C
    goto L_83BA5C;
L_83BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA57 CLC
    cpu.setFlag('C', false);
    goto L_83BA58;
L_83BA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA58u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA58 ADC
    cpu.adc(0x20u);
    goto L_83BA5B;
L_83BA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5B TAY
    cpu.transfer("TAY");
    goto L_83BA5C;
L_83BA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,0x83BA5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5F CLC
    cpu.setFlag('C', false);
    goto L_83BA60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5F CLC
    cpu.setFlag('C', false);
    goto L_83BA60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,0x83BA5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA60 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83BA62;
L_83BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA62 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10DCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA65;
L_83BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA65 BEQ -> $83BA78
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA78; }
    goto L_83BA67;
L_83BA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA67 DEY
    cpu.decReg('Y');
    goto L_83BA68;
L_83BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA68 BNE -> $83BA72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA72; }
    goto L_83BA6A;
L_83BA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA6A PHA
    cpu.push("PHA", hw);
    goto L_83BA6B;
L_83BA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu, 8u, 4u, 0x8484F7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BA6B JSL -> $8484F7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8484F7u, 0x83BA6Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BA6F;
L_83BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,0x83BA6Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA6F PLA
    cpu.pop("PLA", hw);
    goto L_83BA70;
L_83BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA70 BRA -> $83BA7D
    goto L_83BA7D;
L_83BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA72 PHA
    cpu.push("PHA", hw);
    goto L_83BA73;
L_83BA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u, 8u, 4u, 0x8484F2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BA73 JSL -> $8484F2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA77u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8484F2u, 0x83BA73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BA77;
L_83BA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA77u,0x83BA77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA77u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA77u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA77 PLA
    cpu.pop("PLA", hw);
    goto L_83BA78;
L_83BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 5u + 1u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA78 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x10BCu), cpu.m8?8:16));
    goto L_83BA7B;
L_83BA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7B BEQ -> $83BA82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA82; }
    goto L_83BA7D;
L_83BA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7D STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_83BA7F;
L_83BA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Fu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7F STA
    hw.write(cpu.address("absx", 0x10BCu), cpu.a, cpu.m8?8:16);
    goto L_83BA82;
L_83BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA82 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BA82u);return;} hw.unresolvedReturn(0x83BA82u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA83 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_83BA85;
L_83BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA85 CMP
    cpu.compareA(0xCu);
    goto L_83BA88;
L_83BA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA88 BCC -> $83BA8F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BA8F; }
    goto L_83BA8A;
L_83BA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8A LDY
    cpu.setY(0x20u, 16);
    goto L_83BA8D;
L_83BA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8D STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_83BA8F;
L_83BA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8F ASL
    cpu.aslA();
    goto L_83BA90;
L_83BA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA90 TAY
    cpu.transfer("TAY");
    goto L_83BA91;
L_83BA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA91u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA91u, 5u + 1u, 3u, cpu.address("absy", 0xD6AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA91 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA94;
L_83BA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA94 SEC
    cpu.setFlag('C', true);
    goto L_83BA95;
L_83BA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA95 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83BA97;
L_83BA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA97 AND
    cpu.logicAnd(0xF0u);
    goto L_83BA9A;
L_83BA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9A LSR
    cpu.lsrA();
    goto L_83BA9B;
L_83BA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9B LSR
    cpu.lsrA();
    goto L_83BA9C;
L_83BA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9C LSR
    cpu.lsrA();
    goto L_83BA9D;
L_83BA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83BA9F;
L_83BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9F TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA0u,0x83BA9Fu); return;
}

void sub_83B94D_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83B94Du: goto L_83B94D;
    case 0x83B94Fu: goto L_83B94F;
    case 0x83B952u: goto L_83B952;
    case 0x83B954u: goto L_83B954;
    case 0x83B957u: goto L_83B957;
    case 0x83B959u: goto L_83B959;
    case 0x83B95Cu: goto L_83B95C;
    case 0x83B95Fu: goto L_83B95F;
    case 0x83B961u: goto L_83B961;
    case 0x83B964u: goto L_83B964;
    case 0x83B966u: goto L_83B966;
    case 0x83B969u: goto L_83B969;
    case 0x83B96Bu: goto L_83B96B;
    case 0x83B96Eu: goto L_83B96E;
    case 0x83B970u: goto L_83B970;
    case 0x83B972u: goto L_83B972;
    case 0x83B975u: goto L_83B975;
    case 0x83B977u: goto L_83B977;
    case 0x83B97Au: goto L_83B97A;
    case 0x83B97Cu: goto L_83B97C;
    case 0x83B97Fu: goto L_83B97F;
    case 0x83B981u: goto L_83B981;
    case 0x83B982u: goto L_83B982;
    case 0x83B984u: goto L_83B984;
    case 0x83B987u: goto L_83B987;
    case 0x83B989u: goto L_83B989;
    case 0x83B98Bu: goto L_83B98B;
    case 0x83B98Eu: goto L_83B98E;
    case 0x83B991u: goto L_83B991;
    case 0x83B994u: goto L_83B994;
    case 0x83B997u: goto L_83B997;
    case 0x83B999u: goto L_83B999;
    case 0x83B99Au: goto L_83B99A;
    case 0x83B99Bu: goto L_83B99B;
    case 0x83B99Cu: goto L_83B99C;
    case 0x83B99Du: goto L_83B99D;
    case 0x83B99Fu: goto L_83B99F;
    case 0x83B9A1u: goto L_83B9A1;
    case 0x83B9A2u: goto L_83B9A2;
    case 0x83B9A4u: goto L_83B9A4;
    case 0x83B9A7u: goto L_83B9A7;
    case 0x83B9A9u: goto L_83B9A9;
    case 0x83B9ACu: goto L_83B9AC;
    case 0x83B9AEu: goto L_83B9AE;
    case 0x83B9B1u: goto L_83B9B1;
    case 0x83B9B4u: goto L_83B9B4;
    case 0x83B9B6u: goto L_83B9B6;
    case 0x83B9B9u: goto L_83B9B9;
    case 0x83B9BBu: goto L_83B9BB;
    case 0x83B9BEu: goto L_83B9BE;
    case 0x83B9C0u: goto L_83B9C0;
    case 0x83B9C3u: goto L_83B9C3;
    case 0x83B9C6u: goto L_83B9C6;
    case 0x83B9C8u: goto L_83B9C8;
    case 0x83B9CBu: goto L_83B9CB;
    case 0x83B9CDu: goto L_83B9CD;
    case 0x83B9CFu: goto L_83B9CF;
    case 0x83B9D2u: goto L_83B9D2;
    case 0x83B9D3u: goto L_83B9D3;
    case 0x83B9D6u: goto L_83B9D6;
    case 0x83B9D8u: goto L_83B9D8;
    case 0x83B9DBu: goto L_83B9DB;
    case 0x83B9DCu: goto L_83B9DC;
    case 0x83B9DFu: goto L_83B9DF;
    case 0x83B9E1u: goto L_83B9E1;
    case 0x83B9E4u: goto L_83B9E4;
    case 0x83B9E6u: goto L_83B9E6;
    case 0x83B9E9u: goto L_83B9E9;
    case 0x83B9ECu: goto L_83B9EC;
    case 0x83B9EEu: goto L_83B9EE;
    case 0x83B9F1u: goto L_83B9F1;
    case 0x83B9F4u: goto L_83B9F4;
    case 0x83B9F6u: goto L_83B9F6;
    case 0x83B9F9u: goto L_83B9F9;
    case 0x83B9FBu: goto L_83B9FB;
    case 0x83B9FCu: goto L_83B9FC;
    case 0x83B9FFu: goto L_83B9FF;
    case 0x83BA02u: goto L_83BA02;
    case 0x83BA04u: goto L_83BA04;
    case 0x83BA07u: goto L_83BA07;
    case 0x83BA09u: goto L_83BA09;
    case 0x83BA0Bu: goto L_83BA0B;
    case 0x83BA0Eu: goto L_83BA0E;
    case 0x83BA11u: goto L_83BA11;
    case 0x83BA13u: goto L_83BA13;
    case 0x83BA15u: goto L_83BA15;
    case 0x83BA16u: goto L_83BA16;
    case 0x83BA19u: goto L_83BA19;
    case 0x83BA1Bu: goto L_83BA1B;
    case 0x83BA1Du: goto L_83BA1D;
    case 0x83BA20u: goto L_83BA20;
    case 0x83BA21u: goto L_83BA21;
    case 0x83BA24u: goto L_83BA24;
    case 0x83BA26u: goto L_83BA26;
    case 0x83BA27u: goto L_83BA27;
    case 0x83BA2Au: goto L_83BA2A;
    case 0x83BA2Du: goto L_83BA2D;
    case 0x83BA2Fu: goto L_83BA2F;
    case 0x83BA32u: goto L_83BA32;
    case 0x83BA34u: goto L_83BA34;
    case 0x83BA36u: goto L_83BA36;
    case 0x83BA38u: goto L_83BA38;
    case 0x83BA3Bu: goto L_83BA3B;
    case 0x83BA3Du: goto L_83BA3D;
    case 0x83BA3Eu: goto L_83BA3E;
    case 0x83BA41u: goto L_83BA41;
    case 0x83BA43u: goto L_83BA43;
    case 0x83BA44u: goto L_83BA44;
    case 0x83BA47u: goto L_83BA47;
    case 0x83BA4Au: goto L_83BA4A;
    case 0x83BA4Cu: goto L_83BA4C;
    case 0x83BA4Eu: goto L_83BA4E;
    case 0x83BA51u: goto L_83BA51;
    case 0x83BA53u: goto L_83BA53;
    case 0x83BA55u: goto L_83BA55;
    case 0x83BA57u: goto L_83BA57;
    case 0x83BA58u: goto L_83BA58;
    case 0x83BA5Bu: goto L_83BA5B;
    case 0x83BA5Cu: goto L_83BA5C;
    case 0x83BA5Fu: goto L_83BA5F;
    case 0x83BA60u: goto L_83BA60;
    case 0x83BA62u: goto L_83BA62;
    case 0x83BA65u: goto L_83BA65;
    case 0x83BA67u: goto L_83BA67;
    case 0x83BA68u: goto L_83BA68;
    case 0x83BA6Au: goto L_83BA6A;
    case 0x83BA6Bu: goto L_83BA6B;
    case 0x83BA6Fu: goto L_83BA6F;
    case 0x83BA70u: goto L_83BA70;
    case 0x83BA72u: goto L_83BA72;
    case 0x83BA73u: goto L_83BA73;
    case 0x83BA77u: goto L_83BA77;
    case 0x83BA78u: goto L_83BA78;
    case 0x83BA7Bu: goto L_83BA7B;
    case 0x83BA7Du: goto L_83BA7D;
    case 0x83BA7Fu: goto L_83BA7F;
    case 0x83BA82u: goto L_83BA82;
    case 0x83BA83u: goto L_83BA83;
    case 0x83BA85u: goto L_83BA85;
    case 0x83BA88u: goto L_83BA88;
    case 0x83BA8Au: goto L_83BA8A;
    case 0x83BA8Du: goto L_83BA8D;
    case 0x83BA8Fu: goto L_83BA8F;
    case 0x83BA90u: goto L_83BA90;
    case 0x83BA91u: goto L_83BA91;
    case 0x83BA94u: goto L_83BA94;
    case 0x83BA95u: goto L_83BA95;
    case 0x83BA97u: goto L_83BA97;
    case 0x83BA9Au: goto L_83BA9A;
    case 0x83BA9Bu: goto L_83BA9B;
    case 0x83BA9Cu: goto L_83BA9C;
    case 0x83BA9Du: goto L_83BA9D;
    case 0x83BA9Fu: goto L_83BA9F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83B94D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Du,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B94D LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83B94F;
L_83B94F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB94Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB94Fu, 5u + 1u, 3u, cpu.address("absy", 0xD8FBu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B94F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD8FBu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B952;
L_83B952:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB952u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB952u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB952u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B952 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83B954;
L_83B954:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB954u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB954u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB954u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B954 CPY
    cpu.compareY(0x6u);
    goto L_83B957;
L_83B957:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB957u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB957u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B957 BNE -> $83B95C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B95C; }
    goto L_83B959;
L_83B959:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB959u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB959u, 3u, 3u, cpu.address("abs", 0xBB0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B959 JMP -> $83BB0E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBB0Eu),0x83B959u); return;
L_83B95C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B95C CPY
    cpu.compareY(0xAu);
    goto L_83B95F;
L_83B95F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB95Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB95Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B95F BCC -> $83B964
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B964; }
    goto L_83B961;
L_83B961:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB961u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB961u, 3u, 3u, cpu.address("abs", 0xBB30u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B961 JMP -> $83BB30
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBB30u),0x83B961u); return;
L_83B964:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB964u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB964u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB964u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B964 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x4Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B966;
L_83B966:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB966u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB966u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B966 AND
    cpu.logicAnd(0x7u);
    goto L_83B969;
L_83B969:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB969u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB969u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x4Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B969 STA
    hw.write(cpu.address("dpx", 0x4Eu), cpu.a, cpu.m8?8:16);
    goto L_83B96B;
L_83B96B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Bu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B96B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B96E;
L_83B96E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB96Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB96Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B96E BNE -> $83B991
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B970;
L_83B970:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB970u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB970u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B970 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B972;
L_83B972:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB972u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB972u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B972 CMP
    cpu.compareA(0x4u);
    goto L_83B975;
L_83B975:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB975u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB975u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B975 BCS -> $83B991
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B977;
L_83B977:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB977u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB977u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B977 CMP
    cpu.compareA(0x2u);
    goto L_83B97A;
L_83B97A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97A BEQ -> $83B989
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B97C;
L_83B97C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Cu, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B97F;
L_83B97F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB97Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB97Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B97F BPL -> $83B989
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B981;
L_83B981:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB981u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB981u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB981u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B981 TYA
    cpu.transfer("TYA");
    goto L_83B982;
L_83B982:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB982u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB982u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B982 BEQ -> $83B989
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B989; }
    goto L_83B984;
L_83B984:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB984u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB984u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B984 CPY
    cpu.compareY(0x2u);
    goto L_83B987;
L_83B987:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB987u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB987u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B987 BNE -> $83B991
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B991; }
    goto L_83B989;
L_83B989:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB989u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB989u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B989 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B98B;
L_83B98B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B98B AND
    cpu.logicAnd(0xF0u);
    goto L_83B98E;
L_83B98E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB98Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB98Eu, 6u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B98E STA
    hw.write(cpu.address("absx", 0x1096u), cpu.a, cpu.m8?8:16);
    goto L_83B991;
L_83B991:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB991u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB991u, 5u + 1u, 3u, cpu.address("absx", 0x1096u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B991 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1096u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B994;
L_83B994:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB994u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB994u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B994 AND
    cpu.logicAnd(0xF0u);
    goto L_83B997;
L_83B997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB997u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B997 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_83B999;
L_83B999:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB999u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB999u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B999 LSR
    cpu.lsrA();
    goto L_83B99A;
L_83B99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99A LSR
    cpu.lsrA();
    goto L_83B99B;
L_83B99B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99B LSR
    cpu.lsrA();
    goto L_83B99C;
L_83B99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99C TAY
    cpu.transfer("TAY");
    goto L_83B99D;
L_83B99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99D STY
    hw.write(cpu.address("dp", 0xEu), cpu.y, cpu.x8?8:16);
    goto L_83B99F;
L_83B99F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB99Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB99Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B99F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9A1;
L_83B9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A1 LSR
    cpu.lsrA();
    goto L_83B9A2;
L_83B9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A2 BEQ -> $83B9A7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9A7; }
    goto L_83B9A4;
L_83B9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A4u, 3u, 3u, cpu.address("abs", 0xBAD8u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A4 JMP -> $83BAD8
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAD8u),0x83B9A4u); return;
L_83B9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9A9;
L_83B9A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9A9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9A9 CMP
    cpu.compareA(0x8u);
    goto L_83B9AC;
L_83B9AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9AC BCC -> $83B9B1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9B1; }
    goto L_83B9AE;
L_83B9AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9AEu, 3u, 3u, cpu.address("abs", 0xBA83u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9AE JMP -> $83BA83
    goto L_83BA83;
L_83B9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B1u, 5u + 1u, 3u, cpu.address("absx", 0x10CAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10CAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9B4;
L_83B9B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B4 BEQ -> $83B9B9
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9B9; }
    goto L_83B9B6;
L_83B9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B6u, 3u, 3u, cpu.address("abs", 0xBAB3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B6 JMP -> $83BAB3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAB3u),0x83B9B6u); return;
L_83B9B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9B9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9B9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9BB;
L_83B9BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9BB CMP
    cpu.compareA(0x6u);
    goto L_83B9BE;
L_83B9BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9BE BCC -> $83B9C3
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9C3; }
    goto L_83B9C0;
L_83B9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C0u, 3u, 3u, cpu.address("abs", 0xBA5Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C0 JMP -> $83BA5C
    goto L_83BA5C;
L_83B9C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C3 CMP
    cpu.compareA(0x2u);
    goto L_83B9C6;
L_83B9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C6 BNE -> $83B9E1
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9E1; }
    goto L_83B9C8;
L_83B9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9C8u, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9C8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9CB;
L_83B9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CB BEQ -> $83B9E1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9E1; }
    goto L_83B9CD;
L_83B9CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9CF;
L_83B9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9CF AND
    cpu.logicAnd(0x4u);
    goto L_83B9D2;
L_83B9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D2 SEC
    cpu.setFlag('C', true);
    goto L_83B9D3;
L_83B9D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D3 SBC
    cpu.sbc(0x2u);
    goto L_83B9D6;
L_83B9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D6 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16));
    goto L_83B9D8;
L_83B9D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9D8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9D8 AND
    cpu.logicAnd(0x1Eu);
    goto L_83B9DB;
L_83B9DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DB CLC
    cpu.setFlag('C', false);
    goto L_83B9DC;
L_83B9DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DC ADC
    cpu.adc(0x40u);
    goto L_83B9DF;
L_83B9DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9DFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9DF BRA -> $83BA5B
    goto L_83BA5B;
L_83B9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E1u, 5u, 3u, cpu.address("abs", 0x1BDAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BDAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9E4;
L_83B9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E4 BEQ -> $83B9F1
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83B9F1; }
    goto L_83B9E6;
L_83B9E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E6u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9E9;
L_83B9E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9E9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9E9 CMP
    cpu.compareA(0x200u);
    goto L_83B9EC;
L_83B9EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9ECu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9EC BCC -> $83B9F1
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83B9F1; }
    goto L_83B9EE;
L_83B9EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9EEu, 3u, 3u, cpu.address("abs", 0xBAC3u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9EE JMP -> $83BAC3
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xBAC3u),0x83B9EEu); return;
L_83B9F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F1u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F1 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9F4;
L_83B9F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F4 BEQ -> $83BA5C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83B9F6;
L_83B9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F6u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9F9;
L_83B9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9F9 BPL -> $83BA0B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA0B; }
    goto L_83B9FB;
L_83B9FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FB CLC
    cpu.setFlag('C', false);
    goto L_83B9FC;
L_83B9FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FCu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FC LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83B9FF;
L_83B9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB9FFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83B9FF BIT
    cpu.bit(0x300u, true);
    goto L_83BA02;
L_83BA02:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA02u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA02u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA02 BEQ -> $83BA5C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA04;
L_83BA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA04u,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA04u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA04 BIT
    cpu.bit(0x100u, true);
    goto L_83BA07;
L_83BA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA07u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA07 BNE -> $83BA3D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA3D; }
    goto L_83BA09;
L_83BA09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA09u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA09 BEQ -> $83BA43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA0B;
L_83BA0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA0E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Bu, 5u + 1u, 3u, cpu.address("absx", 0x10A8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0B LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA0E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA0Bu,0x83BA0Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA0Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16));
    goto L_83BA11;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,cpu,0x1Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA0Eu, 5u + 1u, 3u, cpu.address("absx", 0x1094u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA0E ORA
    cpu.logicOr(hw.readW(cpu.address("absx", 0x1094u), cpu.m8?8:16));
    goto L_83BA11;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA0Eu,0x83BA0Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA11u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA11 BNE -> $83BA5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA13;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA11 BNE -> $83BA5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA13;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA11u,0x83BA11u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA13u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA13 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA15;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA13u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA13 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA15;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA13u,0x83BA13u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA15:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA15u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA15 SEC
    cpu.setFlag('C', true);
    goto L_83BA16;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA15u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA15 SEC
    cpu.setFlag('C', true);
    goto L_83BA16;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA15u,0x83BA15u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA16u,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA16u, 5u + 1u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA16 SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x10A2u), cpu.m8?8:16));
    goto L_83BA19;
L_83BA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA19u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA19 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83BA1B;
L_83BA1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA1B BPL -> $83BA21
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA21; }
    goto L_83BA1D;
L_83BA1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA1Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA1D EOR
    cpu.logicXor(0xFFFFu);
    goto L_83BA20;
L_83BA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA20u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA20 INC
    cpu.inc('A');
    goto L_83BA21;
L_83BA21:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA21u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA21u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA21 CMP
    cpu.compareA(0x5u);
    goto L_83BA24;
L_83BA24:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA24u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA24u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA24 BCC -> $83BA5C
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BA5C; }
    goto L_83BA26;
L_83BA26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA26u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA26 CLC
    cpu.setFlag('C', false);
    goto L_83BA27;
L_83BA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA27u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA27 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA2A;
L_83BA2A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2A BIT
    cpu.bit(0x300u, true);
    goto L_83BA2D;
L_83BA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2D BEQ -> $83BA36
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA36; }
    goto L_83BA2F;
L_83BA2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu,cpu,0x89u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA2Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA2F BIT
    cpu.bit(0x100u, true);
    goto L_83BA32;
L_83BA32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA32u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA32 BNE -> $83BA3D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA3D; }
    goto L_83BA34;
L_83BA34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA34u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA34 BEQ -> $83BA43
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA36;
L_83BA36:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA36u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA36u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA36 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA38;
L_83BA38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA38u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA38 AND
    cpu.logicAnd(0x80u);
    goto L_83BA3B;
L_83BA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3B BNE -> $83BA43
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA43; }
    goto L_83BA3D;
L_83BA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3D TYA
    cpu.transfer("TYA");
    goto L_83BA3E;
L_83BA3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA3Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA3E ADC
    cpu.adc(0xA0u);
    goto L_83BA41;
L_83BA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA41u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA41 BRA -> $83BA47
    goto L_83BA47;
L_83BA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA43u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA43 TYA
    cpu.transfer("TYA");
    goto L_83BA44;
L_83BA44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA44u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA44 ADC
    cpu.adc(0xE0u);
    goto L_83BA47;
L_83BA47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA47u, 5u + 1u, 3u, cpu.address("absx", 0x10A6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA47 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10A6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA4A;
L_83BA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4A BPL -> $83BA5B
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83BA5B; }
    goto L_83BA4C;
L_83BA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4C LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA4E;
L_83BA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA4Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA4E CPY
    cpu.compareY(0x4u);
    goto L_83BA51;
L_83BA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA51u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA51u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA51 BNE -> $83BA57
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA57; }
    goto L_83BA53;
L_83BA53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA53u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA53 LDY
    cpu.setY(hw.readW(cpu.address("dp", 0xEu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA55;
L_83BA55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA55u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA55 BRA -> $83BA5C
    goto L_83BA5C;
L_83BA57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA57u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA57 CLC
    cpu.setFlag('C', false);
    goto L_83BA58;
L_83BA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA58u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA58u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA58 ADC
    cpu.adc(0x20u);
    goto L_83BA5B;
L_83BA5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5B TAY
    cpu.transfer("TAY");
    goto L_83BA5C;
L_83BA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA5F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Cu, 5u + 1u, 3u, cpu.address("absy", 0xD909u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD909u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA5Cu,0x83BA5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5F CLC
    cpu.setFlag('C', false);
    goto L_83BA60;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA5F CLC
    cpu.setFlag('C', false);
    goto L_83BA60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA5Fu,0x83BA5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83BA60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA60 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_83BA62;
L_83BA62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA62u, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA62 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10DCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83BA65;
L_83BA65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA65u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA65 BEQ -> $83BA78
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA78; }
    goto L_83BA67;
L_83BA67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA67 DEY
    cpu.decReg('Y');
    goto L_83BA68;
L_83BA68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA68 BNE -> $83BA72
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA72; }
    goto L_83BA6A;
L_83BA6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA6A PHA
    cpu.push("PHA", hw);
    goto L_83BA6B;
L_83BA6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Bu, 8u, 4u, 0x8484F7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BA6B JSL -> $8484F7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA6Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8484F7u, 0x83BA6Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BA6F;
L_83BA6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA6Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,0x83BA6Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA6Fu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA6F PLA
    cpu.pop("PLA", hw);
    goto L_83BA70;
L_83BA70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA70u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA70 BRA -> $83BA7D
    goto L_83BA7D;
L_83BA72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA72u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA72 PHA
    cpu.push("PHA", hw);
    goto L_83BA73;
L_83BA73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA73u, 8u, 4u, 0x8484F2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83BA73 JSL -> $8484F2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBA76u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBA77u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8484F2u, 0x83BA73u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83BA77;
L_83BA77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA77u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBA77u,0x83BA77u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA77u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA77u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA77 PLA
    cpu.pop("PLA", hw);
    goto L_83BA78;
L_83BA78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA78u, 5u + 1u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA78 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x10BCu), cpu.m8?8:16));
    goto L_83BA7B;
L_83BA7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7B BEQ -> $83BA82
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83BA82; }
    goto L_83BA7D;
L_83BA7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7D STA
    hw.write(cpu.address("dpx", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_83BA7F;
L_83BA7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA7Fu, 6u, 3u, cpu.address("absx", 0x10BCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA7F STA
    hw.write(cpu.address("absx", 0x10BCu), cpu.a, cpu.m8?8:16);
    goto L_83BA82;
L_83BA82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA82u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83BA82 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83BA82u);return;} hw.unresolvedReturn(0x83BA82u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83BA83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA83u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA83 STZ
    hw.write(cpu.address("dp", 0x8u), 0, cpu.m8?8:16);
    goto L_83BA85;
L_83BA85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA85u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA85 CMP
    cpu.compareA(0xCu);
    goto L_83BA88;
L_83BA88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA88u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA88 BCC -> $83BA8F
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83BA8F; }
    goto L_83BA8A;
L_83BA8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8A LDY
    cpu.setY(0x20u, 16);
    goto L_83BA8D;
L_83BA8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8D STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_83BA8F;
L_83BA8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA8Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA8F ASL
    cpu.aslA();
    goto L_83BA90;
L_83BA90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA90u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA90 TAY
    cpu.transfer("TAY");
    goto L_83BA91;
L_83BA91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA91u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA91u, 5u + 1u, 3u, cpu.address("absy", 0xD6AEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA91 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD6AEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83BA94;
L_83BA94:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA94u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA94u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA94 SEC
    cpu.setFlag('C', true);
    goto L_83BA95;
L_83BA95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA95u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA95 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16));
    goto L_83BA97;
L_83BA97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA97u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA97 AND
    cpu.logicAnd(0xF0u);
    goto L_83BA9A;
L_83BA9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9A LSR
    cpu.lsrA();
    goto L_83BA9B;
L_83BA9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9B LSR
    cpu.lsrA();
    goto L_83BA9C;
L_83BA9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9C LSR
    cpu.lsrA();
    goto L_83BA9D;
L_83BA9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9D ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83BA9F;
L_83BA9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBA9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBA9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83BA9F TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBAA0u,0x83BA9Fu); return;
}

void sub_83C65D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83C65Du: goto L_83C65D;
    case 0x83C660u: goto L_83C660;
    case 0x83C663u: goto L_83C663;
    case 0x83C666u: goto L_83C666;
    case 0x83C669u: goto L_83C669;
    case 0x83C66Au: goto L_83C66A;
    case 0x83C66Du: goto L_83C66D;
    case 0x83C66Eu: goto L_83C66E;
    case 0x83C66Fu: goto L_83C66F;
    case 0x83C670u: goto L_83C670;
    case 0x83C671u: goto L_83C671;
    case 0x83C674u: goto L_83C674;
    case 0x83C675u: goto L_83C675;
    case 0x83C678u: goto L_83C678;
    case 0x83C67Au: goto L_83C67A;
    case 0x83C67Du: goto L_83C67D;
    case 0x83C680u: goto L_83C680;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83C65D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC65Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC65Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C65D LDX
    cpu.setX(0x700u, 16);
    goto L_83C660;
L_83C660:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC660u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC660u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC660u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C660 LDY
    cpu.setY(0x0u, 16);
    goto L_83C663;
L_83C663:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC663u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC663u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC663u, 5u + 1u, 3u, cpu.address("absx", 0x10B4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C663 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10B4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83C666;
L_83C666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC666u,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC666u, 6u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C666 STA
    hw.write(cpu.address("absy", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_83C669;
L_83C669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC669u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC669u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C669 TXA
    cpu.transfer("TXA");
    goto L_83C66A;
L_83C66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Au,cpu,0x99u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Au, 6u, 3u, cpu.address("absy", 0x0010u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C66A STA
    hw.write(cpu.address("absy", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_83C66D;
L_83C66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C66D INY
    cpu.inc('Y');
    goto L_83C66E;
L_83C66E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C66E INY
    cpu.inc('Y');
    goto L_83C66F;
L_83C66F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC66Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Fu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC66Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C66F TXA
    cpu.transfer("TXA");
    goto L_83C670;
L_83C670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC670u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC670u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C670 CLC
    cpu.setFlag('C', false);
    goto L_83C671;
L_83C671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC671u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC671u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C671 ADC
    cpu.adc(0x50u);
    goto L_83C674;
L_83C674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC674u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC674u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C674 TAX
    cpu.transfer("TAX");
    goto L_83C675;
L_83C675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC675u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC675u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C675 CPX
    cpu.compareX(0x8E0u);
    goto L_83C678;
L_83C678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC678u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C678 BCC -> $83C663
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83C663; }
    goto L_83C67A;
L_83C67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Au,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Au, 6u, 3u, cpu.address("abs", 0xC84Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83C67A JSR -> $83C84C stack real
    { cpu.push16Value(hw,0xC67Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xC67Du,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xC84Cu), 0x83C67Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83C67D;
L_83C67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC67Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xC67Du,0x83C67Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Du,cpu,0xAEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC67Du, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83C67D LDX
    cpu.setX(hw.readW(cpu.address("abs", 0x1BB4u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_83C680;
L_83C680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83C680 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83C680u);return;} hw.unresolvedReturn(0x83C680u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_83CEC0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83CEC0u: goto L_83CEC0;
    case 0x83CEC2u: goto L_83CEC2;
    case 0x83CEC4u: goto L_83CEC4;
    case 0x83CEC6u: goto L_83CEC6;
    case 0x83CEC7u: goto L_83CEC7;
    case 0x83CECAu: goto L_83CECA;
    case 0x83CECCu: goto L_83CECC;
    case 0x83CECFu: goto L_83CECF;
    case 0x83CED1u: goto L_83CED1;
    case 0x83CED3u: goto L_83CED3;
    case 0x83CED6u: goto L_83CED6;
    case 0x83CED9u: goto L_83CED9;
    case 0x83CEDCu: goto L_83CEDC;
    case 0x83CEDEu: goto L_83CEDE;
    case 0x83CEE1u: goto L_83CEE1;
    case 0x83CEE2u: goto L_83CEE2;
    case 0x83CEE5u: goto L_83CEE5;
    case 0x83CEE7u: goto L_83CEE7;
    case 0x83CEE8u: goto L_83CEE8;
    case 0x83CEE9u: goto L_83CEE9;
    case 0x83CEEBu: goto L_83CEEB;
    case 0x83CEECu: goto L_83CEEC;
    case 0x83CEEFu: goto L_83CEEF;
    case 0x83CEF1u: goto L_83CEF1;
    case 0x83CEF4u: goto L_83CEF4;
    case 0x83CEF6u: goto L_83CEF6;
    case 0x83CEF8u: goto L_83CEF8;
    case 0x83CEFBu: goto L_83CEFB;
    case 0x83CEFEu: goto L_83CEFE;
    case 0x83CF01u: goto L_83CF01;
    case 0x83CF03u: goto L_83CF03;
    case 0x83CF06u: goto L_83CF06;
    case 0x83CF07u: goto L_83CF07;
    case 0x83CF0Au: goto L_83CF0A;
    case 0x83CF0Cu: goto L_83CF0C;
    case 0x83CF0Du: goto L_83CF0D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83CEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEC0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CEC2;
L_83CEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEC2 BNE -> $83CEE9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83CEE9; }
    goto L_83CEC4;
L_83CEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEC4 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CEC6;
L_83CEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEC6 SEC
    cpu.setFlag('C', true);
    goto L_83CEC7;
L_83CEC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC7u, 5u, 3u, cpu.address("abs", 0x070Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEC7 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x70Au), cpu.m8?8:16));
    goto L_83CECA;
L_83CECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CECA BMI -> $83CEE2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEE2; }
    goto L_83CECC;
L_83CECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CECC CMP
    cpu.compareA(0xC0u);
    goto L_83CECF;
L_83CECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CECF BPL -> $83CEE7
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEE7; }
    goto L_83CED1;
L_83CED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CED1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CED3;
L_83CED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED3u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED3u, 5u, 3u, cpu.address("abs", 0x070Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CED3 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x70Eu), cpu.m8?8:16));
    goto L_83CED6;
L_83CED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CED6 ADC
    cpu.adc(0x12u);
    goto L_83CED9;
L_83CED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CED9 CMP
    cpu.compareA(0x24u);
    goto L_83CEDC;
L_83CEDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEDC BCS -> $83CEE8
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CEE8; }
    goto L_83CEDE;
L_83CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEDE LDA
    cpu.setA(0x700u, 16);
    goto L_83CEE1;
L_83CEE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE1u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEE1 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEE1u);return;} hw.unresolvedReturn(0x83CEE1u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEE2 ADC
    cpu.adc(0xC0u);
    goto L_83CEE5;
L_83CEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEE5 BPL -> $83CED1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CED1; }
    goto L_83CEE7;
L_83CEE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEE7 SEC
    cpu.setFlag('C', true);
    goto L_83CEE8;
L_83CEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEE8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEE8u);return;} hw.unresolvedReturn(0x83CEE8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CEE8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CEE8u);return;} hw.unresolvedReturn(0x83CEE8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEE8u,0x83CEE8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83CEE9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEE9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE9u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEE9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEE9 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CEEB;
L_83CEEB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEBu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEEB SEC
    cpu.setFlag('C', true);
    goto L_83CEEC;
L_83CEEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEECu, 5u, 3u, cpu.address("abs", 0x075Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEEC SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x75Au), cpu.m8?8:16));
    goto L_83CEEF;
L_83CEEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEEF BMI -> $83CF07
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CF07; }
    goto L_83CEF1;
L_83CEF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEF1 CMP
    cpu.compareA(0xC0u);
    goto L_83CEF4;
L_83CEF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEF4 BPL -> $83CF0C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CF0C; }
    goto L_83CEF6;
L_83CEF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEF6 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83CEF8;
L_83CEF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEF8u, 5u, 3u, cpu.address("abs", 0x075Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEF8 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x75Eu), cpu.m8?8:16));
    goto L_83CEFB;
L_83CEFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEFB ADC
    cpu.adc(0x12u);
    goto L_83CEFE;
L_83CEFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEFEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CEFE CMP
    cpu.compareA(0x24u);
    goto L_83CF01;
L_83CF01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CF01 BCS -> $83CF0D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83CF0D; }
    goto L_83CF03;
L_83CF03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF03u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF03u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CF03 LDA
    cpu.setA(0x750u, 16);
    goto L_83CF06;
L_83CF06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF06u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CF06 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CF06u);return;} hw.unresolvedReturn(0x83CF06u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83CF07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF07u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CF07 ADC
    cpu.adc(0xC0u);
    goto L_83CF0A;
L_83CF0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CF0A BPL -> $83CEF6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83CEF6; }
    goto L_83CF0C;
L_83CF0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Cu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83CF0C SEC
    cpu.setFlag('C', true);
    goto L_83CF0D;
L_83CF0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF0Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CF0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CF0Du);return;} hw.unresolvedReturn(0x83CF0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83CF0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83CF0Du);return;} hw.unresolvedReturn(0x83CF0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF0Du,0x83CF0Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_83F6CC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F675u: goto L_83F675;
    case 0x83F678u: goto L_83F678;
    case 0x83F67Au: goto L_83F67A;
    case 0x83F67Cu: goto L_83F67C;
    case 0x83F67Eu: goto L_83F67E;
    case 0x83F681u: goto L_83F681;
    case 0x83F683u: goto L_83F683;
    case 0x83F686u: goto L_83F686;
    case 0x83F688u: goto L_83F688;
    case 0x83F68Bu: goto L_83F68B;
    case 0x83F68Eu: goto L_83F68E;
    case 0x83F691u: goto L_83F691;
    case 0x83F694u: goto L_83F694;
    case 0x83F697u: goto L_83F697;
    case 0x83F69Bu: goto L_83F69B;
    case 0x83F69Cu: goto L_83F69C;
    case 0x83F69Fu: goto L_83F69F;
    case 0x83F6A0u: goto L_83F6A0;
    case 0x83F6A3u: goto L_83F6A3;
    case 0x83F6A5u: goto L_83F6A5;
    case 0x83F6A8u: goto L_83F6A8;
    case 0x83F6AAu: goto L_83F6AA;
    case 0x83F6ACu: goto L_83F6AC;
    case 0x83F6AEu: goto L_83F6AE;
    case 0x83F6B1u: goto L_83F6B1;
    case 0x83F6B3u: goto L_83F6B3;
    case 0x83F6B6u: goto L_83F6B6;
    case 0x83F6B8u: goto L_83F6B8;
    case 0x83F6BBu: goto L_83F6BB;
    case 0x83F6BEu: goto L_83F6BE;
    case 0x83F6C1u: goto L_83F6C1;
    case 0x83F6C4u: goto L_83F6C4;
    case 0x83F6C7u: goto L_83F6C7;
    case 0x83F6CBu: goto L_83F6CB;
    case 0x83F6CCu: goto L_83F6CC;
    case 0x83F6CFu: goto L_83F6CF;
    case 0x83F6D1u: goto L_83F6D1;
    case 0x83F6D4u: goto L_83F6D4;
    case 0x83F6D7u: goto L_83F6D7;
    case 0x83F6DAu: goto L_83F6DA;
    case 0x83F6DCu: goto L_83F6DC;
    case 0x83F6DEu: goto L_83F6DE;
    case 0x83F6E0u: goto L_83F6E0;
    case 0x83F6E2u: goto L_83F6E2;
    case 0x83F6E4u: goto L_83F6E4;
    case 0x83F6E7u: goto L_83F6E7;
    case 0x83F6E8u: goto L_83F6E8;
    case 0x83F6EBu: goto L_83F6EB;
    case 0x83F6EDu: goto L_83F6ED;
    case 0x83F6F0u: goto L_83F6F0;
    case 0x83F6F2u: goto L_83F6F2;
    case 0x83F6F4u: goto L_83F6F4;
    case 0x83F6F6u: goto L_83F6F6;
    case 0x83F6F9u: goto L_83F6F9;
    case 0x83F6FBu: goto L_83F6FB;
    case 0x83F6FEu: goto L_83F6FE;
    case 0x83F700u: goto L_83F700;
    case 0x83F703u: goto L_83F703;
    case 0x83F706u: goto L_83F706;
    case 0x83F709u: goto L_83F709;
    case 0x83F70Cu: goto L_83F70C;
    case 0x83F70Fu: goto L_83F70F;
    case 0x83F713u: goto L_83F713;
    case 0x83F714u: goto L_83F714;
    case 0x83F717u: goto L_83F717;
    case 0x83F719u: goto L_83F719;
    case 0x83F71Bu: goto L_83F71B;
    case 0x83F71Du: goto L_83F71D;
    case 0x83F720u: goto L_83F720;
    case 0x83F722u: goto L_83F722;
    case 0x83F725u: goto L_83F725;
    case 0x83F727u: goto L_83F727;
    case 0x83F72Au: goto L_83F72A;
    case 0x83F72Du: goto L_83F72D;
    case 0x83F730u: goto L_83F730;
    case 0x83F733u: goto L_83F733;
    case 0x83F736u: goto L_83F736;
    case 0x83F73Au: goto L_83F73A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF675u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F675 CMP
    cpu.compareA(0xFFFEu);
    goto L_83F678;
L_83F678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF678u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F678 BCC -> $83F6CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F67A;
L_83F67A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F67A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F67C;
L_83F67C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F67C BEQ -> $83F6CB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F67E;
L_83F67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF67Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F67E CMP
    cpu.compareA(0x3u);
    goto L_83F681;
L_83F681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF681u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF681u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F681 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F683;
L_83F683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF683u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF683u, 6u, 3u, cpu.address("abs", 0xCF0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F683 JSR -> $83CF0E stack real
    { cpu.push16Value(hw,0xF685u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF686u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCF0Eu), 0x83F683u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F686;
L_83F686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF686u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F686 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F688;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F686 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F688;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF686u,0x83F686u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF688u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F688 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F68B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF688u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F688 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F68B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF688u,0x83F688u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F68B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F68B LDA
    cpu.setA(0x4000u, 16);
    goto L_83F68E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F68B LDA
    cpu.setA(0x4000u, 16);
    goto L_83F68E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF68Bu,0x83F68Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F68E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF68Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Eu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F68E STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F691;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF68Eu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F68E STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F691;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF68Eu,0x83F68Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF691u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F691 LDA
    cpu.setA(0x400u, 16);
    goto L_83F694;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF691u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F691 LDA
    cpu.setA(0x400u, 16);
    goto L_83F694;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF691u,0x83F691u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF694u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF694u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF694u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F694 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83F697;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF694u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF694u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F694 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83F697;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF694u,0x83F694u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF697u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF697u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF697u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F697 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF69Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF69Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F697u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F69B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF697u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF697u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F697 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF69Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF69Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F697u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F69B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF697u,0x83F697u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F69B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF69Bu,0x83F69Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Bu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F69B RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F69Bu);return;} hw.unresolvedReturn(0x83F69Bu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83F69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Cu, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F69C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F69F;
L_83F69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF69Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F69F SEC
    cpu.setFlag('C', true);
    goto L_83F6A0;
L_83F6A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A0u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A0u, 5u, 3u, cpu.address("abs", 0x0978u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6A0 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x978u), cpu.m8?8:16));
    goto L_83F6A3;
L_83F6A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A3u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6A3 BMI -> $83F675
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F675; }
    goto L_83F6A5;
L_83F6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6A5 CMP
    cpu.compareA(0x2u);
    goto L_83F6A8;
L_83F6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6A8 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F6AA;
L_83F6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6AA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6AC;
L_83F6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6AC BEQ -> $83F6CB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F6AE;
L_83F6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AEu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6AEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6AE CMP
    cpu.compareA(0x3u);
    goto L_83F6B1;
L_83F6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6B1 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F6B3;
L_83F6B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B3u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B3u, 6u, 3u, cpu.address("abs", 0xCE72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F6B3 JSR -> $83CE72 stack real
    { cpu.push16Value(hw,0xF6B5u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6B6u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE72u), 0x83F6B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F6B6;
L_83F6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6B6 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F6B8;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6B6 BCS -> $83F6CB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F6CB; }
    goto L_83F6B8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B6u,0x83F6B6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6B8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6B8 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F6BB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6B8u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6B8 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F6BB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6B8u,0x83F6B8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6BB LDA
    cpu.setA(0x4000u, 16);
    goto L_83F6BE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6BB LDA
    cpu.setA(0x4000u, 16);
    goto L_83F6BE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BBu,0x83F6BBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6BEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6BE STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F6C1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6BEu, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6BE STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F6C1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6BEu,0x83F6BEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6C1 LDA
    cpu.setA(0x10u, 16);
    goto L_83F6C4;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6C1 LDA
    cpu.setA(0x10u, 16);
    goto L_83F6C4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C1u,0x83F6C1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C4u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C4u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6C4 STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83F6C7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C4u, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6C4 STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83F6C7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C4u,0x83F6C4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6C7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F6C7 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF6CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F6C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F6CB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6C7u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F6C7 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF6CAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6CBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F6C7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F6CB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6C7u,0x83F6C7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F6CB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F6CBu);return;} hw.unresolvedReturn(0x83F6CBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CBu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CBu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F6CB RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F6CBu);return;} hw.unresolvedReturn(0x83F6CBu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6CBu,0x83F6CBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F6CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CCu, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6CC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6CF;
L_83F6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6CF BNE -> $83F713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6D1;
L_83F6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6D1 LDA
    cpu.setA(0x4u, 16);
    goto L_83F6D4;
L_83F6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D4u, 6u, 3u, cpu.address("abs", 0xCC41u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F6D4 JSR -> $83CC41 stack real
    { cpu.push16Value(hw,0xF6D6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6D7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCC41u), 0x83F6D4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F6D7;
L_83F6D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6D7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6D7u,0x83F6D7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6D7u, 5u + 1u, 3u, cpu.address("absx", 0x10C6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6D7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6DA;
L_83F6DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6DA BEQ -> $83F713
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6DC;
L_83F6DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DCu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6DC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6DE;
L_83F6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6DE BNE -> $83F713
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6E0;
L_83F6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6E0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6E2;
L_83F6E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6E2 BNE -> $83F69C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F69C; }
    goto L_83F6E4;
L_83F6E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E4u, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6E4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6E7;
L_83F6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6E7 SEC
    cpu.setFlag('C', true);
    goto L_83F6E8;
L_83F6E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E8u,cpu,0xEDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6E8u, 5u, 3u, cpu.address("abs", 0x0928u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6E8 SBC
    cpu.sbc(hw.readW(cpu.address("abs", 0x928u), cpu.m8?8:16));
    goto L_83F6EB;
L_83F6EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6EB BMI -> $83F714
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F714; }
    goto L_83F6ED;
L_83F6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6EDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6ED CMP
    cpu.compareA(0x2u);
    goto L_83F6F0;
L_83F6F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6F0 BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6F2;
L_83F6F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6F2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F6F4;
L_83F6F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6F4 BEQ -> $83F713
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6F6;
L_83F6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F6u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6F6 CMP
    cpu.compareA(0x3u);
    goto L_83F6F9;
L_83F6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6F9 BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F6FB;
L_83F6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FBu, 6u, 3u, cpu.address("abs", 0xCE72u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F6FB JSR -> $83CE72 stack real
    { cpu.push16Value(hw,0xF6FDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF6FEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCE72u), 0x83F6FBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F6FE;
L_83F6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF6FEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6FE BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F700;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FEu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF6FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F6FE BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F700;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF6FEu,0x83F6FEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF700u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF700u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF700u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F700 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F703;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF700u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF700u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F700 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F703;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF700u,0x83F700u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F703:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF703u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF703u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF703u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F703 LDA
    cpu.setA(0x4000u, 16);
    goto L_83F706;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF703u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF703u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F703 LDA
    cpu.setA(0x4000u, 16);
    goto L_83F706;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF703u,0x83F703u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F706:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF706u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF706u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF706u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F706 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F709;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF706u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF706u, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F706 STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F709;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF706u,0x83F706u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F709:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF709u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F709 LDA
    cpu.setA(0x10u, 16);
    goto L_83F70C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF709u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F709 LDA
    cpu.setA(0x10u, 16);
    goto L_83F70C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF709u,0x83F709u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F70C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Cu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F70C STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83F70F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Cu, 6u, 3u, cpu.address("absx", 0x10DAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F70C STA
    hw.write(cpu.address("absx", 0x10DAu), cpu.a, cpu.m8?8:16);
    goto L_83F70F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF70Cu,0x83F70Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F70F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF70Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F70F JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF712u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF713u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F70Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F713;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF70Fu, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F70F JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF712u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF713u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F70Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F713;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF70Fu,0x83F70Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F713:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF713u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F713u);return;} hw.unresolvedReturn(0x83F713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF713u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF713u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F713 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F713u);return;} hw.unresolvedReturn(0x83F713u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF713u,0x83F713u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF714u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F714 CMP
    cpu.compareA(0xFFFEu);
    goto L_83F717;
L_83F717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F717 BCC -> $83F713
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F719;
L_83F719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF719u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F719 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F71B;
L_83F71B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Bu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F71B BEQ -> $83F713
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F71D;
L_83F71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF71Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Du,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF71Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F71D CMP
    cpu.compareA(0x3u);
    goto L_83F720;
L_83F720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF720u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF720u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F720 BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F722;
L_83F722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF722u, 6u, 3u, cpu.address("abs", 0xCF0Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F722 JSR -> $83CF0E stack real
    { cpu.push16Value(hw,0xF724u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF725u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xCF0Eu), 0x83F722u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F725;
L_83F725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF725u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F725 BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F727;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF725u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F725 BCS -> $83F713
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F713; }
    goto L_83F727;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF725u,0x83F725u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F727:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF727u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF727u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF727u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F727 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F72A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF727u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF727u, 6u, 3u, cpu.address("absx", 0x021Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F727 STA
    hw.write(cpu.address("absx", 0x21Au), cpu.a, cpu.m8?8:16);
    goto L_83F72A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF727u,0x83F727u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F72A LDA
    cpu.setA(0x4000u, 16);
    goto L_83F72D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F72A LDA
    cpu.setA(0x4000u, 16);
    goto L_83F72D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF72Au,0x83F72Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F72D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF72Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F72D STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F730;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF72Du, 5u, 3u, cpu.address("abs", 0x1BB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F72D STA
    hw.write(cpu.address("abs", 0x1BB2u), cpu.a, cpu.m8?8:16);
    goto L_83F730;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF72Du,0x83F72Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F730:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF730u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F730 LDA
    cpu.setA(0x400u, 16);
    goto L_83F733;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF730u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F730 LDA
    cpu.setA(0x400u, 16);
    goto L_83F733;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF730u,0x83F730u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF733u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F733 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83F736;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF733u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F733 STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_83F736;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF733u,0x83F733u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF736u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F736 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF739u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF73Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F736u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F73A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF736u, 8u, 4u, 0x83CE10u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F736 JSL -> $83CE10 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF739u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF73Au,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CE10u, 0x83F736u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F73A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF736u,0x83F736u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F73A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF73Au))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF73Au,0x83F73Au); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF73Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F73A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83F73Au);return;} hw.unresolvedReturn(0x83F73Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848561_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848561u: goto L_848561;
    case 0x848563u: goto L_848563;
    case 0x848566u: goto L_848566;
    case 0x848567u: goto L_848567;
    case 0x84856Au: goto L_84856A;
    case 0x84856Du: goto L_84856D;
    case 0x848570u: goto L_848570;
    case 0x848571u: goto L_848571;
    case 0x848574u: goto L_848574;
    case 0x848578u: goto L_848578;
    case 0x84857Cu: goto L_84857C;
    case 0x84857Du: goto L_84857D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8561u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848561 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_848563;
L_848563:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8563u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8563u, 5u + 1u, 3u, cpu.address("absy", 0xFB0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848563 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xFB0Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848566;
L_848566:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8566u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8566u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848566 TAY
    cpu.transfer("TAY");
    goto L_848567;
L_848567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848567 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84856A;
L_84856A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84856A AND
    cpu.logicAnd(0xFFu);
    goto L_84856D;
L_84856D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x856Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x856Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84856D ORA
    cpu.logicOr(0x10u);
    goto L_848570;
L_848570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8570u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $848570 PHX
    cpu.push("PHX", hw);
    goto L_848571;
L_848571:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8571u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8571u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848571 LDX
    cpu.setX(0x1F60u, 16);
    goto L_848574;
L_848574:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8574u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8574u, 8u, 4u, 0x80B6C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848574 JSL -> $80B6C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8577u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8578u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6C0u, 0x848574u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848578;
L_848578:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8578u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8578u,0x848578u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8578u, 8u, 4u, 0x80B73Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848578 JSL -> $80B73A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x857Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x857Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B73Au, 0x848578u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_84857C;
L_84857C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x857Cu,0x84857Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84857C PLX
    cpu.pop("PLX", hw);
    goto L_84857D;
L_84857D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x857Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x857Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $84857D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x84857Du);return;} hw.unresolvedReturn(0x84857Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

