#include "generated.hpp"
void sub_8081D9_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8081D9u: goto L_8081D9;
    case 0x8081DBu: goto L_8081DB;
    case 0x8081DDu: goto L_8081DD;
    case 0x8081DFu: goto L_8081DF;
    case 0x8081E0u: goto L_8081E0;
    case 0x8081E2u: goto L_8081E2;
    case 0x8081E5u: goto L_8081E5;
    case 0x8081E8u: goto L_8081E8;
    case 0x8081EBu: goto L_8081EB;
    case 0x8081EEu: goto L_8081EE;
    case 0x8081F1u: goto L_8081F1;
    case 0x8081F4u: goto L_8081F4;
    case 0x8081F6u: goto L_8081F6;
    case 0x8081F9u: goto L_8081F9;
    case 0x8081FCu: goto L_8081FC;
    case 0x8081FFu: goto L_8081FF;
    case 0x808202u: goto L_808202;
    case 0x808205u: goto L_808205;
    case 0x808208u: goto L_808208;
    case 0x80820Bu: goto L_80820B;
    case 0x80820Eu: goto L_80820E;
    case 0x808211u: goto L_808211;
    case 0x808214u: goto L_808214;
    case 0x808217u: goto L_808217;
    case 0x80821Au: goto L_80821A;
    case 0x80821Du: goto L_80821D;
    case 0x80821Fu: goto L_80821F;
    case 0x808220u: goto L_808220;
    case 0x808222u: goto L_808222;
    case 0x808225u: goto L_808225;
    case 0x808228u: goto L_808228;
    case 0x80822Bu: goto L_80822B;
    case 0x80822Eu: goto L_80822E;
    case 0x808231u: goto L_808231;
    case 0x808234u: goto L_808234;
    case 0x808236u: goto L_808236;
    case 0x808239u: goto L_808239;
    case 0x80823Cu: goto L_80823C;
    case 0x80823Fu: goto L_80823F;
    case 0x808242u: goto L_808242;
    case 0x808245u: goto L_808245;
    case 0x808248u: goto L_808248;
    case 0x80824Bu: goto L_80824B;
    case 0x80824Eu: goto L_80824E;
    case 0x808251u: goto L_808251;
    case 0x808254u: goto L_808254;
    case 0x808257u: goto L_808257;
    case 0x80825Au: goto L_80825A;
    case 0x80825Du: goto L_80825D;
    case 0x80825Fu: goto L_80825F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8081D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081D9 SEP
    cpu.sep(0x10u);
    goto L_8081DB;
L_8081DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DB LDY
    cpu.setY(0x1u, 8);
    goto L_8081DD;
L_8081DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8081DF;
L_8081DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DF LSR
    cpu.lsrA();
    goto L_8081E0;
L_8081E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E0 BCS -> $808220
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808220; }
    goto L_8081E2;
L_8081E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E2 LDA
    cpu.setA(0x80u, 16);
    goto L_8081E5;
L_8081E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E5 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_8081E8;
L_8081E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E8 LDA
    cpu.setA(0x410u, 16);
    goto L_8081EB;
L_8081EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081EB STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8081EE;
L_8081EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081EE LDA
    cpu.setA(0x2EFu, 16);
    goto L_8081F1;
L_8081F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F1 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8081F4;
L_8081F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F4 LDX
    cpu.setX(0x0u, 8);
    goto L_8081F6;
L_8081F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F6 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_8081F9;
L_8081F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F9 LDA
    cpu.setA(0x100u, 16);
    goto L_8081FC;
L_8081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081FC STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8081FF;
L_8081FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081FF STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808202;
L_808202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808202 LDA
    cpu.setA(0x108u, 16);
    goto L_808205;
L_808205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808205 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808208;
L_808208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808208 LDA
    cpu.setA(0x400u, 16);
    goto L_80820B;
L_80820B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80820B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80820E;
L_80820E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80820E LDA
    cpu.setA(0x2F0u, 16);
    goto L_808211;
L_808211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808211 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808214;
L_808214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8214u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8214u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808214 LDA
    cpu.setA(0x10u, 16);
    goto L_808217;
L_808217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808217 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80821A;
L_80821A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80821A STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80821D;
L_80821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80821D REP
    cpu.rep(0x10u);
    goto L_80821F;
L_80821F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80821F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80821Fu);return;} hw.unresolvedReturn(0x80821Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_808220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808220 LDY
    cpu.setY(0x1u, 8);
    goto L_808222;
L_808222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808222 LDA
    cpu.setA(0x80u, 16);
    goto L_808225;
L_808225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808225 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808228;
L_808228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808228 LDA
    cpu.setA(0x410u, 16);
    goto L_80822B;
L_80822B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80822B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80822E;
L_80822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80822E LDA
    cpu.setA(0x4EFu, 16);
    goto L_808231;
L_808231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808231 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808234;
L_808234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808234 LDX
    cpu.setX(0x0u, 8);
    goto L_808236;
L_808236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808236 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808239;
L_808239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808239 LDA
    cpu.setA(0x100u, 16);
    goto L_80823C;
L_80823C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Cu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80823C STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80823F;
L_80823F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Fu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80823F STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808242;
L_808242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808242 LDA
    cpu.setA(0x108u, 16);
    goto L_808245;
L_808245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808245 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808248;
L_808248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808248 LDA
    cpu.setA(0x400u, 16);
    goto L_80824B;
L_80824B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80824B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80824E;
L_80824E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80824E LDA
    cpu.setA(0x4F0u, 16);
    goto L_808251;
L_808251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808251 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808254;
L_808254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8254u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8254u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808254 LDA
    cpu.setA(0x10u, 16);
    goto L_808257;
L_808257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808257 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80825A;
L_80825A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80825A STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80825D;
L_80825D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80825D REP
    cpu.rep(0x10u);
    goto L_80825F;
L_80825F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80825F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80825Fu);return;} hw.unresolvedReturn(0x80825Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_8081D9_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8081D9u: goto L_8081D9;
    case 0x8081DBu: goto L_8081DB;
    case 0x8081DDu: goto L_8081DD;
    case 0x8081DFu: goto L_8081DF;
    case 0x8081E0u: goto L_8081E0;
    case 0x8081E2u: goto L_8081E2;
    case 0x8081E5u: goto L_8081E5;
    case 0x8081E8u: goto L_8081E8;
    case 0x8081EBu: goto L_8081EB;
    case 0x8081EEu: goto L_8081EE;
    case 0x8081F1u: goto L_8081F1;
    case 0x8081F4u: goto L_8081F4;
    case 0x8081F6u: goto L_8081F6;
    case 0x8081F9u: goto L_8081F9;
    case 0x8081FCu: goto L_8081FC;
    case 0x8081FFu: goto L_8081FF;
    case 0x808202u: goto L_808202;
    case 0x808205u: goto L_808205;
    case 0x808208u: goto L_808208;
    case 0x80820Bu: goto L_80820B;
    case 0x80820Eu: goto L_80820E;
    case 0x808211u: goto L_808211;
    case 0x808214u: goto L_808214;
    case 0x808217u: goto L_808217;
    case 0x80821Au: goto L_80821A;
    case 0x80821Du: goto L_80821D;
    case 0x80821Fu: goto L_80821F;
    case 0x808220u: goto L_808220;
    case 0x808222u: goto L_808222;
    case 0x808225u: goto L_808225;
    case 0x808228u: goto L_808228;
    case 0x80822Bu: goto L_80822B;
    case 0x80822Eu: goto L_80822E;
    case 0x808231u: goto L_808231;
    case 0x808234u: goto L_808234;
    case 0x808236u: goto L_808236;
    case 0x808239u: goto L_808239;
    case 0x80823Cu: goto L_80823C;
    case 0x80823Fu: goto L_80823F;
    case 0x808242u: goto L_808242;
    case 0x808245u: goto L_808245;
    case 0x808248u: goto L_808248;
    case 0x80824Bu: goto L_80824B;
    case 0x80824Eu: goto L_80824E;
    case 0x808251u: goto L_808251;
    case 0x808254u: goto L_808254;
    case 0x808257u: goto L_808257;
    case 0x80825Au: goto L_80825A;
    case 0x80825Du: goto L_80825D;
    case 0x80825Fu: goto L_80825F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8081D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081D9 SEP
    cpu.sep(0x10u);
    goto L_8081DB;
L_8081DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DB LDY
    cpu.setY(0x1u, 8);
    goto L_8081DD;
L_8081DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xD0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xD0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8081DF;
L_8081DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DFu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081DF LSR
    cpu.lsrA();
    goto L_8081E0;
L_8081E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E0 BCS -> $808220
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_808220; }
    goto L_8081E2;
L_8081E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E2 LDA
    cpu.setA(0x80u, 16);
    goto L_8081E5;
L_8081E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E5 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_8081E8;
L_8081E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081E8 LDA
    cpu.setA(0x410u, 16);
    goto L_8081EB;
L_8081EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081EB STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_8081EE;
L_8081EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081EE LDA
    cpu.setA(0x2EFu, 16);
    goto L_8081F1;
L_8081F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F1u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F1 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_8081F4;
L_8081F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F4 LDX
    cpu.setX(0x0u, 8);
    goto L_8081F6;
L_8081F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F6 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_8081F9;
L_8081F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081F9 LDA
    cpu.setA(0x100u, 16);
    goto L_8081FC;
L_8081FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FCu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081FC STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_8081FF;
L_8081FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FFu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8081FF STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808202;
L_808202:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8202u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8202u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808202 LDA
    cpu.setA(0x108u, 16);
    goto L_808205;
L_808205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808205 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808208;
L_808208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808208 LDA
    cpu.setA(0x400u, 16);
    goto L_80820B;
L_80820B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80820B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80820E;
L_80820E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80820E LDA
    cpu.setA(0x2F0u, 16);
    goto L_808211;
L_808211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8211u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808211 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808214;
L_808214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8214u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8214u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808214 LDA
    cpu.setA(0x10u, 16);
    goto L_808217;
L_808217:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8217u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8217u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808217 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80821A;
L_80821A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80821A STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80821D;
L_80821D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80821D REP
    cpu.rep(0x10u);
    goto L_80821F;
L_80821F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80821F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80821Fu);return;} hw.unresolvedReturn(0x80821Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_808220:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8220u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8220u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808220 LDY
    cpu.setY(0x1u, 8);
    goto L_808222;
L_808222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8222u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808222 LDA
    cpu.setA(0x80u, 16);
    goto L_808225;
L_808225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8225u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808225 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808228;
L_808228:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8228u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8228u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808228 LDA
    cpu.setA(0x410u, 16);
    goto L_80822B;
L_80822B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80822B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80822E;
L_80822E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80822E LDA
    cpu.setA(0x4EFu, 16);
    goto L_808231;
L_808231:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8231u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8231u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808231 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808234;
L_808234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8234u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808234 LDX
    cpu.setX(0x0u, 8);
    goto L_808236;
L_808236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8236u, 4u, 3u, cpu.address("abs", 0x4304u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808236 STX
    hw.write(cpu.address("abs", 0x4304u), cpu.x, cpu.x8?8:16);
    goto L_808239;
L_808239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8239u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808239 LDA
    cpu.setA(0x100u, 16);
    goto L_80823C;
L_80823C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Cu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80823C STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80823F;
L_80823F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Fu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Fu, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80823F STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_808242;
L_808242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8242u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808242 LDA
    cpu.setA(0x108u, 16);
    goto L_808245;
L_808245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8245u, 5u, 3u, cpu.address("abs", 0x2102u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808245 STA
    hw.write(cpu.address("abs", 0x2102u), cpu.a, cpu.m8?8:16);
    goto L_808248;
L_808248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8248u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808248 LDA
    cpu.setA(0x400u, 16);
    goto L_80824B;
L_80824B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Bu, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80824B STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_80824E;
L_80824E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80824E LDA
    cpu.setA(0x4F0u, 16);
    goto L_808251;
L_808251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8251u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808251 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_808254;
L_808254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8254u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8254u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808254 LDA
    cpu.setA(0x10u, 16);
    goto L_808257;
L_808257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808257 STA
    hw.write(cpu.address("abs", 0x4305u), cpu.a, cpu.m8?8:16);
    goto L_80825A;
L_80825A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Au, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80825A STY
    hw.write(cpu.address("abs", 0x420Bu), cpu.y, cpu.x8?8:16);
    goto L_80825D;
L_80825D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80825D REP
    cpu.rep(0x10u);
    goto L_80825F;
L_80825F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x825Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x825Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80825F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80825Fu);return;} hw.unresolvedReturn(0x80825Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_808D32_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x808D32u: goto L_808D32;
    case 0x808D34u: goto L_808D34;
    case 0x808D37u: goto L_808D37;
    case 0x808D39u: goto L_808D39;
    case 0x808D3Au: goto L_808D3A;
    case 0x808D3Du: goto L_808D3D;
    case 0x808D3Eu: goto L_808D3E;
    case 0x808D41u: goto L_808D41;
    case 0x808D44u: goto L_808D44;
    case 0x808D47u: goto L_808D47;
    case 0x808D49u: goto L_808D49;
    case 0x808D4Au: goto L_808D4A;
    case 0x808D4Bu: goto L_808D4B;
    case 0x808D4Cu: goto L_808D4C;
    case 0x808D4Eu: goto L_808D4E;
    case 0x808D4Fu: goto L_808D4F;
    case 0x808D52u: goto L_808D52;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_808D32:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D32u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D32u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D32 SEP
    cpu.sep(0x20u);
    goto L_808D34;
L_808D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D34 STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808D37;
L_808D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D37 LDA
    cpu.setA(0x0u, 8);
    goto L_808D39;
L_808D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D39 XBA
    cpu.xba();
    goto L_808D3A;
L_808D3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Au, 4u, 3u, cpu.address("abs", 0x211Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3A STA
    hw.write(cpu.address("abs", 0x211Bu), cpu.a, cpu.m8?8:16);
    goto L_808D3D;
L_808D3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3D TYA
    cpu.transfer("TYA");
    goto L_808D3E;
L_808D3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Eu, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D3E STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808D41;
L_808D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u, 4u, 3u, cpu.address("abs", 0x211Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D41 STA
    hw.write(cpu.address("abs", 0x211Cu), cpu.a, cpu.m8?8:16);
    goto L_808D44;
L_808D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 4u, 3u, cpu.address("abs", 0x2136u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D44 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2136u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D47;
L_808D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D47 BPL -> $808D4C
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_808D4C; }
    goto L_808D49;
L_808D49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D49u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D49 XBA
    cpu.xba();
    goto L_808D4A;
L_808D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4A DEC
    cpu.decReg('A');
    goto L_808D4B;
L_808D4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4B XBA
    cpu.xba();
    goto L_808D4C;
L_808D4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4C REP
    cpu.rep(0x20u);
    goto L_808D4E;
L_808D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4E TAY
    cpu.transfer("TAY");
    goto L_808D4F;
L_808D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Fu, 5u, 3u, cpu.address("abs", 0x2134u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $808D4F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2134u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_808D52;
L_808D52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D52u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D52u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808D52 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808D52u);return;} hw.unresolvedReturn(0x808D52u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809849_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809849u: goto L_809849;
    case 0x80984Cu: goto L_80984C;
    case 0x80984Fu: goto L_80984F;
    case 0x809851u: goto L_809851;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9849u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9849u, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809849 STA
    hw.write(cpu.address("abs", 0x2140u), cpu.a, cpu.m8?8:16);
    goto L_80984C;
L_80984C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Cu, 4u, 3u, cpu.address("abs", 0x2140u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80984C CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16));
    goto L_80984F;
L_80984F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x984Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x984Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80984F BNE -> $809849
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809849; }
    goto L_809851;
L_809851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9851u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809851 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809851u);return;} hw.unresolvedReturn(0x809851u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_809B1F_E0M0X0CQ_part13(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809D45u: goto L_809D45;
    case 0x809D47u: goto L_809D47;
    case 0x809D4Au: goto L_809D4A;
    case 0x809D4Du: goto L_809D4D;
    case 0x809D4Fu: goto L_809D4F;
    case 0x809D51u: goto L_809D51;
    case 0x809D53u: goto L_809D53;
    case 0x809D54u: goto L_809D54;
    case 0x809D55u: goto L_809D55;
    case 0x809D56u: goto L_809D56;
    case 0x809D57u: goto L_809D57;
    case 0x809D59u: goto L_809D59;
    case 0x809D5Bu: goto L_809D5B;
    case 0x809D5Du: goto L_809D5D;
    case 0x809D60u: goto L_809D60;
    case 0x809D63u: goto L_809D63;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D45u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D45u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D45 STA
    hw.write(cpu.address("dp", 0xFAu), cpu.a, cpu.m8?8:16);
    goto L_809D47;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D45u,0x809D45u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D47u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D47u, 5u + 1u, 3u, cpu.address("absx", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D47 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D4A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D47u,0x809D47u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Au))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4A AND
    cpu.logicAnd(0x10u);
    goto L_809D4D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D4Au,0x809D4Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4D BEQ -> $809CDF
    if (cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809CDFu,0x809D4Du); return; }
    goto L_809D4F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D4Du,0x809D4Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D4Fu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D4Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D4F BRA -> $809D60
    goto L_809D60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D4Fu,0x809D4Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D51u))return;
  // 17 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D51 REP
    cpu.rep(0x20u);
    goto L_809D53;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D51u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D51 REP
    cpu.rep(0x20u);
    goto L_809D53;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D51u,0x809D51u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D53u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D53 INX
    cpu.inc('X');
    goto L_809D54;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D53u,0x809D53u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D54u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D54u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D54 INX
    cpu.inc('X');
    goto L_809D55;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D54u,0x809D54u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D55u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D55u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D55 INX
    cpu.inc('X');
    goto L_809D56;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D55u,0x809D55u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D56u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D56u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D56 INX
    cpu.inc('X');
    goto L_809D57;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D56u,0x809D56u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D57u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D57u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D57 DEC
    cpu.decMem(hw, cpu.address("dp", 0xFAu), cpu.m8?8:16);
    goto L_809D59;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D57u,0x809D57u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D59u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D59u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D59 BNE -> $809D47
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_809D47; }
    goto L_809D5B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D59u,0x809D59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Bu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5B LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809D5D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D5Bu,0x809D5Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D5Du))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Du,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D5Du, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D5D BRL -> $809BD1
    hw.requestDispatch(0x809BD1u,0x809D5Du); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D5Du,0x809D5Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D60u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D60u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D60u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D60 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809D63;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D60u,0x809D60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809D63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D63u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D63u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D63u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809D63 AND
    cpu.logicAnd(0xFF00u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D66u,0x809D63u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D63u,0x809D63u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_809DD5_E0M0X0C0_part6(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809EB3u: goto L_809EB3;
    case 0x809EB5u: goto L_809EB5;
    case 0x809EB8u: goto L_809EB8;
    case 0x809EBAu: goto L_809EBA;
    case 0x809EBCu: goto L_809EBC;
    case 0x809EBEu: goto L_809EBE;
    case 0x809EC0u: goto L_809EC0;
    case 0x809EC2u: goto L_809EC2;
    case 0x809EC4u: goto L_809EC4;
    case 0x809EC6u: goto L_809EC6;
    case 0x809EC7u: goto L_809EC7;
    case 0x809EC8u: goto L_809EC8;
    case 0x809EC9u: goto L_809EC9;
    case 0x809ECBu: goto L_809ECB;
    case 0x809ECDu: goto L_809ECD;
    case 0x809ED0u: goto L_809ED0;
    case 0x809ED2u: goto L_809ED2;
    case 0x809ED5u: goto L_809ED5;
    case 0x809ED7u: goto L_809ED7;
    case 0x809ED9u: goto L_809ED9;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xFCu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809EB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x809EB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 3u, 3u, cpu.address("abs", 0x9E3Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EB5 JMP -> $809E3E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9E3Eu),0x809EB5u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB5u,0x809EB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0x92u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 2u, 0u);
    // $809EB8 STA
    hw.write(cpu.addressDpIndirect(hw, 0x1Cu), cpu.a, cpu.m8?8:16);
    goto L_809EBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB8u,0x809EB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBAu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBA LDA
    cpu.setA(0x80u, 8);
    goto L_809EBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBAu,0x809EBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBC STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_809EBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBCu,0x809EBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBEu))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EBE INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_809EC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBEu,0x809EBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC0 BNE -> $809EDB
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809EDBu,0x809EC0u); return; }
    goto L_809EC2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC0u,0x809EC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC2u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC2 REP
    cpu.rep(0x20u);
    goto L_809EC4;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC2u,0x809EC2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC4u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x18u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x18u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809EC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC4u,0x809EC4u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
  // 8 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0x1Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC6 TCS
    cpu.tcs();
    goto L_809EC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC6u,0x809EC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $809EC7 PLB
    cpu.pop("PLB", hw);
    goto L_809EC8;
L_809EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809EC8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x809EC8u);return;} hw.unresolvedReturn(0x809EC8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_809EC9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809EC9 STX
    hw.write(cpu.address("dp", 0xFCu), cpu.x, cpu.x8?8:16);
    goto L_809ECB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC9u,0x809EC9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_809ECD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECBu,0x809ECBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ECD LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECDu,0x809ECDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED0u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xFAu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED0 STA
    hw.write(cpu.address("dp", 0xFAu), cpu.a, cpu.m8?8:16);
    goto L_809ED2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED0u,0x809ED0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED2u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED2u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED2 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_809ED5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED2u,0x809ED2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED5u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED5 BPL -> $809E6E
    if (!cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x809E6Eu,0x809ED5u); return; }
    goto L_809ED7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED5u,0x809ED5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED7u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED7 BRA -> $809EE6
    hw.requestDispatch(0x809EE6u,0x809ED7u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED7u,0x809ED7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_809ED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED9u))return;
  // 9 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809ED9 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x809ED9u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ED9u,0x809ED9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80A997_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098E7u: goto L_8098E7;
    case 0x8098E9u: goto L_8098E9;
    case 0x8098EAu: goto L_8098EA;
    case 0x8098ECu: goto L_8098EC;
    case 0x8098F0u: goto L_8098F0;
    case 0x8098F4u: goto L_8098F4;
    case 0x80A997u: goto L_80A997;
    case 0x80A99Au: goto L_80A99A;
    case 0x80A99Bu: goto L_80A99B;
    case 0x80A99Cu: goto L_80A99C;
    case 0x80A9A0u: goto L_80A9A0;
    case 0x80A9A1u: goto L_80A9A1;
    case 0x80A9A2u: goto L_80A9A2;
    case 0x80A9A3u: goto L_80A9A3;
    case 0x80A9A7u: goto L_80A9A7;
    case 0x80A9A8u: goto L_80A9A8;
    case 0x80A9AAu: goto L_80A9AA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098E9;
L_8098E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98E9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098E9 SEC
    cpu.setFlag('C', true);
    goto L_8098EA;
L_8098EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98EAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098EA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098EC;
L_8098EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98ECu,cpu,0xFFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98ECu, 6u, 4u, ((0x7DFFFCu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098EC SBC
    cpu.sbc(hw.readW(((0x7DFFFCu + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_8098F0;
L_8098F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F0u, 6u, 4u, ((0x7DFFFEu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098F0 STA
    hw.write(((0x7DFFFEu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098F4;
L_8098F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98F4u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098F4 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098F4u);return;} hw.unresolvedReturn(0x8098F4u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80A997:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA997u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA997u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA997u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A997 LDA
    cpu.setA(0x0u, 16);
    goto L_80A99A;
L_80A99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Au,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Au, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A99A PHX
    cpu.push("PHX", hw);
    goto L_80A99B;
L_80A99B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A99B PHA
    cpu.push("PHA", hw);
    goto L_80A99C;
L_80A99C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA99Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA99Cu, 8u, 4u, 0x8098B4u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A99C JSL -> $8098B4 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA99Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9A0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B4u, 0x80A99Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9A0;
L_80A9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9A0u,0x80A9A0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A9A0 PLA
    cpu.pop("PLA", hw);
    goto L_80A9A1;
L_80A9A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A1u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A1u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80A9A1 PLX
    cpu.pop("PLX", hw);
    goto L_80A9A2;
L_80A9A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9A2 TXY
    cpu.transfer("TXY");
    goto L_80A9A3;
L_80A9A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A3u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9A3 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9A6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9A7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x80A9A3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9A7;
L_80A9A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9A7u,0x80A9A7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A7u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9A7 DEY
    cpu.decReg('Y');
    goto L_80A9A8;
L_80A9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9A8 BNE -> $80A9A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80A9A3; }
    goto L_80A9AA;
L_80A9AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AAu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9AAu, 4u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9AA JML -> $8098E7
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8098E7;
}

void sub_80BD17_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BD17u: goto L_80BD17;
    case 0x80BD19u: goto L_80BD19;
    case 0x80BD1Au: goto L_80BD1A;
    case 0x80BD1Bu: goto L_80BD1B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BD17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD17u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x82u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD17 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x82u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BD19;
L_80BD19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD19u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD19 ASL
    cpu.aslA();
    goto L_80BD1A;
L_80BD1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BD1A TAX
    cpu.transfer("TAX");
    goto L_80BD1B;
L_80BD1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBD1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Bu,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBD1Bu, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0xBD1Eu + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $80BD1B JMP (BD1E,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0xBD1Eu+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0x80BD1Bu); return; }
}

void sub_80D885_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D885u: goto L_80D885;
    case 0x80D888u: goto L_80D888;
    case 0x80D88Bu: goto L_80D88B;
    case 0x80D88Cu: goto L_80D88C;
    case 0x80D88Du: goto L_80D88D;
    case 0x80D890u: goto L_80D890;
    case 0x80D893u: goto L_80D893;
    case 0x80D894u: goto L_80D894;
    case 0x80D897u: goto L_80D897;
    case 0x80D89Au: goto L_80D89A;
    case 0x80D89Eu: goto L_80D89E;
    case 0x80D89Fu: goto L_80D89F;
    case 0x80D8A0u: goto L_80D8A0;
    case 0x80D8A3u: goto L_80D8A3;
    case 0x80D8A6u: goto L_80D8A6;
    case 0x80D8A8u: goto L_80D8A8;
    case 0x80D8A9u: goto L_80D8A9;
    case 0x80D8ACu: goto L_80D8AC;
    case 0x80D8AEu: goto L_80D8AE;
    case 0x80D8B0u: goto L_80D8B0;
    case 0x80D8B1u: goto L_80D8B1;
    case 0x80D8B4u: goto L_80D8B4;
    case 0x80D8B5u: goto L_80D8B5;
    case 0x80D8B6u: goto L_80D8B6;
    case 0x80D8B8u: goto L_80D8B8;
    case 0x80D8BBu: goto L_80D8BB;
    case 0x80D8BCu: goto L_80D8BC;
    case 0x80D8BFu: goto L_80D8BF;
    case 0x80D8C3u: goto L_80D8C3;
    case 0x80D8C4u: goto L_80D8C4;
    case 0x80D8C5u: goto L_80D8C5;
    case 0x80D8C6u: goto L_80D8C6;
    case 0x80D8C8u: goto L_80D8C8;
    case 0x80D8CAu: goto L_80D8CA;
    case 0x80D8CCu: goto L_80D8CC;
    case 0x80D8CEu: goto L_80D8CE;
    case 0x80D8D0u: goto L_80D8D0;
    case 0x80D8D1u: goto L_80D8D1;
    case 0x80D8D4u: goto L_80D8D4;
    case 0x80D8D6u: goto L_80D8D6;
    case 0x80D8D8u: goto L_80D8D8;
    case 0x80D8D9u: goto L_80D8D9;
    case 0x80D8DBu: goto L_80D8DB;
    case 0x80D8DCu: goto L_80D8DC;
    case 0x80D8DDu: goto L_80D8DD;
    case 0x80D8DFu: goto L_80D8DF;
    case 0x80D8E2u: goto L_80D8E2;
    case 0x80D8E3u: goto L_80D8E3;
    case 0x80D8E6u: goto L_80D8E6;
    case 0x80D8E7u: goto L_80D8E7;
    case 0x80D8E8u: goto L_80D8E8;
    case 0x80D8EAu: goto L_80D8EA;
    case 0x80D8EDu: goto L_80D8ED;
    case 0x80D8EFu: goto L_80D8EF;
    case 0x80D8F3u: goto L_80D8F3;
    case 0x80D8F4u: goto L_80D8F4;
    case 0x80D8F5u: goto L_80D8F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D885 LDA
    cpu.setA(0x8u, 16);
    goto L_80D888;
L_80D888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u, 6u, 3u, cpu.address("absx", 0x1C78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D888 STA
    hw.write(cpu.address("absx", 0x1C78u), cpu.a, cpu.m8?8:16);
    goto L_80D88B;
L_80D88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88B PHY
    cpu.push("PHY", hw);
    goto L_80D88C;
L_80D88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88C PHX
    cpu.push("PHX", hw);
    goto L_80D88D;
L_80D88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D88D LDA
    cpu.setA(0x5CADu, 16);
    goto L_80D890;
L_80D890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u, 6u, 3u, cpu.address("abs", 0xD8F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D890 JSR -> $80D8F6 stack real
    { cpu.push16Value(hw,0xD892u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD893u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD8F6u), 0x80D890u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D893;
L_80D893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD893u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D893 TAY
    cpu.transfer("TAY");
    goto L_80D894;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D893 TAY
    cpu.transfer("TAY");
    goto L_80D894;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD893u,0x80D893u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD894u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D894 LDX
    cpu.setX(0xA6D7u, 16);
    goto L_80D897;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D894 LDX
    cpu.setX(0xA6D7u, 16);
    goto L_80D897;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD894u,0x80D894u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD897u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D897 LDA
    cpu.setA(0x2400u, 16);
    goto L_80D89A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D897 LDA
    cpu.setA(0x2400u, 16);
    goto L_80D89A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD897u,0x80D897u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D89A JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD89Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD89Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80D89Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D89E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D89A JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD89Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD89Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80D89Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D89E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD89Au,0x80D89Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD89Eu,0x80D89Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89E PLX
    cpu.pop("PLX", hw);
    goto L_80D89F;
L_80D89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89F PHX
    cpu.push("PHX", hw);
    goto L_80D8A0;
L_80D8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A0 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A3;
L_80D8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u, 5u + 1u, 3u, cpu.address("absy", 0xA510u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A3 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA510u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A6;
L_80D8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A8;
L_80D8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8A8 PHY
    cpu.push("PHY", hw);
    goto L_80D8A9;
L_80D8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u, 5u + 1u, 3u, cpu.address("absy", 0xA703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA703u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8AC;
L_80D8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8AE;
L_80D8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B0;
L_80D8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B0 SEC
    cpu.setFlag('C', true);
    goto L_80D8B1;
L_80D8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B1 SBC
    cpu.sbc(0x4Eu);
    goto L_80D8B4;
L_80D8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8B4 PHA
    cpu.push("PHA", hw);
    goto L_80D8B5;
L_80D8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B5 TAX
    cpu.transfer("TAX");
    goto L_80D8B6;
L_80D8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B8;
L_80D8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B8 AND
    cpu.logicAnd(0x7u);
    goto L_80D8BB;
L_80D8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BB TAY
    cpu.transfer("TAY");
    goto L_80D8BC;
L_80D8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BC LDA
    cpu.setA(0x245Eu, 16);
    goto L_80D8BF;
L_80D8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu, 6u, 4u, ((0x7E000Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BF STA
    hw.write(((0x7E000Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D8C3;
L_80D8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C3 INX
    cpu.inc('X');
    goto L_80D8C4;
L_80D8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C4 INX
    cpu.inc('X');
    goto L_80D8C5;
L_80D8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C5 DEY
    cpu.decReg('Y');
    goto L_80D8C6;
L_80D8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C6 BNE -> $80D8BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8BF; }
    goto L_80D8C8;
L_80D8C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C8 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CA;
L_80D8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CA LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CC;
L_80D8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CE;
L_80D8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CE LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8D0;
L_80D8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D0 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D1;
L_80D8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D1 ADC
    cpu.adc(0x1Au);
    goto L_80D8D4;
L_80D8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D4 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16));
    goto L_80D8D6;
L_80D8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D6 BCC -> $80D8B4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D8B4; }
    goto L_80D8D8;
L_80D8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D8 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D9;
L_80D8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8DB;
L_80D8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DB ASL
    cpu.aslA();
    goto L_80D8DC;
L_80D8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DC ASL
    cpu.aslA();
    goto L_80D8DD;
L_80D8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D8DF;
L_80D8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DF ADC
    cpu.adc(0xA8B9u);
    goto L_80D8E2;
L_80D8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E2 TAY
    cpu.transfer("TAY");
    goto L_80D8E3;
L_80D8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E3 LDA
    cpu.setA(0x5D01u, 16);
    goto L_80D8E6;
L_80D8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E6 PLX
    cpu.pop("PLX", hw);
    goto L_80D8E7;
L_80D8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E7 PHX
    cpu.push("PHX", hw);
    goto L_80D8E8;
L_80D8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E8 BEQ -> $80D8ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8ED; }
    goto L_80D8EA;
L_80D8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8EA LDA
    cpu.setA(0x5F55u, 16);
    goto L_80D8ED;
L_80D8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8ED STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80D8EF;
L_80D8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D8EF JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD8F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD8F3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80D8EFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D8F3;
L_80D8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8F3u,0x80D8F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F3 PLX
    cpu.pop("PLX", hw);
    goto L_80D8F4;
L_80D8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F4 PLY
    cpu.pop("PLY", hw);
    goto L_80D8F5;
L_80D8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8F5u);return;} hw.unresolvedReturn(0x80D8F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D885_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D885u: goto L_80D885;
    case 0x80D888u: goto L_80D888;
    case 0x80D88Bu: goto L_80D88B;
    case 0x80D88Cu: goto L_80D88C;
    case 0x80D88Du: goto L_80D88D;
    case 0x80D890u: goto L_80D890;
    case 0x80D893u: goto L_80D893;
    case 0x80D894u: goto L_80D894;
    case 0x80D897u: goto L_80D897;
    case 0x80D89Au: goto L_80D89A;
    case 0x80D89Eu: goto L_80D89E;
    case 0x80D89Fu: goto L_80D89F;
    case 0x80D8A0u: goto L_80D8A0;
    case 0x80D8A3u: goto L_80D8A3;
    case 0x80D8A6u: goto L_80D8A6;
    case 0x80D8A8u: goto L_80D8A8;
    case 0x80D8A9u: goto L_80D8A9;
    case 0x80D8ACu: goto L_80D8AC;
    case 0x80D8AEu: goto L_80D8AE;
    case 0x80D8B0u: goto L_80D8B0;
    case 0x80D8B1u: goto L_80D8B1;
    case 0x80D8B4u: goto L_80D8B4;
    case 0x80D8B5u: goto L_80D8B5;
    case 0x80D8B6u: goto L_80D8B6;
    case 0x80D8B8u: goto L_80D8B8;
    case 0x80D8BBu: goto L_80D8BB;
    case 0x80D8BCu: goto L_80D8BC;
    case 0x80D8BFu: goto L_80D8BF;
    case 0x80D8C3u: goto L_80D8C3;
    case 0x80D8C4u: goto L_80D8C4;
    case 0x80D8C5u: goto L_80D8C5;
    case 0x80D8C6u: goto L_80D8C6;
    case 0x80D8C8u: goto L_80D8C8;
    case 0x80D8CAu: goto L_80D8CA;
    case 0x80D8CCu: goto L_80D8CC;
    case 0x80D8CEu: goto L_80D8CE;
    case 0x80D8D0u: goto L_80D8D0;
    case 0x80D8D1u: goto L_80D8D1;
    case 0x80D8D4u: goto L_80D8D4;
    case 0x80D8D6u: goto L_80D8D6;
    case 0x80D8D8u: goto L_80D8D8;
    case 0x80D8D9u: goto L_80D8D9;
    case 0x80D8DBu: goto L_80D8DB;
    case 0x80D8DCu: goto L_80D8DC;
    case 0x80D8DDu: goto L_80D8DD;
    case 0x80D8DFu: goto L_80D8DF;
    case 0x80D8E2u: goto L_80D8E2;
    case 0x80D8E3u: goto L_80D8E3;
    case 0x80D8E6u: goto L_80D8E6;
    case 0x80D8E7u: goto L_80D8E7;
    case 0x80D8E8u: goto L_80D8E8;
    case 0x80D8EAu: goto L_80D8EA;
    case 0x80D8EDu: goto L_80D8ED;
    case 0x80D8EFu: goto L_80D8EF;
    case 0x80D8F3u: goto L_80D8F3;
    case 0x80D8F4u: goto L_80D8F4;
    case 0x80D8F5u: goto L_80D8F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D885 LDA
    cpu.setA(0x8u, 16);
    goto L_80D888;
L_80D888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u, 6u, 3u, cpu.address("absx", 0x1C78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D888 STA
    hw.write(cpu.address("absx", 0x1C78u), cpu.a, cpu.m8?8:16);
    goto L_80D88B;
L_80D88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88B PHY
    cpu.push("PHY", hw);
    goto L_80D88C;
L_80D88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88C PHX
    cpu.push("PHX", hw);
    goto L_80D88D;
L_80D88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D88D LDA
    cpu.setA(0x5CADu, 16);
    goto L_80D890;
L_80D890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u, 6u, 3u, cpu.address("abs", 0xD8F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D890 JSR -> $80D8F6 stack real
    { cpu.push16Value(hw,0xD892u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD893u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD8F6u), 0x80D890u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D893;
L_80D893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD893u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D893 TAY
    cpu.transfer("TAY");
    goto L_80D894;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D893 TAY
    cpu.transfer("TAY");
    goto L_80D894;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD893u,0x80D893u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD894u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D894 LDX
    cpu.setX(0xA6D7u, 16);
    goto L_80D897;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D894 LDX
    cpu.setX(0xA6D7u, 16);
    goto L_80D897;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD894u,0x80D894u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD897u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D897 LDA
    cpu.setA(0x2400u, 16);
    goto L_80D89A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D897 LDA
    cpu.setA(0x2400u, 16);
    goto L_80D89A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD897u,0x80D897u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D89A JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD89Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD89Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80D89Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D89E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D89A JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD89Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD89Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80D89Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D89E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD89Au,0x80D89Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80D89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD89Eu,0x80D89Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89E PLX
    cpu.pop("PLX", hw);
    goto L_80D89F;
L_80D89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89F PHX
    cpu.push("PHX", hw);
    goto L_80D8A0;
L_80D8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A0 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A3;
L_80D8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u, 5u + 1u, 3u, cpu.address("absy", 0xA510u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A3 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA510u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A6;
L_80D8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A8;
L_80D8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8A8 PHY
    cpu.push("PHY", hw);
    goto L_80D8A9;
L_80D8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u, 5u + 1u, 3u, cpu.address("absy", 0xA703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA703u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8AC;
L_80D8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8AE;
L_80D8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B0;
L_80D8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B0 SEC
    cpu.setFlag('C', true);
    goto L_80D8B1;
L_80D8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B1 SBC
    cpu.sbc(0x4Eu);
    goto L_80D8B4;
L_80D8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8B4 PHA
    cpu.push("PHA", hw);
    goto L_80D8B5;
L_80D8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B5 TAX
    cpu.transfer("TAX");
    goto L_80D8B6;
L_80D8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B8;
L_80D8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B8 AND
    cpu.logicAnd(0x7u);
    goto L_80D8BB;
L_80D8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BB TAY
    cpu.transfer("TAY");
    goto L_80D8BC;
L_80D8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BC LDA
    cpu.setA(0x245Eu, 16);
    goto L_80D8BF;
L_80D8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu, 6u, 4u, ((0x7E000Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BF STA
    hw.write(((0x7E000Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D8C3;
L_80D8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C3 INX
    cpu.inc('X');
    goto L_80D8C4;
L_80D8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C4 INX
    cpu.inc('X');
    goto L_80D8C5;
L_80D8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C5 DEY
    cpu.decReg('Y');
    goto L_80D8C6;
L_80D8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C6 BNE -> $80D8BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8BF; }
    goto L_80D8C8;
L_80D8C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C8 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CA;
L_80D8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CA LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CC;
L_80D8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CE;
L_80D8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CE LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8D0;
L_80D8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D0 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D1;
L_80D8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D1 ADC
    cpu.adc(0x1Au);
    goto L_80D8D4;
L_80D8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D4 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16));
    goto L_80D8D6;
L_80D8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D6 BCC -> $80D8B4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D8B4; }
    goto L_80D8D8;
L_80D8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D8 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D9;
L_80D8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8DB;
L_80D8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DB ASL
    cpu.aslA();
    goto L_80D8DC;
L_80D8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DC ASL
    cpu.aslA();
    goto L_80D8DD;
L_80D8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D8DF;
L_80D8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DF ADC
    cpu.adc(0xA8B9u);
    goto L_80D8E2;
L_80D8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E2 TAY
    cpu.transfer("TAY");
    goto L_80D8E3;
L_80D8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E3 LDA
    cpu.setA(0x5D01u, 16);
    goto L_80D8E6;
L_80D8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E6 PLX
    cpu.pop("PLX", hw);
    goto L_80D8E7;
L_80D8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E7 PHX
    cpu.push("PHX", hw);
    goto L_80D8E8;
L_80D8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E8 BEQ -> $80D8ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8ED; }
    goto L_80D8EA;
L_80D8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8EA LDA
    cpu.setA(0x5F55u, 16);
    goto L_80D8ED;
L_80D8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8ED STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80D8EF;
L_80D8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D8EF JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD8F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD8F3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80D8EFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D8F3;
L_80D8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8F3u,0x80D8F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F3 PLX
    cpu.pop("PLX", hw);
    goto L_80D8F4;
L_80D8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F4 PLY
    cpu.pop("PLY", hw);
    goto L_80D8F5;
L_80D8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8F5u);return;} hw.unresolvedReturn(0x80D8F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80D885_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D885u: goto L_80D885;
    case 0x80D888u: goto L_80D888;
    case 0x80D88Bu: goto L_80D88B;
    case 0x80D88Cu: goto L_80D88C;
    case 0x80D88Du: goto L_80D88D;
    case 0x80D890u: goto L_80D890;
    case 0x80D893u: goto L_80D893;
    case 0x80D894u: goto L_80D894;
    case 0x80D897u: goto L_80D897;
    case 0x80D89Au: goto L_80D89A;
    case 0x80D89Eu: goto L_80D89E;
    case 0x80D89Fu: goto L_80D89F;
    case 0x80D8A0u: goto L_80D8A0;
    case 0x80D8A3u: goto L_80D8A3;
    case 0x80D8A6u: goto L_80D8A6;
    case 0x80D8A8u: goto L_80D8A8;
    case 0x80D8A9u: goto L_80D8A9;
    case 0x80D8ACu: goto L_80D8AC;
    case 0x80D8AEu: goto L_80D8AE;
    case 0x80D8B0u: goto L_80D8B0;
    case 0x80D8B1u: goto L_80D8B1;
    case 0x80D8B4u: goto L_80D8B4;
    case 0x80D8B5u: goto L_80D8B5;
    case 0x80D8B6u: goto L_80D8B6;
    case 0x80D8B8u: goto L_80D8B8;
    case 0x80D8BBu: goto L_80D8BB;
    case 0x80D8BCu: goto L_80D8BC;
    case 0x80D8BFu: goto L_80D8BF;
    case 0x80D8C3u: goto L_80D8C3;
    case 0x80D8C4u: goto L_80D8C4;
    case 0x80D8C5u: goto L_80D8C5;
    case 0x80D8C6u: goto L_80D8C6;
    case 0x80D8C8u: goto L_80D8C8;
    case 0x80D8CAu: goto L_80D8CA;
    case 0x80D8CCu: goto L_80D8CC;
    case 0x80D8CEu: goto L_80D8CE;
    case 0x80D8D0u: goto L_80D8D0;
    case 0x80D8D1u: goto L_80D8D1;
    case 0x80D8D4u: goto L_80D8D4;
    case 0x80D8D6u: goto L_80D8D6;
    case 0x80D8D8u: goto L_80D8D8;
    case 0x80D8D9u: goto L_80D8D9;
    case 0x80D8DBu: goto L_80D8DB;
    case 0x80D8DCu: goto L_80D8DC;
    case 0x80D8DDu: goto L_80D8DD;
    case 0x80D8DFu: goto L_80D8DF;
    case 0x80D8E2u: goto L_80D8E2;
    case 0x80D8E3u: goto L_80D8E3;
    case 0x80D8E6u: goto L_80D8E6;
    case 0x80D8E7u: goto L_80D8E7;
    case 0x80D8E8u: goto L_80D8E8;
    case 0x80D8EAu: goto L_80D8EA;
    case 0x80D8EDu: goto L_80D8ED;
    case 0x80D8EFu: goto L_80D8EF;
    case 0x80D8F3u: goto L_80D8F3;
    case 0x80D8F4u: goto L_80D8F4;
    case 0x80D8F5u: goto L_80D8F5;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD885u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D885 LDA
    cpu.setA(0x8u, 16);
    goto L_80D888;
L_80D888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD888u, 6u, 3u, cpu.address("absx", 0x1C78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D888 STA
    hw.write(cpu.address("absx", 0x1C78u), cpu.a, cpu.m8?8:16);
    goto L_80D88B;
L_80D88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88B PHY
    cpu.push("PHY", hw);
    goto L_80D88C;
L_80D88C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D88C PHX
    cpu.push("PHX", hw);
    goto L_80D88D;
L_80D88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD88Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D88D LDA
    cpu.setA(0x5CADu, 16);
    goto L_80D890;
L_80D890:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD890u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD890u, 6u, 3u, cpu.address("abs", 0xD8F6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D890 JSR -> $80D8F6 stack real
    { cpu.push16Value(hw,0xD892u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD893u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD8F6u), 0x80D890u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D893;
L_80D893:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD893u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD893u,0x80D893u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD893u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D893 TAY
    cpu.transfer("TAY");
    goto L_80D894;
L_80D894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD894u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D894 LDX
    cpu.setX(0xA6D7u, 16);
    goto L_80D897;
L_80D897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD897u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D897 LDA
    cpu.setA(0x2400u, 16);
    goto L_80D89A;
L_80D89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Au, 8u, 4u, 0x80A9C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D89A JSL -> $80A9C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD89Du); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD89Eu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A9C0u, 0x80D89Au); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D89E;
L_80D89E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Eu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD89Eu,0x80D89Eu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Eu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89E PLX
    cpu.pop("PLX", hw);
    goto L_80D89F;
L_80D89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD89Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D89F PHX
    cpu.push("PHX", hw);
    goto L_80D8A0;
L_80D8A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A0u, 5u + 1u, 3u, cpu.address("absx", 0x1C5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A0 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1C5Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A3;
L_80D8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A3u, 5u + 1u, 3u, cpu.address("absy", 0xA510u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A3 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0xA510u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A6;
L_80D8A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A6 LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80D8A8;
L_80D8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A8u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8A8 PHY
    cpu.push("PHY", hw);
    goto L_80D8A9;
L_80D8A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8A9u, 5u + 1u, 3u, cpu.address("absy", 0xA703u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8A9 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xA703u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8AC;
L_80D8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8ACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AC STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8AE;
L_80D8AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8AE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B0;
L_80D8B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B0 SEC
    cpu.setFlag('C', true);
    goto L_80D8B1;
L_80D8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B1 SBC
    cpu.sbc(0x4Eu);
    goto L_80D8B4;
L_80D8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B4u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8B4 PHA
    cpu.push("PHA", hw);
    goto L_80D8B5;
L_80D8B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B5 TAX
    cpu.transfer("TAX");
    goto L_80D8B6;
L_80D8B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80D8B8;
L_80D8B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8B8 AND
    cpu.logicAnd(0x7u);
    goto L_80D8BB;
L_80D8BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BB TAY
    cpu.transfer("TAY");
    goto L_80D8BC;
L_80D8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BC LDA
    cpu.setA(0x245Eu, 16);
    goto L_80D8BF;
L_80D8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8BFu, 6u, 4u, ((0x7E000Eu + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8BF STA
    hw.write(((0x7E000Eu + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D8C3;
L_80D8C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C3 INX
    cpu.inc('X');
    goto L_80D8C4;
L_80D8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C4 INX
    cpu.inc('X');
    goto L_80D8C5;
L_80D8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C5 DEY
    cpu.decReg('Y');
    goto L_80D8C6;
L_80D8C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C6 BNE -> $80D8BF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8BF; }
    goto L_80D8C8;
L_80D8C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8C8u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8C8 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CA;
L_80D8CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CAu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CA LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CC;
L_80D8CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CC LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8CE;
L_80D8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8CEu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8CE LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80D8D0;
L_80D8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D0u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D0 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D1;
L_80D8D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D1 ADC
    cpu.adc(0x1Au);
    goto L_80D8D4;
L_80D8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D4 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16));
    goto L_80D8D6;
L_80D8D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D6 BCC -> $80D8B4
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80D8B4; }
    goto L_80D8D8;
L_80D8D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D8u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8D8 PLA
    cpu.pop("PLA", hw);
    goto L_80D8D9;
L_80D8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8D9 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80D8DB;
L_80D8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DB ASL
    cpu.aslA();
    goto L_80D8DC;
L_80D8DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DC ASL
    cpu.aslA();
    goto L_80D8DD;
L_80D8DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_80D8DF;
L_80D8DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8DFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8DF ADC
    cpu.adc(0xA8B9u);
    goto L_80D8E2;
L_80D8E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E2 TAY
    cpu.transfer("TAY");
    goto L_80D8E3;
L_80D8E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E3 LDA
    cpu.setA(0x5D01u, 16);
    goto L_80D8E6;
L_80D8E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E6u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E6 PLX
    cpu.pop("PLX", hw);
    goto L_80D8E7;
L_80D8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8E7 PHX
    cpu.push("PHX", hw);
    goto L_80D8E8;
L_80D8E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8E8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8E8 BEQ -> $80D8ED
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80D8ED; }
    goto L_80D8EA;
L_80D8EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8EA LDA
    cpu.setA(0x5F55u, 16);
    goto L_80D8ED;
L_80D8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D8ED STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80D8EF;
L_80D8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8EFu, 8u, 4u, 0x82F6C8u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D8EF JSL -> $82F6C8 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD8F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD8F3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F6C8u, 0x80D8EFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80D8F3;
L_80D8F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD8F3u,0x80D8F3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F3u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F3 PLX
    cpu.pop("PLX", hw);
    goto L_80D8F4;
L_80D8F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F4u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F4 PLY
    cpu.pop("PLY", hw);
    goto L_80D8F5;
L_80D8F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD8F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD8F5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80D8F5 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80D8F5u);return;} hw.unresolvedReturn(0x80D8F5u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80DE70_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80DE70u: goto L_80DE70;
    case 0x80DE74u: goto L_80DE74;
    case 0x80DE76u: goto L_80DE76;
    case 0x80DE7Au: goto L_80DE7A;
    case 0x80DE7Cu: goto L_80DE7C;
    case 0x80DE7Fu: goto L_80DE7F;
    case 0x80DE83u: goto L_80DE83;
    case 0x80DE87u: goto L_80DE87;
    case 0x80DE88u: goto L_80DE88;
    case 0x80DE8Bu: goto L_80DE8B;
    case 0x80DE8Fu: goto L_80DE8F;
    case 0x80DE90u: goto L_80DE90;
    case 0x80DE93u: goto L_80DE93;
    case 0x80DE97u: goto L_80DE97;
    case 0x80DE9Bu: goto L_80DE9B;
    case 0x80DE9Cu: goto L_80DE9C;
    case 0x80DE9Fu: goto L_80DE9F;
    case 0x80DEA3u: goto L_80DEA3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80DE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE70u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE70u, 8u, 4u, 0x82F095u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE70 JSL -> $82F095 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE73u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE74u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F095u, 0x80DE70u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE74;
L_80DE74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE74u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE74u,0x80DE74u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE74u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE74u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE74 INC
    cpu.incMem(hw, cpu.address("dp", 0x3Cu), cpu.m8?8:16);
    goto L_80DE76;
L_80DE76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE76u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE76u, 6u, 4u, 0x7EFE4Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE76 LDA
    cpu.loadA(hw.readW(0x7EFE4Au, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE7A;
L_80DE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Au,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE7A BNE -> $80DE90
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80DE90; }
    goto L_80DE7C;
L_80DE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Cu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE7C LDY
    cpu.setY(0xCD85u, 16);
    goto L_80DE7F;
L_80DE7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE7Fu, 8u, 4u, 0x82F0EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE7F JSL -> $82F0ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE82u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE83u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0EDu, 0x80DE7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE83;
L_80DE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE83u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE83u,0x80DE83u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE83u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE83u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE83 LDA
    cpu.loadA(hw.readW(0x7EFE12u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE87;
L_80DE87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE87u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE87u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE87 CLC
    cpu.setFlag('C', false);
    goto L_80DE88;
L_80DE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE88u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE88u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE88u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE88 ADC
    cpu.adc(0x6u);
    goto L_80DE8B;
L_80DE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE8Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE8Bu, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE8B JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE8Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE8Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DE8Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE8F;
L_80DE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE8Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE8Fu,0x80DE8Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE8Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE8F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DE8Fu);return;} hw.unresolvedReturn(0x80DE8Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80DE90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE90u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE90u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE90 LDY
    cpu.setY(0xCDA3u, 16);
    goto L_80DE93;
L_80DE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE93u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE93u, 8u, 4u, 0x82F0EDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE93 JSL -> $82F0ED stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDE96u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDE97u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0EDu, 0x80DE93u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DE97;
L_80DE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE97u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDE97u,0x80DE97u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE97u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE97u, 6u, 4u, 0x7EFE12u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE97 LDA
    cpu.loadA(hw.readW(0x7EFE12u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_80DE9B;
L_80DE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Bu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE9B CLC
    cpu.setFlag('C', false);
    goto L_80DE9C;
L_80DE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Cu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80DE9C ADC
    cpu.adc(0x9u);
    goto L_80DE9F;
L_80DE9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDE9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDE9Fu, 8u, 4u, 0x82F0C0u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DE9F JSL -> $82F0C0 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xDEA2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xDEA3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82F0C0u, 0x80DE9Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80DEA3;
L_80DEA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xDEA3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xDEA3u,0x80DEA3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xDEA3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80DEA3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80DEA3u);return;} hw.unresolvedReturn(0x80DEA3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_828042_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x828042u: goto L_828042;
    case 0x828045u: goto L_828045;
    case 0x828047u: goto L_828047;
    case 0x828048u: goto L_828048;
    case 0x82804Au: goto L_82804A;
    case 0x82804Cu: goto L_82804C;
    case 0x82804Du: goto L_82804D;
    case 0x828050u: goto L_828050;
    case 0x828051u: goto L_828051;
    case 0x828052u: goto L_828052;
    case 0x828053u: goto L_828053;
    case 0x828057u: goto L_828057;
    case 0x828058u: goto L_828058;
    case 0x82805Au: goto L_82805A;
    case 0x8280A3u: goto L_8280A3;
    case 0x8280A6u: goto L_8280A6;
    case 0x8280AAu: goto L_8280AA;
    case 0x8280ADu: goto L_8280AD;
    case 0x8280B0u: goto L_8280B0;
    case 0x8280B3u: goto L_8280B3;
    case 0x8280B7u: goto L_8280B7;
    case 0x8280BAu: goto L_8280BA;
    case 0x8280BDu: goto L_8280BD;
    case 0x8280BEu: goto L_8280BE;
    case 0x8280C1u: goto L_8280C1;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_828042:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8042u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8042u, 5u, 3u, cpu.address("abs", 0x1A60u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828042 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A60u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828045;
L_828045:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8045u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8045u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828045 BEQ -> $82804C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82804C; }
    goto L_828047;
L_828047:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8047u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8047u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828047 DEC
    cpu.decReg('A');
    goto L_828048;
L_828048:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8048u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8048u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828048 BEQ -> $8280A3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_8280A3; }
    goto L_82804A;
L_82804A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82804A BRA -> $82804D
    goto L_82804D;
L_82804C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82804C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x82804Cu);return;} hw.unresolvedReturn(0x82804Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_82804D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x804Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x804Du, 5u, 3u, cpu.address("abs", 0x1A62u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82804D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A62u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828050;
L_828050:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8050u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8050u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828050 PHX
    cpu.push("PHX", hw);
    goto L_828051;
L_828051:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8051u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8051u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828051 ASL
    cpu.aslA();
    goto L_828052;
L_828052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8052u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8052u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828052 TAX
    cpu.transfer("TAX");
    goto L_828053;
L_828053:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8053u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8053u, 6u, 4u, ((0x82805Du + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828053 LDA
    cpu.loadA(hw.readW(((0x82805Du + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_828057;
L_828057:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8057u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8057u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $828057 PLX
    cpu.pop("PLX", hw);
    goto L_828058;
L_828058:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8058u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8058u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828058 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82805A;
L_82805A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x805Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au,cpu,0x6Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x805Au, 5u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, 0x0008u, 2u, 0u);
    // $82805A JMP (0008) dinamico
    { auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(0x0008u); hw.requestDispatch(dst,0x82805Au); return; }
L_8280A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A3u, 5u, 3u, cpu.address("abs", 0x1A6Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280A3 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A6Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8280A6;
L_8280A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A6u, 8u, 4u, 0x8280C2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8280A6 JSL -> $8280C2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A9u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AAu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8280C2u, 0x8280A6u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8280AA;
L_8280AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AAu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AAu,0x8280AAu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AAu, 5u, 3u, cpu.address("abs", 0x1FC8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280AA STY
    hw.write(cpu.address("abs", 0x1FC8u), cpu.y, cpu.x8?8:16);
    goto L_8280AD;
L_8280AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ADu, 5u, 3u, cpu.address("abs", 0x1FCAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280AD STA
    hw.write(cpu.address("abs", 0x1FCAu), cpu.a, cpu.m8?8:16);
    goto L_8280B0;
L_8280B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B0u, 5u, 3u, cpu.address("abs", 0x1A70u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280B0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1A70u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8280B3;
L_8280B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B3u, 8u, 4u, 0x8280C2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8280B3 JSL -> $8280C2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80B6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80B7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8280C2u, 0x8280B3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_8280B7;
L_8280B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80B7u,0x8280B7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u,cpu,0x8Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B7u, 5u, 3u, cpu.address("abs", 0x1FCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280B7 STY
    hw.write(cpu.address("abs", 0x1FCEu), cpu.y, cpu.x8?8:16);
    goto L_8280BA;
L_8280BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280BA EOR
    cpu.logicXor(0xFFFFu);
    goto L_8280BD;
L_8280BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280BD INC
    cpu.inc('A');
    goto L_8280BE;
L_8280BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BEu, 5u, 3u, cpu.address("abs", 0x1FCCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8280BE STA
    hw.write(cpu.address("abs", 0x1FCCu), cpu.a, cpu.m8?8:16);
    goto L_8280C1;
L_8280C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8280C1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8280C1u);return;} hw.unresolvedReturn(0x8280C1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829AA3_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x829AA3u: goto L_829AA3;
    case 0x829AA5u: goto L_829AA5;
    case 0x829AA7u: goto L_829AA7;
    case 0x829AA9u: goto L_829AA9;
    case 0x829AABu: goto L_829AAB;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_829AA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA3u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xAEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AA3 STZ
    hw.write(cpu.address("dp", 0xAEu), 0, cpu.m8?8:16);
    goto L_829AA5;
L_829AA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AA5 STZ
    hw.write(cpu.address("dp", 0xB2u), 0, cpu.m8?8:16);
    goto L_829AA7;
L_829AA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA7u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AA7 STZ
    hw.write(cpu.address("dp", 0xB0u), 0, cpu.m8?8:16);
    goto L_829AA9;
L_829AA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA9u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AA9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $829AA9 STZ
    hw.write(cpu.address("dp", 0xB4u), 0, cpu.m8?8:16);
    goto L_829AAB;
L_829AAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9AABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9AABu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $829AAB RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x829AABu);return;} hw.unresolvedReturn(0x829AABu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_829FCF_E0M0X0CQ_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82A20Eu: goto L_82A20E;
    case 0x82A211u: goto L_82A211;
    case 0x82A212u: goto L_82A212;
    case 0x82A214u: goto L_82A214;
    case 0x82A216u: goto L_82A216;
    case 0x82A218u: goto L_82A218;
    case 0x82A21Cu: goto L_82A21C;
    case 0x82A21Eu: goto L_82A21E;
    case 0x82A221u: goto L_82A221;
    case 0x82A222u: goto L_82A222;
    case 0x82A223u: goto L_82A223;
    case 0x82A224u: goto L_82A224;
    case 0x82A225u: goto L_82A225;
    case 0x82A226u: goto L_82A226;
    case 0x82A227u: goto L_82A227;
    case 0x82A229u: goto L_82A229;
    case 0x82A22Cu: goto L_82A22C;
    case 0x82A22Du: goto L_82A22D;
    case 0x82A22Fu: goto L_82A22F;
    case 0x82A232u: goto L_82A232;
    case 0x82A233u: goto L_82A233;
    case 0x82A235u: goto L_82A235;
    case 0x82A238u: goto L_82A238;
    case 0x82A239u: goto L_82A239;
    case 0x82A23Bu: goto L_82A23B;
    case 0x82A23Du: goto L_82A23D;
    case 0x82A23Fu: goto L_82A23F;
    case 0x82A242u: goto L_82A242;
    case 0x82A244u: goto L_82A244;
    case 0x82A246u: goto L_82A246;
    case 0x82A248u: goto L_82A248;
    case 0x82A249u: goto L_82A249;
    case 0x82A24Au: goto L_82A24A;
    case 0x82A24Cu: goto L_82A24C;
    case 0x82A24Eu: goto L_82A24E;
    case 0x82A24Fu: goto L_82A24F;
    case 0x82A250u: goto L_82A250;
    case 0x82A252u: goto L_82A252;
    case 0x82A254u: goto L_82A254;
    case 0x82A255u: goto L_82A255;
    case 0x82A256u: goto L_82A256;
    case 0x82A258u: goto L_82A258;
    case 0x82A25Au: goto L_82A25A;
    case 0x82A25Bu: goto L_82A25B;
    case 0x82A25Cu: goto L_82A25C;
    case 0x82A25Eu: goto L_82A25E;
    case 0x82A260u: goto L_82A260;
    case 0x82A261u: goto L_82A261;
    case 0x82A262u: goto L_82A262;
    case 0x82A264u: goto L_82A264;
    case 0x82A266u: goto L_82A266;
    case 0x82A267u: goto L_82A267;
    case 0x82A268u: goto L_82A268;
    case 0x82A26Au: goto L_82A26A;
    case 0x82A26Cu: goto L_82A26C;
    case 0x82A26Fu: goto L_82A26F;
    case 0x82A270u: goto L_82A270;
    case 0x82A274u: goto L_82A274;
    case 0x82A276u: goto L_82A276;
    case 0x82A279u: goto L_82A279;
    case 0x82A27Au: goto L_82A27A;
    case 0x82A27Bu: goto L_82A27B;
    case 0x82A27Cu: goto L_82A27C;
    case 0x82A27Du: goto L_82A27D;
    case 0x82A27Eu: goto L_82A27E;
    case 0x82A27Fu: goto L_82A27F;
    case 0x82A281u: goto L_82A281;
    case 0x82A284u: goto L_82A284;
    case 0x82A285u: goto L_82A285;
    case 0x82A287u: goto L_82A287;
    case 0x82A28Au: goto L_82A28A;
    case 0x82A28Bu: goto L_82A28B;
    case 0x82A28Du: goto L_82A28D;
    case 0x82A290u: goto L_82A290;
    case 0x82A291u: goto L_82A291;
    case 0x82A293u: goto L_82A293;
    case 0x82A295u: goto L_82A295;
    case 0x82A297u: goto L_82A297;
    case 0x82A29Bu: goto L_82A29B;
    case 0x82A29Du: goto L_82A29D;
    case 0x82A2A0u: goto L_82A2A0;
    case 0x82A2A1u: goto L_82A2A1;
    case 0x82A2A2u: goto L_82A2A2;
    case 0x82A2A3u: goto L_82A2A3;
    case 0x82A2A4u: goto L_82A2A4;
    case 0x82A2A5u: goto L_82A2A5;
    case 0x82A2A6u: goto L_82A2A6;
    case 0x82A2A8u: goto L_82A2A8;
    case 0x82A2ABu: goto L_82A2AB;
    case 0x82A2ACu: goto L_82A2AC;
    case 0x82A2AEu: goto L_82A2AE;
    case 0x82A2B1u: goto L_82A2B1;
    case 0x82A2B2u: goto L_82A2B2;
    case 0x82A2B4u: goto L_82A2B4;
    case 0x82A2B7u: goto L_82A2B7;
    case 0x82A2B8u: goto L_82A2B8;
    case 0x82A2BAu: goto L_82A2BA;
    case 0x82A2BCu: goto L_82A2BC;
    case 0x82A2BEu: goto L_82A2BE;
    case 0x82A2C2u: goto L_82A2C2;
    case 0x82A2C4u: goto L_82A2C4;
    case 0x82A2C7u: goto L_82A2C7;
    case 0x82A2C8u: goto L_82A2C8;
    case 0x82A2C9u: goto L_82A2C9;
    case 0x82A2CAu: goto L_82A2CA;
    case 0x82A2CBu: goto L_82A2CB;
    case 0x82A2CCu: goto L_82A2CC;
    case 0x82A2CDu: goto L_82A2CD;
    case 0x82A2CFu: goto L_82A2CF;
    case 0x82A2D2u: goto L_82A2D2;
    case 0x82A2D3u: goto L_82A2D3;
    case 0x82A2D5u: goto L_82A2D5;
    case 0x82A2D8u: goto L_82A2D8;
    case 0x82A2D9u: goto L_82A2D9;
    case 0x82A2DBu: goto L_82A2DB;
    case 0x82A2DEu: goto L_82A2DE;
    case 0x82A2DFu: goto L_82A2DF;
    case 0x82A2E1u: goto L_82A2E1;
    case 0x82A2E3u: goto L_82A2E3;
    case 0x82A2E5u: goto L_82A2E5;
    case 0x82A2E9u: goto L_82A2E9;
    case 0x82A2EBu: goto L_82A2EB;
    case 0x82A2EEu: goto L_82A2EE;
    case 0x82A2EFu: goto L_82A2EF;
    case 0x82A2F0u: goto L_82A2F0;
    case 0x82A2F1u: goto L_82A2F1;
    case 0x82A2F2u: goto L_82A2F2;
    case 0x82A2F3u: goto L_82A2F3;
    case 0x82A2F4u: goto L_82A2F4;
    case 0x82A2F6u: goto L_82A2F6;
    case 0x82A2F9u: goto L_82A2F9;
    case 0x82A2FAu: goto L_82A2FA;
    case 0x82A2FCu: goto L_82A2FC;
    case 0x82A2FFu: goto L_82A2FF;
    case 0x82A300u: goto L_82A300;
    case 0x82A302u: goto L_82A302;
    case 0x82A305u: goto L_82A305;
    case 0x82A306u: goto L_82A306;
    case 0x82A308u: goto L_82A308;
    case 0x82A30Au: goto L_82A30A;
    case 0x82A30Cu: goto L_82A30C;
    case 0x82A30Fu: goto L_82A30F;
    case 0x82A311u: goto L_82A311;
    case 0x82A313u: goto L_82A313;
    case 0x82A315u: goto L_82A315;
    case 0x82A316u: goto L_82A316;
    case 0x82A317u: goto L_82A317;
    case 0x82A319u: goto L_82A319;
    case 0x82A31Bu: goto L_82A31B;
    case 0x82A31Cu: goto L_82A31C;
    case 0x82A31Du: goto L_82A31D;
    case 0x82A31Fu: goto L_82A31F;
    case 0x82A321u: goto L_82A321;
    case 0x82A322u: goto L_82A322;
    case 0x82A323u: goto L_82A323;
    case 0x82A325u: goto L_82A325;
    case 0x82A327u: goto L_82A327;
    case 0x82A328u: goto L_82A328;
    case 0x82A329u: goto L_82A329;
    case 0x82A32Bu: goto L_82A32B;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82A20E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA20Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA20Eu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A20E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A211;
L_82A211:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA211u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA211u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA211u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A211 ASL
    cpu.aslA();
    goto L_82A212;
L_82A212:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA212u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA212u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A212 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A214;
L_82A214:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA214u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA214u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A214 REP
    cpu.rep(0x20u);
    goto L_82A216;
L_82A216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA216u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA216u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A216 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A218;
L_82A218:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA218u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA218u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA218u, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A218 LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A21C;
L_82A21C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA21Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Cu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A21C STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A21E;
L_82A21E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA21Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA21Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A21E AND
    cpu.logicAnd(0x3FFu);
    goto L_82A221;
L_82A221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA221u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA221u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A221 ASL
    cpu.aslA();
    goto L_82A222;
L_82A222:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA222u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA222u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA222u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A222 ASL
    cpu.aslA();
    goto L_82A223;
L_82A223:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA223u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA223u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA223u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A223 ASL
    cpu.aslA();
    goto L_82A224;
L_82A224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA224u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A224 ASL
    cpu.aslA();
    goto L_82A225;
L_82A225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA225u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA225u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A225 ASL
    cpu.aslA();
    goto L_82A226;
L_82A226:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA226u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA226u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA226u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A226 TAX
    cpu.transfer("TAX");
    goto L_82A227;
L_82A227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA227u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A227 SEP
    cpu.sep(0x20u);
    goto L_82A229;
L_82A229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA229u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA229u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A229 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A22C;
L_82A22C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A22C ASL
    cpu.aslA();
    goto L_82A22D;
L_82A22D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Du,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A22D ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A22F;
L_82A22F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA22Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Fu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA22Fu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A22F LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A232;
L_82A232:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA232u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA232u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A232 ASL
    cpu.aslA();
    goto L_82A233;
L_82A233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA233u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA233u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A233 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A235;
L_82A235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA235u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA235u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A235 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A238;
L_82A238:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA238u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA238u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA238u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A238 ASL
    cpu.aslA();
    goto L_82A239;
L_82A239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA239u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA239u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A239 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A23B;
L_82A23B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A23B REP
    cpu.rep(0x20u);
    goto L_82A23D;
L_82A23D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Du,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A23D LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A23F;
L_82A23F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA23Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Fu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA23Fu, 5u + 1u, 3u, cpu.address("absy", 0x8006u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A23F LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8006u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A242;
L_82A242:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA242u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA242u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA242u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A242 BNE -> $82A26F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82A26F; }
    goto L_82A244;
L_82A244:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA244u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA244u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A244 SEP
    cpu.sep(0x20u);
    goto L_82A246;
L_82A246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA246u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A246 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A248;
L_82A248:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA248u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA248u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA248u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A248 ASL
    cpu.aslA();
    goto L_82A249;
L_82A249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA249u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A249 ASL
    cpu.aslA();
    goto L_82A24A;
L_82A24A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Au, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24A STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82A24C;
L_82A24C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A24E;
L_82A24E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Eu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24E ASL
    cpu.aslA();
    goto L_82A24F;
L_82A24F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA24Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Fu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA24Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A24F ASL
    cpu.aslA();
    goto L_82A250;
L_82A250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA250u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA250u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA250u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A250 STA
    hw.write(cpu.address("dp", 0x9u), cpu.a, cpu.m8?8:16);
    goto L_82A252;
L_82A252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA252u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A252 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A254;
L_82A254:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA254u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA254u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A254 ASL
    cpu.aslA();
    goto L_82A255;
L_82A255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA255u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A255 ASL
    cpu.aslA();
    goto L_82A256;
L_82A256:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA256u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA256u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA256u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A256 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82A258;
L_82A258:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA258u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA258u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA258u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A258 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A25A;
L_82A25A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25A ASL
    cpu.aslA();
    goto L_82A25B;
L_82A25B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25B ASL
    cpu.aslA();
    goto L_82A25C;
L_82A25C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25C STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82A25E;
L_82A25E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA25Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA25Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A25E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A260;
L_82A260:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA260u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA260u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA260u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A260 ASL
    cpu.aslA();
    goto L_82A261;
L_82A261:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA261u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA261u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA261u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A261 ASL
    cpu.aslA();
    goto L_82A262;
L_82A262:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA262u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA262u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA262u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A262 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_82A264;
L_82A264:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA264u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA264u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA264u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A264 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A266;
L_82A266:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA266u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA266u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA266u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A266 ASL
    cpu.aslA();
    goto L_82A267;
L_82A267:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA267u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA267u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A267 ASL
    cpu.aslA();
    goto L_82A268;
L_82A268:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA268u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA268u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA268u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A268 STA
    hw.write(cpu.address("dp", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_82A26A;
L_82A26A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A26A REP
    cpu.rep(0x20u);
    goto L_82A26C;
L_82A26C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Cu, 3u, 3u, cpu.address("abs", 0xA30Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A26C JMP -> $82A30C
    goto L_82A30C;
L_82A26F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA26Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Fu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA26Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A26F TAX
    cpu.transfer("TAX");
    goto L_82A270;
L_82A270:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA270u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA270u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA270u, 6u, 4u, ((0x7F8000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A270 LDA
    cpu.loadA(hw.readW(((0x7F8000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A274;
L_82A274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA274u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA274u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A274 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A276;
L_82A276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA276u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A276 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A279;
L_82A279:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA279u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA279u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A279 ASL
    cpu.aslA();
    goto L_82A27A;
L_82A27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27A ASL
    cpu.aslA();
    goto L_82A27B;
L_82A27B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27B ASL
    cpu.aslA();
    goto L_82A27C;
L_82A27C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27C ASL
    cpu.aslA();
    goto L_82A27D;
L_82A27D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Du,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27D ASL
    cpu.aslA();
    goto L_82A27E;
L_82A27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27E TAX
    cpu.transfer("TAX");
    goto L_82A27F;
L_82A27F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA27Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA27Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A27F SEP
    cpu.sep(0x20u);
    goto L_82A281;
L_82A281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA281u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA281u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A281 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A284;
L_82A284:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA284u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA284u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA284u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A284 ASL
    cpu.aslA();
    goto L_82A285;
L_82A285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA285u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA285u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A285 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A287;
L_82A287:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA287u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA287u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A287 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A28A;
L_82A28A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A28A ASL
    cpu.aslA();
    goto L_82A28B;
L_82A28B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Bu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A28B ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A28D;
L_82A28D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA28Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA28Du, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A28D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A290;
L_82A290:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA290u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA290u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA290u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A290 ASL
    cpu.aslA();
    goto L_82A291;
L_82A291:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA291u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA291u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA291u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A291 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A293;
L_82A293:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA293u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA293u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A293 REP
    cpu.rep(0x20u);
    goto L_82A295;
L_82A295:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA295u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA295u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA295u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A295 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A297;
L_82A297:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA297u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA297u, 6u, 4u, ((0x7F8004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A297 LDA
    cpu.loadA(hw.readW(((0x7F8004u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A29B;
L_82A29B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29B STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A29D;
L_82A29D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA29Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA29Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A29D AND
    cpu.logicAnd(0x3FFu);
    goto L_82A2A0;
L_82A2A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A0 ASL
    cpu.aslA();
    goto L_82A2A1;
L_82A2A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A1 ASL
    cpu.aslA();
    goto L_82A2A2;
L_82A2A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A2 ASL
    cpu.aslA();
    goto L_82A2A3;
L_82A2A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A3 ASL
    cpu.aslA();
    goto L_82A2A4;
L_82A2A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A4 ASL
    cpu.aslA();
    goto L_82A2A5;
L_82A2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A5u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A5 TAX
    cpu.transfer("TAX");
    goto L_82A2A6;
L_82A2A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A6u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A6 SEP
    cpu.sep(0x20u);
    goto L_82A2A8;
L_82A2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A8u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2A8u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2A8 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2AB;
L_82A2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ABu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ABu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2AB ASL
    cpu.aslA();
    goto L_82A2AC;
L_82A2AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ACu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2ACu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2AC ROL
    cpu.rolMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_82A2AE;
L_82A2AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2AEu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2AEu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2AE LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2B1;
L_82A2B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2B1 ASL
    cpu.aslA();
    goto L_82A2B2;
L_82A2B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B2u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B2u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x09u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2B2 ROL
    cpu.rolMem(hw, cpu.address("dp", 0x9u), cpu.m8?8:16);
    goto L_82A2B4;
L_82A2B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B4u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2B4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2B7;
L_82A2B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2B7 ASL
    cpu.aslA();
    goto L_82A2B8;
L_82A2B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B8u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2B8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2B8 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xAu), cpu.m8?8:16);
    goto L_82A2BA;
L_82A2BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2BA REP
    cpu.rep(0x20u);
    goto L_82A2BC;
L_82A2BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BCu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BCu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2BC LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A2BE;
L_82A2BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BEu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2BEu, 6u, 4u, ((0x7F8010u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2BE LDA
    cpu.loadA(hw.readW(((0x7F8010u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2C2;
L_82A2C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2C2 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A2C4;
L_82A2C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C4u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2C4 AND
    cpu.logicAnd(0x3FFu);
    goto L_82A2C7;
L_82A2C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C7u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2C7 ASL
    cpu.aslA();
    goto L_82A2C8;
L_82A2C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2C8 ASL
    cpu.aslA();
    goto L_82A2C9;
L_82A2C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2C9 ASL
    cpu.aslA();
    goto L_82A2CA;
L_82A2CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CAu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2CA ASL
    cpu.aslA();
    goto L_82A2CB;
L_82A2CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2CB ASL
    cpu.aslA();
    goto L_82A2CC;
L_82A2CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CCu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2CC TAX
    cpu.transfer("TAX");
    goto L_82A2CD;
L_82A2CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CDu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2CD SEP
    cpu.sep(0x20u);
    goto L_82A2CF;
L_82A2CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CFu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2CFu, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2CF LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2D2;
L_82A2D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2D2 ASL
    cpu.aslA();
    goto L_82A2D3;
L_82A2D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D3u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2D3 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A2D5;
L_82A2D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D5u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D5u, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2D5 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2D8;
L_82A2D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D8u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2D8 ASL
    cpu.aslA();
    goto L_82A2D9;
L_82A2D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D9u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2D9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2D9 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A2DB;
L_82A2DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DBu, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2DB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2DE;
L_82A2DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2DE ASL
    cpu.aslA();
    goto L_82A2DF;
L_82A2DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DFu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2DFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2DF ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A2E1;
L_82A2E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E1u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2E1 REP
    cpu.rep(0x20u);
    goto L_82A2E3;
L_82A2E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E3u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2E3 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A2E5;
L_82A2E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E5u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E5u, 6u, 4u, ((0x7F8012u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2E5 LDA
    cpu.loadA(hw.readW(((0x7F8012u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2E9;
L_82A2E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E9u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2E9 STX
    hw.write(cpu.address("dp", 0x1Au), cpu.x, cpu.x8?8:16);
    goto L_82A2EB;
L_82A2EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2EB AND
    cpu.logicAnd(0x3FFu);
    goto L_82A2EE;
L_82A2EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EEu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2EE ASL
    cpu.aslA();
    goto L_82A2EF;
L_82A2EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2EF ASL
    cpu.aslA();
    goto L_82A2F0;
L_82A2F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F0 ASL
    cpu.aslA();
    goto L_82A2F1;
L_82A2F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F1 ASL
    cpu.aslA();
    goto L_82A2F2;
L_82A2F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F2u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F2 ASL
    cpu.aslA();
    goto L_82A2F3;
L_82A2F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F3 TAX
    cpu.transfer("TAX");
    goto L_82A2F4;
L_82A2F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F4u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F4 SEP
    cpu.sep(0x20u);
    goto L_82A2F6;
L_82A2F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F6u, 4u + 1u, 3u, cpu.address("absx", 0x4001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4001u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2F9;
L_82A2F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2F9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2F9 ASL
    cpu.aslA();
    goto L_82A2FA;
L_82A2FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FAu,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2FA ROL
    cpu.rolMem(hw, cpu.address("dp", 0xCu), cpu.m8?8:16);
    goto L_82A2FC;
L_82A2FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FCu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FCu, 4u + 1u, 3u, cpu.address("absx", 0x4010u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2FC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4010u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A2FF;
L_82A2FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA2FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA2FFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A2FF ASL
    cpu.aslA();
    goto L_82A300;
L_82A300:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA300u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA300u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A300 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xDu), cpu.m8?8:16);
    goto L_82A302;
L_82A302:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA302u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA302u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA302u, 4u + 1u, 3u, cpu.address("absx", 0x4011u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A302 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x4011u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A305;
L_82A305:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA305u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA305u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA305u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A305 ASL
    cpu.aslA();
    goto L_82A306;
L_82A306:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA306u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA306u,cpu,0x26u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA306u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A306 ROL
    cpu.rolMem(hw, cpu.address("dp", 0xEu), cpu.m8?8:16);
    goto L_82A308;
L_82A308:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA308u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA308u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA308u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A308 REP
    cpu.rep(0x20u);
    goto L_82A30A;
L_82A30A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A30A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x1Au), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82A30C;
L_82A30C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Cu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Cu, 5u + 1u, 3u, cpu.address("absy", 0x8100u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A30C LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x8100u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A30F;
L_82A30F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA30Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA30Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A30F BNE -> $82A33C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x82A33Cu,0x82A30Fu); return; }
    goto L_82A311;
L_82A311:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA311u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA311u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA311u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A311 SEP
    cpu.sep(0x20u);
    goto L_82A313;
L_82A313:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA313u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA313u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA313u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A313 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A315;
L_82A315:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA315u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA315u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA315u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A315 ASL
    cpu.aslA();
    goto L_82A316;
L_82A316:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA316u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA316u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA316u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A316 ASL
    cpu.aslA();
    goto L_82A317;
L_82A317:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA317u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA317u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA317u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A317 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82A319;
L_82A319:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA319u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA319u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA319u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A319 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A31B;
L_82A31B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A31B ASL
    cpu.aslA();
    goto L_82A31C;
L_82A31C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A31C ASL
    cpu.aslA();
    goto L_82A31D;
L_82A31D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A31D STA
    hw.write(cpu.address("dp", 0x11u), cpu.a, cpu.m8?8:16);
    goto L_82A31F;
L_82A31F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA31Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA31Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A31F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A321;
L_82A321:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA321u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA321u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA321u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A321 ASL
    cpu.aslA();
    goto L_82A322;
L_82A322:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA322u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA322u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA322u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A322 ASL
    cpu.aslA();
    goto L_82A323;
L_82A323:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA323u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA323u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A323 STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82A325;
L_82A325:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA325u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA325u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA325u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A325 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82A327;
L_82A327:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA327u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA327u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A327 ASL
    cpu.aslA();
    goto L_82A328;
L_82A328:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA328u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA328u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA328u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A328 ASL
    cpu.aslA();
    goto L_82A329;
L_82A329:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA329u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA329u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A329 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82A32B;
L_82A32B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA32Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA32Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x15u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82A32B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x15u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA32Du,0x82A32Bu); return;
}

void sub_839E6C_E0M0X0C0_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839E6Cu: goto L_839E6C;
    case 0x839E6Fu: goto L_839E6F;
    case 0x839E73u: goto L_839E73;
    case 0x839E76u: goto L_839E76;
    case 0x839E77u: goto L_839E77;
    case 0x839E7Au: goto L_839E7A;
    case 0x839E7Du: goto L_839E7D;
    case 0x839E7Fu: goto L_839E7F;
    case 0x839E82u: goto L_839E82;
    case 0x839E84u: goto L_839E84;
    case 0x839E87u: goto L_839E87;
    case 0x839E8Au: goto L_839E8A;
    case 0x839E8Du: goto L_839E8D;
    case 0x839E90u: goto L_839E90;
    case 0x839E93u: goto L_839E93;
    case 0x839E96u: goto L_839E96;
    case 0x839E99u: goto L_839E99;
    case 0x839E9Au: goto L_839E9A;
    case 0x839E9Du: goto L_839E9D;
    case 0x839E9Eu: goto L_839E9E;
    case 0x839EA1u: goto L_839EA1;
    case 0x839EA2u: goto L_839EA2;
    case 0x839EA5u: goto L_839EA5;
    case 0x839EA7u: goto L_839EA7;
    case 0x839EABu: goto L_839EAB;
    case 0x839EACu: goto L_839EAC;
    case 0x839EAEu: goto L_839EAE;
    case 0x839EB0u: goto L_839EB0;
    case 0x839EB3u: goto L_839EB3;
    case 0x839EB5u: goto L_839EB5;
    case 0x839EB8u: goto L_839EB8;
    case 0x839EB9u: goto L_839EB9;
    case 0x839EBAu: goto L_839EBA;
    case 0x839EBCu: goto L_839EBC;
    case 0x839EBEu: goto L_839EBE;
    case 0x839EC0u: goto L_839EC0;
    case 0x839EC1u: goto L_839EC1;
    case 0x839EC3u: goto L_839EC3;
    case 0x839EC5u: goto L_839EC5;
    case 0x839EC6u: goto L_839EC6;
    case 0x839EC7u: goto L_839EC7;
    case 0x839EC8u: goto L_839EC8;
    case 0x839ECBu: goto L_839ECB;
    case 0x839ECDu: goto L_839ECD;
    case 0x839ECFu: goto L_839ECF;
    case 0x839ED1u: goto L_839ED1;
    case 0x839ED3u: goto L_839ED3;
    case 0x839ED5u: goto L_839ED5;
    case 0x839ED8u: goto L_839ED8;
    case 0x839EDAu: goto L_839EDA;
    case 0x839EDBu: goto L_839EDB;
    case 0x839EDDu: goto L_839EDD;
    case 0x839EE0u: goto L_839EE0;
    case 0x839EE2u: goto L_839EE2;
    case 0x839EE5u: goto L_839EE5;
    case 0x839EE7u: goto L_839EE7;
    case 0x839EEAu: goto L_839EEA;
    case 0x839EECu: goto L_839EEC;
    case 0x839EEFu: goto L_839EEF;
    case 0x839EF1u: goto L_839EF1;
    case 0x839EF4u: goto L_839EF4;
    case 0x839EF6u: goto L_839EF6;
    case 0x839EF8u: goto L_839EF8;
    case 0x839EFAu: goto L_839EFA;
    case 0x839EFDu: goto L_839EFD;
    case 0x839EFFu: goto L_839EFF;
    case 0x839F01u: goto L_839F01;
    case 0x839F04u: goto L_839F04;
    case 0x839F06u: goto L_839F06;
    case 0x839F09u: goto L_839F09;
    case 0x839F0Cu: goto L_839F0C;
    case 0x839F0Eu: goto L_839F0E;
    case 0x839F11u: goto L_839F11;
    case 0x839F13u: goto L_839F13;
    case 0x839F16u: goto L_839F16;
    case 0x839F19u: goto L_839F19;
    case 0x839F1Bu: goto L_839F1B;
    case 0x839F1Eu: goto L_839F1E;
    case 0x839F20u: goto L_839F20;
    case 0x839F23u: goto L_839F23;
    case 0x839F26u: goto L_839F26;
    case 0x839F28u: goto L_839F28;
    case 0x839F2Bu: goto L_839F2B;
    case 0x839F2Eu: goto L_839F2E;
    case 0x839F31u: goto L_839F31;
    case 0x839F33u: goto L_839F33;
    case 0x839F34u: goto L_839F34;
    case 0x839F35u: goto L_839F35;
    case 0x839F38u: goto L_839F38;
    case 0x839F3Au: goto L_839F3A;
    case 0x839F3Bu: goto L_839F3B;
    case 0x839F3Eu: goto L_839F3E;
    case 0x839F41u: goto L_839F41;
    case 0x839F43u: goto L_839F43;
    case 0x839F46u: goto L_839F46;
    case 0x839F49u: goto L_839F49;
    case 0x839F4Bu: goto L_839F4B;
    case 0x839F4Eu: goto L_839F4E;
    case 0x839F50u: goto L_839F50;
    case 0x839F52u: goto L_839F52;
    case 0x839F55u: goto L_839F55;
    case 0x839F58u: goto L_839F58;
    case 0x839F5Cu: goto L_839F5C;
    case 0x839F5Fu: goto L_839F5F;
    case 0x839F61u: goto L_839F61;
    case 0x839F64u: goto L_839F64;
    case 0x839F66u: goto L_839F66;
    case 0x839F67u: goto L_839F67;
    case 0x839F69u: goto L_839F69;
    case 0x839F6Bu: goto L_839F6B;
    case 0x839F6Cu: goto L_839F6C;
    case 0x839F6Du: goto L_839F6D;
    case 0x839F6Fu: goto L_839F6F;
    case 0x839F71u: goto L_839F71;
    case 0x839F74u: goto L_839F74;
    case 0x839F76u: goto L_839F76;
    case 0x839F79u: goto L_839F79;
    case 0x839F7Cu: goto L_839F7C;
    case 0x839F7Fu: goto L_839F7F;
    case 0x839F82u: goto L_839F82;
    case 0x839F84u: goto L_839F84;
    case 0x839F87u: goto L_839F87;
    case 0x839F89u: goto L_839F89;
    case 0x839F8Cu: goto L_839F8C;
    case 0x839F8Eu: goto L_839F8E;
    case 0x839F90u: goto L_839F90;
    case 0x839F92u: goto L_839F92;
    case 0x839F95u: goto L_839F95;
    case 0x839F97u: goto L_839F97;
    case 0x839F9Au: goto L_839F9A;
    case 0x839F9Du: goto L_839F9D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839E6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E6C STX
    hw.write(cpu.address("abs", 0x1BB4u), cpu.x, cpu.x8?8:16);
    goto L_839E6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E6C STX
    hw.write(cpu.address("abs", 0x1BB4u), cpu.x, cpu.x8?8:16);
    goto L_839E6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,0x839E6Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839E6F JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9E72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E73u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x839E6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839E73;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839E6F JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9E72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E73u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x839E6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839E73;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,0x839E6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E73u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E73u,0x839E73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u, 5u, 3u, cpu.address("abs", 0x1BA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E73 STA
    hw.write(cpu.address("abs", 0x1BA6u), cpu.a, cpu.m8?8:16);
    goto L_839E76;
L_839E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E76 ROR
    cpu.rorA();
    goto L_839E77;
L_839E77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E77 STA
    hw.write(cpu.address("abs", 0x1BA8u), cpu.a, cpu.m8?8:16);
    goto L_839E7A;
L_839E7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au, 5u, 3u, cpu.address("abs", 0x1BCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E7D;
L_839E7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7D BEQ -> $839E87
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839E87; }
    goto L_839E7F;
L_839E7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Fu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Fu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7F CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_839E82;
L_839E82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E82 BEQ -> $839E87
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839E87; }
    goto L_839E84;
L_839E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 3u, 3u, cpu.address("abs", 0x9F82u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E84 JMP -> $839F82
    goto L_839F82;
L_839E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E87 STZ
    hw.write(cpu.address("abs", 0x1BD4u), 0, cpu.m8?8:16);
    goto L_839E8A;
L_839E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E8A STZ
    hw.write(cpu.address("abs", 0x1BD2u), 0, cpu.m8?8:16);
    goto L_839E8D;
L_839E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E8D STZ
    hw.write(cpu.address("abs", 0x1BD8u), 0, cpu.m8?8:16);
    goto L_839E90;
L_839E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E90 STZ
    hw.write(cpu.address("abs", 0x1BD6u), 0, cpu.m8?8:16);
    goto L_839E93;
L_839E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 5u, 3u, cpu.address("abs", 0x1BF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E93 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BF0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839E96;
L_839E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 5u + 1u, 3u, cpu.address("absy", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E99;
L_839E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E99 SEC
    cpu.setFlag('C', true);
    goto L_839E9A;
L_839E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9A SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16));
    goto L_839E9D;
L_839E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9D CLC
    cpu.setFlag('C', false);
    goto L_839E9E;
L_839E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9E ADC
    cpu.adc(0x5u);
    goto L_839EA1;
L_839EA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA1 ASL
    cpu.aslA();
    goto L_839EA2;
L_839EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u, 6u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA2 STA
    hw.write(cpu.address("absx", 0x222u), cpu.a, cpu.m8?8:16);
    goto L_839EA5;
L_839EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EA7;
L_839EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 8u, 4u, 0x848734u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839EA7 JSL -> $848734 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848734u, 0x839EA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839EAB;
L_839EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EAB PHP
    cpu.push("PHP", hw);
    goto L_839EAC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EAB PHP
    cpu.push("PHP", hw);
    goto L_839EAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EABu,0x839EABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAC STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_839EAE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAC STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_839EAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EACu,0x839EACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAEu,0x839EAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB0 CMP
    cpu.compareA(0x2u);
    goto L_839EB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB0 CMP
    cpu.compareA(0x2u);
    goto L_839EB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB0u,0x839EB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB3 BEQ -> $839EBE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839EBE; }
    goto L_839EB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x839EB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 5u, 3u, cpu.address("abs", 0x1BA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB5u,0x839EB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB8 LSR
    cpu.lsrA();
    goto L_839EB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB8u,0x839EB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB9 LSR
    cpu.lsrA();
    goto L_839EBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB9u,0x839EB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBA BCC -> $839EBE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EBE; }
    goto L_839EBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBAu,0x839EBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBC INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_839EBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBCu,0x839EBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBEu,0x839EBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC0 SEC
    cpu.setFlag('C', true);
    goto L_839EC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC0u,0x839EC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_839EC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC1u,0x839EC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC3 BCS -> $839EC6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EC6; }
    goto L_839EC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC3u,0x839EC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC5 TDC
    cpu.tdc();
    goto L_839EC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC5u,0x839EC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC6 TAY
    cpu.transfer("TAY");
    goto L_839EC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC6u,0x839EC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EC7 PLP
    cpu.pop("PLP", hw);
    goto L_839EC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC7u,0x839EC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC8 LDA
    cpu.setA(0x2000u, 16);
    goto L_839ECB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC8 LDA
    cpu.setA(0x2000u, 16);
    goto L_839ECB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC8u,0x839EC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_839ECD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_839ECD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECBu,0x839ECBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECD BCC -> $839EDB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839ECF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECD BCC -> $839EDB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839ECF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECDu,0x839ECDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECF LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_839ED1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECF LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_839ED1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECFu,0x839ECFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED1 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_839ED3;
L_839ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED3 BCS -> $839EDA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDA; }
    goto L_839ED5;
L_839ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED5 CPY
    cpu.compareY(0x40u);
    goto L_839ED8;
L_839ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED8 BCS -> $839EDB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839EDA;
L_839EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDA LSR
    cpu.lsrA();
    goto L_839EDB;
L_839EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x24u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x24u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x839EDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDD CPY
    cpu.compareY(0x3u);
    goto L_839EE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDD CPY
    cpu.compareY(0x3u);
    goto L_839EE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDDu,0x839EDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE0 BEQ -> $839F01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F01; }
    goto L_839EE2;
L_839EE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE2 CPY
    cpu.compareY(0x9u);
    goto L_839EE5;
L_839EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE5 BEQ -> $839F06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F06; }
    goto L_839EE7;
L_839EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE7 CPY
    cpu.compareY(0xAu);
    goto L_839EEA;
L_839EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEA BEQ -> $839F06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F06; }
    goto L_839EEC;
L_839EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEC CPY
    cpu.compareY(0x8u);
    goto L_839EEF;
L_839EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEF BCS -> $839F19
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839EF1;
L_839EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1092u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EF4;
L_839EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF4 BEQ -> $839F13
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F13; }
    goto L_839EF6;
L_839EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839EF8;
L_839EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EFA;
L_839EFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFA AND
    cpu.logicAnd(0x600u);
    goto L_839EFD;
L_839EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839EFF;
L_839EFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFF BRA -> $839F19
    goto L_839F19;
L_839F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F01 LDA
    cpu.setA(0x3000u, 16);
    goto L_839F04;
L_839F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F04 BRA -> $839F13
    goto L_839F13;
L_839F06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F06u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F06u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F06 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10B8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839F09;
L_839F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F09 CPY
    cpu.compareY(0x2u);
    goto L_839F0C;
L_839F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F0C BEQ -> $839F19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839F0E;
L_839F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F0E CPY
    cpu.compareY(0x5u);
    goto L_839F11;
L_839F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F11 BEQ -> $839F19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839F13;
L_839F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u, 5u, 3u, cpu.address("abs", 0x1B9Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F13 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B9Fu), cpu.m8?8:16));
    goto L_839F16;
L_839F16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F16 AND
    cpu.logicAnd(0xFF00u);
    goto L_839F19;
L_839F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F19 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_839F1B;
L_839F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F1B AND
    cpu.logicAnd(0xCFFFu);
    goto L_839F1E;
L_839F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F1E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_839F20;
L_839F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 6u, 3u, cpu.address("absx", 0x022Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F20 STA
    hw.write(cpu.address("absx", 0x22Au), cpu.a, cpu.m8?8:16);
    goto L_839F23;
L_839F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F23 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F26;
L_839F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F26 BEQ -> $839F3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F3E; }
    goto L_839F28;
L_839F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F28 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_839F2B;
L_839F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F2B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839F2E;
L_839F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F2E CPY
    cpu.compareY(0xCu);
    goto L_839F31;
L_839F31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F31 BNE -> $839F34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F34; }
    goto L_839F33;
L_839F33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F33 ASL
    cpu.aslA();
    goto L_839F34;
L_839F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F34 CLC
    cpu.setFlag('C', false);
    goto L_839F35;
L_839F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F35 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16));
    goto L_839F38;
L_839F38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F38u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F38 BCS -> $839F3B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839F3B; }
    goto L_839F3A;
L_839F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3A TDC
    cpu.tdc();
    goto L_839F3B;
L_839F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3B STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_839F3E;
L_839F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F41;
L_839F41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F41u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F41 BEQ -> $839F46
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F46; }
    goto L_839F43;
L_839F43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u, 9u, 3u, cpu.address("absx", 0x10DCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F43 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10DCu), cpu.m8?8:16);
    goto L_839F46;
L_839F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F46 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F49;
L_839F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F49 BEQ -> $839F58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F58; }
    goto L_839F4B;
L_839F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 9u, 3u, cpu.address("absx", 0x10BEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F4B DEC
    cpu.decMem(hw, cpu.address("absx", 0x10BEu), cpu.m8?8:16);
    goto L_839F4E;
L_839F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F4E BNE -> $839F58
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F58; }
    goto L_839F50;
L_839F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F50u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F50 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F52;
L_839F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F52 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839F55;
L_839F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F55 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839F58;
L_839F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 8u, 4u, 0x83CDCBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839F58 JSL -> $83CDCB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CDCBu, 0x839F58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839F5C;
L_839F5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,0x839F5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Cu, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F5C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F5F;
L_839F5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F5F BPL -> $839F64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839F64; }
    goto L_839F61;
L_839F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u, 3u, 3u, cpu.address("abs", 0x9FACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F61 JMP -> $839FAC
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9FACu),0x839F61u); return;
L_839F64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F64 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F66;
L_839F66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F66u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F66 LSR
    cpu.lsrA();
    goto L_839F67;
L_839F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F67 BNE -> $839F7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F69;
L_839F69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F6B;
L_839F6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6B LSR
    cpu.lsrA();
    goto L_839F6C;
L_839F6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6C DEC
    cpu.decReg('A');
    goto L_839F6D;
L_839F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6D BNE -> $839F7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F6F;
L_839F6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F71;
L_839F71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F71u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F71 CMP
    cpu.compareA(0x6u);
    goto L_839F74;
L_839F74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F74 BEQ -> $839F7F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F76;
L_839F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F76 LDA
    cpu.setA(0x400u, 16);
    goto L_839F79;
L_839F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F79u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F79u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F79 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_839F7C;
L_839F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F7C STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_839F7F;
L_839F7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu, 6u, 3u, cpu.address("abs", 0x9FE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839F7F JSR -> $839FE2 stack real
    { cpu.push16Value(hw,0x9F81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9FE2u), 0x839F7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839F82;
L_839F82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F82u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F82u,0x839F82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F84u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F84u,0x839F84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F87 BNE -> $839F8E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F8E; }
    goto L_839F89;
L_839F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F89 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F8C;
L_839F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F8C BMI -> $839F97
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839F97; }
    goto L_839F8E;
L_839F8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F8E SEP
    cpu.sep(0x20u);
    goto L_839F90;
L_839F90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F90 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F92;
L_839F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u, 5u, 3u, cpu.address("absx", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F92 STA
    hw.write(cpu.address("absx", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_839F95;
L_839F95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F95u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F95 REP
    cpu.rep(0x20u);
    goto L_839F97;
L_839F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F97 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_839F9A;
L_839F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9A INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_839F9D;
L_839F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9D TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,0x839F9Du); return;
}

void sub_839E6C_E0M0X0CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839E6Cu: goto L_839E6C;
    case 0x839E6Fu: goto L_839E6F;
    case 0x839E73u: goto L_839E73;
    case 0x839E76u: goto L_839E76;
    case 0x839E77u: goto L_839E77;
    case 0x839E7Au: goto L_839E7A;
    case 0x839E7Du: goto L_839E7D;
    case 0x839E7Fu: goto L_839E7F;
    case 0x839E82u: goto L_839E82;
    case 0x839E84u: goto L_839E84;
    case 0x839E87u: goto L_839E87;
    case 0x839E8Au: goto L_839E8A;
    case 0x839E8Du: goto L_839E8D;
    case 0x839E90u: goto L_839E90;
    case 0x839E93u: goto L_839E93;
    case 0x839E96u: goto L_839E96;
    case 0x839E99u: goto L_839E99;
    case 0x839E9Au: goto L_839E9A;
    case 0x839E9Du: goto L_839E9D;
    case 0x839E9Eu: goto L_839E9E;
    case 0x839EA1u: goto L_839EA1;
    case 0x839EA2u: goto L_839EA2;
    case 0x839EA5u: goto L_839EA5;
    case 0x839EA7u: goto L_839EA7;
    case 0x839EABu: goto L_839EAB;
    case 0x839EACu: goto L_839EAC;
    case 0x839EAEu: goto L_839EAE;
    case 0x839EB0u: goto L_839EB0;
    case 0x839EB3u: goto L_839EB3;
    case 0x839EB5u: goto L_839EB5;
    case 0x839EB8u: goto L_839EB8;
    case 0x839EB9u: goto L_839EB9;
    case 0x839EBAu: goto L_839EBA;
    case 0x839EBCu: goto L_839EBC;
    case 0x839EBEu: goto L_839EBE;
    case 0x839EC0u: goto L_839EC0;
    case 0x839EC1u: goto L_839EC1;
    case 0x839EC3u: goto L_839EC3;
    case 0x839EC5u: goto L_839EC5;
    case 0x839EC6u: goto L_839EC6;
    case 0x839EC7u: goto L_839EC7;
    case 0x839EC8u: goto L_839EC8;
    case 0x839ECBu: goto L_839ECB;
    case 0x839ECDu: goto L_839ECD;
    case 0x839ECFu: goto L_839ECF;
    case 0x839ED1u: goto L_839ED1;
    case 0x839ED3u: goto L_839ED3;
    case 0x839ED5u: goto L_839ED5;
    case 0x839ED8u: goto L_839ED8;
    case 0x839EDAu: goto L_839EDA;
    case 0x839EDBu: goto L_839EDB;
    case 0x839EDDu: goto L_839EDD;
    case 0x839EE0u: goto L_839EE0;
    case 0x839EE2u: goto L_839EE2;
    case 0x839EE5u: goto L_839EE5;
    case 0x839EE7u: goto L_839EE7;
    case 0x839EEAu: goto L_839EEA;
    case 0x839EECu: goto L_839EEC;
    case 0x839EEFu: goto L_839EEF;
    case 0x839EF1u: goto L_839EF1;
    case 0x839EF4u: goto L_839EF4;
    case 0x839EF6u: goto L_839EF6;
    case 0x839EF8u: goto L_839EF8;
    case 0x839EFAu: goto L_839EFA;
    case 0x839EFDu: goto L_839EFD;
    case 0x839EFFu: goto L_839EFF;
    case 0x839F01u: goto L_839F01;
    case 0x839F04u: goto L_839F04;
    case 0x839F06u: goto L_839F06;
    case 0x839F09u: goto L_839F09;
    case 0x839F0Cu: goto L_839F0C;
    case 0x839F0Eu: goto L_839F0E;
    case 0x839F11u: goto L_839F11;
    case 0x839F13u: goto L_839F13;
    case 0x839F16u: goto L_839F16;
    case 0x839F19u: goto L_839F19;
    case 0x839F1Bu: goto L_839F1B;
    case 0x839F1Eu: goto L_839F1E;
    case 0x839F20u: goto L_839F20;
    case 0x839F23u: goto L_839F23;
    case 0x839F26u: goto L_839F26;
    case 0x839F28u: goto L_839F28;
    case 0x839F2Bu: goto L_839F2B;
    case 0x839F2Eu: goto L_839F2E;
    case 0x839F31u: goto L_839F31;
    case 0x839F33u: goto L_839F33;
    case 0x839F34u: goto L_839F34;
    case 0x839F35u: goto L_839F35;
    case 0x839F38u: goto L_839F38;
    case 0x839F3Au: goto L_839F3A;
    case 0x839F3Bu: goto L_839F3B;
    case 0x839F3Eu: goto L_839F3E;
    case 0x839F41u: goto L_839F41;
    case 0x839F43u: goto L_839F43;
    case 0x839F46u: goto L_839F46;
    case 0x839F49u: goto L_839F49;
    case 0x839F4Bu: goto L_839F4B;
    case 0x839F4Eu: goto L_839F4E;
    case 0x839F50u: goto L_839F50;
    case 0x839F52u: goto L_839F52;
    case 0x839F55u: goto L_839F55;
    case 0x839F58u: goto L_839F58;
    case 0x839F5Cu: goto L_839F5C;
    case 0x839F5Fu: goto L_839F5F;
    case 0x839F61u: goto L_839F61;
    case 0x839F64u: goto L_839F64;
    case 0x839F66u: goto L_839F66;
    case 0x839F67u: goto L_839F67;
    case 0x839F69u: goto L_839F69;
    case 0x839F6Bu: goto L_839F6B;
    case 0x839F6Cu: goto L_839F6C;
    case 0x839F6Du: goto L_839F6D;
    case 0x839F6Fu: goto L_839F6F;
    case 0x839F71u: goto L_839F71;
    case 0x839F74u: goto L_839F74;
    case 0x839F76u: goto L_839F76;
    case 0x839F79u: goto L_839F79;
    case 0x839F7Cu: goto L_839F7C;
    case 0x839F7Fu: goto L_839F7F;
    case 0x839F82u: goto L_839F82;
    case 0x839F84u: goto L_839F84;
    case 0x839F87u: goto L_839F87;
    case 0x839F89u: goto L_839F89;
    case 0x839F8Cu: goto L_839F8C;
    case 0x839F8Eu: goto L_839F8E;
    case 0x839F90u: goto L_839F90;
    case 0x839F92u: goto L_839F92;
    case 0x839F95u: goto L_839F95;
    case 0x839F97u: goto L_839F97;
    case 0x839F9Au: goto L_839F9A;
    case 0x839F9Du: goto L_839F9D;
    case 0x839F9Eu: goto L_839F9E;
    case 0x839F9Fu: goto L_839F9F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839E6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Cu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E6C STX
    hw.write(cpu.address("abs", 0x1BB4u), cpu.x, cpu.x8?8:16);
    goto L_839E6F;
L_839E6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E6Fu, 8u, 4u, 0x8486E3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839E6F JSL -> $8486E3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9E72u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9E73u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486E3u, 0x839E6Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839E73;
L_839E73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E73u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9E73u,0x839E73u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E73u, 5u, 3u, cpu.address("abs", 0x1BA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E73 STA
    hw.write(cpu.address("abs", 0x1BA6u), cpu.a, cpu.m8?8:16);
    goto L_839E76;
L_839E76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u,cpu,0x6Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E76u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E76 ROR
    cpu.rorA();
    goto L_839E77;
L_839E77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E77u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E77 STA
    hw.write(cpu.address("abs", 0x1BA8u), cpu.a, cpu.m8?8:16);
    goto L_839E7A;
L_839E7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Au, 5u, 3u, cpu.address("abs", 0x1BCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E7D;
L_839E7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7D BEQ -> $839E87
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839E87; }
    goto L_839E7F;
L_839E7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Fu,cpu,0xCDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E7Fu, 5u, 3u, cpu.address("abs", 0x1BB4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E7F CMP
    cpu.compareA(hw.readW(cpu.address("abs", 0x1BB4u), cpu.m8?8:16));
    goto L_839E82;
L_839E82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E82 BEQ -> $839E87
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839E87; }
    goto L_839E84;
L_839E84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E84u, 3u, 3u, cpu.address("abs", 0x9F82u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E84 JMP -> $839F82
    goto L_839F82;
L_839E87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E87u, 5u, 3u, cpu.address("abs", 0x1BD4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E87 STZ
    hw.write(cpu.address("abs", 0x1BD4u), 0, cpu.m8?8:16);
    goto L_839E8A;
L_839E8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Au, 5u, 3u, cpu.address("abs", 0x1BD2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E8A STZ
    hw.write(cpu.address("abs", 0x1BD2u), 0, cpu.m8?8:16);
    goto L_839E8D;
L_839E8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E8Du, 5u, 3u, cpu.address("abs", 0x1BD8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E8D STZ
    hw.write(cpu.address("abs", 0x1BD8u), 0, cpu.m8?8:16);
    goto L_839E90;
L_839E90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E90u, 5u, 3u, cpu.address("abs", 0x1BD6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E90 STZ
    hw.write(cpu.address("abs", 0x1BD6u), 0, cpu.m8?8:16);
    goto L_839E93;
L_839E93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u,cpu,0xACu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E93u, 5u, 3u, cpu.address("abs", 0x1BF0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E93 LDY
    cpu.setY(hw.readW(cpu.address("abs", 0x1BF0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839E96;
L_839E96:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E96u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E96u, 5u + 1u, 3u, cpu.address("absy", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E96 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x228u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839E99;
L_839E99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E99u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E99 SEC
    cpu.setFlag('C', true);
    goto L_839E9A;
L_839E9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au,cpu,0xFDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Au, 5u + 1u, 3u, cpu.address("absx", 0x0228u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9A SBC
    cpu.sbc(hw.readW(cpu.address("absx", 0x228u), cpu.m8?8:16));
    goto L_839E9D;
L_839E9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9D CLC
    cpu.setFlag('C', false);
    goto L_839E9E;
L_839E9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9E9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9E9Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839E9E ADC
    cpu.adc(0x5u);
    goto L_839EA1;
L_839EA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA1 ASL
    cpu.aslA();
    goto L_839EA2;
L_839EA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA2u, 6u, 3u, cpu.address("absx", 0x0222u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA2 STA
    hw.write(cpu.address("absx", 0x222u), cpu.a, cpu.m8?8:16);
    goto L_839EA5;
L_839EA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EA5 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EA7;
L_839EA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EA7u, 8u, 4u, 0x848734u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839EA7 JSL -> $848734 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9EAAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9EABu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848734u, 0x839EA7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839EAB;
L_839EAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EAB PHP
    cpu.push("PHP", hw);
    goto L_839EAC;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EABu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EAB PHP
    cpu.push("PHP", hw);
    goto L_839EAC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EABu,0x839EABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EACu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAC STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_839EAE;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EACu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAC STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_839EAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EACu,0x839EACu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EAEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EAEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xA4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EAE LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xA4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EAEu,0x839EAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB0 CMP
    cpu.compareA(0x2u);
    goto L_839EB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB0 CMP
    cpu.compareA(0x2u);
    goto L_839EB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB0u,0x839EB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB3 BEQ -> $839EBE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839EBE; }
    goto L_839EB5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB3u,0x839EB3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB5u, 5u, 3u, cpu.address("abs", 0x1BA6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EB8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB5u,0x839EB5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB8 LSR
    cpu.lsrA();
    goto L_839EB9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB8u,0x839EB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EB9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EB9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EB9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EB9 LSR
    cpu.lsrA();
    goto L_839EBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EB9u,0x839EB9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBA BCC -> $839EBE
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EBE; }
    goto L_839EBC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBAu,0x839EBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBCu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBCu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBC INC
    cpu.incMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_839EBE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBCu,0x839EBCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EBEu))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EBEu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EBE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EC0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EBEu,0x839EBEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC0 SEC
    cpu.setFlag('C', true);
    goto L_839EC1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC0u,0x839EC0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC1u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xE0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC1 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0xE0u), cpu.m8?8:16));
    goto L_839EC3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC1u,0x839EC1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC3 BCS -> $839EC6
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EC6; }
    goto L_839EC5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC3u,0x839EC3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC5 TDC
    cpu.tdc();
    goto L_839EC6;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC5u,0x839EC5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC6 TAY
    cpu.transfer("TAY");
    goto L_839EC7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC6u,0x839EC6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 1 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC7u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $839EC7 PLP
    cpu.pop("PLP", hw);
    goto L_839EC8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC7u,0x839EC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EC8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC8 LDA
    cpu.setA(0x2000u, 16);
    goto L_839ECB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EC8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EC8 LDA
    cpu.setA(0x2000u, 16);
    goto L_839ECB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EC8u,0x839EC8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_839ECD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_839ECD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECBu,0x839ECBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECD BCC -> $839EDB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839ECF;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECD BCC -> $839EDB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839ECF;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECDu,0x839ECDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ECFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECF LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_839ED1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ECFu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ECF LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x0u), cpu.m8?8:16);
    goto L_839ED1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9ECFu,0x839ECFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839ED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u,cpu,0x46u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED1u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED1 LSR
    cpu.lsrMem(hw, cpu.address("dp", 0x2u), cpu.m8?8:16);
    goto L_839ED3;
L_839ED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED3 BCS -> $839EDA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDA; }
    goto L_839ED5;
L_839ED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED5 CPY
    cpu.compareY(0x40u);
    goto L_839ED8;
L_839ED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9ED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9ED8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839ED8 BCS -> $839EDB
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839EDB; }
    goto L_839EDA;
L_839EDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDA LSR
    cpu.lsrA();
    goto L_839EDB;
L_839EDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDBu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x24u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDB LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x24u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDBu,0x839EDBu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EDDu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDD CPY
    cpu.compareY(0x3u);
    goto L_839EE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EDD CPY
    cpu.compareY(0x3u);
    goto L_839EE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9EDDu,0x839EDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839EE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE0u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE0 BEQ -> $839F01
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F01; }
    goto L_839EE2;
L_839EE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE2 CPY
    cpu.compareY(0x9u);
    goto L_839EE5;
L_839EE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE5 BEQ -> $839F06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F06; }
    goto L_839EE7;
L_839EE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EE7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EE7 CPY
    cpu.compareY(0xAu);
    goto L_839EEA;
L_839EEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEA BEQ -> $839F06
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F06; }
    goto L_839EEC;
L_839EEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEC CPY
    cpu.compareY(0x8u);
    goto L_839EEF;
L_839EEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EEF BCS -> $839F19
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839EF1;
L_839EF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF1u, 5u + 1u, 3u, cpu.address("absx", 0x1092u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF1 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1092u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839EF4;
L_839EF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF4 BEQ -> $839F13
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F13; }
    goto L_839EF6;
L_839EF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF6 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_839EF8;
L_839EF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x87u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EF8 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x87u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839EFA;
L_839EFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFA AND
    cpu.logicAnd(0x600u);
    goto L_839EFD;
L_839EFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFD ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839EFF;
L_839EFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9EFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9EFFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839EFF BRA -> $839F19
    goto L_839F19;
L_839F01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F01u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F01 LDA
    cpu.setA(0x3000u, 16);
    goto L_839F04;
L_839F04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F04u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F04 BRA -> $839F13
    goto L_839F13;
L_839F06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F06u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F06u, 5u + 1u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F06 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x10B8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839F09;
L_839F09:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F09u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F09u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F09 CPY
    cpu.compareY(0x2u);
    goto L_839F0C;
L_839F0C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F0C BEQ -> $839F19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839F0E;
L_839F0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F0Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F0E CPY
    cpu.compareY(0x5u);
    goto L_839F11;
L_839F11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F11u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F11 BEQ -> $839F19
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F19; }
    goto L_839F13;
L_839F13:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F13u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F13u, 5u, 3u, cpu.address("abs", 0x1B9Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F13 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1B9Fu), cpu.m8?8:16));
    goto L_839F16;
L_839F16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F16u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F16 AND
    cpu.logicAnd(0xFF00u);
    goto L_839F19;
L_839F19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F19u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F19 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_839F1B;
L_839F1B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F1B AND
    cpu.logicAnd(0xCFFFu);
    goto L_839F1E;
L_839F1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F1E ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_839F20;
L_839F20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F20u, 6u, 3u, cpu.address("absx", 0x022Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F20 STA
    hw.write(cpu.address("absx", 0x22Au), cpu.a, cpu.m8?8:16);
    goto L_839F23;
L_839F23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F23u, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F23 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F26;
L_839F26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F26u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F26 BEQ -> $839F3E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F3E; }
    goto L_839F28;
L_839F28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F28u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F28 LDA
    cpu.setA(0xFFF0u, 16);
    goto L_839F2B;
L_839F2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Bu, 5u + 1u, 3u, cpu.address("absx", 0x0022u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F2B LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x22u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_839F2E;
L_839F2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F2Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F2E CPY
    cpu.compareY(0xCu);
    goto L_839F31;
L_839F31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F31u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F31 BNE -> $839F34
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F34; }
    goto L_839F33;
L_839F33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F33 ASL
    cpu.aslA();
    goto L_839F34;
L_839F34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F34u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F34 CLC
    cpu.setFlag('C', false);
    goto L_839F35;
L_839F35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F35u, 5u + 1u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F35 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x216u), cpu.m8?8:16));
    goto L_839F38;
L_839F38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F38u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F38u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F38 BCS -> $839F3B
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_839F3B; }
    goto L_839F3A;
L_839F3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3A TDC
    cpu.tdc();
    goto L_839F3B;
L_839F3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Bu, 6u, 3u, cpu.address("absx", 0x0216u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3B STA
    hw.write(cpu.address("absx", 0x216u), cpu.a, cpu.m8?8:16);
    goto L_839F3E;
L_839F3E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F3Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F3Eu, 5u + 1u, 3u, cpu.address("absx", 0x10DCu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F3E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10DCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F41;
L_839F41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F41u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F41u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F41 BEQ -> $839F46
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F46; }
    goto L_839F43;
L_839F43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F43u, 9u, 3u, cpu.address("absx", 0x10DCu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F43 DEC
    cpu.decMem(hw, cpu.address("absx", 0x10DCu), cpu.m8?8:16);
    goto L_839F46;
L_839F46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F46u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F46 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F49;
L_839F49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F49u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F49 BEQ -> $839F58
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F58; }
    goto L_839F4B;
L_839F4B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu,cpu,0xDEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Bu, 9u, 3u, cpu.address("absx", 0x10BEu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F4B DEC
    cpu.decMem(hw, cpu.address("absx", 0x10BEu), cpu.m8?8:16);
    goto L_839F4E;
L_839F4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F4E BNE -> $839F58
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F58; }
    goto L_839F50;
L_839F50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F50u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F50u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F50 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F52;
L_839F52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F52u, 6u, 3u, cpu.address("absx", 0x1098u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F52 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_839F55;
L_839F55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F55u, 6u, 3u, cpu.address("absx", 0x10A2u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F55 STA
    hw.write(cpu.address("absx", 0x10A2u), cpu.a, cpu.m8?8:16);
    goto L_839F58;
L_839F58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F58u, 8u, 4u, 0x83CDCBu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839F58 JSL -> $83CDCB stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9F5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x83CDCBu, 0x839F58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839F5C;
L_839F5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,0x839F5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Cu, 5u + 1u, 3u, cpu.address("absx", 0x10C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F5C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F5F;
L_839F5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F5Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F5F BPL -> $839F64
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_839F64; }
    goto L_839F61;
L_839F61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F61u, 3u, 3u, cpu.address("abs", 0x9FACu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F61 JMP -> $839FAC
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0x9FACu),0x839F61u); return;
L_839F64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F64u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F64u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F64 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F66;
L_839F66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F66u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F66 LSR
    cpu.lsrA();
    goto L_839F67;
L_839F67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F67 BNE -> $839F7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F69;
L_839F69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F69u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F69u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F69 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F6B;
L_839F6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6B LSR
    cpu.lsrA();
    goto L_839F6C;
L_839F6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6C DEC
    cpu.decReg('A');
    goto L_839F6D;
L_839F6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6D BNE -> $839F7F
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F6F;
L_839F6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F6Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F6F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F71;
L_839F71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F71u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F71u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F71 CMP
    cpu.compareA(0x6u);
    goto L_839F74;
L_839F74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F74u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F74u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F74 BEQ -> $839F7F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F7F; }
    goto L_839F76;
L_839F76:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F76u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F76u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F76 LDA
    cpu.setA(0x400u, 16);
    goto L_839F79;
L_839F79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F79u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F79u, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F79 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x1BB0u), cpu.m8?8:16));
    goto L_839F7C;
L_839F7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Cu, 5u, 3u, cpu.address("abs", 0x1BB0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F7C STA
    hw.write(cpu.address("abs", 0x1BB0u), cpu.a, cpu.m8?8:16);
    goto L_839F7F;
L_839F7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F7Fu, 6u, 3u, cpu.address("abs", 0x9FE2u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839F7F JSR -> $839FE2 stack real
    { cpu.push16Value(hw,0x9F81u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9F82u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0x9FE2u), 0x839F7Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839F82;
L_839F82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F82u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F82u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F82 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F84;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F82u,0x839F82u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839F84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F84u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F84u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F84 CMP
    cpu.compareA(0x2u);
    goto L_839F87;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9F84u,0x839F84u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_839F87:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F87u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F87u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F87 BNE -> $839F8E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_839F8E; }
    goto L_839F89;
L_839F89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F89u, 5u, 3u, cpu.address("abs", 0x1BA8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F89 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BA8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F8C;
L_839F8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F8C BMI -> $839F97
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839F97; }
    goto L_839F8E;
L_839F8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F8Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F8E SEP
    cpu.sep(0x20u);
    goto L_839F90;
L_839F90:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F90u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F90u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F90 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839F92;
L_839F92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F92u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F92u, 5u, 3u, cpu.address("absx", 0x0226u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F92 STA
    hw.write(cpu.address("absx", 0x226u), cpu.a, cpu.m8?8:16);
    goto L_839F95;
L_839F95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F95u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F95u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F95 REP
    cpu.rep(0x20u);
    goto L_839F97;
L_839F97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F97u, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F97 INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_839F9A;
L_839F9A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Au, 8u, 3u, cpu.address("abs", 0x1BA0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9A INC
    cpu.incMem(hw, cpu.address("abs", 0x1BA0u), cpu.m8?8:16);
    goto L_839F9D;
L_839F9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Du,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9D TXA
    cpu.transfer("TXA");
    goto L_839F9E;
L_839F9E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9E CLC
    cpu.setFlag('C', false);
    goto L_839F9F;
L_839F9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9F9Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9F9Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839F9F ADC
    cpu.adc(0x50u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9FA2u,0x839F9Fu); return;
}

void sub_83DC2B_E0M0X0C1_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E62Fu: goto L_83E62F;
    case 0x83E631u: goto L_83E631;
    case 0x83E632u: goto L_83E632;
    case 0x83E633u: goto L_83E633;
    case 0x83E635u: goto L_83E635;
    case 0x83E637u: goto L_83E637;
    case 0x83E638u: goto L_83E638;
    case 0x83E63Au: goto L_83E63A;
    case 0x83E63Cu: goto L_83E63C;
    case 0x83E63Fu: goto L_83E63F;
    case 0x83E641u: goto L_83E641;
    case 0x83E642u: goto L_83E642;
    case 0x83E644u: goto L_83E644;
    case 0x83E647u: goto L_83E647;
    case 0x83E649u: goto L_83E649;
    case 0x83E64Au: goto L_83E64A;
    case 0x83E64Cu: goto L_83E64C;
    case 0x83E64Eu: goto L_83E64E;
    case 0x83E64Fu: goto L_83E64F;
    case 0x83E650u: goto L_83E650;
    case 0x83E652u: goto L_83E652;
    case 0x83E654u: goto L_83E654;
    case 0x83E655u: goto L_83E655;
    case 0x83E657u: goto L_83E657;
    case 0x83E659u: goto L_83E659;
    case 0x83E65Cu: goto L_83E65C;
    case 0x83E65Eu: goto L_83E65E;
    case 0x83E65Fu: goto L_83E65F;
    case 0x83E661u: goto L_83E661;
    case 0x83E664u: goto L_83E664;
    case 0x83E666u: goto L_83E666;
    case 0x83E667u: goto L_83E667;
    case 0x83E668u: goto L_83E668;
    case 0x83E66Au: goto L_83E66A;
    case 0x83E66Du: goto L_83E66D;
    case 0x83E670u: goto L_83E670;
    case 0x83E673u: goto L_83E673;
    case 0x83E675u: goto L_83E675;
    case 0x83E677u: goto L_83E677;
    case 0x83E679u: goto L_83E679;
    case 0x83E67Bu: goto L_83E67B;
    case 0x83E67Du: goto L_83E67D;
    case 0x83E67Eu: goto L_83E67E;
    case 0x83E681u: goto L_83E681;
    case 0x83E683u: goto L_83E683;
    case 0x83E684u: goto L_83E684;
    case 0x83E686u: goto L_83E686;
    case 0x83E688u: goto L_83E688;
    case 0x83E68Au: goto L_83E68A;
    case 0x83E68Du: goto L_83E68D;
    case 0x83E68Fu: goto L_83E68F;
    case 0x83E690u: goto L_83E690;
    case 0x83E692u: goto L_83E692;
    case 0x83E695u: goto L_83E695;
    case 0x83E698u: goto L_83E698;
    case 0x83E69Au: goto L_83E69A;
    case 0x83E69Cu: goto L_83E69C;
    case 0x83E69Fu: goto L_83E69F;
    case 0x83E6A1u: goto L_83E6A1;
    case 0x83E6A5u: goto L_83E6A5;
    case 0x83E6A8u: goto L_83E6A8;
    case 0x83E6AAu: goto L_83E6AA;
    case 0x83E6ACu: goto L_83E6AC;
    case 0x83E6AEu: goto L_83E6AE;
    case 0x83E6B0u: goto L_83E6B0;
    case 0x83E6B1u: goto L_83E6B1;
    case 0x83E6B2u: goto L_83E6B2;
    case 0x83E6B4u: goto L_83E6B4;
    case 0x83E6B6u: goto L_83E6B6;
    case 0x83E6B7u: goto L_83E6B7;
    case 0x83E6B9u: goto L_83E6B9;
    case 0x83E6BBu: goto L_83E6BB;
    case 0x83E6BEu: goto L_83E6BE;
    case 0x83E6C0u: goto L_83E6C0;
    case 0x83E6C1u: goto L_83E6C1;
    case 0x83E6C3u: goto L_83E6C3;
    case 0x83E6C6u: goto L_83E6C6;
    case 0x83E6C8u: goto L_83E6C8;
    case 0x83E6C9u: goto L_83E6C9;
    case 0x83E6CBu: goto L_83E6CB;
    case 0x83E6CDu: goto L_83E6CD;
    case 0x83E6CEu: goto L_83E6CE;
    case 0x83E6CFu: goto L_83E6CF;
    case 0x83E6D1u: goto L_83E6D1;
    case 0x83E6D3u: goto L_83E6D3;
    case 0x83E6D4u: goto L_83E6D4;
    case 0x83E6D6u: goto L_83E6D6;
    case 0x83E6D8u: goto L_83E6D8;
    case 0x83E6DBu: goto L_83E6DB;
    case 0x83E6DDu: goto L_83E6DD;
    case 0x83E6DEu: goto L_83E6DE;
    case 0x83E6E0u: goto L_83E6E0;
    case 0x83E6E3u: goto L_83E6E3;
    case 0x83E6E5u: goto L_83E6E5;
    case 0x83E6E6u: goto L_83E6E6;
    case 0x83E6E7u: goto L_83E6E7;
    case 0x83E6EAu: goto L_83E6EA;
    case 0x83E6EDu: goto L_83E6ED;
    case 0x83E6EFu: goto L_83E6EF;
    case 0x83E6F1u: goto L_83E6F1;
    case 0x83E6F3u: goto L_83E6F3;
    case 0x83E6F5u: goto L_83E6F5;
    case 0x83E6F6u: goto L_83E6F6;
    case 0x83E6F9u: goto L_83E6F9;
    case 0x83E6FBu: goto L_83E6FB;
    case 0x83E6FCu: goto L_83E6FC;
    case 0x83E6FEu: goto L_83E6FE;
    case 0x83E700u: goto L_83E700;
    case 0x83E702u: goto L_83E702;
    case 0x83E705u: goto L_83E705;
    case 0x83E707u: goto L_83E707;
    case 0x83E708u: goto L_83E708;
    case 0x83E70Au: goto L_83E70A;
    case 0x83E70Du: goto L_83E70D;
    case 0x83E710u: goto L_83E710;
    case 0x83E712u: goto L_83E712;
    case 0x83E714u: goto L_83E714;
    case 0x83E717u: goto L_83E717;
    case 0x83E719u: goto L_83E719;
    case 0x83E71Du: goto L_83E71D;
    case 0x83E720u: goto L_83E720;
    case 0x83E722u: goto L_83E722;
    case 0x83E724u: goto L_83E724;
    case 0x83E726u: goto L_83E726;
    case 0x83E728u: goto L_83E728;
    case 0x83E729u: goto L_83E729;
    case 0x83E72Au: goto L_83E72A;
    case 0x83E72Cu: goto L_83E72C;
    case 0x83E72Eu: goto L_83E72E;
    case 0x83E72Fu: goto L_83E72F;
    case 0x83E731u: goto L_83E731;
    case 0x83E733u: goto L_83E733;
    case 0x83E736u: goto L_83E736;
    case 0x83E738u: goto L_83E738;
    case 0x83E739u: goto L_83E739;
    case 0x83E73Bu: goto L_83E73B;
    case 0x83E73Eu: goto L_83E73E;
    case 0x83E740u: goto L_83E740;
    case 0x83E741u: goto L_83E741;
    case 0x83E743u: goto L_83E743;
    case 0x83E745u: goto L_83E745;
    case 0x83E746u: goto L_83E746;
    case 0x83E747u: goto L_83E747;
    case 0x83E749u: goto L_83E749;
    case 0x83E74Bu: goto L_83E74B;
    case 0x83E74Cu: goto L_83E74C;
    case 0x83E74Eu: goto L_83E74E;
    case 0x83E750u: goto L_83E750;
    case 0x83E753u: goto L_83E753;
    case 0x83E755u: goto L_83E755;
    case 0x83E756u: goto L_83E756;
    case 0x83E758u: goto L_83E758;
    case 0x83E75Bu: goto L_83E75B;
    case 0x83E75Du: goto L_83E75D;
    case 0x83E75Eu: goto L_83E75E;
    case 0x83E75Fu: goto L_83E75F;
    case 0x83E761u: goto L_83E761;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E62F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E631;
L_83E631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE631u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE631u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E631 TAY
    cpu.transfer("TAY");
    goto L_83E632;
L_83E632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE632u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE632u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E632 SEC
    cpu.setFlag('C', true);
    goto L_83E633;
L_83E633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE633u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE633u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E633 SBC
    cpu.sbc(0x20u);
    goto L_83E635;
L_83E635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE635u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE635u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E635 CMP
    cpu.compareA(0x80u);
    goto L_83E637;
L_83E637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE637u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE637u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E637 TYA
    cpu.transfer("TYA");
    goto L_83E638;
L_83E638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE638u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE638u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E638 BCS -> $83E642
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E642; }
    goto L_83E63A;
L_83E63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63A SBC
    cpu.sbc(0x3Fu);
    goto L_83E63C;
L_83E63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E63F;
L_83E63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63F REP
    cpu.rep(0x20u);
    goto L_83E641;
L_83E641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE641u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE641u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E641 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E641u);return;} hw.unresolvedReturn(0x83E641u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E642 ADC
    cpu.adc(0x3Fu);
    goto L_83E644;
L_83E644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE644u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE644u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E644 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E647;
L_83E647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE647u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E647 REP
    cpu.rep(0x20u);
    goto L_83E649;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E647 REP
    cpu.rep(0x20u);
    goto L_83E649;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE647u,0x83E647u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E649 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E649u);return;} hw.unresolvedReturn(0x83E649u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64A SEP
    cpu.sep(0x20u);
    goto L_83E64C;
L_83E64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E64E;
L_83E64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64E TAY
    cpu.transfer("TAY");
    goto L_83E64F;
L_83E64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64F SEC
    cpu.setFlag('C', true);
    goto L_83E650;
L_83E650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE650u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE650u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E650 SBC
    cpu.sbc(0x20u);
    goto L_83E652;
L_83E652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E652 CMP
    cpu.compareA(0x80u);
    goto L_83E654;
L_83E654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E654 TYA
    cpu.transfer("TYA");
    goto L_83E655;
L_83E655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE655u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E655 BCS -> $83E65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E65F; }
    goto L_83E657;
L_83E657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE657u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E657 ADC
    cpu.adc(0x40u);
    goto L_83E659;
L_83E659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE659u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE659u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E659 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E65C;
L_83E65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E65C REP
    cpu.rep(0x20u);
    goto L_83E65E;
L_83E65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E65E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E65Eu);return;} hw.unresolvedReturn(0x83E65Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E65F SBC
    cpu.sbc(0x40u);
    goto L_83E661;
L_83E661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE661u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE661u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E661 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E664;
L_83E664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE664u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE664u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E664 REP
    cpu.rep(0x20u);
    goto L_83E666;
L_83E666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE666u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE666u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E666 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E666u);return;} hw.unresolvedReturn(0x83E666u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE667u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE667u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E667 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E667u);return;} hw.unresolvedReturn(0x83E667u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE668u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE668u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E668 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E66A;
L_83E66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Au, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E66A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E66D;
L_83E66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E66D ADC
    cpu.adc(0x14u);
    goto L_83E670;
L_83E670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE670u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE670u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E670 CMP
    cpu.compareA(0x28u);
    goto L_83E673;
L_83E673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE673u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE673u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E673 BCC -> $83E6EF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6EF; }
    goto L_83E675;
L_83E675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE675u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE675u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E675 BMI -> $83E6E7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E6E7; }
    goto L_83E677;
L_83E677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E677 SEP
    cpu.sep(0x20u);
    goto L_83E679;
L_83E679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E679 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E67B;
L_83E67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67B AND
    cpu.logicAnd(0xF0u);
    goto L_83E67D;
L_83E67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67D SEC
    cpu.setFlag('C', true);
    goto L_83E67E;
L_83E67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Eu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67E SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E681;
L_83E681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E681 BEQ -> $83E690
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E690; }
    goto L_83E683;
L_83E683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE683u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE683u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E683 ASL
    cpu.aslA();
    goto L_83E684;
L_83E684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E684 LDA
    cpu.setA(0x82u, 8);
    goto L_83E686;
L_83E686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E686 BCC -> $83E68A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E68A; }
    goto L_83E688;
L_83E688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE688u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E688 LDA
    cpu.setA(0x81u, 8);
    goto L_83E68A;
L_83E68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E68A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E68D;
L_83E68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E68D REP
    cpu.rep(0x20u);
    goto L_83E68F;
L_83E68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E68F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E68Fu);return;} hw.unresolvedReturn(0x83E68Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E690 LDA
    cpu.setA(0x80u, 8);
    goto L_83E692;
L_83E692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E692 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E695;
L_83E695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE695u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE695u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E695 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E698;
L_83E698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE698u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE698u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E698 REP
    cpu.rep(0x20u);
    goto L_83E69A;
L_83E69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69A BEQ -> $83E6E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E6E6; }
    goto L_83E69C;
L_83E69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E69F;
L_83E69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69F BNE -> $83E6C6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E6C6; }
    goto L_83E6A1;
L_83E6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A1u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6A1 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE6A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE6A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E6A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E6A5;
L_83E6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6A5u,0x83E6A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6A8;
L_83E6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A8u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6A8 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E6AA;
L_83E6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AA BMI -> $83E6C9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E6C9; }
    goto L_83E6AC;
L_83E6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ACu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AC SEP
    cpu.sep(0x20u);
    goto L_83E6AE;
L_83E6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6B0;
L_83E6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B0 TAY
    cpu.transfer("TAY");
    goto L_83E6B1;
L_83E6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B1 SEC
    cpu.setFlag('C', true);
    goto L_83E6B2;
L_83E6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B2 SBC
    cpu.sbc(0x20u);
    goto L_83E6B4;
L_83E6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B4 CMP
    cpu.compareA(0x80u);
    goto L_83E6B6;
L_83E6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B6 TYA
    cpu.transfer("TYA");
    goto L_83E6B7;
L_83E6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B7 BCS -> $83E6C1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6C1; }
    goto L_83E6B9;
L_83E6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B9 SBC
    cpu.sbc(0x3Fu);
    goto L_83E6BB;
L_83E6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BBu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6BB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6BE;
L_83E6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6BE REP
    cpu.rep(0x20u);
    goto L_83E6C0;
L_83E6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6C0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6C0u);return;} hw.unresolvedReturn(0x83E6C0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C1 ADC
    cpu.adc(0x3Fu);
    goto L_83E6C3;
L_83E6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C3u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C3 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6C6;
L_83E6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C6 REP
    cpu.rep(0x20u);
    goto L_83E6C8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C6 REP
    cpu.rep(0x20u);
    goto L_83E6C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6C6u,0x83E6C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6C8u);return;} hw.unresolvedReturn(0x83E6C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C9 SEP
    cpu.sep(0x20u);
    goto L_83E6CB;
L_83E6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6CD;
L_83E6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CD TAY
    cpu.transfer("TAY");
    goto L_83E6CE;
L_83E6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CE SEC
    cpu.setFlag('C', true);
    goto L_83E6CF;
L_83E6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CF SBC
    cpu.sbc(0x20u);
    goto L_83E6D1;
L_83E6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D1 CMP
    cpu.compareA(0x80u);
    goto L_83E6D3;
L_83E6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D3 TYA
    cpu.transfer("TYA");
    goto L_83E6D4;
L_83E6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D4 BCS -> $83E6DE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6DE; }
    goto L_83E6D6;
L_83E6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D6 ADC
    cpu.adc(0x40u);
    goto L_83E6D8;
L_83E6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6DB;
L_83E6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6DB REP
    cpu.rep(0x20u);
    goto L_83E6DD;
L_83E6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6DDu);return;} hw.unresolvedReturn(0x83E6DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6DE SBC
    cpu.sbc(0x40u);
    goto L_83E6E0;
L_83E6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E0u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E0 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6E3;
L_83E6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E3 REP
    cpu.rep(0x20u);
    goto L_83E6E5;
L_83E6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6E5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6E5u);return;} hw.unresolvedReturn(0x83E6E5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6E6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6E6u);return;} hw.unresolvedReturn(0x83E6E6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E7u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6EA;
L_83E6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6EA CMP
    cpu.compareA(0x500u);
    goto L_83E6ED;
L_83E6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6ED BMI -> $83E75F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E75F; }
    goto L_83E6EF;
L_83E6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6EF SEP
    cpu.sep(0x20u);
    goto L_83E6F1;
L_83E6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6F3;
L_83E6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F3 AND
    cpu.logicAnd(0xF0u);
    goto L_83E6F5;
L_83E6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F5 SEC
    cpu.setFlag('C', true);
    goto L_83E6F6;
L_83E6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F6 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E6F9;
L_83E6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F9 BEQ -> $83E708
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E708; }
    goto L_83E6FB;
L_83E6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FB ASL
    cpu.aslA();
    goto L_83E6FC;
L_83E6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FC LDA
    cpu.setA(0x82u, 8);
    goto L_83E6FE;
L_83E6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FE BCC -> $83E702
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E702; }
    goto L_83E700;
L_83E700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE700u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE700u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E700 LDA
    cpu.setA(0x81u, 8);
    goto L_83E702;
L_83E702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E702 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E705;
L_83E705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E705 REP
    cpu.rep(0x20u);
    goto L_83E707;
L_83E707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E707 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E707u);return;} hw.unresolvedReturn(0x83E707u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E708 LDA
    cpu.setA(0x80u, 8);
    goto L_83E70A;
L_83E70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E70D;
L_83E70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E710;
L_83E710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E710 REP
    cpu.rep(0x20u);
    goto L_83E712;
L_83E712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E712 BEQ -> $83E75E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E75E; }
    goto L_83E714;
L_83E714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E714 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E717;
L_83E717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E717 BNE -> $83E73E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E73E; }
    goto L_83E719;
L_83E719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E719 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE71Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE71Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E719u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E71D;
L_83E71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE71Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE71Du,0x83E71Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E71D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E720;
L_83E720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E720 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E722;
L_83E722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E722 BMI -> $83E741
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E741; }
    goto L_83E724;
L_83E724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E724 SEP
    cpu.sep(0x20u);
    goto L_83E726;
L_83E726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E728;
L_83E728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E728 TAY
    cpu.transfer("TAY");
    goto L_83E729;
L_83E729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E729 SEC
    cpu.setFlag('C', true);
    goto L_83E72A;
L_83E72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72A SBC
    cpu.sbc(0x20u);
    goto L_83E72C;
L_83E72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72C CMP
    cpu.compareA(0x80u);
    goto L_83E72E;
L_83E72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72E TYA
    cpu.transfer("TYA");
    goto L_83E72F;
L_83E72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72F BCS -> $83E739
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E739; }
    goto L_83E731;
L_83E731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E731 SBC
    cpu.sbc(0x3Fu);
    goto L_83E733;
L_83E733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E733 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E736;
L_83E736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E736 REP
    cpu.rep(0x20u);
    goto L_83E738;
L_83E738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E738 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E738u);return;} hw.unresolvedReturn(0x83E738u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E739 ADC
    cpu.adc(0x3Fu);
    goto L_83E73B;
L_83E73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E73E;
L_83E73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE73Eu,0x83E73Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E740 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E740u);return;} hw.unresolvedReturn(0x83E740u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E741 SEP
    cpu.sep(0x20u);
    goto L_83E743;
L_83E743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E743 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E745;
L_83E745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E745 TAY
    cpu.transfer("TAY");
    goto L_83E746;
L_83E746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E746 SEC
    cpu.setFlag('C', true);
    goto L_83E747;
L_83E747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E747 SBC
    cpu.sbc(0x20u);
    goto L_83E749;
L_83E749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E749 CMP
    cpu.compareA(0x80u);
    goto L_83E74B;
L_83E74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74B TYA
    cpu.transfer("TYA");
    goto L_83E74C;
L_83E74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74C BCS -> $83E756
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E756; }
    goto L_83E74E;
L_83E74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74E ADC
    cpu.adc(0x40u);
    goto L_83E750;
L_83E750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E750 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E753;
L_83E753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E753 REP
    cpu.rep(0x20u);
    goto L_83E755;
L_83E755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E755 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E755u);return;} hw.unresolvedReturn(0x83E755u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E756 SBC
    cpu.sbc(0x40u);
    goto L_83E758;
L_83E758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E758 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E75B;
L_83E75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75B REP
    cpu.rep(0x20u);
    goto L_83E75D;
L_83E75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Du);return;} hw.unresolvedReturn(0x83E75Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Eu);return;} hw.unresolvedReturn(0x83E75Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75F SEP
    cpu.sep(0x20u);
    goto L_83E761;
L_83E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E761 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE763u,0x83E761u); return;
}

void sub_83DC2B_E0M0X0CQ_part8(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83E62Fu: goto L_83E62F;
    case 0x83E631u: goto L_83E631;
    case 0x83E632u: goto L_83E632;
    case 0x83E633u: goto L_83E633;
    case 0x83E635u: goto L_83E635;
    case 0x83E637u: goto L_83E637;
    case 0x83E638u: goto L_83E638;
    case 0x83E63Au: goto L_83E63A;
    case 0x83E63Cu: goto L_83E63C;
    case 0x83E63Fu: goto L_83E63F;
    case 0x83E641u: goto L_83E641;
    case 0x83E642u: goto L_83E642;
    case 0x83E644u: goto L_83E644;
    case 0x83E647u: goto L_83E647;
    case 0x83E649u: goto L_83E649;
    case 0x83E64Au: goto L_83E64A;
    case 0x83E64Cu: goto L_83E64C;
    case 0x83E64Eu: goto L_83E64E;
    case 0x83E64Fu: goto L_83E64F;
    case 0x83E650u: goto L_83E650;
    case 0x83E652u: goto L_83E652;
    case 0x83E654u: goto L_83E654;
    case 0x83E655u: goto L_83E655;
    case 0x83E657u: goto L_83E657;
    case 0x83E659u: goto L_83E659;
    case 0x83E65Cu: goto L_83E65C;
    case 0x83E65Eu: goto L_83E65E;
    case 0x83E65Fu: goto L_83E65F;
    case 0x83E661u: goto L_83E661;
    case 0x83E664u: goto L_83E664;
    case 0x83E666u: goto L_83E666;
    case 0x83E667u: goto L_83E667;
    case 0x83E668u: goto L_83E668;
    case 0x83E66Au: goto L_83E66A;
    case 0x83E66Du: goto L_83E66D;
    case 0x83E670u: goto L_83E670;
    case 0x83E673u: goto L_83E673;
    case 0x83E675u: goto L_83E675;
    case 0x83E677u: goto L_83E677;
    case 0x83E679u: goto L_83E679;
    case 0x83E67Bu: goto L_83E67B;
    case 0x83E67Du: goto L_83E67D;
    case 0x83E67Eu: goto L_83E67E;
    case 0x83E681u: goto L_83E681;
    case 0x83E683u: goto L_83E683;
    case 0x83E684u: goto L_83E684;
    case 0x83E686u: goto L_83E686;
    case 0x83E688u: goto L_83E688;
    case 0x83E68Au: goto L_83E68A;
    case 0x83E68Du: goto L_83E68D;
    case 0x83E68Fu: goto L_83E68F;
    case 0x83E690u: goto L_83E690;
    case 0x83E692u: goto L_83E692;
    case 0x83E695u: goto L_83E695;
    case 0x83E698u: goto L_83E698;
    case 0x83E69Au: goto L_83E69A;
    case 0x83E69Cu: goto L_83E69C;
    case 0x83E69Fu: goto L_83E69F;
    case 0x83E6A1u: goto L_83E6A1;
    case 0x83E6A5u: goto L_83E6A5;
    case 0x83E6A8u: goto L_83E6A8;
    case 0x83E6AAu: goto L_83E6AA;
    case 0x83E6ACu: goto L_83E6AC;
    case 0x83E6AEu: goto L_83E6AE;
    case 0x83E6B0u: goto L_83E6B0;
    case 0x83E6B1u: goto L_83E6B1;
    case 0x83E6B2u: goto L_83E6B2;
    case 0x83E6B4u: goto L_83E6B4;
    case 0x83E6B6u: goto L_83E6B6;
    case 0x83E6B7u: goto L_83E6B7;
    case 0x83E6B9u: goto L_83E6B9;
    case 0x83E6BBu: goto L_83E6BB;
    case 0x83E6BEu: goto L_83E6BE;
    case 0x83E6C0u: goto L_83E6C0;
    case 0x83E6C1u: goto L_83E6C1;
    case 0x83E6C3u: goto L_83E6C3;
    case 0x83E6C6u: goto L_83E6C6;
    case 0x83E6C8u: goto L_83E6C8;
    case 0x83E6C9u: goto L_83E6C9;
    case 0x83E6CBu: goto L_83E6CB;
    case 0x83E6CDu: goto L_83E6CD;
    case 0x83E6CEu: goto L_83E6CE;
    case 0x83E6CFu: goto L_83E6CF;
    case 0x83E6D1u: goto L_83E6D1;
    case 0x83E6D3u: goto L_83E6D3;
    case 0x83E6D4u: goto L_83E6D4;
    case 0x83E6D6u: goto L_83E6D6;
    case 0x83E6D8u: goto L_83E6D8;
    case 0x83E6DBu: goto L_83E6DB;
    case 0x83E6DDu: goto L_83E6DD;
    case 0x83E6DEu: goto L_83E6DE;
    case 0x83E6E0u: goto L_83E6E0;
    case 0x83E6E3u: goto L_83E6E3;
    case 0x83E6E5u: goto L_83E6E5;
    case 0x83E6E6u: goto L_83E6E6;
    case 0x83E6E7u: goto L_83E6E7;
    case 0x83E6EAu: goto L_83E6EA;
    case 0x83E6EDu: goto L_83E6ED;
    case 0x83E6EFu: goto L_83E6EF;
    case 0x83E6F1u: goto L_83E6F1;
    case 0x83E6F3u: goto L_83E6F3;
    case 0x83E6F5u: goto L_83E6F5;
    case 0x83E6F6u: goto L_83E6F6;
    case 0x83E6F9u: goto L_83E6F9;
    case 0x83E6FBu: goto L_83E6FB;
    case 0x83E6FCu: goto L_83E6FC;
    case 0x83E6FEu: goto L_83E6FE;
    case 0x83E700u: goto L_83E700;
    case 0x83E702u: goto L_83E702;
    case 0x83E705u: goto L_83E705;
    case 0x83E707u: goto L_83E707;
    case 0x83E708u: goto L_83E708;
    case 0x83E70Au: goto L_83E70A;
    case 0x83E70Du: goto L_83E70D;
    case 0x83E710u: goto L_83E710;
    case 0x83E712u: goto L_83E712;
    case 0x83E714u: goto L_83E714;
    case 0x83E717u: goto L_83E717;
    case 0x83E719u: goto L_83E719;
    case 0x83E71Du: goto L_83E71D;
    case 0x83E720u: goto L_83E720;
    case 0x83E722u: goto L_83E722;
    case 0x83E724u: goto L_83E724;
    case 0x83E726u: goto L_83E726;
    case 0x83E728u: goto L_83E728;
    case 0x83E729u: goto L_83E729;
    case 0x83E72Au: goto L_83E72A;
    case 0x83E72Cu: goto L_83E72C;
    case 0x83E72Eu: goto L_83E72E;
    case 0x83E72Fu: goto L_83E72F;
    case 0x83E731u: goto L_83E731;
    case 0x83E733u: goto L_83E733;
    case 0x83E736u: goto L_83E736;
    case 0x83E738u: goto L_83E738;
    case 0x83E739u: goto L_83E739;
    case 0x83E73Bu: goto L_83E73B;
    case 0x83E73Eu: goto L_83E73E;
    case 0x83E740u: goto L_83E740;
    case 0x83E741u: goto L_83E741;
    case 0x83E743u: goto L_83E743;
    case 0x83E745u: goto L_83E745;
    case 0x83E746u: goto L_83E746;
    case 0x83E747u: goto L_83E747;
    case 0x83E749u: goto L_83E749;
    case 0x83E74Bu: goto L_83E74B;
    case 0x83E74Cu: goto L_83E74C;
    case 0x83E74Eu: goto L_83E74E;
    case 0x83E750u: goto L_83E750;
    case 0x83E753u: goto L_83E753;
    case 0x83E755u: goto L_83E755;
    case 0x83E756u: goto L_83E756;
    case 0x83E758u: goto L_83E758;
    case 0x83E75Bu: goto L_83E75B;
    case 0x83E75Du: goto L_83E75D;
    case 0x83E75Eu: goto L_83E75E;
    case 0x83E75Fu: goto L_83E75F;
    case 0x83E761u: goto L_83E761;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83E62F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE62Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE62Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E62F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E631;
L_83E631:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE631u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE631u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE631u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E631 TAY
    cpu.transfer("TAY");
    goto L_83E632;
L_83E632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE632u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE632u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E632 SEC
    cpu.setFlag('C', true);
    goto L_83E633;
L_83E633:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE633u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE633u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE633u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E633 SBC
    cpu.sbc(0x20u);
    goto L_83E635;
L_83E635:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE635u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE635u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE635u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E635 CMP
    cpu.compareA(0x80u);
    goto L_83E637;
L_83E637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE637u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE637u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E637 TYA
    cpu.transfer("TYA");
    goto L_83E638;
L_83E638:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE638u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE638u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE638u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E638 BCS -> $83E642
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E642; }
    goto L_83E63A;
L_83E63A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63A SBC
    cpu.sbc(0x3Fu);
    goto L_83E63C;
L_83E63C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Cu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63C STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E63F;
L_83E63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE63Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E63F REP
    cpu.rep(0x20u);
    goto L_83E641;
L_83E641:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE641u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE641u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE641u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E641 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E641u);return;} hw.unresolvedReturn(0x83E641u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE642u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E642 ADC
    cpu.adc(0x3Fu);
    goto L_83E644;
L_83E644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE644u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE644u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E644 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E647;
L_83E647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE647u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E647 REP
    cpu.rep(0x20u);
    goto L_83E649;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE647u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E647 REP
    cpu.rep(0x20u);
    goto L_83E649;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE647u,0x83E647u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE649u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E649 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E649u);return;} hw.unresolvedReturn(0x83E649u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Au,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64A SEP
    cpu.sep(0x20u);
    goto L_83E64C;
L_83E64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64C LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E64E;
L_83E64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64E TAY
    cpu.transfer("TAY");
    goto L_83E64F;
L_83E64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE64Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E64F SEC
    cpu.setFlag('C', true);
    goto L_83E650;
L_83E650:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE650u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE650u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE650u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E650 SBC
    cpu.sbc(0x20u);
    goto L_83E652;
L_83E652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE652u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E652 CMP
    cpu.compareA(0x80u);
    goto L_83E654;
L_83E654:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE654u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE654u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E654 TYA
    cpu.transfer("TYA");
    goto L_83E655;
L_83E655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE655u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE655u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E655 BCS -> $83E65F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E65F; }
    goto L_83E657;
L_83E657:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE657u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE657u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE657u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E657 ADC
    cpu.adc(0x40u);
    goto L_83E659;
L_83E659:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE659u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE659u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE659u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E659 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E65C;
L_83E65C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Cu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E65C REP
    cpu.rep(0x20u);
    goto L_83E65E;
L_83E65E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E65E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E65Eu);return;} hw.unresolvedReturn(0x83E65Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E65F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE65Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Fu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE65Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E65F SBC
    cpu.sbc(0x40u);
    goto L_83E661;
L_83E661:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE661u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE661u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE661u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E661 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E664;
L_83E664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE664u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE664u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E664 REP
    cpu.rep(0x20u);
    goto L_83E666;
L_83E666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE666u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE666u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E666 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E666u);return;} hw.unresolvedReturn(0x83E666u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E667:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE667u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE667u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE667u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E667 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E667u);return;} hw.unresolvedReturn(0x83E667u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E668:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE668u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE668u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE668u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E668 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E66A;
L_83E66A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE66Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Au,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Au, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E66A SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83E66D;
L_83E66D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE66Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Du,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE66Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E66D ADC
    cpu.adc(0x14u);
    goto L_83E670;
L_83E670:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE670u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE670u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE670u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E670 CMP
    cpu.compareA(0x28u);
    goto L_83E673;
L_83E673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE673u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE673u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E673 BCC -> $83E6EF
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6EF; }
    goto L_83E675;
L_83E675:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE675u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE675u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE675u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E675 BMI -> $83E6E7
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E6E7; }
    goto L_83E677;
L_83E677:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE677u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE677u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E677 SEP
    cpu.sep(0x20u);
    goto L_83E679;
L_83E679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE679u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E679 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E67B;
L_83E67B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67B AND
    cpu.logicAnd(0xF0u);
    goto L_83E67D;
L_83E67D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67D SEC
    cpu.setFlag('C', true);
    goto L_83E67E;
L_83E67E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE67Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Eu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE67Eu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E67E SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83E681;
L_83E681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE681u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E681 BEQ -> $83E690
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E690; }
    goto L_83E683;
L_83E683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE683u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE683u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E683 ASL
    cpu.aslA();
    goto L_83E684;
L_83E684:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE684u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE684u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E684 LDA
    cpu.setA(0x82u, 8);
    goto L_83E686;
L_83E686:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE686u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE686u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E686 BCC -> $83E68A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E68A; }
    goto L_83E688;
L_83E688:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE688u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE688u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE688u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E688 LDA
    cpu.setA(0x81u, 8);
    goto L_83E68A;
L_83E68A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E68A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E68D;
L_83E68D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E68D REP
    cpu.rep(0x20u);
    goto L_83E68F;
L_83E68F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE68Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE68Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E68F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E68Fu);return;} hw.unresolvedReturn(0x83E68Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE690u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E690 LDA
    cpu.setA(0x80u, 8);
    goto L_83E692;
L_83E692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE692u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E692 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E695;
L_83E695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE695u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE695u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E695 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E698;
L_83E698:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE698u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE698u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE698u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E698 REP
    cpu.rep(0x20u);
    goto L_83E69A;
L_83E69A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69A BEQ -> $83E6E6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E6E6; }
    goto L_83E69C;
L_83E69C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Cu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69C LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E69F;
L_83E69F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE69Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE69Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E69F BNE -> $83E6C6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E6C6; }
    goto L_83E6A1;
L_83E6A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A1u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A1u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6A1 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE6A4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE6A5u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E6A1u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E6A5;
L_83E6A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A5u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6A5u,0x83E6A5u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A5u, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6A5 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6A8;
L_83E6A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A8u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6A8u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6A8 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E6AA;
L_83E6AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AAu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AA BMI -> $83E6C9
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E6C9; }
    goto L_83E6AC;
L_83E6AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ACu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6ACu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AC SEP
    cpu.sep(0x20u);
    goto L_83E6AE;
L_83E6AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6AEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6AE LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6B0;
L_83E6B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B0 TAY
    cpu.transfer("TAY");
    goto L_83E6B1;
L_83E6B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B1u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B1 SEC
    cpu.setFlag('C', true);
    goto L_83E6B2;
L_83E6B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B2 SBC
    cpu.sbc(0x20u);
    goto L_83E6B4;
L_83E6B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B4 CMP
    cpu.compareA(0x80u);
    goto L_83E6B6;
L_83E6B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B6u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B6 TYA
    cpu.transfer("TYA");
    goto L_83E6B7;
L_83E6B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B7 BCS -> $83E6C1
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6C1; }
    goto L_83E6B9;
L_83E6B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B9u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6B9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6B9 SBC
    cpu.sbc(0x3Fu);
    goto L_83E6BB;
L_83E6BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BBu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BBu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6BB STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6BE;
L_83E6BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6BEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6BE REP
    cpu.rep(0x20u);
    goto L_83E6C0;
L_83E6C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6C0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6C0u);return;} hw.unresolvedReturn(0x83E6C0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C1u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C1 ADC
    cpu.adc(0x3Fu);
    goto L_83E6C3;
L_83E6C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C3u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C3u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C3 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6C6;
L_83E6C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C6 REP
    cpu.rep(0x20u);
    goto L_83E6C8;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C6 REP
    cpu.rep(0x20u);
    goto L_83E6C8;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE6C6u,0x83E6C6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E6C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6C8u);return;} hw.unresolvedReturn(0x83E6C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6C9 SEP
    cpu.sep(0x20u);
    goto L_83E6CB;
L_83E6CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6CD;
L_83E6CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CD TAY
    cpu.transfer("TAY");
    goto L_83E6CE;
L_83E6CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CE SEC
    cpu.setFlag('C', true);
    goto L_83E6CF;
L_83E6CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CFu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6CFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6CF SBC
    cpu.sbc(0x20u);
    goto L_83E6D1;
L_83E6D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D1u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D1 CMP
    cpu.compareA(0x80u);
    goto L_83E6D3;
L_83E6D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D3u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D3 TYA
    cpu.transfer("TYA");
    goto L_83E6D4;
L_83E6D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D4u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D4 BCS -> $83E6DE
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E6DE; }
    goto L_83E6D6;
L_83E6D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D6u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D6 ADC
    cpu.adc(0x40u);
    goto L_83E6D8;
L_83E6D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D8u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6D8u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6D8 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6DB;
L_83E6DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DBu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6DB REP
    cpu.rep(0x20u);
    goto L_83E6DD;
L_83E6DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6DD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6DDu);return;} hw.unresolvedReturn(0x83E6DDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DEu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6DE SBC
    cpu.sbc(0x40u);
    goto L_83E6E0;
L_83E6E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E0u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E0u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E0 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E6E3;
L_83E6E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E3u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E3u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E3 REP
    cpu.rep(0x20u);
    goto L_83E6E5;
L_83E6E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E5u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E5u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6E5 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6E5u);return;} hw.unresolvedReturn(0x83E6E5u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6E6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E6u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E6E6 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E6E6u);return;} hw.unresolvedReturn(0x83E6E6u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E6E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E7u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6E7u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6E7 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6EA;
L_83E6EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EAu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6EA CMP
    cpu.compareA(0x500u);
    goto L_83E6ED;
L_83E6ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EDu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6ED BMI -> $83E75F
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E75F; }
    goto L_83E6EF;
L_83E6EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6EF SEP
    cpu.sep(0x20u);
    goto L_83E6F1;
L_83E6F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F1u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F1 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E6F3;
L_83E6F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F3 AND
    cpu.logicAnd(0xF0u);
    goto L_83E6F5;
L_83E6F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F5 SEC
    cpu.setFlag('C', true);
    goto L_83E6F6;
L_83E6F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F6u, 4u + 1u, 3u, cpu.address("absy", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F6 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16));
    goto L_83E6F9;
L_83E6F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6F9 BEQ -> $83E708
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E708; }
    goto L_83E6FB;
L_83E6FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FBu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FB ASL
    cpu.aslA();
    goto L_83E6FC;
L_83E6FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FC LDA
    cpu.setA(0x82u, 8);
    goto L_83E6FE;
L_83E6FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE6FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FEu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE6FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E6FE BCC -> $83E702
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E702; }
    goto L_83E700;
L_83E700:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE700u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE700u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE700u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E700 LDA
    cpu.setA(0x81u, 8);
    goto L_83E702;
L_83E702:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE702u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE702u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E702 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E705;
L_83E705:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE705u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE705u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E705 REP
    cpu.rep(0x20u);
    goto L_83E707;
L_83E707:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE707u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE707u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E707 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E707u);return;} hw.unresolvedReturn(0x83E707u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E708:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE708u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE708u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E708 LDA
    cpu.setA(0x80u, 8);
    goto L_83E70A;
L_83E70A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Au, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70A STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83E70D;
L_83E70D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE70Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE70Du, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E70D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E710;
L_83E710:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE710u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE710u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E710 REP
    cpu.rep(0x20u);
    goto L_83E712;
L_83E712:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE712u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE712u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E712 BEQ -> $83E75E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E75E; }
    goto L_83E714;
L_83E714:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE714u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE714u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E714 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E717;
L_83E717:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE717u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE717u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E717 BNE -> $83E73E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83E73E; }
    goto L_83E719;
L_83E719:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE719u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE719u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E719 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xE71Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xE71Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83E719u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83E71D;
L_83E71D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE71Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE71Du,0x83E71Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE71Du, 5u + 1u, 3u, cpu.address("absy", 0x0004u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E71D LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E720;
L_83E720:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE720u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE720u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E720 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xEu), cpu.m8?8:16));
    goto L_83E722;
L_83E722:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE722u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE722u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E722 BMI -> $83E741
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83E741; }
    goto L_83E724;
L_83E724:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE724u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE724u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E724 SEP
    cpu.sep(0x20u);
    goto L_83E726;
L_83E726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE726u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E726 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E728;
L_83E728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE728u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E728 TAY
    cpu.transfer("TAY");
    goto L_83E729;
L_83E729:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE729u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE729u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E729 SEC
    cpu.setFlag('C', true);
    goto L_83E72A;
L_83E72A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72A SBC
    cpu.sbc(0x20u);
    goto L_83E72C;
L_83E72C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72C CMP
    cpu.compareA(0x80u);
    goto L_83E72E;
L_83E72E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72E TYA
    cpu.transfer("TYA");
    goto L_83E72F;
L_83E72F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE72Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE72Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E72F BCS -> $83E739
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E739; }
    goto L_83E731;
L_83E731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE731u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E731 SBC
    cpu.sbc(0x3Fu);
    goto L_83E733;
L_83E733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE733u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E733 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E736;
L_83E736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE736u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E736 REP
    cpu.rep(0x20u);
    goto L_83E738;
L_83E738:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE738u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE738u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E738 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E738u);return;} hw.unresolvedReturn(0x83E738u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E739:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE739u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE739u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E739 ADC
    cpu.adc(0x3Fu);
    goto L_83E73B;
L_83E73B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Bu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73B STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E73E;
L_83E73E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE73Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE73Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E73E REP
    cpu.rep(0x20u);
    goto L_83E740;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE73Eu,0x83E73Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83E740:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE740u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE740u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E740 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E740u);return;} hw.unresolvedReturn(0x83E740u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E741:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE741u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE741u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E741 SEP
    cpu.sep(0x20u);
    goto L_83E743;
L_83E743:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE743u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE743u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E743 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83E745;
L_83E745:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE745u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE745u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E745 TAY
    cpu.transfer("TAY");
    goto L_83E746;
L_83E746:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE746u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE746u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E746 SEC
    cpu.setFlag('C', true);
    goto L_83E747;
L_83E747:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE747u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE747u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E747 SBC
    cpu.sbc(0x20u);
    goto L_83E749;
L_83E749:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE749u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE749u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E749 CMP
    cpu.compareA(0x80u);
    goto L_83E74B;
L_83E74B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74B TYA
    cpu.transfer("TYA");
    goto L_83E74C;
L_83E74C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74C BCS -> $83E756
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83E756; }
    goto L_83E74E;
L_83E74E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE74Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE74Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E74E ADC
    cpu.adc(0x40u);
    goto L_83E750;
L_83E750:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE750u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE750u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E750 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E753;
L_83E753:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE753u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE753u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E753 REP
    cpu.rep(0x20u);
    goto L_83E755;
L_83E755:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE755u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE755u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E755 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E755u);return;} hw.unresolvedReturn(0x83E755u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E756:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE756u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE756u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E756 SBC
    cpu.sbc(0x40u);
    goto L_83E758;
L_83E758:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE758u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE758u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E758 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83E75B;
L_83E75B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75B REP
    cpu.rep(0x20u);
    goto L_83E75D;
L_83E75D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75D RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Du);return;} hw.unresolvedReturn(0x83E75Du,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83E75E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83E75Eu);return;} hw.unresolvedReturn(0x83E75Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83E75F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE75Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE75Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E75F SEP
    cpu.sep(0x20u);
    goto L_83E761;
L_83E761:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xE761u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xE761u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83E761 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xE763u,0x83E761u); return;
}

void sub_83F73B_E0M0X0C1_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F7B4u: goto L_83F7B4;
    case 0x83F7B6u: goto L_83F7B6;
    case 0x83F7B8u: goto L_83F7B8;
    case 0x83F7BBu: goto L_83F7BB;
    case 0x83F7BDu: goto L_83F7BD;
    case 0x83F7BFu: goto L_83F7BF;
    case 0x83F7C2u: goto L_83F7C2;
    case 0x83F7C4u: goto L_83F7C4;
    case 0x83F7C7u: goto L_83F7C7;
    case 0x83F7CAu: goto L_83F7CA;
    case 0x83F7CCu: goto L_83F7CC;
    case 0x83F7CDu: goto L_83F7CD;
    case 0x83F7D0u: goto L_83F7D0;
    case 0x83F7D3u: goto L_83F7D3;
    case 0x83F7D6u: goto L_83F7D6;
    case 0x83F7D8u: goto L_83F7D8;
    case 0x83F7DAu: goto L_83F7DA;
    case 0x83F7DCu: goto L_83F7DC;
    case 0x83F7DEu: goto L_83F7DE;
    case 0x83F7DFu: goto L_83F7DF;
    case 0x83F7E2u: goto L_83F7E2;
    case 0x83F7E4u: goto L_83F7E4;
    case 0x83F7E5u: goto L_83F7E5;
    case 0x83F7E7u: goto L_83F7E7;
    case 0x83F7E9u: goto L_83F7E9;
    case 0x83F7EBu: goto L_83F7EB;
    case 0x83F7EEu: goto L_83F7EE;
    case 0x83F7F0u: goto L_83F7F0;
    case 0x83F7F3u: goto L_83F7F3;
    case 0x83F7F4u: goto L_83F7F4;
    case 0x83F7F7u: goto L_83F7F7;
    case 0x83F7F9u: goto L_83F7F9;
    case 0x83F7FBu: goto L_83F7FB;
    case 0x83F7FEu: goto L_83F7FE;
    case 0x83F800u: goto L_83F800;
    case 0x83F804u: goto L_83F804;
    case 0x83F807u: goto L_83F807;
    case 0x83F809u: goto L_83F809;
    case 0x83F80Bu: goto L_83F80B;
    case 0x83F80Du: goto L_83F80D;
    case 0x83F80Fu: goto L_83F80F;
    case 0x83F810u: goto L_83F810;
    case 0x83F811u: goto L_83F811;
    case 0x83F813u: goto L_83F813;
    case 0x83F815u: goto L_83F815;
    case 0x83F816u: goto L_83F816;
    case 0x83F818u: goto L_83F818;
    case 0x83F81Au: goto L_83F81A;
    case 0x83F81Du: goto L_83F81D;
    case 0x83F81Fu: goto L_83F81F;
    case 0x83F820u: goto L_83F820;
    case 0x83F822u: goto L_83F822;
    case 0x83F825u: goto L_83F825;
    case 0x83F827u: goto L_83F827;
    case 0x83F828u: goto L_83F828;
    case 0x83F82Au: goto L_83F82A;
    case 0x83F82Cu: goto L_83F82C;
    case 0x83F82Du: goto L_83F82D;
    case 0x83F82Eu: goto L_83F82E;
    case 0x83F830u: goto L_83F830;
    case 0x83F832u: goto L_83F832;
    case 0x83F833u: goto L_83F833;
    case 0x83F835u: goto L_83F835;
    case 0x83F837u: goto L_83F837;
    case 0x83F83Au: goto L_83F83A;
    case 0x83F83Cu: goto L_83F83C;
    case 0x83F83Du: goto L_83F83D;
    case 0x83F83Fu: goto L_83F83F;
    case 0x83F842u: goto L_83F842;
    case 0x83F844u: goto L_83F844;
    case 0x83F845u: goto L_83F845;
    case 0x83F846u: goto L_83F846;
    case 0x83F848u: goto L_83F848;
    case 0x83F849u: goto L_83F849;
    case 0x83F84Cu: goto L_83F84C;
    case 0x83F84Du: goto L_83F84D;
    case 0x83F84Fu: goto L_83F84F;
    case 0x83F851u: goto L_83F851;
    case 0x83F853u: goto L_83F853;
    case 0x83F854u: goto L_83F854;
    case 0x83F857u: goto L_83F857;
    case 0x83F859u: goto L_83F859;
    case 0x83F85Au: goto L_83F85A;
    case 0x83F85Cu: goto L_83F85C;
    case 0x83F85Eu: goto L_83F85E;
    case 0x83F860u: goto L_83F860;
    case 0x83F863u: goto L_83F863;
    case 0x83F865u: goto L_83F865;
    case 0x83F868u: goto L_83F868;
    case 0x83F869u: goto L_83F869;
    case 0x83F86Cu: goto L_83F86C;
    case 0x83F86Eu: goto L_83F86E;
    case 0x83F870u: goto L_83F870;
    case 0x83F873u: goto L_83F873;
    case 0x83F875u: goto L_83F875;
    case 0x83F879u: goto L_83F879;
    case 0x83F87Cu: goto L_83F87C;
    case 0x83F87Eu: goto L_83F87E;
    case 0x83F880u: goto L_83F880;
    case 0x83F882u: goto L_83F882;
    case 0x83F884u: goto L_83F884;
    case 0x83F885u: goto L_83F885;
    case 0x83F886u: goto L_83F886;
    case 0x83F888u: goto L_83F888;
    case 0x83F88Au: goto L_83F88A;
    case 0x83F88Bu: goto L_83F88B;
    case 0x83F88Du: goto L_83F88D;
    case 0x83F88Fu: goto L_83F88F;
    case 0x83F892u: goto L_83F892;
    case 0x83F894u: goto L_83F894;
    case 0x83F895u: goto L_83F895;
    case 0x83F897u: goto L_83F897;
    case 0x83F89Au: goto L_83F89A;
    case 0x83F89Cu: goto L_83F89C;
    case 0x83F89Du: goto L_83F89D;
    case 0x83F89Fu: goto L_83F89F;
    case 0x83F8A1u: goto L_83F8A1;
    case 0x83F8A2u: goto L_83F8A2;
    case 0x83F8A3u: goto L_83F8A3;
    case 0x83F8A5u: goto L_83F8A5;
    case 0x83F8A7u: goto L_83F8A7;
    case 0x83F8A8u: goto L_83F8A8;
    case 0x83F8AAu: goto L_83F8AA;
    case 0x83F8ACu: goto L_83F8AC;
    case 0x83F8AFu: goto L_83F8AF;
    case 0x83F8B1u: goto L_83F8B1;
    case 0x83F8B2u: goto L_83F8B2;
    case 0x83F8B4u: goto L_83F8B4;
    case 0x83F8B7u: goto L_83F8B7;
    case 0x83F8B9u: goto L_83F8B9;
    case 0x83F8BAu: goto L_83F8BA;
    case 0x83F8BCu: goto L_83F8BC;
    case 0x83F8BEu: goto L_83F8BE;
    case 0x83F8BFu: goto L_83F8BF;
    case 0x83F8C2u: goto L_83F8C2;
    case 0x83F8C4u: goto L_83F8C4;
    case 0x83F8C5u: goto L_83F8C5;
    case 0x83F8C7u: goto L_83F8C7;
    case 0x83F8C9u: goto L_83F8C9;
    case 0x83F8CBu: goto L_83F8CB;
    case 0x83F8CEu: goto L_83F8CE;
    case 0x83F8D0u: goto L_83F8D0;
    case 0x83F8D3u: goto L_83F8D3;
    case 0x83F8D4u: goto L_83F8D4;
    case 0x83F8D7u: goto L_83F8D7;
    case 0x83F8D9u: goto L_83F8D9;
    case 0x83F8DBu: goto L_83F8DB;
    case 0x83F8DEu: goto L_83F8DE;
    case 0x83F8E0u: goto L_83F8E0;
    case 0x83F8E4u: goto L_83F8E4;
    case 0x83F8E7u: goto L_83F8E7;
    case 0x83F8E9u: goto L_83F8E9;
    case 0x83F8EBu: goto L_83F8EB;
    case 0x83F8EDu: goto L_83F8ED;
    case 0x83F8EFu: goto L_83F8EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B4 BPL -> $83F7CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7B6;
L_83F7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7B8;
L_83F7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B8 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F7BB;
L_83F7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BB BNE -> $83F7CA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7BD;
L_83F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7BF;
L_83F7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BF CMP
    cpu.compareA(0x8u);
    goto L_83F7C2;
L_83F7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C2 BCC -> $83F7CA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7C4;
L_83F7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C4 LDA
    cpu.setA(0x600u, 16);
    goto L_83F7C7;
L_83F7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C7 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F7CA;
L_83F7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7CC;
L_83F7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CC SEC
    cpu.setFlag('C', true);
    goto L_83F7CD;
L_83F7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CD SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_83F7D0;
L_83F7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D0 ADC
    cpu.adc(0x8u);
    goto L_83F7D3;
L_83F7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D3 CMP
    cpu.compareA(0x10u);
    goto L_83F7D6;
L_83F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D6 BCS -> $83F845
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F845; }
    goto L_83F7D8;
L_83F7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D8 SEP
    cpu.sep(0x20u);
    goto L_83F7DA;
L_83F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7DC;
L_83F7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DC AND
    cpu.logicAnd(0xF0u);
    goto L_83F7DE;
L_83F7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DE SEC
    cpu.setFlag('C', true);
    goto L_83F7DF;
L_83F7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F7E2;
L_83F7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E2 BEQ -> $83F7F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7F4; }
    goto L_83F7E4;
L_83F7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E4 ASL
    cpu.aslA();
    goto L_83F7E5;
L_83F7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E5 LDA
    cpu.setA(0x82u, 8);
    goto L_83F7E7;
L_83F7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E7 BCC -> $83F7EB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F7EB; }
    goto L_83F7E9;
L_83F7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E9 LDA
    cpu.setA(0x81u, 8);
    goto L_83F7EB;
L_83F7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7EB STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F7EE;
L_83F7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7EE REP
    cpu.rep(0x20u);
    goto L_83F7F0;
L_83F7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F7F0 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF7F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7F3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F7F0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F7F3;
L_83F7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F7F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F7F3u);return;} hw.unresolvedReturn(0x83F7F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F7F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F7F3u);return;} hw.unresolvedReturn(0x83F7F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7F3u,0x83F7F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7F7;
L_83F7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F7 BEQ -> $83F7EE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7EE; }
    goto L_83F7F9;
L_83F7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F9 REP
    cpu.rep(0x20u);
    goto L_83F7FB;
L_83F7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FBu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7FE;
L_83F7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7FE BNE -> $83F825
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F825; }
    goto L_83F800;
L_83F800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F800 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF803u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF804u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F800u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F804;
L_83F804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF804u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF804u,0x83F804u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F804 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F807;
L_83F807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF807u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF807u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F807 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F809;
L_83F809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F809 BMI -> $83F828
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F828; }
    goto L_83F80B;
L_83F80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80B SEP
    cpu.sep(0x20u);
    goto L_83F80D;
L_83F80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F80F;
L_83F80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80F TAY
    cpu.transfer("TAY");
    goto L_83F810;
L_83F810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF810u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF810u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F810 SEC
    cpu.setFlag('C', true);
    goto L_83F811;
L_83F811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F811 SBC
    cpu.sbc(0x20u);
    goto L_83F813;
L_83F813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF813u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F813 CMP
    cpu.compareA(0x80u);
    goto L_83F815;
L_83F815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F815 TYA
    cpu.transfer("TYA");
    goto L_83F816;
L_83F816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF816u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF816u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F816 BCS -> $83F820
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F820; }
    goto L_83F818;
L_83F818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF818u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF818u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F818 SBC
    cpu.sbc(0x3Fu);
    goto L_83F81A;
L_83F81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F81A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F81D;
L_83F81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F81D REP
    cpu.rep(0x20u);
    goto L_83F81F;
L_83F81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F81F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F81Fu);return;} hw.unresolvedReturn(0x83F81Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF820u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF820u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F820 ADC
    cpu.adc(0x3Fu);
    goto L_83F822;
L_83F822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF822u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF822u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F822 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F825;
L_83F825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF825u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F825 REP
    cpu.rep(0x20u);
    goto L_83F827;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F825 REP
    cpu.rep(0x20u);
    goto L_83F827;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF825u,0x83F825u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF827u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF827u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F827 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F827u);return;} hw.unresolvedReturn(0x83F827u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F828 SEP
    cpu.sep(0x20u);
    goto L_83F82A;
L_83F82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F82C;
L_83F82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82C TAY
    cpu.transfer("TAY");
    goto L_83F82D;
L_83F82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82D SEC
    cpu.setFlag('C', true);
    goto L_83F82E;
L_83F82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82E SBC
    cpu.sbc(0x20u);
    goto L_83F830;
L_83F830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF830u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF830u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F830 CMP
    cpu.compareA(0x80u);
    goto L_83F832;
L_83F832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF832u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF832u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F832 TYA
    cpu.transfer("TYA");
    goto L_83F833;
L_83F833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF833u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F833 BCS -> $83F83D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F83D; }
    goto L_83F835;
L_83F835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F835 ADC
    cpu.adc(0x40u);
    goto L_83F837;
L_83F837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF837u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF837u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F837 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F83A;
L_83F83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83A REP
    cpu.rep(0x20u);
    goto L_83F83C;
L_83F83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F83C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F83Cu);return;} hw.unresolvedReturn(0x83F83Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83D SBC
    cpu.sbc(0x40u);
    goto L_83F83F;
L_83F83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F842;
L_83F842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF842u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF842u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F842 REP
    cpu.rep(0x20u);
    goto L_83F844;
L_83F844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF844u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF844u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F844 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F844u);return;} hw.unresolvedReturn(0x83F844u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F845 ASL
    cpu.aslA();
    goto L_83F846;
L_83F846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF846u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF846u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F846 SEP
    cpu.sep(0x20u);
    goto L_83F848;
L_83F848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF848u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF848u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F848 ROL
    cpu.rolA();
    goto L_83F849;
L_83F849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F849 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F84C;
L_83F84C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84C LSR
    cpu.lsrA();
    goto L_83F84D;
L_83F84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84D BCC -> $83F8BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8BA; }
    goto L_83F84F;
L_83F84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F851;
L_83F851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F851 AND
    cpu.logicAnd(0xF0u);
    goto L_83F853;
L_83F853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F853 SEC
    cpu.setFlag('C', true);
    goto L_83F854;
L_83F854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF854u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF854u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F854 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F857;
L_83F857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF857u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F857 BEQ -> $83F869
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F869; }
    goto L_83F859;
L_83F859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F859 ASL
    cpu.aslA();
    goto L_83F85A;
L_83F85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85A LDA
    cpu.setA(0x82u, 8);
    goto L_83F85C;
L_83F85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85C BCC -> $83F860
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F860; }
    goto L_83F85E;
L_83F85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85E LDA
    cpu.setA(0x81u, 8);
    goto L_83F860;
L_83F860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F860 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F863;
L_83F863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF863u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF863u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F863 REP
    cpu.rep(0x20u);
    goto L_83F865;
L_83F865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F865 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF867u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF868u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F865u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F868;
L_83F868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF868u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F868 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F868u);return;} hw.unresolvedReturn(0x83F868u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F868 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F868u);return;} hw.unresolvedReturn(0x83F868u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF868u,0x83F868u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F869 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F86C;
L_83F86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F86C BEQ -> $83F863
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F863; }
    goto L_83F86E;
L_83F86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F86E REP
    cpu.rep(0x20u);
    goto L_83F870;
L_83F870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F870 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F873;
L_83F873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F873 BNE -> $83F89A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F89A; }
    goto L_83F875;
L_83F875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F875 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF878u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF879u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F875u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F879;
L_83F879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF879u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF879u,0x83F879u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F879 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F87C;
L_83F87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F87C CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F87E;
L_83F87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F87E BMI -> $83F89D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F89D; }
    goto L_83F880;
L_83F880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF880u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF880u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F880 SEP
    cpu.sep(0x20u);
    goto L_83F882;
L_83F882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F882 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F884;
L_83F884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F884 TAY
    cpu.transfer("TAY");
    goto L_83F885;
L_83F885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F885 SEC
    cpu.setFlag('C', true);
    goto L_83F886;
L_83F886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F886 SBC
    cpu.sbc(0x20u);
    goto L_83F888;
L_83F888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F888 CMP
    cpu.compareA(0x80u);
    goto L_83F88A;
L_83F88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88A TYA
    cpu.transfer("TYA");
    goto L_83F88B;
L_83F88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88B BCS -> $83F895
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F895; }
    goto L_83F88D;
L_83F88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88D SBC
    cpu.sbc(0x3Fu);
    goto L_83F88F;
L_83F88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F892;
L_83F892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F892 REP
    cpu.rep(0x20u);
    goto L_83F894;
L_83F894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F894 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F894u);return;} hw.unresolvedReturn(0x83F894u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F895 ADC
    cpu.adc(0x3Fu);
    goto L_83F897;
L_83F897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F897 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F89A;
L_83F89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89A REP
    cpu.rep(0x20u);
    goto L_83F89C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89A REP
    cpu.rep(0x20u);
    goto L_83F89C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF89Au,0x83F89Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F89C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F89Cu);return;} hw.unresolvedReturn(0x83F89Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89D SEP
    cpu.sep(0x20u);
    goto L_83F89F;
L_83F89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8A1;
L_83F8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A1 TAY
    cpu.transfer("TAY");
    goto L_83F8A2;
L_83F8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A2 SEC
    cpu.setFlag('C', true);
    goto L_83F8A3;
L_83F8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A3 SBC
    cpu.sbc(0x20u);
    goto L_83F8A5;
L_83F8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A5 CMP
    cpu.compareA(0x80u);
    goto L_83F8A7;
L_83F8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A7 TYA
    cpu.transfer("TYA");
    goto L_83F8A8;
L_83F8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A8 BCS -> $83F8B2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8B2; }
    goto L_83F8AA;
L_83F8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AA ADC
    cpu.adc(0x40u);
    goto L_83F8AC;
L_83F8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ACu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ACu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F8AF;
L_83F8AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AF REP
    cpu.rep(0x20u);
    goto L_83F8B1;
L_83F8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8B1u);return;} hw.unresolvedReturn(0x83F8B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B2 SBC
    cpu.sbc(0x40u);
    goto L_83F8B4;
L_83F8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B4 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F8B7;
L_83F8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B7 REP
    cpu.rep(0x20u);
    goto L_83F8B9;
L_83F8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8B9u);return;} hw.unresolvedReturn(0x83F8B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8BC;
L_83F8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BC AND
    cpu.logicAnd(0xF0u);
    goto L_83F8BE;
L_83F8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BE SEC
    cpu.setFlag('C', true);
    goto L_83F8BF;
L_83F8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83F8C2;
L_83F8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C2 BEQ -> $83F8D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F8D4; }
    goto L_83F8C4;
L_83F8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C4 ASL
    cpu.aslA();
    goto L_83F8C5;
L_83F8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C5 LDA
    cpu.setA(0x82u, 8);
    goto L_83F8C7;
L_83F8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C7 BCC -> $83F8CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8CB; }
    goto L_83F8C9;
L_83F8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C9 LDA
    cpu.setA(0x81u, 8);
    goto L_83F8CB;
L_83F8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8CB STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F8CE;
L_83F8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8CE REP
    cpu.rep(0x20u);
    goto L_83F8D0;
L_83F8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F8D0 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF8D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F8D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F8D3;
L_83F8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8D3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8D3u);return;} hw.unresolvedReturn(0x83F8D3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8D3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8D3u);return;} hw.unresolvedReturn(0x83F8D3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8D3u,0x83F8D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D4u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8D7;
L_83F8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D7 BEQ -> $83F8CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F8CE; }
    goto L_83F8D9;
L_83F8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D9 REP
    cpu.rep(0x20u);
    goto L_83F8DB;
L_83F8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8DB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8DE;
L_83F8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8DE BNE -> $83F905
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F905u,0x83F8DEu); return; }
    goto L_83F8E0;
L_83F8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8E0 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF8E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8E4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F8E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F8E4;
L_83F8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8E4u,0x83F8E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E4u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8E7;
L_83F8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F8E9;
L_83F8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E9 BMI -> $83F908
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F908u,0x83F8E9u); return; }
    goto L_83F8EB;
L_83F8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8EB SEP
    cpu.sep(0x20u);
    goto L_83F8ED;
L_83F8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8ED LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8EF;
L_83F8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8EF TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8F0u,0x83F8EFu); return;
}

void sub_83F73B_E0M0X0CQ_part5(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83F7B4u: goto L_83F7B4;
    case 0x83F7B6u: goto L_83F7B6;
    case 0x83F7B8u: goto L_83F7B8;
    case 0x83F7BBu: goto L_83F7BB;
    case 0x83F7BDu: goto L_83F7BD;
    case 0x83F7BFu: goto L_83F7BF;
    case 0x83F7C2u: goto L_83F7C2;
    case 0x83F7C4u: goto L_83F7C4;
    case 0x83F7C7u: goto L_83F7C7;
    case 0x83F7CAu: goto L_83F7CA;
    case 0x83F7CCu: goto L_83F7CC;
    case 0x83F7CDu: goto L_83F7CD;
    case 0x83F7D0u: goto L_83F7D0;
    case 0x83F7D3u: goto L_83F7D3;
    case 0x83F7D6u: goto L_83F7D6;
    case 0x83F7D8u: goto L_83F7D8;
    case 0x83F7DAu: goto L_83F7DA;
    case 0x83F7DCu: goto L_83F7DC;
    case 0x83F7DEu: goto L_83F7DE;
    case 0x83F7DFu: goto L_83F7DF;
    case 0x83F7E2u: goto L_83F7E2;
    case 0x83F7E4u: goto L_83F7E4;
    case 0x83F7E5u: goto L_83F7E5;
    case 0x83F7E7u: goto L_83F7E7;
    case 0x83F7E9u: goto L_83F7E9;
    case 0x83F7EBu: goto L_83F7EB;
    case 0x83F7EEu: goto L_83F7EE;
    case 0x83F7F0u: goto L_83F7F0;
    case 0x83F7F3u: goto L_83F7F3;
    case 0x83F7F4u: goto L_83F7F4;
    case 0x83F7F7u: goto L_83F7F7;
    case 0x83F7F9u: goto L_83F7F9;
    case 0x83F7FBu: goto L_83F7FB;
    case 0x83F7FEu: goto L_83F7FE;
    case 0x83F800u: goto L_83F800;
    case 0x83F804u: goto L_83F804;
    case 0x83F807u: goto L_83F807;
    case 0x83F809u: goto L_83F809;
    case 0x83F80Bu: goto L_83F80B;
    case 0x83F80Du: goto L_83F80D;
    case 0x83F80Fu: goto L_83F80F;
    case 0x83F810u: goto L_83F810;
    case 0x83F811u: goto L_83F811;
    case 0x83F813u: goto L_83F813;
    case 0x83F815u: goto L_83F815;
    case 0x83F816u: goto L_83F816;
    case 0x83F818u: goto L_83F818;
    case 0x83F81Au: goto L_83F81A;
    case 0x83F81Du: goto L_83F81D;
    case 0x83F81Fu: goto L_83F81F;
    case 0x83F820u: goto L_83F820;
    case 0x83F822u: goto L_83F822;
    case 0x83F825u: goto L_83F825;
    case 0x83F827u: goto L_83F827;
    case 0x83F828u: goto L_83F828;
    case 0x83F82Au: goto L_83F82A;
    case 0x83F82Cu: goto L_83F82C;
    case 0x83F82Du: goto L_83F82D;
    case 0x83F82Eu: goto L_83F82E;
    case 0x83F830u: goto L_83F830;
    case 0x83F832u: goto L_83F832;
    case 0x83F833u: goto L_83F833;
    case 0x83F835u: goto L_83F835;
    case 0x83F837u: goto L_83F837;
    case 0x83F83Au: goto L_83F83A;
    case 0x83F83Cu: goto L_83F83C;
    case 0x83F83Du: goto L_83F83D;
    case 0x83F83Fu: goto L_83F83F;
    case 0x83F842u: goto L_83F842;
    case 0x83F844u: goto L_83F844;
    case 0x83F845u: goto L_83F845;
    case 0x83F846u: goto L_83F846;
    case 0x83F848u: goto L_83F848;
    case 0x83F849u: goto L_83F849;
    case 0x83F84Cu: goto L_83F84C;
    case 0x83F84Du: goto L_83F84D;
    case 0x83F84Fu: goto L_83F84F;
    case 0x83F851u: goto L_83F851;
    case 0x83F853u: goto L_83F853;
    case 0x83F854u: goto L_83F854;
    case 0x83F857u: goto L_83F857;
    case 0x83F859u: goto L_83F859;
    case 0x83F85Au: goto L_83F85A;
    case 0x83F85Cu: goto L_83F85C;
    case 0x83F85Eu: goto L_83F85E;
    case 0x83F860u: goto L_83F860;
    case 0x83F863u: goto L_83F863;
    case 0x83F865u: goto L_83F865;
    case 0x83F868u: goto L_83F868;
    case 0x83F869u: goto L_83F869;
    case 0x83F86Cu: goto L_83F86C;
    case 0x83F86Eu: goto L_83F86E;
    case 0x83F870u: goto L_83F870;
    case 0x83F873u: goto L_83F873;
    case 0x83F875u: goto L_83F875;
    case 0x83F879u: goto L_83F879;
    case 0x83F87Cu: goto L_83F87C;
    case 0x83F87Eu: goto L_83F87E;
    case 0x83F880u: goto L_83F880;
    case 0x83F882u: goto L_83F882;
    case 0x83F884u: goto L_83F884;
    case 0x83F885u: goto L_83F885;
    case 0x83F886u: goto L_83F886;
    case 0x83F888u: goto L_83F888;
    case 0x83F88Au: goto L_83F88A;
    case 0x83F88Bu: goto L_83F88B;
    case 0x83F88Du: goto L_83F88D;
    case 0x83F88Fu: goto L_83F88F;
    case 0x83F892u: goto L_83F892;
    case 0x83F894u: goto L_83F894;
    case 0x83F895u: goto L_83F895;
    case 0x83F897u: goto L_83F897;
    case 0x83F89Au: goto L_83F89A;
    case 0x83F89Cu: goto L_83F89C;
    case 0x83F89Du: goto L_83F89D;
    case 0x83F89Fu: goto L_83F89F;
    case 0x83F8A1u: goto L_83F8A1;
    case 0x83F8A2u: goto L_83F8A2;
    case 0x83F8A3u: goto L_83F8A3;
    case 0x83F8A5u: goto L_83F8A5;
    case 0x83F8A7u: goto L_83F8A7;
    case 0x83F8A8u: goto L_83F8A8;
    case 0x83F8AAu: goto L_83F8AA;
    case 0x83F8ACu: goto L_83F8AC;
    case 0x83F8AFu: goto L_83F8AF;
    case 0x83F8B1u: goto L_83F8B1;
    case 0x83F8B2u: goto L_83F8B2;
    case 0x83F8B4u: goto L_83F8B4;
    case 0x83F8B7u: goto L_83F8B7;
    case 0x83F8B9u: goto L_83F8B9;
    case 0x83F8BAu: goto L_83F8BA;
    case 0x83F8BCu: goto L_83F8BC;
    case 0x83F8BEu: goto L_83F8BE;
    case 0x83F8BFu: goto L_83F8BF;
    case 0x83F8C2u: goto L_83F8C2;
    case 0x83F8C4u: goto L_83F8C4;
    case 0x83F8C5u: goto L_83F8C5;
    case 0x83F8C7u: goto L_83F8C7;
    case 0x83F8C9u: goto L_83F8C9;
    case 0x83F8CBu: goto L_83F8CB;
    case 0x83F8CEu: goto L_83F8CE;
    case 0x83F8D0u: goto L_83F8D0;
    case 0x83F8D3u: goto L_83F8D3;
    case 0x83F8D4u: goto L_83F8D4;
    case 0x83F8D7u: goto L_83F8D7;
    case 0x83F8D9u: goto L_83F8D9;
    case 0x83F8DBu: goto L_83F8DB;
    case 0x83F8DEu: goto L_83F8DE;
    case 0x83F8E0u: goto L_83F8E0;
    case 0x83F8E4u: goto L_83F8E4;
    case 0x83F8E7u: goto L_83F8E7;
    case 0x83F8E9u: goto L_83F8E9;
    case 0x83F8EBu: goto L_83F8EB;
    case 0x83F8EDu: goto L_83F8ED;
    case 0x83F8EFu: goto L_83F8EF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83F7B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B4 BPL -> $83F7CA
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7B6;
L_83F7B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B6u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B6 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7B8;
L_83F7B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7B8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7B8 AND
    cpu.logicAnd(0x3Fu);
    goto L_83F7BB;
L_83F7BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BB BNE -> $83F7CA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7BD;
L_83F7BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0xDEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xDEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7BF;
L_83F7BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7BFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7BF CMP
    cpu.compareA(0x8u);
    goto L_83F7C2;
L_83F7C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C2 BCC -> $83F7CA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F7CA; }
    goto L_83F7C4;
L_83F7C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C4 LDA
    cpu.setA(0x600u, 16);
    goto L_83F7C7;
L_83F7C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7C7u, 6u, 3u, cpu.address("absx", 0x10AAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7C7 STA
    hw.write(cpu.address("absx", 0x10AAu), cpu.a, cpu.m8?8:16);
    goto L_83F7CA;
L_83F7CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7CC;
L_83F7CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CC SEC
    cpu.setFlag('C', true);
    goto L_83F7CD;
L_83F7CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7CDu, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7CD SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16));
    goto L_83F7D0;
L_83F7D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D0u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D0 ADC
    cpu.adc(0x8u);
    goto L_83F7D3;
L_83F7D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D3 CMP
    cpu.compareA(0x10u);
    goto L_83F7D6;
L_83F7D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D6 BCS -> $83F845
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F845; }
    goto L_83F7D8;
L_83F7D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7D8 SEP
    cpu.sep(0x20u);
    goto L_83F7DA;
L_83F7DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7DC;
L_83F7DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DC AND
    cpu.logicAnd(0xF0u);
    goto L_83F7DE;
L_83F7DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DE SEC
    cpu.setFlag('C', true);
    goto L_83F7DF;
L_83F7DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7DFu, 4u + 1u, 3u, cpu.address("absy", 0x0004u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7DF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x4u), cpu.m8?8:16));
    goto L_83F7E2;
L_83F7E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E2 BEQ -> $83F7F4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7F4; }
    goto L_83F7E4;
L_83F7E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E4 ASL
    cpu.aslA();
    goto L_83F7E5;
L_83F7E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E5 LDA
    cpu.setA(0x82u, 8);
    goto L_83F7E7;
L_83F7E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E7 BCC -> $83F7EB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F7EB; }
    goto L_83F7E9;
L_83F7E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7E9 LDA
    cpu.setA(0x81u, 8);
    goto L_83F7EB;
L_83F7EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EBu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7EB STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F7EE;
L_83F7EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7EEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7EE REP
    cpu.rep(0x20u);
    goto L_83F7F0;
L_83F7F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F0u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F7F0 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF7F2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF7F3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F7F0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F7F3;
L_83F7F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F7F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F7F3u);return;} hw.unresolvedReturn(0x83F7F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F7F3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F7F3u);return;} hw.unresolvedReturn(0x83F7F3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF7F3u,0x83F7F3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F7F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F4u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7F7;
L_83F7F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F7 BEQ -> $83F7EE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F7EE; }
    goto L_83F7F9;
L_83F7F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7F9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7F9 REP
    cpu.rep(0x20u);
    goto L_83F7FB;
L_83F7FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FBu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7FB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F7FE;
L_83F7FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF7FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF7FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F7FE BNE -> $83F825
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F825; }
    goto L_83F800;
L_83F800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF800u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F800 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF803u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF804u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F800u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F804;
L_83F804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF804u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF804u,0x83F804u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF804u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F804 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F807;
L_83F807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF807u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF807u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F807 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F809;
L_83F809:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF809u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF809u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F809 BMI -> $83F828
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F828; }
    goto L_83F80B;
L_83F80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Bu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80B SEP
    cpu.sep(0x20u);
    goto L_83F80D;
L_83F80D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80D LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F80F;
L_83F80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF80Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F80F TAY
    cpu.transfer("TAY");
    goto L_83F810;
L_83F810:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF810u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF810u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF810u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F810 SEC
    cpu.setFlag('C', true);
    goto L_83F811;
L_83F811:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF811u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF811u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F811 SBC
    cpu.sbc(0x20u);
    goto L_83F813;
L_83F813:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF813u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF813u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF813u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F813 CMP
    cpu.compareA(0x80u);
    goto L_83F815;
L_83F815:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF815u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF815u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F815 TYA
    cpu.transfer("TYA");
    goto L_83F816;
L_83F816:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF816u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF816u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF816u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F816 BCS -> $83F820
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F820; }
    goto L_83F818;
L_83F818:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF818u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF818u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF818u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F818 SBC
    cpu.sbc(0x3Fu);
    goto L_83F81A;
L_83F81A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Au, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F81A STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F81D;
L_83F81D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F81D REP
    cpu.rep(0x20u);
    goto L_83F81F;
L_83F81F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF81Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF81Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F81F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F81Fu);return;} hw.unresolvedReturn(0x83F81Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF820u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF820u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F820 ADC
    cpu.adc(0x3Fu);
    goto L_83F822;
L_83F822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF822u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF822u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F822 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F825;
L_83F825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF825u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F825 REP
    cpu.rep(0x20u);
    goto L_83F827;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF825u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F825 REP
    cpu.rep(0x20u);
    goto L_83F827;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF825u,0x83F825u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F827:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF827u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF827u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF827u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F827 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F827u);return;} hw.unresolvedReturn(0x83F827u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF828u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F828 SEP
    cpu.sep(0x20u);
    goto L_83F82A;
L_83F82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Au,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82A LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F82C;
L_83F82C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Cu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82C TAY
    cpu.transfer("TAY");
    goto L_83F82D;
L_83F82D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82D SEC
    cpu.setFlag('C', true);
    goto L_83F82E;
L_83F82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Eu,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF82Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F82E SBC
    cpu.sbc(0x20u);
    goto L_83F830;
L_83F830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF830u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF830u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F830 CMP
    cpu.compareA(0x80u);
    goto L_83F832;
L_83F832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF832u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF832u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F832 TYA
    cpu.transfer("TYA");
    goto L_83F833;
L_83F833:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF833u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF833u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF833u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F833 BCS -> $83F83D
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F83D; }
    goto L_83F835;
L_83F835:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF835u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF835u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F835 ADC
    cpu.adc(0x40u);
    goto L_83F837;
L_83F837:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF837u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF837u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF837u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F837 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F83A;
L_83F83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83A REP
    cpu.rep(0x20u);
    goto L_83F83C;
L_83F83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F83C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F83Cu);return;} hw.unresolvedReturn(0x83F83Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83D SBC
    cpu.sbc(0x40u);
    goto L_83F83F;
L_83F83F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF83Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF83Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F83F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F842;
L_83F842:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF842u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF842u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF842u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F842 REP
    cpu.rep(0x20u);
    goto L_83F844;
L_83F844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF844u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF844u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F844 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F844u);return;} hw.unresolvedReturn(0x83F844u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F845:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF845u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF845u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F845 ASL
    cpu.aslA();
    goto L_83F846;
L_83F846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF846u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF846u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F846 SEP
    cpu.sep(0x20u);
    goto L_83F848;
L_83F848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF848u,cpu,0x2Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF848u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F848 ROL
    cpu.rolA();
    goto L_83F849;
L_83F849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u,cpu,0x59u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF849u, 4u + 1u, 3u, cpu.address("absy", 0x0007u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F849 EOR
    cpu.logicXor(hw.readW(cpu.address("absy", 0x7u), cpu.m8?8:16));
    goto L_83F84C;
L_83F84C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Cu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84C LSR
    cpu.lsrA();
    goto L_83F84D;
L_83F84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84D BCC -> $83F8BA
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8BA; }
    goto L_83F84F;
L_83F84F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF84Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF84Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F84F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F851;
L_83F851:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF851u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF851u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F851 AND
    cpu.logicAnd(0xF0u);
    goto L_83F853;
L_83F853:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF853u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF853u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F853 SEC
    cpu.setFlag('C', true);
    goto L_83F854;
L_83F854:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF854u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF854u,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF854u, 4u + 1u, 3u, cpu.address("absy", 0x0003u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F854 SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x3u), cpu.m8?8:16));
    goto L_83F857;
L_83F857:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF857u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF857u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF857u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F857 BEQ -> $83F869
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F869; }
    goto L_83F859;
L_83F859:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF859u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF859u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F859 ASL
    cpu.aslA();
    goto L_83F85A;
L_83F85A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85A LDA
    cpu.setA(0x82u, 8);
    goto L_83F85C;
L_83F85C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Cu,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85C BCC -> $83F860
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F860; }
    goto L_83F85E;
L_83F85E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF85Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF85Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F85E LDA
    cpu.setA(0x81u, 8);
    goto L_83F860;
L_83F860:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF860u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF860u, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F860 STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F863;
L_83F863:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF863u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF863u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF863u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F863 REP
    cpu.rep(0x20u);
    goto L_83F865;
L_83F865:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF865u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF865u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F865 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF867u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF868u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F865u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F868;
L_83F868:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF868u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F868 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F868u);return;} hw.unresolvedReturn(0x83F868u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF868u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F868 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F868u);return;} hw.unresolvedReturn(0x83F868u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF868u,0x83F868u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F869:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF869u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF869u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F869 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F86C;
L_83F86C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F86C BEQ -> $83F863
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F863; }
    goto L_83F86E;
L_83F86E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF86Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF86Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F86E REP
    cpu.rep(0x20u);
    goto L_83F870;
L_83F870:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF870u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF870u, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F870 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F873;
L_83F873:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF873u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF873u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F873 BNE -> $83F89A
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F89A; }
    goto L_83F875;
L_83F875:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF875u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF875u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F875 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF878u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF879u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F875u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F879;
L_83F879:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF879u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF879u,0x83F879u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF879u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F879 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F87C;
L_83F87C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Cu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F87C CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F87E;
L_83F87E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF87Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF87Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F87E BMI -> $83F89D
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83F89D; }
    goto L_83F880;
L_83F880:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF880u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF880u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF880u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F880 SEP
    cpu.sep(0x20u);
    goto L_83F882;
L_83F882:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF882u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF882u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F882 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F884;
L_83F884:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF884u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF884u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F884 TAY
    cpu.transfer("TAY");
    goto L_83F885;
L_83F885:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF885u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF885u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F885 SEC
    cpu.setFlag('C', true);
    goto L_83F886;
L_83F886:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF886u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF886u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F886 SBC
    cpu.sbc(0x20u);
    goto L_83F888;
L_83F888:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF888u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF888u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F888 CMP
    cpu.compareA(0x80u);
    goto L_83F88A;
L_83F88A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88A TYA
    cpu.transfer("TYA");
    goto L_83F88B;
L_83F88B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88B BCS -> $83F895
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F895; }
    goto L_83F88D;
L_83F88D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88D SBC
    cpu.sbc(0x3Fu);
    goto L_83F88F;
L_83F88F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF88Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF88Fu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F88F STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F892;
L_83F892:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF892u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF892u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F892 REP
    cpu.rep(0x20u);
    goto L_83F894;
L_83F894:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF894u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF894u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F894 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F894u);return;} hw.unresolvedReturn(0x83F894u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F895:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF895u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF895u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F895 ADC
    cpu.adc(0x3Fu);
    goto L_83F897;
L_83F897:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF897u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF897u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F897 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F89A;
L_83F89A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89A REP
    cpu.rep(0x20u);
    goto L_83F89C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89A REP
    cpu.rep(0x20u);
    goto L_83F89C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF89Au,0x83F89Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F89C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F89C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F89Cu);return;} hw.unresolvedReturn(0x83F89Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F89D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89D SEP
    cpu.sep(0x20u);
    goto L_83F89F;
L_83F89F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF89Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF89Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F89F LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8A1;
L_83F8A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A1 TAY
    cpu.transfer("TAY");
    goto L_83F8A2;
L_83F8A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A2 SEC
    cpu.setFlag('C', true);
    goto L_83F8A3;
L_83F8A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A3 SBC
    cpu.sbc(0x20u);
    goto L_83F8A5;
L_83F8A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A5 CMP
    cpu.compareA(0x80u);
    goto L_83F8A7;
L_83F8A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A7u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A7 TYA
    cpu.transfer("TYA");
    goto L_83F8A8;
L_83F8A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8A8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8A8 BCS -> $83F8B2
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8B2; }
    goto L_83F8AA;
L_83F8AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AA ADC
    cpu.adc(0x40u);
    goto L_83F8AC;
L_83F8AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ACu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8ACu, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AC STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F8AF;
L_83F8AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8AFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8AF REP
    cpu.rep(0x20u);
    goto L_83F8B1;
L_83F8B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B1u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8B1 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8B1u);return;} hw.unresolvedReturn(0x83F8B1u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F8B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B2 SBC
    cpu.sbc(0x40u);
    goto L_83F8B4;
L_83F8B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B4u, 5u, 3u, cpu.address("absx", 0x1098u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B4 STA
    hw.write(cpu.address("absx", 0x1098u), cpu.a, cpu.m8?8:16);
    goto L_83F8B7;
L_83F8B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8B7 REP
    cpu.rep(0x20u);
    goto L_83F8B9;
L_83F8B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8B9u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8B9 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8B9u);return;} hw.unresolvedReturn(0x83F8B9u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_83F8BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BA LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8BC;
L_83F8BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BC AND
    cpu.logicAnd(0xF0u);
    goto L_83F8BE;
L_83F8BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BE SEC
    cpu.setFlag('C', true);
    goto L_83F8BF;
L_83F8BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu,cpu,0xF9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8BFu, 4u + 1u, 3u, cpu.address("absy", 0x0002u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8BF SBC
    cpu.sbc(hw.readW(cpu.address("absy", 0x2u), cpu.m8?8:16));
    goto L_83F8C2;
L_83F8C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C2u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C2 BEQ -> $83F8D4
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F8D4; }
    goto L_83F8C4;
L_83F8C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C4 ASL
    cpu.aslA();
    goto L_83F8C5;
L_83F8C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C5 LDA
    cpu.setA(0x82u, 8);
    goto L_83F8C7;
L_83F8C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C7 BCC -> $83F8CB
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83F8CB; }
    goto L_83F8C9;
L_83F8C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8C9 LDA
    cpu.setA(0x81u, 8);
    goto L_83F8CB;
L_83F8CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CBu, 4u, 3u, cpu.address("abs", 0x1BB1u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8CB STA
    hw.write(cpu.address("abs", 0x1BB1u), cpu.a, cpu.m8?8:16);
    goto L_83F8CE;
L_83F8CE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8CEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8CEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8CE REP
    cpu.rep(0x20u);
    goto L_83F8D0;
L_83F8D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D0u, 6u, 3u, cpu.address("abs", 0xFDA6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83F8D0 JSR -> $83FDA6 stack real
    { cpu.push16Value(hw,0xF8D2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8D3u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xFDA6u), 0x83F8D0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F8D3;
L_83F8D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8D3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8D3u);return;} hw.unresolvedReturn(0x83F8D3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8D3 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x83F8D3u);return;} hw.unresolvedReturn(0x83F8D3u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8D3u,0x83F8D3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_83F8D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D4u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D4u, 4u + 1u, 3u, cpu.address("absx", 0x10A8u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D4 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10A8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8D7;
L_83F8D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D7 BEQ -> $83F8CE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_83F8CE; }
    goto L_83F8D9;
L_83F8D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8D9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8D9 REP
    cpu.rep(0x20u);
    goto L_83F8DB;
L_83F8DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DBu, 5u + 1u, 3u, cpu.address("absx", 0x10BEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8DB LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8DE;
L_83F8DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8DE BNE -> $83F905
    if (!cpu.z) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F905u,0x83F8DEu); return; }
    goto L_83F8E0;
L_83F8E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E0u, 8u, 4u, 0x84851Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $83F8E0 JSL -> $84851D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xF8E3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xF8E4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84851Du, 0x83F8E0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_83F8E4;
L_83F8E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8E4u,0x83F8E4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E4u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E4u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E4 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8E7;
L_83F8E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u,cpu,0xD5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E7u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E7 CMP
    cpu.compareA(hw.readW(cpu.address("dpx", 0xAu), cpu.m8?8:16));
    goto L_83F8E9;
L_83F8E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8E9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8E9 BMI -> $83F908
    if (cpu.n) { hw.addCpuInternalCycles(1u); hw.requestDispatch(0x83F908u,0x83F8E9u); return; }
    goto L_83F8EB;
L_83F8EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EBu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EBu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8EB SEP
    cpu.sep(0x20u);
    goto L_83F8ED;
L_83F8ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8ED LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83F8EF;
L_83F8EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xF8EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xF8EFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83F8EF TAY
    cpu.transfer("TAY");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xF8F0u,0x83F8EFu); return;
}

void sub_849049_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849049u: goto L_849049;
    case 0x84904Cu: goto L_84904C;
    case 0x84904Eu: goto L_84904E;
    case 0x849052u: goto L_849052;
    case 0x849054u: goto L_849054;
    case 0x849055u: goto L_849055;
    case 0x849059u: goto L_849059;
    case 0x84905Bu: goto L_84905B;
    case 0x84905Eu: goto L_84905E;
    case 0x849060u: goto L_849060;
    case 0x849063u: goto L_849063;
    case 0x849065u: goto L_849065;
    case 0x849068u: goto L_849068;
    case 0x84906Au: goto L_84906A;
    case 0x84906Du: goto L_84906D;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849074u: goto L_849074;
    case 0x849076u: goto L_849076;
    case 0x849078u: goto L_849078;
    case 0x84907Au: goto L_84907A;
    case 0x84907Cu: goto L_84907C;
    case 0x84907Du: goto L_84907D;
    case 0x84907Eu: goto L_84907E;
    case 0x84907Fu: goto L_84907F;
    case 0x849080u: goto L_849080;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849049 LDY
    cpu.setY(0xEu, 16);
    goto L_84904C;
L_84904C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904C STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_84904E;
L_84904E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904E BRA -> $849052
    goto L_849052;
L_849052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849052 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 TXY
    cpu.transfer("TXY");
    goto L_849055;
L_849055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 8u, 4u, 0x8486B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849055 JSL -> $8486B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9058u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9059u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486B2u, 0x849055u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849059;
L_849059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9059u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9059u,0x849059u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Bu,0x84905Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Eu,0x84905Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9060u,0x849060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9063u,0x849063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9065u,0x849065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9068u,0x849068u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Au,0x84906Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x84906Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Fu,0x84906Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9072u,0x849072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9074u,0x849074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9076u,0x849076u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9078u,0x849078u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Au,0x84907Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Cu,0x84907Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Du,0x84907Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84907E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x84907Eu);return;} hw.unresolvedReturn(0x84907Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_84907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x84907Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9080u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9080u,0x849080u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_849049_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x849049u: goto L_849049;
    case 0x84904Cu: goto L_84904C;
    case 0x84904Eu: goto L_84904E;
    case 0x849052u: goto L_849052;
    case 0x849054u: goto L_849054;
    case 0x849055u: goto L_849055;
    case 0x849059u: goto L_849059;
    case 0x84905Bu: goto L_84905B;
    case 0x84905Eu: goto L_84905E;
    case 0x849060u: goto L_849060;
    case 0x849063u: goto L_849063;
    case 0x849065u: goto L_849065;
    case 0x849068u: goto L_849068;
    case 0x84906Au: goto L_84906A;
    case 0x84906Du: goto L_84906D;
    case 0x84906Fu: goto L_84906F;
    case 0x849072u: goto L_849072;
    case 0x849074u: goto L_849074;
    case 0x849076u: goto L_849076;
    case 0x849078u: goto L_849078;
    case 0x84907Au: goto L_84907A;
    case 0x84907Cu: goto L_84907C;
    case 0x84907Du: goto L_84907D;
    case 0x84907Eu: goto L_84907E;
    case 0x84907Fu: goto L_84907F;
    case 0x849080u: goto L_849080;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_849049:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9049u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9049u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849049 LDY
    cpu.setY(0xEu, 16);
    goto L_84904C;
L_84904C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904C STY
    hw.write(cpu.address("dp", 0xCu), cpu.y, cpu.x8?8:16);
    goto L_84904E;
L_84904E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x904Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x904Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84904E BRA -> $849052
    goto L_849052;
L_849052:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9052u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9052u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849052 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849054;
L_849054:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9054u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9054u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849054 TXY
    cpu.transfer("TXY");
    goto L_849055;
L_849055:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9055u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9055u, 8u, 4u, 0x8486B2u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $849055 JSL -> $8486B2 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9058u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9059u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8486B2u, 0x849055u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_849059;
L_849059:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9059u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9059u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849059 BCS -> $84907F
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_84907F; }
    goto L_84905B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9059u,0x849059u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905B LDA
    cpu.setA(0x28u, 16);
    goto L_84905E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Bu,0x84905Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84905E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x905Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x905Eu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84905E STA
    hw.write(cpu.address("dpx", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_849060;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x905Eu,0x84905Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849060:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9060u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9060u, 5u + 1u, 3u, cpu.address("absy", 0x000Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849060 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849063;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9060u,0x849060u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849063:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9063u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9063u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849063 STA
    hw.write(cpu.address("dpx", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_849065;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9063u,0x849063u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849065:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9065u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9065u, 5u + 1u, 3u, cpu.address("absy", 0x000Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849065 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849068;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9065u,0x849065u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849068:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9068u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9068u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x0Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849068 STA
    hw.write(cpu.address("dpx", 0xEu), cpu.a, cpu.m8?8:16);
    goto L_84906A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9068u,0x849068u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Au, 5u + 1u, 3u, cpu.address("absy", 0x0014u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906A LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x14u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84906D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Au,0x84906Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Du, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906D STA
    hw.write(cpu.address("dpx", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_84906F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Du,0x84906Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84906F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x906Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x906Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84906F LDA
    cpu.setA(0x2000u, 16);
    goto L_849072;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x906Fu,0x84906Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849072:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9072u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9072u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849072 STA
    hw.write(cpu.address("dpx", 0x4u), cpu.a, cpu.m8?8:16);
    goto L_849074;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9072u,0x849072u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849074:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9074u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9074u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849074 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_849076;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9074u,0x849074u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849076:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9076u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9076u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849076 STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_849078;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9076u,0x849076u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849078:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9078u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9078u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $849078 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_84907A;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9078u,0x849078u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Au))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Au, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907A STA
    hw.write(cpu.address("dpx", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_84907C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Au,0x84907Au); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907C TYX
    cpu.transfer("TYX");
    goto L_84907D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Cu,0x84907Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907D CLC
    cpu.setFlag('C', false);
    goto L_84907E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Du,0x84907Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_84907E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $84907E RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x84907Eu);return;} hw.unresolvedReturn(0x84907Eu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_84907F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x907Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x907Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $84907F TYX
    cpu.transfer("TYX");
    goto L_849080;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x907Fu,0x84907Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_849080:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9080u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9080u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $849080 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x849080u);return;} hw.unresolvedReturn(0x849080u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9080u,0x849080u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

