#include "generated.hpp"
void sub_80890B_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80890Bu: goto L_80890B;
    case 0x80890Du: goto L_80890D;
    case 0x808911u: goto L_808911;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80890B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80890B STZ
    hw.write(cpu.address("dp", 0x78u), 0, cpu.m8?8:16);
    goto L_80890D;
L_80890D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x890Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x890Du, 8u, 4u, 0x808B0Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80890D JSL -> $808B0D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8910u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8911u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808B0Du, 0x80890Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_808911;
L_808911:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8911u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8911u,0x808911u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8911u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $808911 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x808911u);return;} hw.unresolvedReturn(0x808911u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_809224_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x809224u: goto L_809224;
    case 0x809225u: goto L_809225;
    case 0x809229u: goto L_809229;
    case 0x80922Au: goto L_80922A;
    case 0x80922Bu: goto L_80922B;
    case 0x80922Eu: goto L_80922E;
    case 0x80922Fu: goto L_80922F;
    case 0x809230u: goto L_809230;
    case 0x809234u: goto L_809234;
    case 0x809236u: goto L_809236;
    case 0x809239u: goto L_809239;
    case 0x80923Bu: goto L_80923B;
    case 0x80923Fu: goto L_80923F;
    case 0x809241u: goto L_809241;
    case 0x809245u: goto L_809245;
    case 0x809246u: goto L_809246;
    case 0x809247u: goto L_809247;
    case 0x80924Au: goto L_80924A;
    case 0x80924Cu: goto L_80924C;
    case 0x809250u: goto L_809250;
    case 0x809251u: goto L_809251;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_809224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9224u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809224 PHX
    cpu.push("PHX", hw);
    goto L_809225;
L_809225:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9225u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9225u, 6u, 4u, 0x7EFE00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809225 LDA
    cpu.loadA(hw.readW(0x7EFE00u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_809229;
L_809229:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9229u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9229u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809229 TAY
    cpu.transfer("TAY");
    goto L_80922A;
L_80922A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80922A TAX
    cpu.transfer("TAX");
    goto L_80922B;
L_80922B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80922B LDA
    cpu.setA(0xFFFEu, 16);
    goto L_80922E;
L_80922E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80922E INC
    cpu.inc('A');
    goto L_80922F;
L_80922F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x922Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x922Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80922F INC
    cpu.inc('A');
    goto L_809230;
L_809230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9230u, 6u, 4u, 0x7EFE02u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809230 CMP
    cpu.compareA(hw.readW(0x7EFE02u, cpu.m8?8:16));
    goto L_809234;
L_809234:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9234u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9234u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809234 BEQ -> $80922E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80922E; }
    goto L_809236;
L_809236:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9236u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9236u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809236 CPY
    cpu.compareY(0x0u);
    goto L_809239;
L_809239:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9239u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9239u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809239 BEQ -> $809241
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_809241; }
    goto L_80923B;
L_80923B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Bu, 6u, 4u, 0x7EFE04u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80923B CMP
    cpu.compareA(hw.readW(0x7EFE04u, cpu.m8?8:16));
    goto L_80923F;
L_80923F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x923Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x923Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80923F BEQ -> $80922E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80922E; }
    goto L_809241;
L_809241:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9241u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9241u, 6u, 4u, ((0x7EFE04u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809241 STA
    hw.write(((0x7EFE04u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_809245;
L_809245:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9245u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9245u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809245 INX
    cpu.inc('X');
    goto L_809246;
L_809246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9246u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809246 INX
    cpu.inc('X');
    goto L_809247;
L_809247:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9247u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9247u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $809247 CPX
    cpu.compareX(0xAu);
    goto L_80924A;
L_80924A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80924A BCC -> $80922E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80922E; }
    goto L_80924C;
L_80924C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x924Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x924Cu, 8u, 4u, 0x809252u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80924C JSL -> $809252 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x924Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9250u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x809252u, 0x80924Cu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_809250;
L_809250:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9250u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9250u,0x809250u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9250u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $809250 PLX
    cpu.pop("PLX", hw);
    goto L_809251;
L_809251:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9251u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9251u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $809251 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x809251u);return;} hw.unresolvedReturn(0x809251u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80929D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80929Du: goto L_80929D;
    case 0x8092A0u: goto L_8092A0;
    case 0x8092A2u: goto L_8092A2;
    case 0x8092A5u: goto L_8092A5;
    case 0x8092A8u: goto L_8092A8;
    case 0x8092ABu: goto L_8092AB;
    case 0x8092ADu: goto L_8092AD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80929D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x929Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x929Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80929D LDA
    cpu.setA(0x4u, 16);
    goto L_8092A0;
L_8092A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8092A0 STA
    hw.write(cpu.address("dpx", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_8092A2;
L_8092A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A2u, 6u, 3u, cpu.address("absx", 0x10B8u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8092A2 STZ
    hw.write(cpu.address("absx", 0x10B8u), 0, cpu.m8?8:16);
    goto L_8092A5;
L_8092A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A5u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A5u, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8092A5 STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_8092A8;
L_8092A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8092A8 LDA
    cpu.setA(0x10u, 16);
    goto L_8092AB;
L_8092AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8092AB STA
    hw.write(cpu.address("dpx", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_8092AD;
L_8092AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x92ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x92ADu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8092AD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8092ADu);return;} hw.unresolvedReturn(0x8092ADu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8098B7_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098B7u: goto L_8098B7;
    case 0x8098B9u: goto L_8098B9;
    case 0x8098BDu: goto L_8098BD;
    case 0x8098BEu: goto L_8098BE;
    case 0x8098C2u: goto L_8098C2;
    case 0x8098C4u: goto L_8098C4;
    case 0x8098C8u: goto L_8098C8;
    case 0x8098C9u: goto L_8098C9;
    case 0x8098CAu: goto L_8098CA;
    case 0x8098CDu: goto L_8098CD;
    case 0x8098CFu: goto L_8098CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098B9;
L_8098B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B9 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098BD;
L_8098BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BD TYA
    cpu.transfer("TYA");
    goto L_8098BE;
L_8098BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BE STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C2;
L_8098C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098C4;
L_8098C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C4 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C8;
L_8098C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C8 TXA
    cpu.transfer("TXA");
    goto L_8098C9;
L_8098C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C9 CLC
    cpu.setFlag('C', false);
    goto L_8098CA;
L_8098CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CA ADC
    cpu.adc(0x8u);
    goto L_8098CD;
L_8098CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CD STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8098CF;
L_8098CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098CFu);return;} hw.unresolvedReturn(0x8098CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8098B7_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098B7u: goto L_8098B7;
    case 0x8098B9u: goto L_8098B9;
    case 0x8098BDu: goto L_8098BD;
    case 0x8098BEu: goto L_8098BE;
    case 0x8098C2u: goto L_8098C2;
    case 0x8098C4u: goto L_8098C4;
    case 0x8098C8u: goto L_8098C8;
    case 0x8098C9u: goto L_8098C9;
    case 0x8098CAu: goto L_8098CA;
    case 0x8098CDu: goto L_8098CD;
    case 0x8098CFu: goto L_8098CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098B9;
L_8098B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B9 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098BD;
L_8098BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BD TYA
    cpu.transfer("TYA");
    goto L_8098BE;
L_8098BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BE STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C2;
L_8098C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098C4;
L_8098C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C4 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C8;
L_8098C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C8 TXA
    cpu.transfer("TXA");
    goto L_8098C9;
L_8098C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C9 CLC
    cpu.setFlag('C', false);
    goto L_8098CA;
L_8098CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CA ADC
    cpu.adc(0x8u);
    goto L_8098CD;
L_8098CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CD STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8098CF;
L_8098CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098CFu);return;} hw.unresolvedReturn(0x8098CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_8098B7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8098B7u: goto L_8098B7;
    case 0x8098B9u: goto L_8098B9;
    case 0x8098BDu: goto L_8098BD;
    case 0x8098BEu: goto L_8098BE;
    case 0x8098C2u: goto L_8098C2;
    case 0x8098C4u: goto L_8098C4;
    case 0x8098C8u: goto L_8098C8;
    case 0x8098C9u: goto L_8098C9;
    case 0x8098CAu: goto L_8098CA;
    case 0x8098CDu: goto L_8098CD;
    case 0x8098CFu: goto L_8098CF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8098B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B7 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x50u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_8098B9;
L_8098B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98B9u, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098B9 STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098BD;
L_8098BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BD TYA
    cpu.transfer("TYA");
    goto L_8098BE;
L_8098BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98BEu, 6u, 4u, ((0x7E0002u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098BE STA
    hw.write(((0x7E0002u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C2;
L_8098C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8098C4;
L_8098C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C4u, 6u, 4u, ((0x7E0004u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C4 STA
    hw.write(((0x7E0004u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_8098C8;
L_8098C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C8 TXA
    cpu.transfer("TXA");
    goto L_8098C9;
L_8098C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98C9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098C9 CLC
    cpu.setFlag('C', false);
    goto L_8098CA;
L_8098CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CA ADC
    cpu.adc(0x8u);
    goto L_8098CD;
L_8098CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x50u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8098CD STA
    hw.write(cpu.address("dp", 0x50u), cpu.a, cpu.m8?8:16);
    goto L_8098CF;
L_8098CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x98CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x98CFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8098CF RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8098CFu);return;} hw.unresolvedReturn(0x8098CFu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A9C0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A9C0u: goto L_80A9C0;
    case 0x80A9C2u: goto L_80A9C2;
    case 0x80A9C4u: goto L_80A9C4;
    case 0x80A9C6u: goto L_80A9C6;
    case 0x80A9C9u: goto L_80A9C9;
    case 0x80A9EBu: goto L_80A9EB;
    case 0x80A9EDu: goto L_80A9ED;
    case 0x80A9F0u: goto L_80A9F0;
    case 0x80A9F2u: goto L_80A9F2;
    case 0x80A9F5u: goto L_80A9F5;
    case 0x80A9F6u: goto L_80A9F6;
    case 0x80A9F7u: goto L_80A9F7;
    case 0x80A9F9u: goto L_80A9F9;
    case 0x80A9FDu: goto L_80A9FD;
    case 0x80A9FFu: goto L_80A9FF;
    case 0x80AA01u: goto L_80AA01;
    case 0x80AA04u: goto L_80AA04;
    case 0x80AA05u: goto L_80AA05;
    case 0x80AA07u: goto L_80AA07;
    case 0x80AA0Au: goto L_80AA0A;
    case 0x80AA0Du: goto L_80AA0D;
    case 0x80AA0Fu: goto L_80AA0F;
    case 0x80AA12u: goto L_80AA12;
    case 0x80AA14u: goto L_80AA14;
    case 0x80AA17u: goto L_80AA17;
    case 0x80AA19u: goto L_80AA19;
    case 0x80AA1Cu: goto L_80AA1C;
    case 0x80AA1Eu: goto L_80AA1E;
    case 0x80AA20u: goto L_80AA20;
    case 0x80AA22u: goto L_80AA22;
    case 0x80AA25u: goto L_80AA25;
    case 0x80AA27u: goto L_80AA27;
    case 0x80AA2Bu: goto L_80AA2B;
    case 0x80AA2Du: goto L_80AA2D;
    case 0x80AA30u: goto L_80AA30;
    case 0x80AA31u: goto L_80AA31;
    case 0x80AA33u: goto L_80AA33;
    case 0x80AA35u: goto L_80AA35;
    case 0x80AA37u: goto L_80AA37;
    case 0x80AA3Bu: goto L_80AA3B;
    case 0x80AA3Du: goto L_80AA3D;
    case 0x80AA41u: goto L_80AA41;
    case 0x80AA43u: goto L_80AA43;
    case 0x80AA46u: goto L_80AA46;
    case 0x80AA49u: goto L_80AA49;
    case 0x80AA4Au: goto L_80AA4A;
    case 0x80AA4Cu: goto L_80AA4C;
    case 0x80AA4Eu: goto L_80AA4E;
    case 0x80AA4Fu: goto L_80AA4F;
    case 0x80AA51u: goto L_80AA51;
    case 0x80AA54u: goto L_80AA54;
    case 0x80AA56u: goto L_80AA56;
    case 0x80AA58u: goto L_80AA58;
    case 0x80AA5Cu: goto L_80AA5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80A9C2;
L_80A9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C2 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9C4;
L_80A9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9C6;
L_80A9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C6 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9C9;
L_80A9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C9 BRA -> $80A9F9
    goto L_80A9F9;
L_80A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9EB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9ED;
L_80A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9ED LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9F0;
L_80A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F0 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9F2;
L_80A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F2 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9F5;
L_80A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F5 INX
    cpu.inc('X');
    goto L_80A9F6;
L_80A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F6 INX
    cpu.inc('X');
    goto L_80A9F7;
L_80A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F7 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9F9;
L_80A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9F9u,0x80A9F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9FDu,0x80A9FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FD STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80A9FF;
L_80A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA01;
L_80AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA04;
L_80AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA04 INX
    cpu.inc('X');
    goto L_80AA05;
L_80AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA05 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA07;
L_80AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA07 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA0A;
L_80AA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0A CMP
    cpu.compareA(0xFFu);
    goto L_80AA0D;
L_80AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0D BEQ -> $80AA56
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA56; }
    goto L_80AA0F;
L_80AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0F CMP
    cpu.compareA(0xFEu);
    goto L_80AA12;
L_80AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA12 BEQ -> $80AA37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA37; }
    goto L_80AA14;
L_80AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA14 CMP
    cpu.compareA(0xFDu);
    goto L_80AA17;
L_80AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA17 BEQ -> $80AA2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA2D; }
    goto L_80AA19;
L_80AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA19 CMP
    cpu.compareA(0xFBu);
    goto L_80AA1C;
L_80AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1C BEQ -> $80AA3D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA3D; }
    goto L_80AA1E;
L_80AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA20;
L_80AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA20 BEQ -> $80AA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA25; }
    goto L_80AA22;
L_80AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA22 LDA
    cpu.setA(0x0u, 16);
    goto L_80AA25;
L_80AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA25 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80AA27;
L_80AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA27 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x80AA27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA2B;
L_80AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,0x80AA2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2B BRA -> $80A9FF
    goto L_80A9FF;
L_80AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA30;
L_80AA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA30 INX
    cpu.inc('X');
    goto L_80AA31;
L_80AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA31 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA33;
L_80AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA33 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_80AA35;
L_80AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA35 BRA -> $80A9FF
    goto L_80A9FF;
L_80AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA37 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA37u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA3B;
L_80AA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,0x80AA3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA3B BRA -> $80A9EB
    goto L_80A9EB;
L_80AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA3D JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA41;
L_80AA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA41u,0x80AA41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA41 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA43;
L_80AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA43 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA46;
L_80AA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA46 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA49;
L_80AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA49 CLC
    cpu.setFlag('C', false);
    goto L_80AA4A;
L_80AA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80AA4C;
L_80AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4C STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80AA4E;
L_80AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4E TAY
    cpu.transfer("TAY");
    goto L_80AA4F;
L_80AA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80AA51;
L_80AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA51 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80AA54;
L_80AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA54 BRA -> $80A9F9
    goto L_80A9F9;
L_80AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA56 STZ
    hw.write(cpu.address("dp", 0x8Cu), 0, cpu.m8?8:16);
    goto L_80AA58;
L_80AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA58 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA5C;
L_80AA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,0x80AA5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA5C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AA5Cu);return;} hw.unresolvedReturn(0x80AA5Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A9C0_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A9C0u: goto L_80A9C0;
    case 0x80A9C2u: goto L_80A9C2;
    case 0x80A9C4u: goto L_80A9C4;
    case 0x80A9C6u: goto L_80A9C6;
    case 0x80A9C9u: goto L_80A9C9;
    case 0x80A9EBu: goto L_80A9EB;
    case 0x80A9EDu: goto L_80A9ED;
    case 0x80A9F0u: goto L_80A9F0;
    case 0x80A9F2u: goto L_80A9F2;
    case 0x80A9F5u: goto L_80A9F5;
    case 0x80A9F6u: goto L_80A9F6;
    case 0x80A9F7u: goto L_80A9F7;
    case 0x80A9F9u: goto L_80A9F9;
    case 0x80A9FDu: goto L_80A9FD;
    case 0x80A9FFu: goto L_80A9FF;
    case 0x80AA01u: goto L_80AA01;
    case 0x80AA04u: goto L_80AA04;
    case 0x80AA05u: goto L_80AA05;
    case 0x80AA07u: goto L_80AA07;
    case 0x80AA0Au: goto L_80AA0A;
    case 0x80AA0Du: goto L_80AA0D;
    case 0x80AA0Fu: goto L_80AA0F;
    case 0x80AA12u: goto L_80AA12;
    case 0x80AA14u: goto L_80AA14;
    case 0x80AA17u: goto L_80AA17;
    case 0x80AA19u: goto L_80AA19;
    case 0x80AA1Cu: goto L_80AA1C;
    case 0x80AA1Eu: goto L_80AA1E;
    case 0x80AA20u: goto L_80AA20;
    case 0x80AA22u: goto L_80AA22;
    case 0x80AA25u: goto L_80AA25;
    case 0x80AA27u: goto L_80AA27;
    case 0x80AA2Bu: goto L_80AA2B;
    case 0x80AA2Du: goto L_80AA2D;
    case 0x80AA30u: goto L_80AA30;
    case 0x80AA31u: goto L_80AA31;
    case 0x80AA33u: goto L_80AA33;
    case 0x80AA35u: goto L_80AA35;
    case 0x80AA37u: goto L_80AA37;
    case 0x80AA3Bu: goto L_80AA3B;
    case 0x80AA3Du: goto L_80AA3D;
    case 0x80AA41u: goto L_80AA41;
    case 0x80AA43u: goto L_80AA43;
    case 0x80AA46u: goto L_80AA46;
    case 0x80AA49u: goto L_80AA49;
    case 0x80AA4Au: goto L_80AA4A;
    case 0x80AA4Cu: goto L_80AA4C;
    case 0x80AA4Eu: goto L_80AA4E;
    case 0x80AA4Fu: goto L_80AA4F;
    case 0x80AA51u: goto L_80AA51;
    case 0x80AA54u: goto L_80AA54;
    case 0x80AA56u: goto L_80AA56;
    case 0x80AA58u: goto L_80AA58;
    case 0x80AA5Cu: goto L_80AA5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80A9C2;
L_80A9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C2 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9C4;
L_80A9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9C6;
L_80A9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C6 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9C9;
L_80A9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C9 BRA -> $80A9F9
    goto L_80A9F9;
L_80A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9EB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9ED;
L_80A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9ED LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9F0;
L_80A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F0 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9F2;
L_80A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F2 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9F5;
L_80A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F5 INX
    cpu.inc('X');
    goto L_80A9F6;
L_80A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F6 INX
    cpu.inc('X');
    goto L_80A9F7;
L_80A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F7 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9F9;
L_80A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9F9u,0x80A9F9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9FDu,0x80A9FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FD STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80A9FF;
L_80A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA01;
L_80AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA04;
L_80AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA04 INX
    cpu.inc('X');
    goto L_80AA05;
L_80AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA05 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA07;
L_80AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA07 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA0A;
L_80AA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0A CMP
    cpu.compareA(0xFFu);
    goto L_80AA0D;
L_80AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0D BEQ -> $80AA56
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA56; }
    goto L_80AA0F;
L_80AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0F CMP
    cpu.compareA(0xFEu);
    goto L_80AA12;
L_80AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA12 BEQ -> $80AA37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA37; }
    goto L_80AA14;
L_80AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA14 CMP
    cpu.compareA(0xFDu);
    goto L_80AA17;
L_80AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA17 BEQ -> $80AA2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA2D; }
    goto L_80AA19;
L_80AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA19 CMP
    cpu.compareA(0xFBu);
    goto L_80AA1C;
L_80AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1C BEQ -> $80AA3D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA3D; }
    goto L_80AA1E;
L_80AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA20;
L_80AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA20 BEQ -> $80AA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA25; }
    goto L_80AA22;
L_80AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA22 LDA
    cpu.setA(0x0u, 16);
    goto L_80AA25;
L_80AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA25 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80AA27;
L_80AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA27 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x80AA27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA2B;
L_80AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,0x80AA2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2B BRA -> $80A9FF
    goto L_80A9FF;
L_80AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA30;
L_80AA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA30 INX
    cpu.inc('X');
    goto L_80AA31;
L_80AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA31 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA33;
L_80AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA33 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_80AA35;
L_80AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA35 BRA -> $80A9FF
    goto L_80A9FF;
L_80AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA37 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA37u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA3B;
L_80AA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,0x80AA3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA3B BRA -> $80A9EB
    goto L_80A9EB;
L_80AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA3D JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA41;
L_80AA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA41u,0x80AA41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA41 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA43;
L_80AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA43 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA46;
L_80AA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA46 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA49;
L_80AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA49 CLC
    cpu.setFlag('C', false);
    goto L_80AA4A;
L_80AA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80AA4C;
L_80AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4C STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80AA4E;
L_80AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4E TAY
    cpu.transfer("TAY");
    goto L_80AA4F;
L_80AA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80AA51;
L_80AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA51 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80AA54;
L_80AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA54 BRA -> $80A9F9
    goto L_80A9F9;
L_80AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA56 STZ
    hw.write(cpu.address("dp", 0x8Cu), 0, cpu.m8?8:16);
    goto L_80AA58;
L_80AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA58 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA5C;
L_80AA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,0x80AA5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA5C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AA5Cu);return;} hw.unresolvedReturn(0x80AA5Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80A9C0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80A9C0u: goto L_80A9C0;
    case 0x80A9C2u: goto L_80A9C2;
    case 0x80A9C4u: goto L_80A9C4;
    case 0x80A9C6u: goto L_80A9C6;
    case 0x80A9C9u: goto L_80A9C9;
    case 0x80A9EBu: goto L_80A9EB;
    case 0x80A9EDu: goto L_80A9ED;
    case 0x80A9F0u: goto L_80A9F0;
    case 0x80A9F2u: goto L_80A9F2;
    case 0x80A9F5u: goto L_80A9F5;
    case 0x80A9F6u: goto L_80A9F6;
    case 0x80A9F7u: goto L_80A9F7;
    case 0x80A9F9u: goto L_80A9F9;
    case 0x80A9FDu: goto L_80A9FD;
    case 0x80A9FFu: goto L_80A9FF;
    case 0x80AA01u: goto L_80AA01;
    case 0x80AA04u: goto L_80AA04;
    case 0x80AA05u: goto L_80AA05;
    case 0x80AA07u: goto L_80AA07;
    case 0x80AA0Au: goto L_80AA0A;
    case 0x80AA0Du: goto L_80AA0D;
    case 0x80AA0Fu: goto L_80AA0F;
    case 0x80AA12u: goto L_80AA12;
    case 0x80AA14u: goto L_80AA14;
    case 0x80AA17u: goto L_80AA17;
    case 0x80AA19u: goto L_80AA19;
    case 0x80AA1Cu: goto L_80AA1C;
    case 0x80AA1Eu: goto L_80AA1E;
    case 0x80AA20u: goto L_80AA20;
    case 0x80AA22u: goto L_80AA22;
    case 0x80AA25u: goto L_80AA25;
    case 0x80AA27u: goto L_80AA27;
    case 0x80AA2Bu: goto L_80AA2B;
    case 0x80AA2Du: goto L_80AA2D;
    case 0x80AA30u: goto L_80AA30;
    case 0x80AA31u: goto L_80AA31;
    case 0x80AA33u: goto L_80AA33;
    case 0x80AA35u: goto L_80AA35;
    case 0x80AA37u: goto L_80AA37;
    case 0x80AA3Bu: goto L_80AA3B;
    case 0x80AA3Du: goto L_80AA3D;
    case 0x80AA41u: goto L_80AA41;
    case 0x80AA43u: goto L_80AA43;
    case 0x80AA46u: goto L_80AA46;
    case 0x80AA49u: goto L_80AA49;
    case 0x80AA4Au: goto L_80AA4A;
    case 0x80AA4Cu: goto L_80AA4C;
    case 0x80AA4Eu: goto L_80AA4E;
    case 0x80AA4Fu: goto L_80AA4F;
    case 0x80AA51u: goto L_80AA51;
    case 0x80AA54u: goto L_80AA54;
    case 0x80AA56u: goto L_80AA56;
    case 0x80AA58u: goto L_80AA58;
    case 0x80AA5Cu: goto L_80AA5C;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80A9C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C0 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_80A9C2;
L_80A9C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C2 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9C4;
L_80A9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C4 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9C6;
L_80A9C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C6 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9C9;
L_80A9C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9C9u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9C9 BRA -> $80A9F9
    goto L_80A9F9;
L_80A9EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9EB LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9ED;
L_80A9ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9EDu, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9ED LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x0u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80A9F0;
L_80A9F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F0 STY
    hw.write(cpu.address("dp", 0x10u), cpu.y, cpu.x8?8:16);
    goto L_80A9F2;
L_80A9F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F2 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80A9F5;
L_80A9F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F5 INX
    cpu.inc('X');
    goto L_80A9F6;
L_80A9F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F6 INX
    cpu.inc('X');
    goto L_80A9F7;
L_80A9F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9F7 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80A9F9;
L_80A9F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9F9u, 8u, 4u, 0x8098B7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80A9F9 JSL -> $8098B7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xA9FCu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xA9FDu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098B7u, 0x80A9F9u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80A9FD;
L_80A9FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FDu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xA9FDu,0x80A9FDu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FD STZ
    hw.write(cpu.address("dp", 0xAu), 0, cpu.m8?8:16);
    goto L_80A9FF;
L_80A9FF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xA9FFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xA9FFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80A9FF LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA01;
L_80AA01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA01u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA01 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA04;
L_80AA04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA04u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA04 INX
    cpu.inc('X');
    goto L_80AA05;
L_80AA05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA05u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA05 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA07;
L_80AA07:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA07u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA07u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA07 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA0A;
L_80AA0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0A CMP
    cpu.compareA(0xFFu);
    goto L_80AA0D;
L_80AA0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0D BEQ -> $80AA56
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA56; }
    goto L_80AA0F;
L_80AA0F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA0Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA0Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA0F CMP
    cpu.compareA(0xFEu);
    goto L_80AA12;
L_80AA12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA12u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA12 BEQ -> $80AA37
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA37; }
    goto L_80AA14;
L_80AA14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA14u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA14 CMP
    cpu.compareA(0xFDu);
    goto L_80AA17;
L_80AA17:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA17u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA17u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA17 BEQ -> $80AA2D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA2D; }
    goto L_80AA19;
L_80AA19:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA19u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA19u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA19 CMP
    cpu.compareA(0xFBu);
    goto L_80AA1C;
L_80AA1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1C BEQ -> $80AA3D
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA3D; }
    goto L_80AA1E;
L_80AA1E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA1Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA1Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA1E LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x8Cu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA20;
L_80AA20:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA20u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA20u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA20 BEQ -> $80AA25
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AA25; }
    goto L_80AA22;
L_80AA22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA22u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA22 LDA
    cpu.setA(0x0u, 16);
    goto L_80AA25;
L_80AA25:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA25u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA25u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA25 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16));
    goto L_80AA27;
L_80AA27:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA27u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA27u, 8u, 4u, 0x8098DCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA27 JSL -> $8098DC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA2Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098DCu, 0x80AA27u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA2B;
L_80AA2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,0x80AA2Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2B BRA -> $80A9FF
    goto L_80A9FF;
L_80AA2D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA2Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA2Du, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA2D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA30;
L_80AA30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA30u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA30 INX
    cpu.inc('X');
    goto L_80AA31;
L_80AA31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA31u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA31 STX
    hw.write(cpu.address("dp", 0x8u), cpu.x, cpu.x8?8:16);
    goto L_80AA33;
L_80AA33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA33u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA33 STA
    hw.write(cpu.address("dp", 0xDu), cpu.a, cpu.m8?8:16);
    goto L_80AA35;
L_80AA35:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA35u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA35u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA35 BRA -> $80A9FF
    goto L_80A9FF;
L_80AA37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA37u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA37 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA3Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA37u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA3B;
L_80AA3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Bu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,0x80AA3Bu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA3B BRA -> $80A9EB
    goto L_80A9EB;
L_80AA3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA3Du, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA3D JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA40u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA41u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA3Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA41;
L_80AA41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA41u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA41u,0x80AA41u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA41u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA41 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x8u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AA43;
L_80AA43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA43u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA43 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AA46;
L_80AA46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA46u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA46 AND
    cpu.logicAnd(0xFFu);
    goto L_80AA49;
L_80AA49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA49u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA49 CLC
    cpu.setFlag('C', false);
    goto L_80AA4A;
L_80AA4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4A ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16));
    goto L_80AA4C;
L_80AA4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4C STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_80AA4E;
L_80AA4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4E TAY
    cpu.transfer("TAY");
    goto L_80AA4F;
L_80AA4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA4Fu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA4F INC
    cpu.incMem(hw, cpu.address("dp", 0x8u), cpu.m8?8:16);
    goto L_80AA51;
L_80AA51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA51u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA51 LDA
    cpu.setA(0x7E80u, 16);
    goto L_80AA54;
L_80AA54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA54u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA54 BRA -> $80A9F9
    goto L_80A9F9;
L_80AA56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA56u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x8Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AA56 STZ
    hw.write(cpu.address("dp", 0x8Cu), 0, cpu.m8?8:16);
    goto L_80AA58;
L_80AA58:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA58u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA58u, 8u, 4u, 0x8098E7u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA58 JSL -> $8098E7 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAA5Bu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098E7u, 0x80AA58u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AA5C;
L_80AA5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAA5Cu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,0x80AA5Cu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAA5Cu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AA5C RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AA5Cu);return;} hw.unresolvedReturn(0x80AA5Cu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AC37_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AC37u: goto L_80AC37;
    case 0x80AC39u: goto L_80AC39;
    case 0x80AC3Au: goto L_80AC3A;
    case 0x80AC3Du: goto L_80AC3D;
    case 0x80AC41u: goto L_80AC41;
    case 0x80AC44u: goto L_80AC44;
    case 0x80AC47u: goto L_80AC47;
    case 0x80AC48u: goto L_80AC48;
    case 0x80AC49u: goto L_80AC49;
    case 0x80AC4Cu: goto L_80AC4C;
    case 0x80AC4Du: goto L_80AC4D;
    case 0x80AC4Fu: goto L_80AC4F;
    case 0x80AC50u: goto L_80AC50;
    case 0x80AC53u: goto L_80AC53;
    case 0x80AC57u: goto L_80AC57;
    case 0x80AC5Au: goto L_80AC5A;
    case 0x80AC5Du: goto L_80AC5D;
    case 0x80AC5Eu: goto L_80AC5E;
    case 0x80AC5Fu: goto L_80AC5F;
    case 0x80AC62u: goto L_80AC62;
    case 0x80AC63u: goto L_80AC63;
    case 0x80AC65u: goto L_80AC65;
    case 0x80AC66u: goto L_80AC66;
    case 0x80AC69u: goto L_80AC69;
    case 0x80AC6Du: goto L_80AC6D;
    case 0x80AC70u: goto L_80AC70;
    case 0x80AC73u: goto L_80AC73;
    case 0x80AC74u: goto L_80AC74;
    case 0x80AC75u: goto L_80AC75;
    case 0x80AC78u: goto L_80AC78;
    case 0x80AC79u: goto L_80AC79;
    case 0x80AC7Bu: goto L_80AC7B;
    case 0x80AC7Cu: goto L_80AC7C;
    case 0x80AC7Fu: goto L_80AC7F;
    case 0x80AC83u: goto L_80AC83;
    case 0x80AC86u: goto L_80AC86;
    case 0x80AC89u: goto L_80AC89;
    case 0x80AC8Au: goto L_80AC8A;
    case 0x80AC8Bu: goto L_80AC8B;
    case 0x80AC8Eu: goto L_80AC8E;
    case 0x80AC8Fu: goto L_80AC8F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AC37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC37u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC37u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC37 REP
    cpu.rep(0x30u);
    goto L_80AC39;
L_80AC39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC39u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC39u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC39 PHB
    cpu.push("PHB", hw);
    goto L_80AC3A;
L_80AC3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC3A LDA
    cpu.setA(0x0u, 16);
    goto L_80AC3D;
L_80AC3D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC3Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC3Du, 6u, 4u, 0x7E2000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC3D STA
    hw.write(0x7E2000u, cpu.a, cpu.m8?8:16);
    goto L_80AC41;
L_80AC41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC41u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC41u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC41 LDA
    cpu.setA(0xBFDu, 16);
    goto L_80AC44;
L_80AC44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC44u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC44u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC44 LDX
    cpu.setX(0x2001u, 16);
    goto L_80AC47;
L_80AC47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC47u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC47u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC47 TXY
    cpu.transfer("TXY");
    goto L_80AC48;
L_80AC48:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC48u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC48u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC48u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC48 INY
    cpu.inc('Y');
    goto L_80AC49;
L_80AC49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC49u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC49u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80AC49 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80AC4C;
L_80AC4C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Cu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Cu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC4C PLB
    cpu.pop("PLB", hw);
    goto L_80AC4D;
L_80AC4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC4D REP
    cpu.rep(0x30u);
    goto L_80AC4F;
L_80AC4F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC4Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Fu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC4Fu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC4F PHB
    cpu.push("PHB", hw);
    goto L_80AC50;
L_80AC50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC50u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC50 LDA
    cpu.setA(0x0u, 16);
    goto L_80AC53;
L_80AC53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC53u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC53u, 6u, 4u, 0x001B00u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC53 STA
    hw.write(0x1B00u, cpu.a, cpu.m8?8:16);
    goto L_80AC57;
L_80AC57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC57u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC57u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC57 LDA
    cpu.setA(0x35u, 16);
    goto L_80AC5A;
L_80AC5A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5A LDX
    cpu.setX(0x1B01u, 16);
    goto L_80AC5D;
L_80AC5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5D TXY
    cpu.transfer("TXY");
    goto L_80AC5E;
L_80AC5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC5E INY
    cpu.inc('Y');
    goto L_80AC5F;
L_80AC5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC5Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC5Fu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC5F MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC62;
L_80AC62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC62u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC62u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC62 PLB
    cpu.pop("PLB", hw);
    goto L_80AC63;
L_80AC63:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC63u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC63u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC63 REP
    cpu.rep(0x30u);
    goto L_80AC65;
L_80AC65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC65u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC65u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC65 PHB
    cpu.push("PHB", hw);
    goto L_80AC66;
L_80AC66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC66u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC66 LDA
    cpu.setA(0x0u, 16);
    goto L_80AC69;
L_80AC69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC69u, 6u, 4u, 0x000100u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC69 STA
    hw.write(0x100u, cpu.a, cpu.m8?8:16);
    goto L_80AC6D;
L_80AC6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC6Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC6D LDA
    cpu.setA(0x35u, 16);
    goto L_80AC70;
L_80AC70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC70u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC70 LDX
    cpu.setX(0x101u, 16);
    goto L_80AC73;
L_80AC73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC73u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC73u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC73 TXY
    cpu.transfer("TXY");
    goto L_80AC74;
L_80AC74:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC74u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC74u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC74 INY
    cpu.inc('Y');
    goto L_80AC75;
L_80AC75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC75u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC75u, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC75 MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC78;
L_80AC78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC78u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC78 PLB
    cpu.pop("PLB", hw);
    goto L_80AC79;
L_80AC79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC79u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC79u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC79 REP
    cpu.rep(0x30u);
    goto L_80AC7B;
L_80AC7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC7B PHB
    cpu.push("PHB", hw);
    goto L_80AC7C;
L_80AC7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC7C LDA
    cpu.setA(0x0u, 16);
    goto L_80AC7F;
L_80AC7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC7Fu, 6u, 4u, 0x000300u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC7F STA
    hw.write(0x300u, cpu.a, cpu.m8?8:16);
    goto L_80AC83;
L_80AC83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC83u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC83 LDA
    cpu.setA(0x2Du, 16);
    goto L_80AC86;
L_80AC86:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC86u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC86u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC86 LDX
    cpu.setX(0x301u, 16);
    goto L_80AC89;
L_80AC89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC89u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC89u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC89 TXY
    cpu.transfer("TXY");
    goto L_80AC8A;
L_80AC8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AC8A INY
    cpu.inc('Y');
    goto L_80AC8B;
L_80AC8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Bu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xAC8Bu, (std::uint32_t(cpu.a)+1u), 0x00u, 0x00u);
    // $80AC8B MVN
    cpu.blockMove(hw, 0x00u, 0x00u, false);
    goto L_80AC8E;
L_80AC8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AC8E PLB
    cpu.pop("PLB", hw);
    goto L_80AC8F;
L_80AC8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC8Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AC8F RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80AC8Fu);return;} hw.unresolvedReturn(0x80AC8Fu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80AD2F_E0M0X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80AD92u: goto L_80AD92;
    case 0x80AD95u: goto L_80AD95;
    case 0x80AD98u: goto L_80AD98;
    case 0x80AD9Bu: goto L_80AD9B;
    case 0x80AD9Du: goto L_80AD9D;
    case 0x80AD9Fu: goto L_80AD9F;
    case 0x80ADA0u: goto L_80ADA0;
    case 0x80ADA1u: goto L_80ADA1;
    case 0x80ADA3u: goto L_80ADA3;
    case 0x80ADA4u: goto L_80ADA4;
    case 0x80ADA5u: goto L_80ADA5;
    case 0x80ADA7u: goto L_80ADA7;
    case 0x80ADA9u: goto L_80ADA9;
    case 0x80ADABu: goto L_80ADAB;
    case 0x80ADAEu: goto L_80ADAE;
    case 0x80ADB0u: goto L_80ADB0;
    case 0x80ADB2u: goto L_80ADB2;
    case 0x80ADB3u: goto L_80ADB3;
    case 0x80ADB5u: goto L_80ADB5;
    case 0x80ADB8u: goto L_80ADB8;
    case 0x80ADBBu: goto L_80ADBB;
    case 0x80ADBCu: goto L_80ADBC;
    case 0x80ADBFu: goto L_80ADBF;
    case 0x80ADC1u: goto L_80ADC1;
    case 0x80ADC3u: goto L_80ADC3;
    case 0x80ADC7u: goto L_80ADC7;
    case 0x80ADCBu: goto L_80ADCB;
    case 0x80ADCDu: goto L_80ADCD;
    case 0x80ADCFu: goto L_80ADCF;
    case 0x80ADD1u: goto L_80ADD1;
    case 0x80ADD2u: goto L_80ADD2;
    case 0x80ADD5u: goto L_80ADD5;
    case 0x80ADD7u: goto L_80ADD7;
    case 0x80ADDAu: goto L_80ADDA;
    case 0x80ADDCu: goto L_80ADDC;
    case 0x80ADDDu: goto L_80ADDD;
    case 0x80ADE0u: goto L_80ADE0;
    case 0x80ADE2u: goto L_80ADE2;
    case 0x80ADE4u: goto L_80ADE4;
    case 0x80ADE6u: goto L_80ADE6;
    case 0x80ADE7u: goto L_80ADE7;
    case 0x80ADE8u: goto L_80ADE8;
    case 0x80ADEAu: goto L_80ADEA;
    case 0x80ADECu: goto L_80ADEC;
    case 0x80ADEEu: goto L_80ADEE;
    case 0x80ADF0u: goto L_80ADF0;
    case 0x80ADF2u: goto L_80ADF2;
    case 0x80ADF4u: goto L_80ADF4;
    case 0x80ADF6u: goto L_80ADF6;
    case 0x80ADF8u: goto L_80ADF8;
    case 0x80ADFAu: goto L_80ADFA;
    case 0x80ADFBu: goto L_80ADFB;
    case 0x80ADFCu: goto L_80ADFC;
    case 0x80ADFFu: goto L_80ADFF;
    case 0x80AE59u: goto L_80AE59;
    case 0x80AE5Cu: goto L_80AE5C;
    case 0x80AE5Eu: goto L_80AE5E;
    case 0x80AE5Fu: goto L_80AE5F;
    case 0x80AE60u: goto L_80AE60;
    case 0x80AE62u: goto L_80AE62;
    case 0x80AE64u: goto L_80AE64;
    case 0x80AE66u: goto L_80AE66;
    case 0x80AE68u: goto L_80AE68;
    case 0x80AE6Bu: goto L_80AE6B;
    case 0x80AE6Du: goto L_80AE6D;
    case 0x80AE6Fu: goto L_80AE6F;
    case 0x80AE70u: goto L_80AE70;
    case 0x80AE72u: goto L_80AE72;
    case 0x80AE75u: goto L_80AE75;
    case 0x80AE78u: goto L_80AE78;
    case 0x80AE79u: goto L_80AE79;
    case 0x80AE7Cu: goto L_80AE7C;
    case 0x80AE7Eu: goto L_80AE7E;
    case 0x80AE80u: goto L_80AE80;
    case 0x80AE84u: goto L_80AE84;
    case 0x80AE88u: goto L_80AE88;
    case 0x80AE8Au: goto L_80AE8A;
    case 0x80AE8Cu: goto L_80AE8C;
    case 0x80AE8Eu: goto L_80AE8E;
    case 0x80AE8Fu: goto L_80AE8F;
    case 0x80AE91u: goto L_80AE91;
    case 0x80AE93u: goto L_80AE93;
    case 0x80AE95u: goto L_80AE95;
    case 0x80AE97u: goto L_80AE97;
    case 0x80AE9Bu: goto L_80AE9B;
    case 0x80AE9Cu: goto L_80AE9C;
    case 0x80AEA0u: goto L_80AEA0;
    case 0x80AEA1u: goto L_80AEA1;
    case 0x80AEA4u: goto L_80AEA4;
    case 0x80AEA6u: goto L_80AEA6;
    case 0x80AEA8u: goto L_80AEA8;
    case 0x80AEA9u: goto L_80AEA9;
    case 0x80AEAAu: goto L_80AEAA;
    case 0x80AEABu: goto L_80AEAB;
    case 0x80AEADu: goto L_80AEAD;
    case 0x80AEB0u: goto L_80AEB0;
    case 0x80AEB2u: goto L_80AEB2;
    case 0x80AEB5u: goto L_80AEB5;
    case 0x80AEB8u: goto L_80AEB8;
    case 0x80AEBAu: goto L_80AEBA;
    case 0x80AEBDu: goto L_80AEBD;
    case 0x80B2A9u: goto L_80B2A9;
    case 0x80B2AAu: goto L_80B2AA;
    case 0x80B2ABu: goto L_80B2AB;
    case 0x80B2ADu: goto L_80B2AD;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80AD92:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD92u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 3u, 3u, cpu.address("abs", 0xB2A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD92 JMP -> $80B2A9
    goto L_80B2A9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD92u, 3u, 3u, cpu.address("abs", 0xB2A9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD92 JMP -> $80B2A9
    goto L_80B2A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD92u,0x80AD92u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD95u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD95 JMP -> $80B39A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Au),0x80AD95u); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD95u, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD95 JMP -> $80B39A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Au),0x80AD95u); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD95u,0x80AD95u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD98:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD98u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD9B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD98u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD98 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AD9B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD98u,0x80AD98u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Bu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AD9D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9B STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AD9D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Bu,0x80AD9Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Du))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9D AND
    cpu.logicAnd(0x1u);
    goto L_80AD9F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9D AND
    cpu.logicAnd(0x1u);
    goto L_80AD9F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Du,0x80AD9Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AD9F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAD9Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9F INC
    cpu.inc('A');
    goto L_80ADA0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAD9Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AD9F INC
    cpu.inc('A');
    goto L_80ADA0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAD9Fu,0x80AD9Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA0 ASL
    cpu.aslA();
    goto L_80ADA1;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA0 ASL
    cpu.aslA();
    goto L_80ADA1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA0u,0x80ADA0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA1u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA1 STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80ADA3;
L_80ADA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA3 INX
    cpu.inc('X');
    goto L_80ADA4;
L_80ADA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA4 INX
    cpu.inc('X');
    goto L_80ADA5;
L_80ADA5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA5 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80ADA7;
L_80ADA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA7u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADA9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADA9;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA7u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADA9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA7u,0x80ADA7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADA9u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA9 BNE -> $80ADAE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ADAE; }
    goto L_80ADAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA9 BNE -> $80ADAE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ADAE; }
    goto L_80ADAB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADA9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADA9 BNE -> $80ADAE
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ADAE; }
    goto L_80ADAB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADA9u,0x80ADA9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADABu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 6u, 3u, cpu.address("abs", 0xAE39u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADAB JSR -> $80AE39 stack real
    { cpu.push16Value(hw,0xADADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADAEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAE39u), 0x80ADABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 6u, 3u, cpu.address("abs", 0xAE39u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADAB JSR -> $80AE39 stack real
    { cpu.push16Value(hw,0xADADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADAEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAE39u), 0x80ADABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADAE;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADABu, 6u, 3u, cpu.address("abs", 0xAE39u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADAB JSR -> $80AE39 stack real
    { cpu.push16Value(hw,0xADADu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADAEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAE39u), 0x80ADABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADAE;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADABu,0x80ADABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADAE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADAEu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADAE REP
    cpu.rep(0x20u);
    goto L_80ADB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADAE REP
    cpu.rep(0x20u);
    goto L_80ADB0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADAE REP
    cpu.rep(0x20u);
    goto L_80ADB0;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADAEu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADAE REP
    cpu.rep(0x20u);
    goto L_80ADB0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADAEu,0x80ADAEu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB0u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADB2;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADB2;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADB0u,0x80ADB0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB2u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB2 LSR
    cpu.lsrA();
    goto L_80ADB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB2 LSR
    cpu.lsrA();
    goto L_80ADB3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB2 LSR
    cpu.lsrA();
    goto L_80ADB3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADB2u,0x80ADB2u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB3 BCC -> $80ADB8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80ADB8; }
    goto L_80ADB5;
L_80ADB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB5u, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADB5 JMP -> $80B39E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Eu),0x80ADB5u); return;
L_80ADB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADB8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADB8u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADB8 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80ADBB;
L_80ADBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80ADBB PLB
    cpu.pop("PLB", hw);
    goto L_80ADBC;
L_80ADBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADBC LDA
    cpu.setA(0x400u, 16);
    goto L_80ADBF;
L_80ADBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADBFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADBFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADBF STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80ADC1;
L_80ADC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADC1 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80ADC3;
L_80ADC3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC3u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ADC3 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADC7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80ADC3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADC7;
L_80ADC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADC7u,0x80ADC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADC7u, 8u, 4u, 0x80AFC1u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80ADC7 JSL -> $80AFC1 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xADCAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADCBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80AFC1u, 0x80ADC7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADCB;
L_80ADCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCBu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADCBu,0x80ADCBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADCB LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADCD;
L_80ADCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCDu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADCD BPL -> $80ADC3
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80ADC3; }
    goto L_80ADCF;
L_80ADCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADCFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADCFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADCF SEP
    cpu.sep(0x20u);
    goto L_80ADD1;
L_80ADD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD1u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80ADD1 PLB
    cpu.pop("PLB", hw);
    goto L_80ADD2;
L_80ADD2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD2u, 6u, 3u, cpu.address("abs", 0xB25Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADD2 JSR -> $80B25E stack real
    { cpu.push16Value(hw,0xADD4u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xADD5u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB25Eu), 0x80ADD2u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80ADD5;
L_80ADD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADD5 BCS -> $80ADDA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80ADDA; }
    goto L_80ADD7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD5u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADD5 BCS -> $80ADDA
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80ADDA; }
    goto L_80ADD7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD5u,0x80ADD5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADD7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u, 3u, 3u, cpu.address("abs", 0xADA7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADD7 JMP -> $80ADA7
    goto L_80ADA7;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADD7u, 3u, 3u, cpu.address("abs", 0xADA7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADD7 JMP -> $80ADA7
    goto L_80ADA7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADD7u,0x80ADD7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDAu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDA REP
    cpu.rep(0x30u);
    goto L_80ADDC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDA REP
    cpu.rep(0x30u);
    goto L_80ADDC;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDAu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDA REP
    cpu.rep(0x30u);
    goto L_80ADDC;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADDAu,0x80ADDAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDCu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDC TDC
    cpu.tdc();
    goto L_80ADDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDC TDC
    cpu.tdc();
    goto L_80ADDD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDC TDC
    cpu.tdc();
    goto L_80ADDD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADDCu,0x80ADDCu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADDD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADDDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDD CMP
    cpu.compareA(0x100u);
    goto L_80ADE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDD CMP
    cpu.compareA(0x100u);
    goto L_80ADE0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADDDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADDD CMP
    cpu.compareA(0x100u);
    goto L_80ADE0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xADDDu,0x80ADDDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80ADE0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE0u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE0 BNE -> $80ADFF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ADFF; }
    goto L_80ADE2;
L_80ADE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE2 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x30u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80ADE4;
L_80ADE4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE4 BEQ -> $80ADFF
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80ADFF; }
    goto L_80ADE6;
L_80ADE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE6 DEX
    cpu.decReg('X');
    goto L_80ADE7;
L_80ADE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE7u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE7 DEX
    cpu.decReg('X');
    goto L_80ADE8;
L_80ADE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADE8 STX
    hw.write(cpu.address("dp", 0x30u), cpu.x, cpu.x8?8:16);
    goto L_80ADEA;
L_80ADEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADEA LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x32u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80ADEC;
L_80ADEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADEC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x34u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADEE;
L_80ADEE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADEEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADEEu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADEEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADEE STA
    hw.write(cpu.address("dp", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_80ADF0;
L_80ADF0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x36u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADF2;
L_80ADF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x34u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF2 STA
    hw.write(cpu.address("dp", 0x34u), cpu.a, cpu.m8?8:16);
    goto L_80ADF4;
L_80ADF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF4u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF4 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x38u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80ADF6;
L_80ADF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF6u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF6 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_80ADF8;
L_80ADF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADF8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADF8 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_80ADFA;
L_80ADFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFAu,cpu,0x2Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFAu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80ADFA PLD
    cpu.pop("PLD", hw);
    goto L_80ADFB;
L_80ADFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80ADFB PLB
    cpu.pop("PLB", hw);
    goto L_80ADFC;
L_80ADFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFCu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFCu, 3u, 3u, cpu.address("abs", 0xAD50u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADFC JMP -> $80AD50
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xAD50u),0x80ADFCu); return;
L_80ADFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xADFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xADFFu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xADFFu, 3u, 3u, cpu.address("abs", 0xB39Au), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80ADFF JMP -> $80B39A
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Au),0x80ADFFu); return;
L_80AE59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE59u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE5C;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE59u, 4u + 1u, 3u, cpu.address("absx", 0x0001u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE59 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE5C;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE59u,0x80AE59u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Cu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AE5E;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Cu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5C STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_80AE5E;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE5Cu,0x80AE5Cu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Eu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5E INX
    cpu.inc('X');
    goto L_80AE5F;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5E INX
    cpu.inc('X');
    goto L_80AE5F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE5Eu,0x80AE5Eu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE5Fu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5F INX
    cpu.inc('X');
    goto L_80AE60;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE5F INX
    cpu.inc('X');
    goto L_80AE60;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE5Fu,0x80AE5Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE60u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE60 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80AE62;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE60u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE60 STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80AE62;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE60u,0x80AE60u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE62u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE62 STZ
    hw.write(cpu.address("dp", 0x2Eu), 0, cpu.m8?8:16);
    goto L_80AE64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE62u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE62 STZ
    hw.write(cpu.address("dp", 0x2Eu), 0, cpu.m8?8:16);
    goto L_80AE64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE62u,0x80AE62u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE64:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE64u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE66;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE64u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE64 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE66;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE64u,0x80AE64u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE66u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE66 BNE -> $80AE6B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE6B; }
    goto L_80AE68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE66 BNE -> $80AE6B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE6B; }
    goto L_80AE68;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE66u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE66 BNE -> $80AE6B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AE6B; }
    goto L_80AE68;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE66u,0x80AE66u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE68u))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 6u, 3u, cpu.address("abs", 0xAEF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE68 JSR -> $80AEF7 stack real
    { cpu.push16Value(hw,0xAE6Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAEF7u), 0x80AE68u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 6u, 3u, cpu.address("abs", 0xAEF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE68 JSR -> $80AEF7 stack real
    { cpu.push16Value(hw,0xAE6Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAEF7u), 0x80AE68u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE6B;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE68u, 6u, 3u, cpu.address("abs", 0xAEF7u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE68 JSR -> $80AEF7 stack real
    { cpu.push16Value(hw,0xAE6Au); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xAEF7u), 0x80AE68u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE6B;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE68u,0x80AE68u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Bu))return;
  // 4 variantes de decodificacao M/X para este endereco; 4 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6B REP
    cpu.rep(0x20u);
    goto L_80AE6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6B REP
    cpu.rep(0x20u);
    goto L_80AE6D;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6B REP
    cpu.rep(0x20u);
    goto L_80AE6D;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6B REP
    cpu.rep(0x20u);
    goto L_80AE6D;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE6Bu,0x80AE6Bu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Du))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE6F;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE6F;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE6Du,0x80AE6Du); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE6Fu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6F LSR
    cpu.lsrA();
    goto L_80AE70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6F LSR
    cpu.lsrA();
    goto L_80AE70;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE6Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE6F LSR
    cpu.lsrA();
    goto L_80AE70;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE6Fu,0x80AE6Fu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AE70:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE70u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE70u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE70 BCC -> $80AE75
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AE75; }
    goto L_80AE72;
L_80AE72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE72u, 3u, 3u, cpu.address("abs", 0xB39Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE72 JMP -> $80B39E
    hw.requestDispatch(((std::uint32_t(cpu.pb)<<16)|0xB39Eu),0x80AE72u); return;
L_80AE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE75u, 5u, 3u, cpu.address("abs", 0x847Eu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AE75 PEA
    cpu.push16Value(hw, 0x847Eu);
    goto L_80AE78;
L_80AE78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE78u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AE78 PLB
    cpu.pop("PLB", hw);
    goto L_80AE79;
L_80AE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE79u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE79 LDA
    cpu.setA(0x400u, 16);
    goto L_80AE7C;
L_80AE7C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7C STA
    hw.write(cpu.address("dp", 0x1Eu), cpu.a, cpu.m8?8:16);
    goto L_80AE7E;
L_80AE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE7Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE7E STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_80AE80;
L_80AE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE80u, 8u, 4u, 0x80B3A3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AE80 JSL -> $80B3A3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE83u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE84u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B3A3u, 0x80AE80u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE84;
L_80AE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE84u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE84u,0x80AE84u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE84u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE84u, 8u, 4u, 0x80B165u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80AE84 JSL -> $80B165 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xAE87u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAE88u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B165u, 0x80AE84u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AE88;
L_80AE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE88u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAE88u,0x80AE88u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE88u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x01u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE88 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE8A;
L_80AE8A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE8A BPL -> $80AE80
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AE80; }
    goto L_80AE8C;
L_80AE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE8C SEP
    cpu.sep(0x20u);
    goto L_80AE8E;
L_80AE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80AE8E PLB
    cpu.pop("PLB", hw);
    goto L_80AE8F;
L_80AE8F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE8Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE8Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE8F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE91;
L_80AE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE91 BPL -> $80AEB5
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80AEB5; }
    goto L_80AE93;
L_80AE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE93u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE93 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80AE95;
L_80AE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE95u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE95 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AE97;
L_80AE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE97u, 5u, 4u, ((0x840001u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE97 LDA
    cpu.loadA(hw.readW(((0x840001u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AE9B;
L_80AE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Bu, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE9B XBA
    cpu.xba();
    goto L_80AE9C;
L_80AE9C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAE9Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Cu,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAE9Cu, 5u, 4u, ((0x840000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AE9C LDA
    cpu.loadA(hw.readW(((0x840000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80AEA0;
L_80AEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA0 TAY
    cpu.transfer("TAY");
    goto L_80AEA1;
L_80AEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA1u,cpu,0xC0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA1 CPY
    cpu.compareY(0xFFFFu);
    goto L_80AEA4;
L_80AEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA4 BEQ -> $80AEBD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80AEBD; }
    goto L_80AEA6;
L_80AEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA6 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x2Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80AEA8;
L_80AEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA8 INX
    cpu.inc('X');
    goto L_80AEA9;
L_80AEA9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEA9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEA9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEA9 INX
    cpu.inc('X');
    goto L_80AEAA;
L_80AEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEAAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEAA INX
    cpu.inc('X');
    goto L_80AEAB;
L_80AEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEABu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEAB STX
    hw.write(cpu.address("dp", 0x2Eu), cpu.x, cpu.x8?8:16);
    goto L_80AEAD;
L_80AEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEAD CPX
    cpu.compareX(0x15u);
    goto L_80AEB0;
L_80AEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB0 BCS -> $80AEBD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AEBD; }
    goto L_80AEB2;
L_80AEB2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB2u, 3u, 3u, cpu.address("abs", 0xAE64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB2 JMP -> $80AE64
    goto L_80AE64;
L_80AEB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB5u, 6u, 3u, cpu.address("abs", 0xB272u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80AEB5 JSR -> $80B272 stack real
    { cpu.push16Value(hw,0xAEB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xAEB8u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xB272u), 0x80AEB5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80AEB8;
L_80AEB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEB8u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB8 BCS -> $80AEBD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AEBD; }
    goto L_80AEBA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEB8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEB8 BCS -> $80AEBD
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80AEBD; }
    goto L_80AEBA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEB8u,0x80AEB8u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 3u, 3u, cpu.address("abs", 0xAE64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA JMP -> $80AE64
    goto L_80AE64;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBAu, 3u, 3u, cpu.address("abs", 0xAE64u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBA JMP -> $80AE64
    goto L_80AE64;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBAu,0x80AEBAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80AEBD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAEBDu))return;
  // 3 variantes de decodificacao M/X para este endereco; 3 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    goto L_80ADDA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==true) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    goto L_80ADDA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAEBDu, 3u, 3u, cpu.address("abs", 0xADDAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80AEBD JMP -> $80ADDA
    goto L_80ADDA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xAEBDu,0x80AEBDu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A9 INX
    cpu.inc('X');
    goto L_80B2AA;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A9 INX
    cpu.inc('X');
    goto L_80B2AA;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2A9u,0x80B2A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2AAu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AA INX
    cpu.inc('X');
    goto L_80B2AB;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AA INX
    cpu.inc('X');
    goto L_80B2AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2AAu,0x80B2AAu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2AD;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ABu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AB STX
    hw.write(cpu.address("dp", 0x6u), cpu.x, cpu.x8?8:16);
    goto L_80B2AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2ABu,0x80B2ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_80B2AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu, 4u, 4u, 0x809772u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AD JML -> $809772
    hw.requestDispatch(0x809772u,0x80B2ADu); return;
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2ADu, 4u, 4u, 0x809772u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2AD JML -> $809772
    hw.requestDispatch(0x809772u,0x80B2ADu); return;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB2ADu,0x80B2ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_80B272_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B272u: goto L_80B272;
    case 0x80B274u: goto L_80B274;
    case 0x80B276u: goto L_80B276;
    case 0x80B278u: goto L_80B278;
    case 0x80B27Au: goto L_80B27A;
    case 0x80B27Eu: goto L_80B27E;
    case 0x80B281u: goto L_80B281;
    case 0x80B283u: goto L_80B283;
    case 0x80B285u: goto L_80B285;
    case 0x80B286u: goto L_80B286;
    case 0x80B2A5u: goto L_80B2A5;
    case 0x80B2A7u: goto L_80B2A7;
    case 0x80B2A8u: goto L_80B2A8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B272:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB272u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB272u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB272u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B272 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x6u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B274;
L_80B274:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB274u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB274u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B274 REP
    cpu.rep(0x20u);
    goto L_80B276;
L_80B276:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB276u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB276u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B276 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_80B278;
L_80B278:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB278u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB278u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B278 STZ
    hw.write(cpu.address("dp", 0x4u), 0, cpu.m8?8:16);
    goto L_80B27A;
L_80B27A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Au, 6u, 4u, ((0x840000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B27A LDA
    cpu.loadA(hw.readW(((0x840000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B27E;
L_80B27E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB27Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB27Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B27E CMP
    cpu.compareA(0xFFFFu);
    goto L_80B281;
L_80B281:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB281u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB281u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B281 BNE -> $80B2A5
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B2A5; }
    goto L_80B283;
L_80B283:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB283u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB283u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B283 SEP
    cpu.sep(0x20u);
    goto L_80B285;
L_80B285:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB285u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB285u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B285 SEC
    cpu.setFlag('C', true);
    goto L_80B286;
L_80B286:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB286u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB286u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B286 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B286u);return;} hw.unresolvedReturn(0x80B286u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B2A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A5 SEP
    cpu.sep(0x20u);
    goto L_80B2A7;
L_80B2A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A7u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B2A7 CLC
    cpu.setFlag('C', false);
    goto L_80B2A8;
L_80B2A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB2A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB2A8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B2A8 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B2A8u);return;} hw.unresolvedReturn(0x80B2A8u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_80B3E1_E0M1X0C0_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B533u: goto L_80B533;
    case 0x80B535u: goto L_80B535;
    case 0x80B536u: goto L_80B536;
    case 0x80B538u: goto L_80B538;
    case 0x80B53Au: goto L_80B53A;
    case 0x80B53Bu: goto L_80B53B;
    case 0x80B53Du: goto L_80B53D;
    case 0x80B53Eu: goto L_80B53E;
    case 0x80B53Fu: goto L_80B53F;
    case 0x80B541u: goto L_80B541;
    case 0x80B542u: goto L_80B542;
    case 0x80B544u: goto L_80B544;
    case 0x80B545u: goto L_80B545;
    case 0x80B547u: goto L_80B547;
    case 0x80B549u: goto L_80B549;
    case 0x80B54Bu: goto L_80B54B;
    case 0x80B54Du: goto L_80B54D;
    case 0x80B54Eu: goto L_80B54E;
    case 0x80B550u: goto L_80B550;
    case 0x80B552u: goto L_80B552;
    case 0x80B556u: goto L_80B556;
    case 0x80B558u: goto L_80B558;
    case 0x80B559u: goto L_80B559;
    case 0x80B55Bu: goto L_80B55B;
    case 0x80B55Fu: goto L_80B55F;
    case 0x80B561u: goto L_80B561;
    case 0x80B562u: goto L_80B562;
    case 0x80B565u: goto L_80B565;
    case 0x80B567u: goto L_80B567;
    case 0x80B569u: goto L_80B569;
    case 0x80B56Bu: goto L_80B56B;
    case 0x80B56Du: goto L_80B56D;
    case 0x80B56Eu: goto L_80B56E;
    case 0x80B570u: goto L_80B570;
    case 0x80B572u: goto L_80B572;
    case 0x80B573u: goto L_80B573;
    case 0x80B575u: goto L_80B575;
    case 0x80B577u: goto L_80B577;
    case 0x80B579u: goto L_80B579;
    case 0x80B57Bu: goto L_80B57B;
    case 0x80B57Du: goto L_80B57D;
    case 0x80B57Fu: goto L_80B57F;
    case 0x80B581u: goto L_80B581;
    case 0x80B582u: goto L_80B582;
    case 0x80B583u: goto L_80B583;
    case 0x80B584u: goto L_80B584;
    case 0x80B586u: goto L_80B586;
    case 0x80B588u: goto L_80B588;
    case 0x80B58Bu: goto L_80B58B;
    case 0x80B58Du: goto L_80B58D;
    case 0x80B58Fu: goto L_80B58F;
    case 0x80B590u: goto L_80B590;
    case 0x80B592u: goto L_80B592;
    case 0x80B593u: goto L_80B593;
    case 0x80B596u: goto L_80B596;
    case 0x80B597u: goto L_80B597;
    case 0x80B59Au: goto L_80B59A;
    case 0x80B59Cu: goto L_80B59C;
    case 0x80B59Eu: goto L_80B59E;
    case 0x80B5A0u: goto L_80B5A0;
    case 0x80B5A2u: goto L_80B5A2;
    case 0x80B5A3u: goto L_80B5A3;
    case 0x80B5A5u: goto L_80B5A5;
    case 0x80B5A7u: goto L_80B5A7;
    case 0x80B5A8u: goto L_80B5A8;
    case 0x80B5AAu: goto L_80B5AA;
    case 0x80B5ABu: goto L_80B5AB;
    case 0x80B5AEu: goto L_80B5AE;
    case 0x80B5AFu: goto L_80B5AF;
    case 0x80B5B1u: goto L_80B5B1;
    case 0x80B5B3u: goto L_80B5B3;
    case 0x80B5B5u: goto L_80B5B5;
    case 0x80B5B7u: goto L_80B5B7;
    case 0x80B5B8u: goto L_80B5B8;
    case 0x80B5BAu: goto L_80B5BA;
    case 0x80B5BCu: goto L_80B5BC;
    case 0x80B5BFu: goto L_80B5BF;
    case 0x80B5C1u: goto L_80B5C1;
    case 0x80B5C2u: goto L_80B5C2;
    case 0x80B5C3u: goto L_80B5C3;
    case 0x80B5C4u: goto L_80B5C4;
    case 0x80B5C5u: goto L_80B5C5;
    case 0x80B5C7u: goto L_80B5C7;
    case 0x80B5C8u: goto L_80B5C8;
    case 0x80B5CBu: goto L_80B5CB;
    case 0x80B5CCu: goto L_80B5CC;
    case 0x80B5CFu: goto L_80B5CF;
    case 0x80B5D1u: goto L_80B5D1;
    case 0x80B5D3u: goto L_80B5D3;
    case 0x80B5D5u: goto L_80B5D5;
    case 0x80B5D7u: goto L_80B5D7;
    case 0x80B5D8u: goto L_80B5D8;
    case 0x80B5DAu: goto L_80B5DA;
    case 0x80B5DCu: goto L_80B5DC;
    case 0x80B5DDu: goto L_80B5DD;
    case 0x80B5DFu: goto L_80B5DF;
    case 0x80B5E1u: goto L_80B5E1;
    case 0x80B5E3u: goto L_80B5E3;
    case 0x80B5E5u: goto L_80B5E5;
    case 0x80B5E7u: goto L_80B5E7;
    case 0x80B5E9u: goto L_80B5E9;
    case 0x80B5EBu: goto L_80B5EB;
    case 0x80B5ECu: goto L_80B5EC;
    case 0x80B5EEu: goto L_80B5EE;
    case 0x80B5F0u: goto L_80B5F0;
    case 0x80B5F1u: goto L_80B5F1;
    case 0x80B5F4u: goto L_80B5F4;
    case 0x80B5F5u: goto L_80B5F5;
    case 0x80B5F7u: goto L_80B5F7;
    case 0x80B5F9u: goto L_80B5F9;
    case 0x80B5FBu: goto L_80B5FB;
    case 0x80B5FDu: goto L_80B5FD;
    case 0x80B5FEu: goto L_80B5FE;
    case 0x80B601u: goto L_80B601;
    case 0x80B603u: goto L_80B603;
    case 0x80B604u: goto L_80B604;
    case 0x80B606u: goto L_80B606;
    case 0x80B608u: goto L_80B608;
    case 0x80B60Au: goto L_80B60A;
    case 0x80B60Cu: goto L_80B60C;
    case 0x80B60Du: goto L_80B60D;
    case 0x80B610u: goto L_80B610;
    case 0x80B611u: goto L_80B611;
    case 0x80B614u: goto L_80B614;
    case 0x80B616u: goto L_80B616;
    case 0x80B618u: goto L_80B618;
    case 0x80B61Au: goto L_80B61A;
    case 0x80B61Bu: goto L_80B61B;
    case 0x80B61Du: goto L_80B61D;
    case 0x80B61Fu: goto L_80B61F;
    case 0x80B621u: goto L_80B621;
    case 0x80B622u: goto L_80B622;
    case 0x80B624u: goto L_80B624;
    case 0x80B626u: goto L_80B626;
    case 0x80B627u: goto L_80B627;
    case 0x80B629u: goto L_80B629;
    case 0x80B62Au: goto L_80B62A;
    case 0x80B62Cu: goto L_80B62C;
    case 0x80B62Eu: goto L_80B62E;
    case 0x80B630u: goto L_80B630;
    case 0x80B632u: goto L_80B632;
    case 0x80B634u: goto L_80B634;
    case 0x80B637u: goto L_80B637;
    case 0x80B639u: goto L_80B639;
    case 0x80B63Bu: goto L_80B63B;
    case 0x80B63Du: goto L_80B63D;
    case 0x80B63Fu: goto L_80B63F;
    case 0x80B640u: goto L_80B640;
    case 0x80B643u: goto L_80B643;
    case 0x80B645u: goto L_80B645;
    case 0x80B646u: goto L_80B646;
    case 0x80B648u: goto L_80B648;
    case 0x80B64Au: goto L_80B64A;
    case 0x80B64Cu: goto L_80B64C;
    case 0x80B64Eu: goto L_80B64E;
    case 0x80B64Fu: goto L_80B64F;
    case 0x80B652u: goto L_80B652;
    case 0x80B653u: goto L_80B653;
    case 0x80B656u: goto L_80B656;
    case 0x80B658u: goto L_80B658;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B533 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B535;
L_80B535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B535 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B535u);return;} hw.unresolvedReturn(0x80B535u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B536 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B538;
L_80B538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B538 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B53A;
L_80B53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53A SEC
    cpu.setFlag('C', true);
    goto L_80B53B;
L_80B53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B53D;
L_80B53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53D DEC
    cpu.decReg('A');
    goto L_80B53E;
L_80B53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53E TAX
    cpu.transfer("TAX");
    goto L_80B53F;
L_80B53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B541;
L_80B541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B541 CLC
    cpu.setFlag('C', false);
    goto L_80B542;
L_80B542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB542u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB542u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B542 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B544;
L_80B544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B544 SEC
    cpu.setFlag('C', true);
    goto L_80B545;
L_80B545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB545u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB545u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B545 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B547;
L_80B547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B547 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B549;
L_80B549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B549 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B54B;
L_80B54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B54D;
L_80B54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54D TAY
    cpu.transfer("TAY");
    goto L_80B54E;
L_80B54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54E SEP
    cpu.sep(0x20u);
    goto L_80B550;
L_80B550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B550 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B552;
L_80B552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u, 5u, 4u, 0x8000BEu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B552 STA
    hw.write(0x8000BEu, cpu.a, cpu.m8?8:16);
    goto L_80B556;
L_80B556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B556 REP
    cpu.rep(0x20u);
    goto L_80B558;
L_80B558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B558 TXA
    cpu.transfer("TXA");
    goto L_80B559;
L_80B559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B559 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B55B;
L_80B55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu, 8u, 4u, 0x8000BCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B55B JSL -> $8000BC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB55Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB55Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8000BCu, 0x80B55Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B55F;
L_80B55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB55Fu,0x80B55Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B55F STX
    hw.write(cpu.address("dp", 0xDu), cpu.x, cpu.x8?8:16);
    goto L_80B561;
L_80B561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B561 TYA
    cpu.transfer("TYA");
    goto L_80B562;
L_80B562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B562 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B565;
L_80B565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B565 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B567;
L_80B567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B567 SEP
    cpu.sep(0x20u);
    goto L_80B569;
L_80B569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB569u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB569u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B569 LDA
    cpu.setA(0x6u, 8);
    goto L_80B56B;
L_80B56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56B STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B56D;
L_80B56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B56D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B56Du);return;} hw.unresolvedReturn(0x80B56Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56E REP
    cpu.rep(0x20u);
    goto L_80B570;
L_80B570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB570u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB570u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B570 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B572;
L_80B572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B572 CLC
    cpu.setFlag('C', false);
    goto L_80B573;
L_80B573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B573 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B575;
L_80B575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B575 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B577;
L_80B577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B577 BCC -> $80B57D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B57D; }
    goto L_80B579;
L_80B579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B579 BNE -> $80B5A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A3; }
    goto L_80B57B;
L_80B57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57B INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B57D;
L_80B57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B57F;
L_80B57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B581;
L_80B581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB581u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB581u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B581 TAX
    cpu.transfer("TAX");
    goto L_80B582;
L_80B582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B582 TAY
    cpu.transfer("TAY");
    goto L_80B583;
L_80B583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB583u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB583u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B583 INY
    cpu.inc('Y');
    goto L_80B584;
L_80B584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B584 SEP
    cpu.sep(0x20u);
    goto L_80B586;
L_80B586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B586 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B588;
L_80B588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B588 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B58B;
L_80B58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58B REP
    cpu.rep(0x20u);
    goto L_80B58D;
L_80B58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B58F;
L_80B58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58F DEC
    cpu.decReg('A');
    goto L_80B590;
L_80B590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B590 BEQ -> $80B596
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B596; }
    goto L_80B592;
L_80B592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B592 DEC
    cpu.decReg('A');
    goto L_80B593;
L_80B593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB593u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB593u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B593 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B596;
L_80B596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B596 TYA
    cpu.transfer("TYA");
    goto L_80B597;
L_80B597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B597 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B59A;
L_80B59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59A STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B59C;
L_80B59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59C SEP
    cpu.sep(0x20u);
    goto L_80B59E;
L_80B59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59E STZ
    hw.write(cpu.address("dp", 0x29u), 0, cpu.m8?8:16);
    goto L_80B5A0;
L_80B5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A0 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B5A2;
L_80B5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5A2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B5A2u);return;} hw.unresolvedReturn(0x80B5A2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A3 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B5A5;
L_80B5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5A7;
L_80B5A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A7 SEC
    cpu.setFlag('C', true);
    goto L_80B5A8;
L_80B5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5AA;
L_80B5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AA TAY
    cpu.transfer("TAY");
    goto L_80B5AB;
L_80B5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ABu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AB EOR
    cpu.logicXor(0xFFFFu);
    goto L_80B5AE;
L_80B5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AE SEC
    cpu.setFlag('C', true);
    goto L_80B5AF;
L_80B5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_80B5B1;
L_80B5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B1 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B5B3;
L_80B5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5B5;
L_80B5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5B7;
L_80B5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B7 TAX
    cpu.transfer("TAX");
    goto L_80B5B8;
L_80B5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B8 SEP
    cpu.sep(0x20u);
    goto L_80B5BA;
L_80B5BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5BC;
L_80B5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BC STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B5BF;
L_80B5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BF REP
    cpu.rep(0x20u);
    goto L_80B5C1;
L_80B5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C1 TYA
    cpu.transfer("TYA");
    goto L_80B5C2;
L_80B5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C2 TXY
    cpu.transfer("TXY");
    goto L_80B5C3;
L_80B5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C3 INY
    cpu.inc('Y');
    goto L_80B5C4;
L_80B5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C4 DEC
    cpu.decReg('A');
    goto L_80B5C5;
L_80B5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C5 BEQ -> $80B5CB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5CB; }
    goto L_80B5C7;
L_80B5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C7 DEC
    cpu.decReg('A');
    goto L_80B5C8;
L_80B5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB5C8u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B5C8 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B5CB;
L_80B5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CB TYA
    cpu.transfer("TYA");
    goto L_80B5CC;
L_80B5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CC AND
    cpu.logicAnd(0x3FFu);
    goto L_80B5CF;
L_80B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CF STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B5D1;
L_80B5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D1 SEP
    cpu.sep(0x20u);
    goto L_80B5D3;
L_80B5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D3 LDA
    cpu.setA(0x4u, 8);
    goto L_80B5D5;
L_80B5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D5 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B5D7;
L_80B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B5D7u);return;} hw.unresolvedReturn(0x80B5D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D8 REP
    cpu.rep(0x20u);
    goto L_80B5DA;
L_80B5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5DC;
L_80B5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DC CLC
    cpu.setFlag('C', false);
    goto L_80B5DD;
L_80B5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5DF;
L_80B5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B5E1;
L_80B5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E1 BCC -> $80B5E7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B5E7; }
    goto L_80B5E3;
L_80B5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E3 BNE -> $80B61B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B61B; }
    goto L_80B5E5;
L_80B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E5 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B5E7;
L_80B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5E9;
L_80B5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5EB;
L_80B5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EB TAX
    cpu.transfer("TAX");
    goto L_80B5EC;
L_80B5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5EE;
L_80B5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5F0;
L_80B5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F0 TAY
    cpu.transfer("TAY");
    goto L_80B5F1;
L_80B5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F1 LDA
    cpu.setA(0x400u, 16);
    goto L_80B5F4;
L_80B5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F4 SEC
    cpu.setFlag('C', true);
    goto L_80B5F5;
L_80B5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5F7;
L_80B5F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F7 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_80B5F9;
L_80B5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F9 BCS -> $80B60A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B60A; }
    goto L_80B5FB;
L_80B5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FB STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B5FD;
L_80B5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FD DEC
    cpu.decReg('A');
    goto L_80B5FE;
L_80B5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB5FEu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B5FE MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B601;
L_80B601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B601 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B603;
L_80B603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B603 SEC
    cpu.setFlag('C', true);
    goto L_80B604;
L_80B604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B604 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B606;
L_80B606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B606 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B608;
L_80B608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B608 BRA -> $80B60C
    goto L_80B60C;
L_80B60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B60C;
L_80B60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60C DEC
    cpu.decReg('A');
    goto L_80B60D;
L_80B60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB60Du, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B60D MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B610;
L_80B610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B610 TYA
    cpu.transfer("TYA");
    goto L_80B611;
L_80B611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B611 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B614;
L_80B614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B614 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B616;
L_80B616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B616 SEP
    cpu.sep(0x20u);
    goto L_80B618;
L_80B618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B618 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B61A;
L_80B61A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B61A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B61Au);return;} hw.unresolvedReturn(0x80B61Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61B INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B61D;
L_80B61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B61F;
L_80B61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B621;
L_80B621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B621 TAX
    cpu.transfer("TAX");
    goto L_80B622;
L_80B622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B622 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B624;
L_80B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B624 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B626;
L_80B626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B626 TAY
    cpu.transfer("TAY");
    goto L_80B627;
L_80B627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B627 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B629;
L_80B629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B629 SEC
    cpu.setFlag('C', true);
    goto L_80B62A;
L_80B62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B62C;
L_80B62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62C STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80B62E;
L_80B62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B630;
L_80B630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B630 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B632;
L_80B632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B632 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B634;
L_80B634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B634 LDA
    cpu.setA(0x400u, 16);
    goto L_80B637;
L_80B637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B637 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B639;
L_80B639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B639 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B63B;
L_80B63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63B BCS -> $80B64C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B64C; }
    goto L_80B63D;
L_80B63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63D STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B63F;
L_80B63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63F DEC
    cpu.decReg('A');
    goto L_80B640;
L_80B640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB640u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB640u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B640 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B643;
L_80B643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B643 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B645;
L_80B645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B645 SEC
    cpu.setFlag('C', true);
    goto L_80B646;
L_80B646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B646 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B648;
L_80B648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B648 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B64A;
L_80B64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64A BRA -> $80B64E
    goto L_80B64E;
L_80B64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B64E;
L_80B64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64E DEC
    cpu.decReg('A');
    goto L_80B64F;
L_80B64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB64Fu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B64F MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B652;
L_80B652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B652 TYA
    cpu.transfer("TYA");
    goto L_80B653;
L_80B653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B653 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B656;
L_80B656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B656 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B658;
L_80B658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B658 TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB659u,0x80B658u); return;
}

void sub_80B3E1_E0M1X0CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80B533u: goto L_80B533;
    case 0x80B535u: goto L_80B535;
    case 0x80B536u: goto L_80B536;
    case 0x80B538u: goto L_80B538;
    case 0x80B53Au: goto L_80B53A;
    case 0x80B53Bu: goto L_80B53B;
    case 0x80B53Du: goto L_80B53D;
    case 0x80B53Eu: goto L_80B53E;
    case 0x80B53Fu: goto L_80B53F;
    case 0x80B541u: goto L_80B541;
    case 0x80B542u: goto L_80B542;
    case 0x80B544u: goto L_80B544;
    case 0x80B545u: goto L_80B545;
    case 0x80B547u: goto L_80B547;
    case 0x80B549u: goto L_80B549;
    case 0x80B54Bu: goto L_80B54B;
    case 0x80B54Du: goto L_80B54D;
    case 0x80B54Eu: goto L_80B54E;
    case 0x80B550u: goto L_80B550;
    case 0x80B552u: goto L_80B552;
    case 0x80B556u: goto L_80B556;
    case 0x80B558u: goto L_80B558;
    case 0x80B559u: goto L_80B559;
    case 0x80B55Bu: goto L_80B55B;
    case 0x80B55Fu: goto L_80B55F;
    case 0x80B561u: goto L_80B561;
    case 0x80B562u: goto L_80B562;
    case 0x80B565u: goto L_80B565;
    case 0x80B567u: goto L_80B567;
    case 0x80B569u: goto L_80B569;
    case 0x80B56Bu: goto L_80B56B;
    case 0x80B56Du: goto L_80B56D;
    case 0x80B56Eu: goto L_80B56E;
    case 0x80B570u: goto L_80B570;
    case 0x80B572u: goto L_80B572;
    case 0x80B573u: goto L_80B573;
    case 0x80B575u: goto L_80B575;
    case 0x80B577u: goto L_80B577;
    case 0x80B579u: goto L_80B579;
    case 0x80B57Bu: goto L_80B57B;
    case 0x80B57Du: goto L_80B57D;
    case 0x80B57Fu: goto L_80B57F;
    case 0x80B581u: goto L_80B581;
    case 0x80B582u: goto L_80B582;
    case 0x80B583u: goto L_80B583;
    case 0x80B584u: goto L_80B584;
    case 0x80B586u: goto L_80B586;
    case 0x80B588u: goto L_80B588;
    case 0x80B58Bu: goto L_80B58B;
    case 0x80B58Du: goto L_80B58D;
    case 0x80B58Fu: goto L_80B58F;
    case 0x80B590u: goto L_80B590;
    case 0x80B592u: goto L_80B592;
    case 0x80B593u: goto L_80B593;
    case 0x80B596u: goto L_80B596;
    case 0x80B597u: goto L_80B597;
    case 0x80B59Au: goto L_80B59A;
    case 0x80B59Cu: goto L_80B59C;
    case 0x80B59Eu: goto L_80B59E;
    case 0x80B5A0u: goto L_80B5A0;
    case 0x80B5A2u: goto L_80B5A2;
    case 0x80B5A3u: goto L_80B5A3;
    case 0x80B5A5u: goto L_80B5A5;
    case 0x80B5A7u: goto L_80B5A7;
    case 0x80B5A8u: goto L_80B5A8;
    case 0x80B5AAu: goto L_80B5AA;
    case 0x80B5ABu: goto L_80B5AB;
    case 0x80B5AEu: goto L_80B5AE;
    case 0x80B5AFu: goto L_80B5AF;
    case 0x80B5B1u: goto L_80B5B1;
    case 0x80B5B3u: goto L_80B5B3;
    case 0x80B5B5u: goto L_80B5B5;
    case 0x80B5B7u: goto L_80B5B7;
    case 0x80B5B8u: goto L_80B5B8;
    case 0x80B5BAu: goto L_80B5BA;
    case 0x80B5BCu: goto L_80B5BC;
    case 0x80B5BFu: goto L_80B5BF;
    case 0x80B5C1u: goto L_80B5C1;
    case 0x80B5C2u: goto L_80B5C2;
    case 0x80B5C3u: goto L_80B5C3;
    case 0x80B5C4u: goto L_80B5C4;
    case 0x80B5C5u: goto L_80B5C5;
    case 0x80B5C7u: goto L_80B5C7;
    case 0x80B5C8u: goto L_80B5C8;
    case 0x80B5CBu: goto L_80B5CB;
    case 0x80B5CCu: goto L_80B5CC;
    case 0x80B5CFu: goto L_80B5CF;
    case 0x80B5D1u: goto L_80B5D1;
    case 0x80B5D3u: goto L_80B5D3;
    case 0x80B5D5u: goto L_80B5D5;
    case 0x80B5D7u: goto L_80B5D7;
    case 0x80B5D8u: goto L_80B5D8;
    case 0x80B5DAu: goto L_80B5DA;
    case 0x80B5DCu: goto L_80B5DC;
    case 0x80B5DDu: goto L_80B5DD;
    case 0x80B5DFu: goto L_80B5DF;
    case 0x80B5E1u: goto L_80B5E1;
    case 0x80B5E3u: goto L_80B5E3;
    case 0x80B5E5u: goto L_80B5E5;
    case 0x80B5E7u: goto L_80B5E7;
    case 0x80B5E9u: goto L_80B5E9;
    case 0x80B5EBu: goto L_80B5EB;
    case 0x80B5ECu: goto L_80B5EC;
    case 0x80B5EEu: goto L_80B5EE;
    case 0x80B5F0u: goto L_80B5F0;
    case 0x80B5F1u: goto L_80B5F1;
    case 0x80B5F4u: goto L_80B5F4;
    case 0x80B5F5u: goto L_80B5F5;
    case 0x80B5F7u: goto L_80B5F7;
    case 0x80B5F9u: goto L_80B5F9;
    case 0x80B5FBu: goto L_80B5FB;
    case 0x80B5FDu: goto L_80B5FD;
    case 0x80B5FEu: goto L_80B5FE;
    case 0x80B601u: goto L_80B601;
    case 0x80B603u: goto L_80B603;
    case 0x80B604u: goto L_80B604;
    case 0x80B606u: goto L_80B606;
    case 0x80B608u: goto L_80B608;
    case 0x80B60Au: goto L_80B60A;
    case 0x80B60Cu: goto L_80B60C;
    case 0x80B60Du: goto L_80B60D;
    case 0x80B610u: goto L_80B610;
    case 0x80B611u: goto L_80B611;
    case 0x80B614u: goto L_80B614;
    case 0x80B616u: goto L_80B616;
    case 0x80B618u: goto L_80B618;
    case 0x80B61Au: goto L_80B61A;
    case 0x80B61Bu: goto L_80B61B;
    case 0x80B61Du: goto L_80B61D;
    case 0x80B61Fu: goto L_80B61F;
    case 0x80B621u: goto L_80B621;
    case 0x80B622u: goto L_80B622;
    case 0x80B624u: goto L_80B624;
    case 0x80B626u: goto L_80B626;
    case 0x80B627u: goto L_80B627;
    case 0x80B629u: goto L_80B629;
    case 0x80B62Au: goto L_80B62A;
    case 0x80B62Cu: goto L_80B62C;
    case 0x80B62Eu: goto L_80B62E;
    case 0x80B630u: goto L_80B630;
    case 0x80B632u: goto L_80B632;
    case 0x80B634u: goto L_80B634;
    case 0x80B637u: goto L_80B637;
    case 0x80B639u: goto L_80B639;
    case 0x80B63Bu: goto L_80B63B;
    case 0x80B63Du: goto L_80B63D;
    case 0x80B63Fu: goto L_80B63F;
    case 0x80B640u: goto L_80B640;
    case 0x80B643u: goto L_80B643;
    case 0x80B645u: goto L_80B645;
    case 0x80B646u: goto L_80B646;
    case 0x80B648u: goto L_80B648;
    case 0x80B64Au: goto L_80B64A;
    case 0x80B64Cu: goto L_80B64C;
    case 0x80B64Eu: goto L_80B64E;
    case 0x80B64Fu: goto L_80B64F;
    case 0x80B652u: goto L_80B652;
    case 0x80B653u: goto L_80B653;
    case 0x80B656u: goto L_80B656;
    case 0x80B658u: goto L_80B658;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80B533:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB533u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB533u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B533 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B535;
L_80B535:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB535u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB535u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B535 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B535u);return;} hw.unresolvedReturn(0x80B535u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B536:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB536u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB536u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B536 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B538;
L_80B538:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB538u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB538u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B538 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B53A;
L_80B53A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53A SEC
    cpu.setFlag('C', true);
    goto L_80B53B;
L_80B53B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53B SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B53D;
L_80B53D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53D DEC
    cpu.decReg('A');
    goto L_80B53E;
L_80B53E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Eu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53E TAX
    cpu.transfer("TAX");
    goto L_80B53F;
L_80B53F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB53Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB53Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B53F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B541;
L_80B541:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB541u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB541u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B541 CLC
    cpu.setFlag('C', false);
    goto L_80B542;
L_80B542:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB542u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB542u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB542u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B542 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B544;
L_80B544:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB544u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB544u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B544 SEC
    cpu.setFlag('C', true);
    goto L_80B545;
L_80B545:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB545u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB545u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB545u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B545 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B547;
L_80B547:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB547u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB547u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B547 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B549;
L_80B549:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB549u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB549u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B549 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B54B;
L_80B54B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Bu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Bu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54B ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B54D;
L_80B54D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54D TAY
    cpu.transfer("TAY");
    goto L_80B54E;
L_80B54E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB54Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB54Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B54E SEP
    cpu.sep(0x20u);
    goto L_80B550;
L_80B550:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB550u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB550u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B550 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B552;
L_80B552:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB552u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB552u, 5u, 4u, 0x8000BEu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B552 STA
    hw.write(0x8000BEu, cpu.a, cpu.m8?8:16);
    goto L_80B556;
L_80B556:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB556u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB556u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B556 REP
    cpu.rep(0x20u);
    goto L_80B558;
L_80B558:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB558u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB558u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B558 TXA
    cpu.transfer("TXA");
    goto L_80B559;
L_80B559:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB559u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB559u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B559 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0xDu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B55B;
L_80B55B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Bu, 8u, 4u, 0x8000BCu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80B55B JSL -> $8000BC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB55Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB55Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8000BCu, 0x80B55Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80B55F;
L_80B55F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB55Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB55Fu,0x80B55Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB55Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B55F STX
    hw.write(cpu.address("dp", 0xDu), cpu.x, cpu.x8?8:16);
    goto L_80B561;
L_80B561:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB561u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB561u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B561 TYA
    cpu.transfer("TYA");
    goto L_80B562;
L_80B562:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB562u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB562u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B562 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B565;
L_80B565:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB565u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB565u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B565 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B567;
L_80B567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB567u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B567 SEP
    cpu.sep(0x20u);
    goto L_80B569;
L_80B569:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB569u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB569u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB569u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B569 LDA
    cpu.setA(0x6u, 8);
    goto L_80B56B;
L_80B56B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56B STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B56D;
L_80B56D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B56D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B56Du);return;} hw.unresolvedReturn(0x80B56Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B56E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB56Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Eu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB56Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B56E REP
    cpu.rep(0x20u);
    goto L_80B570;
L_80B570:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB570u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB570u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB570u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B570 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B572;
L_80B572:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB572u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB572u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B572 CLC
    cpu.setFlag('C', false);
    goto L_80B573;
L_80B573:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB573u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB573u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B573 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B575;
L_80B575:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB575u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB575u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B575 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B577;
L_80B577:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB577u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB577u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B577 BCC -> $80B57D
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B57D; }
    goto L_80B579;
L_80B579:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB579u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB579u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B579 BNE -> $80B5A3
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5A3; }
    goto L_80B57B;
L_80B57B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57B INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B57D;
L_80B57D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B57F;
L_80B57F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB57Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB57Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B57F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B581;
L_80B581:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB581u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB581u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB581u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B581 TAX
    cpu.transfer("TAX");
    goto L_80B582;
L_80B582:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB582u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB582u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B582 TAY
    cpu.transfer("TAY");
    goto L_80B583;
L_80B583:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB583u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB583u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB583u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B583 INY
    cpu.inc('Y');
    goto L_80B584;
L_80B584:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB584u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB584u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B584 SEP
    cpu.sep(0x20u);
    goto L_80B586;
L_80B586:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB586u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB586u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B586 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B588;
L_80B588:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB588u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB588u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B588 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B58B;
L_80B58B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58B REP
    cpu.rep(0x20u);
    goto L_80B58D;
L_80B58D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B58F;
L_80B58F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB58Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB58Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B58F DEC
    cpu.decReg('A');
    goto L_80B590;
L_80B590:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB590u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB590u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B590 BEQ -> $80B596
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B596; }
    goto L_80B592;
L_80B592:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB592u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB592u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B592 DEC
    cpu.decReg('A');
    goto L_80B593;
L_80B593:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB593u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB593u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB593u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B593 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B596;
L_80B596:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB596u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB596u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B596 TYA
    cpu.transfer("TYA");
    goto L_80B597;
L_80B597:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB597u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB597u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B597 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B59A;
L_80B59A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59A STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B59C;
L_80B59C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59C SEP
    cpu.sep(0x20u);
    goto L_80B59E;
L_80B59E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB59Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB59Eu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x29u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B59E STZ
    hw.write(cpu.address("dp", 0x29u), 0, cpu.m8?8:16);
    goto L_80B5A0;
L_80B5A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A0 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B5A2;
L_80B5A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A2u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A2u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5A2 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B5A2u);return;} hw.unresolvedReturn(0x80B5A2u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B5A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A3u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A3 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B5A5;
L_80B5A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A5 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5A7;
L_80B5A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A7 SEC
    cpu.setFlag('C', true);
    goto L_80B5A8;
L_80B5A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A8u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5A8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5A8 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5AA;
L_80B5AA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AA TAY
    cpu.transfer("TAY");
    goto L_80B5AB;
L_80B5AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ABu,cpu,0x49u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ABu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AB EOR
    cpu.logicXor(0xFFFFu);
    goto L_80B5AE;
L_80B5AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AE SEC
    cpu.setFlag('C', true);
    goto L_80B5AF;
L_80B5AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AFu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5AFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5AF ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_80B5B1;
L_80B5B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B1u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B1 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B5B3;
L_80B5B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B3 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5B5;
L_80B5B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5B7;
L_80B5B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B7 TAX
    cpu.transfer("TAX");
    goto L_80B5B8;
L_80B5B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5B8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5B8 SEP
    cpu.sep(0x20u);
    goto L_80B5BA;
L_80B5BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x24u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5BC;
L_80B5BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BCu, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BC STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80B5BF;
L_80B5BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5BFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5BF REP
    cpu.rep(0x20u);
    goto L_80B5C1;
L_80B5C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C1 TYA
    cpu.transfer("TYA");
    goto L_80B5C2;
L_80B5C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u,cpu,0x9Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C2 TXY
    cpu.transfer("TXY");
    goto L_80B5C3;
L_80B5C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C3 INY
    cpu.inc('Y');
    goto L_80B5C4;
L_80B5C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C4 DEC
    cpu.decReg('A');
    goto L_80B5C5;
L_80B5C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C5 BEQ -> $80B5CB
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B5CB; }
    goto L_80B5C7;
L_80B5C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5C7 DEC
    cpu.decReg('A');
    goto L_80B5C8;
L_80B5C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5C8u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB5C8u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B5C8 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B5CB;
L_80B5CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CB TYA
    cpu.transfer("TYA");
    goto L_80B5CC;
L_80B5CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CC AND
    cpu.logicAnd(0x3FFu);
    goto L_80B5CF;
L_80B5CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5CFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5CF STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B5D1;
L_80B5D1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D1u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D1 SEP
    cpu.sep(0x20u);
    goto L_80B5D3;
L_80B5D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D3 LDA
    cpu.setA(0x4u, 8);
    goto L_80B5D5;
L_80B5D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D5u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D5 STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_80B5D7;
L_80B5D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B5D7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B5D7u);return;} hw.unresolvedReturn(0x80B5D7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B5D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5D8 REP
    cpu.rep(0x20u);
    goto L_80B5DA;
L_80B5DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5DC;
L_80B5DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DC CLC
    cpu.setFlag('C', false);
    goto L_80B5DD;
L_80B5DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DD ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5DF;
L_80B5DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5DFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5DF CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_80B5E1;
L_80B5E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E1 BCC -> $80B5E7
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B5E7; }
    goto L_80B5E3;
L_80B5E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E3 BNE -> $80B61B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80B61B; }
    goto L_80B5E5;
L_80B5E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E5u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E5 INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B5E7;
L_80B5E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5E9;
L_80B5E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5E9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5E9 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5EB;
L_80B5EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EB TAX
    cpu.transfer("TAX");
    goto L_80B5EC;
L_80B5EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5ECu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EC LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B5EE;
L_80B5EE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5EEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5EEu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5EE ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B5F0;
L_80B5F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F0 TAY
    cpu.transfer("TAY");
    goto L_80B5F1;
L_80B5F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F1 LDA
    cpu.setA(0x400u, 16);
    goto L_80B5F4;
L_80B5F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F4 SEC
    cpu.setFlag('C', true);
    goto L_80B5F5;
L_80B5F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F5 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B5F7;
L_80B5F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F7 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16));
    goto L_80B5F9;
L_80B5F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5F9 BCS -> $80B60A
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B60A; }
    goto L_80B5FB;
L_80B5FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FB STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B5FD;
L_80B5FD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B5FD DEC
    cpu.decReg('A');
    goto L_80B5FE;
L_80B5FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB5FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB5FEu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB5FEu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B5FE MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B601;
L_80B601:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB601u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB601u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B601 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B603;
L_80B603:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB603u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB603u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B603 SEC
    cpu.setFlag('C', true);
    goto L_80B604;
L_80B604:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB604u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB604u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B604 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B606;
L_80B606:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB606u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB606u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B606 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B608;
L_80B608:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB608u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB608u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B608 BRA -> $80B60C
    goto L_80B60C;
L_80B60A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60A LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B60C;
L_80B60C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B60C DEC
    cpu.decReg('A');
    goto L_80B60D;
L_80B60D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB60Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB60Du,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB60Du, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B60D MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B610;
L_80B610:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB610u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB610u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B610 TYA
    cpu.transfer("TYA");
    goto L_80B611;
L_80B611:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB611u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB611u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B611 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B614;
L_80B614:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB614u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB614u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B614 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B616;
L_80B616:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB616u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB616u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B616 SEP
    cpu.sep(0x20u);
    goto L_80B618;
L_80B618:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB618u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB618u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B618 STZ
    hw.write(cpu.address("dp", 0x22u), 0, cpu.m8?8:16);
    goto L_80B61A;
L_80B61A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $80B61A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x80B61Au);return;} hw.unresolvedReturn(0x80B61Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_80B61B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Bu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61B INC
    cpu.incMem(hw, cpu.address("dp", 0x1Cu), cpu.m8?8:16);
    goto L_80B61D;
L_80B61D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B61F;
L_80B61F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB61Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB61Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B61F ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B621;
L_80B621:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB621u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB621u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B621 TAX
    cpu.transfer("TAX");
    goto L_80B622;
L_80B622:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB622u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB622u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B622 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x11u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B624;
L_80B624:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB624u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB624u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B624 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B626;
L_80B626:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB626u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB626u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B626 TAY
    cpu.transfer("TAY");
    goto L_80B627;
L_80B627:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB627u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB627u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B627 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B629;
L_80B629:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB629u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB629u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B629 SEC
    cpu.setFlag('C', true);
    goto L_80B62A;
L_80B62A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62A SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x13u), cpu.m8?8:16));
    goto L_80B62C;
L_80B62C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62C STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_80B62E;
L_80B62E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB62Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB62Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B62E LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x28u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B630;
L_80B630:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB630u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB630u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B630 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B632;
L_80B632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB632u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B632 STA
    hw.write(cpu.address("dp", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80B634;
L_80B634:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB634u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB634u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B634 LDA
    cpu.setA(0x400u, 16);
    goto L_80B637;
L_80B637:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB637u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB637u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x25u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B637 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x25u), cpu.m8?8:16));
    goto L_80B639;
L_80B639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u,cpu,0xC5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB639u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B639 CMP
    cpu.compareA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16));
    goto L_80B63B;
L_80B63B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63B BCS -> $80B64C
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_80B64C; }
    goto L_80B63D;
L_80B63D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63D STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80B63F;
L_80B63F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB63Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB63Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B63F DEC
    cpu.decReg('A');
    goto L_80B640;
L_80B640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB640u,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB640u, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B640 MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B643;
L_80B643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB643u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B643 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B645;
L_80B645:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB645u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB645u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B645 SEC
    cpu.setFlag('C', true);
    goto L_80B646;
L_80B646:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB646u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB646u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B646 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16));
    goto L_80B648;
L_80B648:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB648u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB648u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x11u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B648 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x11u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80B64A;
L_80B64A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64A BRA -> $80B64E
    goto L_80B64E;
L_80B64C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64C LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80B64E;
L_80B64E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B64E DEC
    cpu.decReg('A');
    goto L_80B64F;
L_80B64F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB64Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB64Fu,cpu,0x54u);
    hw.advanceCpuBlockMove((std::uint32_t(cpu.pb)<<16)|0xB64Fu, (std::uint32_t(cpu.a)+1u), 0x7Eu, 0x7Eu);
    // $80B64F MVN
    cpu.blockMove(hw, 0x7Eu, 0x7Eu, false);
    goto L_80B652;
L_80B652:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB652u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB652u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B652 TYA
    cpu.transfer("TYA");
    goto L_80B653;
L_80B653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB653u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B653 AND
    cpu.logicAnd(0x3FFu);
    goto L_80B656;
L_80B656:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB656u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB656u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x13u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B656 STA
    hw.write(cpu.address("dp", 0x13u), cpu.a, cpu.m8?8:16);
    goto L_80B658;
L_80B658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB658u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80B658 TXA
    cpu.transfer("TXA");
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB659u,0x80B658u); return;
}

void sub_80BE7A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80BE7Au: goto L_80BE7A;
    case 0x80BE7Du: goto L_80BE7D;
    case 0x80BE80u: goto L_80BE80;
    case 0x80BE82u: goto L_80BE82;
    case 0x80BE84u: goto L_80BE84;
    case 0x80BE88u: goto L_80BE88;
    case 0x80BE8Bu: goto L_80BE8B;
    case 0x80BE8Du: goto L_80BE8D;
    case 0x80BE91u: goto L_80BE91;
    case 0x80BE95u: goto L_80BE95;
    case 0x80BE99u: goto L_80BE99;
    case 0x80BE9Du: goto L_80BE9D;
    case 0x80BEA1u: goto L_80BEA1;
    case 0x80BEA2u: goto L_80BEA2;
    case 0x80BEA4u: goto L_80BEA4;
    case 0x80BEA7u: goto L_80BEA7;
    case 0x80BEAAu: goto L_80BEAA;
    case 0x80BEACu: goto L_80BEAC;
    case 0x80BEB0u: goto L_80BEB0;
    case 0x80BEB4u: goto L_80BEB4;
    case 0x80BEB8u: goto L_80BEB8;
    case 0x80BEBCu: goto L_80BEBC;
    case 0x80BEC0u: goto L_80BEC0;
    case 0x80BEC2u: goto L_80BEC2;
    case 0x80BEC4u: goto L_80BEC4;
    case 0x80BEC8u: goto L_80BEC8;
    case 0x80BECBu: goto L_80BECB;
    case 0x80BECDu: goto L_80BECD;
    case 0x80BECFu: goto L_80BECF;
    case 0x80BED0u: goto L_80BED0;
    case 0x80BED3u: goto L_80BED3;
    case 0x80BED5u: goto L_80BED5;
    case 0x80BED8u: goto L_80BED8;
    case 0x80BEDAu: goto L_80BEDA;
    case 0x80BEDBu: goto L_80BEDB;
    case 0x80BEDFu: goto L_80BEDF;
    case 0x80BEE2u: goto L_80BEE2;
    case 0x80BEE5u: goto L_80BEE5;
    case 0x80BEE8u: goto L_80BEE8;
    case 0x80BEEAu: goto L_80BEEA;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80BE7A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE7Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE7Au,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE7Au, 5u, 3u, cpu.address("abs", 0x1C14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE7A STZ
    hw.write(cpu.address("abs", 0x1C14u), 0, cpu.m8?8:16);
    goto L_80BE7D;
L_80BE7D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE7Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE7Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE7Du, 5u, 3u, cpu.address("abs", 0x1C16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE7D STZ
    hw.write(cpu.address("abs", 0x1C16u), 0, cpu.m8?8:16);
    goto L_80BE80;
L_80BE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE80u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE80u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x4Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE80 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x4Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE82;
L_80BE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE82u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE82u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE82 BEQ -> $80BE88
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE88; }
    goto L_80BE84;
L_80BE84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE84u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE84u, 8u, 4u, 0x82EE99u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE84 JSL -> $82EE99 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE87u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE88u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82EE99u, 0x80BE84u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE88;
L_80BE88:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE88u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE88u,0x80BE88u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE88u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE88u, 5u, 3u, cpu.address("abs", 0x1BCEu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE88 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x1BCEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BE8B;
L_80BE8B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BE8B BNE -> $80BE91
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BE91; }
    goto L_80BE8D;
L_80BE8D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE8Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE8Du, 8u, 4u, 0x84D788u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE8D JSL -> $84D788 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE90u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE91u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84D788u, 0x80BE8Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE91;
L_80BE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE91u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE91u,0x80BE91u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE91u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE91u, 8u, 4u, 0x8382C6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE91 JSL -> $8382C6 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE94u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE95u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8382C6u, 0x80BE91u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE95;
L_80BE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE95u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE95u,0x80BE95u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE95u, 8u, 4u, 0x848000u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE95 JSL -> $848000 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE98u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE99u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848000u, 0x80BE95u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE99;
L_80BE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE99u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE99u,0x80BE99u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE99u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE99u, 8u, 4u, 0x80C518u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE99 JSL -> $80C518 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBE9Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBE9Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C518u, 0x80BE99u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BE9D;
L_80BE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBE9Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBE9Du,0x80BE9Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBE9Du, 8u, 4u, 0x80C477u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BE9D JSL -> $80C477 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEA0u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEA1u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80C477u, 0x80BE9Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEA1;
L_80BEA1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA1u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEA1u,0x80BEA1u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA1u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA1 CLC
    cpu.setFlag('C', false);
    goto L_80BEA2;
L_80BEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x88u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x88u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEA4;
L_80BEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA4 ADC
    cpu.adc(0x14u);
    goto L_80BEA7;
L_80BEA7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEA7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEA7u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEA7 AND
    cpu.logicAnd(0xFu);
    goto L_80BEAA;
L_80BEAA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEAAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAAu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEAAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEAA BNE -> $80BEAC
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BEAC; }
    goto L_80BEAC;
L_80BEAC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEACu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEACu, 8u, 4u, 0x828846u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEAC JSL -> $828846 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEAFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEB0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x828846u, 0x80BEACu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEB0;
L_80BEB0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEB0u,0x80BEB0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB0u, 8u, 4u, 0x829AACu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEB0 JSL -> $829AAC stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEB3u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEB4u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829AACu, 0x80BEB0u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEB4;
L_80BEB4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB4u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEB4u,0x80BEB4u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB4u, 8u, 4u, 0x829483u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEB4 JSL -> $829483 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEB7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEB8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829483u, 0x80BEB4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEB8;
L_80BEB8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEB8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEB8u,0x80BEB8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEB8u, 8u, 4u, 0x829CE3u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEB8 JSL -> $829CE3 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEBBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEBCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829CE3u, 0x80BEB8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEBC;
L_80BEBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEBCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEBCu,0x80BEBCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBCu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEBCu, 8u, 4u, 0x829217u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEBC JSL -> $829217 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEBFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEC0u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x829217u, 0x80BEBCu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEC0;
L_80BEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEC0u,0x80BEC0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC0u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC0 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BEC2;
L_80BEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC2 BNE -> $80BEC8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_80BEC8; }
    goto L_80BEC4;
L_80BEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC4u, 8u, 4u, 0x80A725u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEC4 JSL -> $80A725 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEC7u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEC8u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A725u, 0x80BEC4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEC8;
L_80BEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEC8u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEC8u,0x80BEC8u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u,cpu,0x2Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEC8u, 5u, 3u, cpu.address("abs", 0x1BC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEC8 BIT
    cpu.bit(hw.readW(cpu.address("abs", 0x1BC6u), cpu.m8?8:16), false);
    goto L_80BECB;
L_80BECB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BECB BMI -> $80BEDA
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BEDA; }
    goto L_80BECD;
L_80BECD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x5Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BECD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x5Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BECF;
L_80BECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBECFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BECF ASL
    cpu.aslA();
    goto L_80BED0;
L_80BED0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED0u, 5u, 3u, cpu.address("abs", 0x17C4u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17C4u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80BED3;
L_80BED3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED3 BCC -> $80BED8
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_80BED8; }
    goto L_80BED5;
L_80BED5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u,cpu,0x2Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED5u, 5u, 3u, cpu.address("abs", 0x1814u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED5 AND
    cpu.logicAnd(hw.readW(cpu.address("abs", 0x1814u), cpu.m8?8:16));
    goto L_80BED8;
L_80BED8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBED8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBED8u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBED8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BED8 BMI -> $80BEDB
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80BEDB; }
    goto L_80BEDA;
L_80BEDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEDA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BEDAu);return;} hw.unresolvedReturn(0x80BEDAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80BEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDBu, 8u, 4u, 0x80BC14u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEDB JSL -> $80BC14 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xBEDEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xBEDFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80BC14u, 0x80BEDBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_80BEDF;
L_80BEDF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEDFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xBEDFu,0x80BEDFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEDFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEDF LDA
    cpu.setA(0x8000u, 16);
    goto L_80BEE2;
L_80BEE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE2u, 5u, 3u, cpu.address("abs", 0x1BC6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE2 STA
    hw.write(cpu.address("abs", 0x1BC6u), cpu.a, cpu.m8?8:16);
    goto L_80BEE5;
L_80BEE5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE5 LDY
    cpu.setY(0xE0u, 16);
    goto L_80BEE8;
L_80BEE8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEE8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEE8u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x86u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80BEE8 STY
    hw.write(cpu.address("dp", 0x86u), cpu.y, cpu.x8?8:16);
    goto L_80BEEA;
L_80BEEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xBEEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEAu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xBEEAu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80BEEA RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80BEEAu);return;} hw.unresolvedReturn(0x80BEEAu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C39F_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C39Fu: goto L_80C39F;
    case 0x80C3A1u: goto L_80C3A1;
    case 0x80C3A3u: goto L_80C3A3;
    case 0x80C3A5u: goto L_80C3A5;
    case 0x80C3ADu: goto L_80C3AD;
    case 0x80C3AFu: goto L_80C3AF;
    case 0x80C3B1u: goto L_80C3B1;
    case 0x80C3B4u: goto L_80C3B4;
    case 0x80C3B6u: goto L_80C3B6;
    case 0x80C3B8u: goto L_80C3B8;
    case 0x80C3B9u: goto L_80C3B9;
    case 0x80C3BAu: goto L_80C3BA;
    case 0x80C3BCu: goto L_80C3BC;
    case 0x80C3BDu: goto L_80C3BD;
    case 0x80C3BEu: goto L_80C3BE;
    case 0x80C3C1u: goto L_80C3C1;
    case 0x80C3C3u: goto L_80C3C3;
    case 0x80C3C5u: goto L_80C3C5;
    case 0x80C3C7u: goto L_80C3C7;
    case 0x80C3C8u: goto L_80C3C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39F STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80C3A1;
L_80C3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A1u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A1 STY
    hw.write(cpu.address("dpx", 0x2Cu), cpu.y, cpu.x8?8:16);
    goto L_80C3A3;
L_80C3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A3 STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3A5;
L_80C3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A5 BRA -> $80C3AD
    goto L_80C3AD;
L_80C3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AD STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80C3AF;
L_80C3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AF LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3B1;
L_80C3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B1u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3B4;
L_80C3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B4 BMI -> $80C3BE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C3BE; }
    goto L_80C3B6;
L_80C3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B6 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3B8;
L_80C3B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B8 INY
    cpu.inc('Y');
    goto L_80C3B9;
L_80C3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B9 INY
    cpu.inc('Y');
    goto L_80C3BA;
L_80C3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BAu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BA STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3BC;
L_80C3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BC CLC
    cpu.setFlag('C', false);
    goto L_80C3BD;
L_80C3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3BD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3BDu);return;} hw.unresolvedReturn(0x80C3BDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BE AND
    cpu.logicAnd(0x7FFFu);
    goto L_80C3C1;
L_80C3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C1 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3C3;
L_80C3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3C5;
L_80C3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C5 STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_80C3C7;
L_80C3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C7 SEC
    cpu.setFlag('C', true);
    goto L_80C3C8;
L_80C3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3C8u);return;} hw.unresolvedReturn(0x80C3C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C39F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C39Fu: goto L_80C39F;
    case 0x80C3A1u: goto L_80C3A1;
    case 0x80C3A3u: goto L_80C3A3;
    case 0x80C3A5u: goto L_80C3A5;
    case 0x80C3ADu: goto L_80C3AD;
    case 0x80C3AFu: goto L_80C3AF;
    case 0x80C3B1u: goto L_80C3B1;
    case 0x80C3B4u: goto L_80C3B4;
    case 0x80C3B6u: goto L_80C3B6;
    case 0x80C3B8u: goto L_80C3B8;
    case 0x80C3B9u: goto L_80C3B9;
    case 0x80C3BAu: goto L_80C3BA;
    case 0x80C3BCu: goto L_80C3BC;
    case 0x80C3BDu: goto L_80C3BD;
    case 0x80C3BEu: goto L_80C3BE;
    case 0x80C3C1u: goto L_80C3C1;
    case 0x80C3C3u: goto L_80C3C3;
    case 0x80C3C5u: goto L_80C3C5;
    case 0x80C3C7u: goto L_80C3C7;
    case 0x80C3C8u: goto L_80C3C8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C39F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC39Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC39Fu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C39F STA
    hw.write(cpu.address("dpx", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_80C3A1;
L_80C3A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A1u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A1 STY
    hw.write(cpu.address("dpx", 0x2Cu), cpu.y, cpu.x8?8:16);
    goto L_80C3A3;
L_80C3A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A3 STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3A5;
L_80C3A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A5u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3A5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3A5 BRA -> $80C3AD
    goto L_80C3AD;
L_80C3AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3ADu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x28u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AD STA
    hw.write(cpu.address("dpx", 0x28u), cpu.a, cpu.m8?8:16);
    goto L_80C3AF;
L_80C3AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu,cpu,0xB4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3AFu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3AF LDY
    cpu.setY(hw.readW(cpu.address("dpx", 0x2Eu), cpu.x8?8:16), cpu.x8?8:16);
    goto L_80C3B1;
L_80C3B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B1u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3B4;
L_80C3B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B4u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B4 BMI -> $80C3BE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_80C3BE; }
    goto L_80C3B6;
L_80C3B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B6u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B6 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3B8;
L_80C3B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B8 INY
    cpu.inc('Y');
    goto L_80C3B9;
L_80C3B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B9u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3B9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3B9 INY
    cpu.inc('Y');
    goto L_80C3BA;
L_80C3BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BAu,cpu,0x94u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BAu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BA STY
    hw.write(cpu.address("dpx", 0x2Eu), cpu.y, cpu.x8?8:16);
    goto L_80C3BC;
L_80C3BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BC CLC
    cpu.setFlag('C', false);
    goto L_80C3BD;
L_80C3BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BDu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BDu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3BD RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3BDu);return;} hw.unresolvedReturn(0x80C3BDu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_80C3BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BEu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3BEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3BE AND
    cpu.logicAnd(0x7FFFu);
    goto L_80C3C1;
L_80C3C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C1u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C1u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C1 STA
    hw.write(cpu.address("dpx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_80C3C3;
L_80C3C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C3u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C3 LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x2Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_80C3C5;
L_80C3C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C5u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C5 STA
    hw.write(cpu.address("dpx", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_80C3C7;
L_80C3C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80C3C7 SEC
    cpu.setFlag('C', true);
    goto L_80C3C8;
L_80C3C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC3C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC3C8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C3C8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C3C8u);return;} hw.unresolvedReturn(0x80C3C8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C518_E0M0X0C0_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C680u: goto L_80C680;
    case 0x80C681u: goto L_80C681;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C680 PLB
    cpu.pop("PLB", hw);
    goto L_80C681;
L_80C681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC681u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC681u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C681 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C681u);return;} hw.unresolvedReturn(0x80C681u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80C518_E0M0X0C1_part2(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80C680u: goto L_80C680;
    case 0x80C681u: goto L_80C681;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80C680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC680u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $80C680 PLB
    cpu.pop("PLB", hw);
    goto L_80C681;
L_80C681:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xC681u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xC681u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xC681u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80C681 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80C681u);return;} hw.unresolvedReturn(0x80C681u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80D99A_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D99Au: goto L_80D99A;
    case 0x80D99Du: goto L_80D99D;
    case 0x80D9A0u: goto L_80D9A0;
    case 0x80D9A4u: goto L_80D9A4;
    case 0x80D9A5u: goto L_80D9A5;
    case 0x80D9A6u: goto L_80D9A6;
    case 0x80D9A8u: goto L_80D9A8;
    case 0x80D9ABu: goto L_80D9AB;
    case 0x80D9AFu: goto L_80D9AF;
    case 0x80D9B0u: goto L_80D9B0;
    case 0x80D9B1u: goto L_80D9B1;
    case 0x80D9B3u: goto L_80D9B3;
    case 0x80D9B6u: goto L_80D9B6;
    case 0x80D9BAu: goto L_80D9BA;
    case 0x80D9BDu: goto L_80D9BD;
    case 0x80D9C1u: goto L_80D9C1;
    case 0x80D9C4u: goto L_80D9C4;
    case 0x80D9C8u: goto L_80D9C8;
    case 0x80D9CBu: goto L_80D9CB;
    case 0x80D9CFu: goto L_80D9CF;
    case 0x80D9D2u: goto L_80D9D2;
    case 0x80D9D6u: goto L_80D9D6;
    case 0x80D9D9u: goto L_80D9D9;
    case 0x80D9DDu: goto L_80D9DD;
    case 0x80D9E1u: goto L_80D9E1;
    case 0x80D9E4u: goto L_80D9E4;
    case 0x80D9E8u: goto L_80D9E8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D99A LDA
    cpu.setA(0x5959u, 16);
    goto L_80D99D;
L_80D99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D99D LDX
    cpu.setX(0xFEu, 16);
    goto L_80D9A0;
L_80D9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u, 6u, 4u, ((0x7EFF00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A0 STA
    hw.write(((0x7EFF00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D9A4;
L_80D9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A4 DEX
    cpu.decReg('X');
    goto L_80D9A5;
L_80D9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A5 DEX
    cpu.decReg('X');
    goto L_80D9A6;
L_80D9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A6 BPL -> $80D9A0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D9A0; }
    goto L_80D9A8;
L_80D9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A8 LDX
    cpu.setX(0xFEu, 16);
    goto L_80D9AB;
L_80D9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu, 6u, 4u, ((0x7EFD00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9AB STA
    hw.write(((0x7EFD00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D9AF;
L_80D9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9AF DEX
    cpu.decReg('X');
    goto L_80D9B0;
L_80D9B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B0 DEX
    cpu.decReg('X');
    goto L_80D9B1;
L_80D9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B1 BPL -> $80D9AB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D9AB; }
    goto L_80D9B3;
L_80D9B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B3 LDA
    cpu.setA(0x4u, 16);
    goto L_80D9B6;
L_80D9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B6u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B6u, 6u, 4u, 0x7EFE80u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B6 STA
    hw.write(0x7EFE80u, cpu.a, cpu.m8?8:16);
    goto L_80D9BA;
L_80D9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9BA LDA
    cpu.setA(0x2u, 16);
    goto L_80D9BD;
L_80D9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu, 6u, 4u, 0x7EFE82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9BD STA
    hw.write(0x7EFE82u, cpu.a, cpu.m8?8:16);
    goto L_80D9C1;
L_80D9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C1 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9C4;
L_80D9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C4 STA
    hw.write(0x7EFE84u, cpu.a, cpu.m8?8:16);
    goto L_80D9C8;
L_80D9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C8 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9CB;
L_80D9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9CB STA
    hw.write(0x7EFE86u, cpu.a, cpu.m8?8:16);
    goto L_80D9CF;
L_80D9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9CF LDA
    cpu.setA(0x0u, 16);
    goto L_80D9D2;
L_80D9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D2u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D2u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D2 STA
    hw.write(0x7EFE88u, cpu.a, cpu.m8?8:16);
    goto L_80D9D6;
L_80D9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D6 LDA
    cpu.setA(0x6u, 16);
    goto L_80D9D9;
L_80D9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D9 STA
    hw.write(0x7EFE8Au, cpu.a, cpu.m8?8:16);
    goto L_80D9DD;
L_80D9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9DD STA
    hw.write(0x7EFE8Cu, cpu.a, cpu.m8?8:16);
    goto L_80D9E1;
L_80D9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9E1 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9E4;
L_80D9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E4u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E4u, 6u, 4u, 0x7EFE8Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9E4 STA
    hw.write(0x7EFE8Eu, cpu.a, cpu.m8?8:16);
    goto L_80D9E8;
L_80D9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D9E8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D9E8u);return;} hw.unresolvedReturn(0x80D9E8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_80D99A_E0M0X0C1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x80D99Au: goto L_80D99A;
    case 0x80D99Du: goto L_80D99D;
    case 0x80D9A0u: goto L_80D9A0;
    case 0x80D9A4u: goto L_80D9A4;
    case 0x80D9A5u: goto L_80D9A5;
    case 0x80D9A6u: goto L_80D9A6;
    case 0x80D9A8u: goto L_80D9A8;
    case 0x80D9ABu: goto L_80D9AB;
    case 0x80D9AFu: goto L_80D9AF;
    case 0x80D9B0u: goto L_80D9B0;
    case 0x80D9B1u: goto L_80D9B1;
    case 0x80D9B3u: goto L_80D9B3;
    case 0x80D9B6u: goto L_80D9B6;
    case 0x80D9BAu: goto L_80D9BA;
    case 0x80D9BDu: goto L_80D9BD;
    case 0x80D9C1u: goto L_80D9C1;
    case 0x80D9C4u: goto L_80D9C4;
    case 0x80D9C8u: goto L_80D9C8;
    case 0x80D9CBu: goto L_80D9CB;
    case 0x80D9CFu: goto L_80D9CF;
    case 0x80D9D2u: goto L_80D9D2;
    case 0x80D9D6u: goto L_80D9D6;
    case 0x80D9D9u: goto L_80D9D9;
    case 0x80D9DDu: goto L_80D9DD;
    case 0x80D9E1u: goto L_80D9E1;
    case 0x80D9E4u: goto L_80D9E4;
    case 0x80D9E8u: goto L_80D9E8;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_80D99A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D99A LDA
    cpu.setA(0x5959u, 16);
    goto L_80D99D;
L_80D99D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD99Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD99Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D99D LDX
    cpu.setX(0xFEu, 16);
    goto L_80D9A0;
L_80D9A0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A0u, 6u, 4u, ((0x7EFF00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A0 STA
    hw.write(((0x7EFF00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D9A4;
L_80D9A4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A4 DEX
    cpu.decReg('X');
    goto L_80D9A5;
L_80D9A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A5u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A5 DEX
    cpu.decReg('X');
    goto L_80D9A6;
L_80D9A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A6 BPL -> $80D9A0
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D9A0; }
    goto L_80D9A8;
L_80D9A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9A8 LDX
    cpu.setX(0xFEu, 16);
    goto L_80D9AB;
L_80D9AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9ABu, 6u, 4u, ((0x7EFD00u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9AB STA
    hw.write(((0x7EFD00u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_80D9AF;
L_80D9AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9AF DEX
    cpu.decReg('X');
    goto L_80D9B0;
L_80D9B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B0u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B0 DEX
    cpu.decReg('X');
    goto L_80D9B1;
L_80D9B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B1 BPL -> $80D9AB
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_80D9AB; }
    goto L_80D9B3;
L_80D9B3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B3 LDA
    cpu.setA(0x4u, 16);
    goto L_80D9B6;
L_80D9B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B6u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9B6u, 6u, 4u, 0x7EFE80u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9B6 STA
    hw.write(0x7EFE80u, cpu.a, cpu.m8?8:16);
    goto L_80D9BA;
L_80D9BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BAu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9BA LDA
    cpu.setA(0x2u, 16);
    goto L_80D9BD;
L_80D9BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9BDu, 6u, 4u, 0x7EFE82u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9BD STA
    hw.write(0x7EFE82u, cpu.a, cpu.m8?8:16);
    goto L_80D9C1;
L_80D9C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C1 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9C4;
L_80D9C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C4u, 6u, 4u, 0x7EFE84u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C4 STA
    hw.write(0x7EFE84u, cpu.a, cpu.m8?8:16);
    goto L_80D9C8;
L_80D9C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9C8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9C8 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9CB;
L_80D9CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CBu, 6u, 4u, 0x7EFE86u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9CB STA
    hw.write(0x7EFE86u, cpu.a, cpu.m8?8:16);
    goto L_80D9CF;
L_80D9CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9CFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9CF LDA
    cpu.setA(0x0u, 16);
    goto L_80D9D2;
L_80D9D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D2u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D2u, 6u, 4u, 0x7EFE88u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D2 STA
    hw.write(0x7EFE88u, cpu.a, cpu.m8?8:16);
    goto L_80D9D6;
L_80D9D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D6u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D6u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D6 LDA
    cpu.setA(0x6u, 16);
    goto L_80D9D9;
L_80D9D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9D9u, 6u, 4u, 0x7EFE8Au, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9D9 STA
    hw.write(0x7EFE8Au, cpu.a, cpu.m8?8:16);
    goto L_80D9DD;
L_80D9DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9DDu, 6u, 4u, 0x7EFE8Cu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9DD STA
    hw.write(0x7EFE8Cu, cpu.a, cpu.m8?8:16);
    goto L_80D9E1;
L_80D9E1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E1u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9E1 LDA
    cpu.setA(0x0u, 16);
    goto L_80D9E4;
L_80D9E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E4u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E4u, 6u, 4u, 0x7EFE8Eu, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $80D9E4 STA
    hw.write(0x7EFE8Eu, cpu.a, cpu.m8?8:16);
    goto L_80D9E8;
L_80D9E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD9E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E8u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD9E8u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $80D9E8 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x80D9E8u);return;} hw.unresolvedReturn(0x80D9E8u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_828687_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x8083B6u: goto L_8083B6;
    case 0x8083B7u: goto L_8083B7;
    case 0x8083B9u: goto L_8083B9;
    case 0x8083BCu: goto L_8083BC;
    case 0x8083BEu: goto L_8083BE;
    case 0x8083C1u: goto L_8083C1;
    case 0x8083C3u: goto L_8083C3;
    case 0x8083C6u: goto L_8083C6;
    case 0x8083C9u: goto L_8083C9;
    case 0x8083CBu: goto L_8083CB;
    case 0x8083CDu: goto L_8083CD;
    case 0x8083CFu: goto L_8083CF;
    case 0x8083D0u: goto L_8083D0;
    case 0x828687u: goto L_828687;
    case 0x82868Au: goto L_82868A;
    case 0x82868Du: goto L_82868D;
    case 0x828691u: goto L_828691;
    case 0x828725u: goto L_828725;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_8083B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u,cpu,0x08u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083B6 PHP
    cpu.push("PHP", hw);
    goto L_8083B7;
L_8083B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B7u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B7 SEP
    cpu.sep(0x20u);
    goto L_8083B9;
L_8083B9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83B9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83B9u, 4u, 3u, cpu.address("abs", 0x4210u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083B9 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x4210u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_8083BC;
L_8083BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BC LDA
    cpu.setA(0xFu, 8);
    goto L_8083BE;
L_8083BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83BEu, 4u, 3u, cpu.address("abs", 0x1FA0u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083BE STA
    hw.write(cpu.address("abs", 0x1FA0u), cpu.a, cpu.m8?8:16);
    goto L_8083C1;
L_8083C1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C1 LDA
    cpu.setA(0x81u, 8);
    goto L_8083C3;
L_8083C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C3u, 4u, 3u, cpu.address("abs", 0x1FA2u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C3 STA
    hw.write(cpu.address("abs", 0x1FA2u), cpu.a, cpu.m8?8:16);
    goto L_8083C6;
L_8083C6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C6 STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_8083C9;
L_8083C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83C9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083C9 LDA
    cpu.setA(0x4u, 8);
    goto L_8083CB;
L_8083CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CBu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x46u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CB STA
    hw.write(cpu.address("dp", 0x46u), cpu.a, cpu.m8?8:16);
    goto L_8083CD;
L_8083CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CDu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $8083CD REP
    cpu.rep(0x20u);
    goto L_8083CF;
L_8083CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu,cpu,0x28u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83CFu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $8083CF PLP
    cpu.pop("PLP", hw);
    goto L_8083D0;
L_8083D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x83D0u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x83D0u,0x8083D0u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x83D0u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $8083D0 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x8083D0u);return;} hw.unresolvedReturn(0x8083D0u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_828687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828687 LDY
    cpu.setY(0x8E6Cu, 16);
    goto L_82868A;
L_82868A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82868A LDX
    cpu.setX(0x1F80u, 16);
    goto L_82868D;
L_82868D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Du, 8u, 4u, 0x80B6DAu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82868D JSL -> $80B6DA stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8690u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8691u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80B6DAu, 0x82868Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_828691;
L_828691:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8691u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8691u,0x828691u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8691u, 3u, 3u, cpu.address("abs", 0x8725u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828691 JMP -> $828725
    goto L_828725;
L_828725:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8725u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u,cpu,0x5Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8725u, 4u, 4u, 0x8083B6u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $828725 JML -> $8083B6
    cpu.pb=0x80u; // JML troca o Program Bank mesmo em goto local recompilado
    goto L_8083B6;
}

void sub_82B800_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B800u: goto L_82B800;
    case 0x82B802u: goto L_82B802;
    case 0x82B804u: goto L_82B804;
    case 0x82B806u: goto L_82B806;
    case 0x82B807u: goto L_82B807;
    case 0x82B808u: goto L_82B808;
    case 0x82B80Bu: goto L_82B80B;
    case 0x82B80Cu: goto L_82B80C;
    case 0x82B80Eu: goto L_82B80E;
    case 0x82B80Fu: goto L_82B80F;
    case 0x82B812u: goto L_82B812;
    case 0x82B814u: goto L_82B814;
    case 0x82B817u: goto L_82B817;
    case 0x82B819u: goto L_82B819;
    case 0x82B81Bu: goto L_82B81B;
    case 0x82B81Cu: goto L_82B81C;
    case 0x82B81Eu: goto L_82B81E;
    case 0x82B820u: goto L_82B820;
    case 0x82B822u: goto L_82B822;
    case 0x82B823u: goto L_82B823;
    case 0x82B825u: goto L_82B825;
    case 0x82B828u: goto L_82B828;
    case 0x82B82Au: goto L_82B82A;
    case 0x82B82Eu: goto L_82B82E;
    case 0x82B82Fu: goto L_82B82F;
    case 0x82B830u: goto L_82B830;
    case 0x82B831u: goto L_82B831;
    case 0x82B832u: goto L_82B832;
    case 0x82B834u: goto L_82B834;
    case 0x82B836u: goto L_82B836;
    case 0x82B838u: goto L_82B838;
    case 0x82B83Au: goto L_82B83A;
    case 0x82B83Cu: goto L_82B83C;
    case 0x82B83Du: goto L_82B83D;
    case 0x82B841u: goto L_82B841;
    case 0x82B843u: goto L_82B843;
    case 0x82B844u: goto L_82B844;
    case 0x82B846u: goto L_82B846;
    case 0x82B848u: goto L_82B848;
    case 0x82B849u: goto L_82B849;
    case 0x82B84Au: goto L_82B84A;
    case 0x82B84Du: goto L_82B84D;
    case 0x82B84Eu: goto L_82B84E;
    case 0x82B850u: goto L_82B850;
    case 0x82B852u: goto L_82B852;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB800u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB800u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B800 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82B802;
L_82B802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB802u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB802u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B802 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82B804;
L_82B804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB804u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B804 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B806;
L_82B806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B806 TXA
    cpu.transfer("TXA");
    goto L_82B807;
L_82B807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB807u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB807u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B807 XBA
    cpu.xba();
    goto L_82B808;
L_82B808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B808 AND
    cpu.logicAnd(0xFFu);
    goto L_82B80B;
L_82B80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80B ASL
    cpu.aslA();
    goto L_82B80C;
L_82B80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82B80E;
L_82B80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80E TXA
    cpu.transfer("TXA");
    goto L_82B80F;
L_82B80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80F AND
    cpu.logicAnd(0xFFu);
    goto L_82B812;
L_82B812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB812u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB812u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B812 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82B814;
L_82B814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B814 LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B817;
L_82B817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B817 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82B819;
L_82B819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB819u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB819u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B819 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B81B;
L_82B81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B81B PHY
    cpu.push("PHY", hw);
    goto L_82B81C;
L_82B81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B81C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B81E;
L_82B81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B81E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B820;
L_82B820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B820 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B822;
L_82B822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B822 LSR
    cpu.lsrA();
    goto L_82B823;
L_82B823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B823 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82B825;
L_82B825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB825u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB825u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B825 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B828;
L_82B828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB828u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB828u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B828 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_82B82A;
L_82B82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82A STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B82E;
L_82B82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82E INY
    cpu.inc('Y');
    goto L_82B82F;
L_82B82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82F INY
    cpu.inc('Y');
    goto L_82B830;
L_82B830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B830 INX
    cpu.inc('X');
    goto L_82B831;
L_82B831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B831 INX
    cpu.inc('X');
    goto L_82B832;
L_82B832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B832 DEC
    cpu.decMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82B834;
L_82B834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B834 BNE -> $82B825
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B825; }
    goto L_82B836;
L_82B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B836 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B838;
L_82B838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B838 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B83A;
L_82B83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B83C;
L_82B83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Cu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B83C PLY
    cpu.pop("PLY", hw);
    goto L_82B83D;
L_82B83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B83D JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB840u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB841u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82B83Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B841;
L_82B841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB841u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB841u,0x82B841u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB841u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB841u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B841 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B843;
L_82B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B843 CLC
    cpu.setFlag('C', false);
    goto L_82B844;
L_82B844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB844u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB844u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B844 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_82B846;
L_82B846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B846 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B848;
L_82B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B848 TYA
    cpu.transfer("TYA");
    goto L_82B849;
L_82B849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB849u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB849u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B849 CLC
    cpu.setFlag('C', false);
    goto L_82B84A;
L_82B84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84A ADC
    cpu.adc(0x20u);
    goto L_82B84D;
L_82B84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84D TAY
    cpu.transfer("TAY");
    goto L_82B84E;
L_82B84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84E DEC
    cpu.decMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82B850;
L_82B850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB850u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB850u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B850 BNE -> $82B81B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B81B; }
    goto L_82B852;
L_82B852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB852u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB852u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B852 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B852u);return;} hw.unresolvedReturn(0x82B852u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82B800_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82B800u: goto L_82B800;
    case 0x82B802u: goto L_82B802;
    case 0x82B804u: goto L_82B804;
    case 0x82B806u: goto L_82B806;
    case 0x82B807u: goto L_82B807;
    case 0x82B808u: goto L_82B808;
    case 0x82B80Bu: goto L_82B80B;
    case 0x82B80Cu: goto L_82B80C;
    case 0x82B80Eu: goto L_82B80E;
    case 0x82B80Fu: goto L_82B80F;
    case 0x82B812u: goto L_82B812;
    case 0x82B814u: goto L_82B814;
    case 0x82B817u: goto L_82B817;
    case 0x82B819u: goto L_82B819;
    case 0x82B81Bu: goto L_82B81B;
    case 0x82B81Cu: goto L_82B81C;
    case 0x82B81Eu: goto L_82B81E;
    case 0x82B820u: goto L_82B820;
    case 0x82B822u: goto L_82B822;
    case 0x82B823u: goto L_82B823;
    case 0x82B825u: goto L_82B825;
    case 0x82B828u: goto L_82B828;
    case 0x82B82Au: goto L_82B82A;
    case 0x82B82Eu: goto L_82B82E;
    case 0x82B82Fu: goto L_82B82F;
    case 0x82B830u: goto L_82B830;
    case 0x82B831u: goto L_82B831;
    case 0x82B832u: goto L_82B832;
    case 0x82B834u: goto L_82B834;
    case 0x82B836u: goto L_82B836;
    case 0x82B838u: goto L_82B838;
    case 0x82B83Au: goto L_82B83A;
    case 0x82B83Cu: goto L_82B83C;
    case 0x82B83Du: goto L_82B83D;
    case 0x82B841u: goto L_82B841;
    case 0x82B843u: goto L_82B843;
    case 0x82B844u: goto L_82B844;
    case 0x82B846u: goto L_82B846;
    case 0x82B848u: goto L_82B848;
    case 0x82B849u: goto L_82B849;
    case 0x82B84Au: goto L_82B84A;
    case 0x82B84Du: goto L_82B84D;
    case 0x82B84Eu: goto L_82B84E;
    case 0x82B850u: goto L_82B850;
    case 0x82B852u: goto L_82B852;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82B800:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB800u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB800u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB800u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B800 STZ
    hw.write(cpu.address("dp", 0x0u), 0, cpu.m8?8:16);
    goto L_82B802;
L_82B802:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB802u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB802u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB802u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B802 STZ
    hw.write(cpu.address("dp", 0x2u), 0, cpu.m8?8:16);
    goto L_82B804;
L_82B804:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB804u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB804u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB804u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B804 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B806;
L_82B806:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB806u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB806u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B806 TXA
    cpu.transfer("TXA");
    goto L_82B807;
L_82B807:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB807u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB807u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB807u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B807 XBA
    cpu.xba();
    goto L_82B808;
L_82B808:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB808u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB808u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B808 AND
    cpu.logicAnd(0xFFu);
    goto L_82B80B;
L_82B80B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Bu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Bu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80B ASL
    cpu.aslA();
    goto L_82B80C;
L_82B80C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80C STA
    hw.write(cpu.address("dp", 0x12u), cpu.a, cpu.m8?8:16);
    goto L_82B80E;
L_82B80E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Eu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80E TXA
    cpu.transfer("TXA");
    goto L_82B80F;
L_82B80F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB80Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB80Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B80F AND
    cpu.logicAnd(0xFFu);
    goto L_82B812;
L_82B812:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB812u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB812u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB812u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B812 STA
    hw.write(cpu.address("dp", 0x14u), cpu.a, cpu.m8?8:16);
    goto L_82B814;
L_82B814:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB814u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB814u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B814 LDA
    cpu.setA(0x7Eu, 16);
    goto L_82B817;
L_82B817:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB817u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB817u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B817 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x2u), cpu.m8?8:16));
    goto L_82B819;
L_82B819:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB819u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB819u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB819u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B819 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_82B81B;
L_82B81B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Bu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B81B PHY
    cpu.push("PHY", hw);
    goto L_82B81C;
L_82B81C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Cu,cpu,0xA4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B81C LDY
    cpu.setY(hw.readW(cpu.address("dp", 0x10u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B81E;
L_82B81E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB81Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB81Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B81E LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x52u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B820;
L_82B820:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB820u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB820u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B820 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B822;
L_82B822:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB822u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB822u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B822 LSR
    cpu.lsrA();
    goto L_82B823;
L_82B823:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB823u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB823u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B823 STA
    hw.write(cpu.address("dp", 0x16u), cpu.a, cpu.m8?8:16);
    goto L_82B825;
L_82B825:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB825u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB825u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB825u, 5u + 1u, 3u, cpu.address("absy", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B825 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B828;
L_82B828:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB828u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB828u,cpu,0x45u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB828u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B828 EOR
    cpu.logicXor(hw.readW(cpu.address("dp", 0x0u), cpu.m8?8:16));
    goto L_82B82A;
L_82B82A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Au, 6u, 4u, ((0x7E0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82A STA
    hw.write(((0x7E0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_82B82E;
L_82B82E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82E INY
    cpu.inc('Y');
    goto L_82B82F;
L_82B82F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB82Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB82Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B82F INY
    cpu.inc('Y');
    goto L_82B830;
L_82B830:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB830u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB830u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B830 INX
    cpu.inc('X');
    goto L_82B831;
L_82B831:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB831u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB831u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B831 INX
    cpu.inc('X');
    goto L_82B832;
L_82B832:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB832u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB832u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x16u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B832 DEC
    cpu.decMem(hw, cpu.address("dp", 0x16u), cpu.m8?8:16);
    goto L_82B834;
L_82B834:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB834u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB834u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B834 BNE -> $82B825
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B825; }
    goto L_82B836;
L_82B836:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB836u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB836u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B836 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x52u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B838;
L_82B838:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB838u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB838u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x52u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B838 STX
    hw.write(cpu.address("dp", 0x52u), cpu.x, cpu.x8?8:16);
    goto L_82B83A;
L_82B83A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B83A LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x12u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82B83C;
L_82B83C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Cu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B83C PLY
    cpu.pop("PLY", hw);
    goto L_82B83D;
L_82B83D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB83Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB83Du, 8u, 4u, 0x8098F5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82B83D JSL -> $8098F5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xB840u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xB841u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x8098F5u, 0x82B83Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82B841;
L_82B841:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB841u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xB841u,0x82B841u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB841u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB841u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B841 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x10u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82B843;
L_82B843:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB843u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB843u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B843 CLC
    cpu.setFlag('C', false);
    goto L_82B844;
L_82B844:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB844u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB844u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB844u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x12u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B844 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x12u), cpu.m8?8:16));
    goto L_82B846;
L_82B846:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB846u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB846u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x10u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B846 STA
    hw.write(cpu.address("dp", 0x10u), cpu.a, cpu.m8?8:16);
    goto L_82B848;
L_82B848:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB848u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB848u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B848 TYA
    cpu.transfer("TYA");
    goto L_82B849;
L_82B849:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB849u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB849u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB849u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B849 CLC
    cpu.setFlag('C', false);
    goto L_82B84A;
L_82B84A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84A ADC
    cpu.adc(0x20u);
    goto L_82B84D;
L_82B84D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84D TAY
    cpu.transfer("TAY");
    goto L_82B84E;
L_82B84E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB84Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB84Eu, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x14u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B84E DEC
    cpu.decMem(hw, cpu.address("dp", 0x14u), cpu.m8?8:16);
    goto L_82B850;
L_82B850:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB850u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB850u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB850u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82B850 BNE -> $82B81B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82B81B; }
    goto L_82B852;
L_82B852:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xB852u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xB852u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xB852u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82B852 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82B852u);return;} hw.unresolvedReturn(0x82B852u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_839CEC_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x839CE2u: goto L_839CE2;
    case 0x839CE3u: goto L_839CE3;
    case 0x839CECu: goto L_839CEC;
    case 0x839CEFu: goto L_839CEF;
    case 0x839CF1u: goto L_839CF1;
    case 0x839CF3u: goto L_839CF3;
    case 0x839CF4u: goto L_839CF4;
    case 0x839CF7u: goto L_839CF7;
    case 0x839CF9u: goto L_839CF9;
    case 0x839CFBu: goto L_839CFB;
    case 0x839CFCu: goto L_839CFC;
    case 0x839CFFu: goto L_839CFF;
    case 0x839D03u: goto L_839D03;
    case 0x839D04u: goto L_839D04;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_839CE2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE2u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CE2 SEC
    cpu.setFlag('C', true);
    goto L_839CE3;
L_839CE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CE3u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839CE3 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839CE3u);return;} hw.unresolvedReturn(0x839CE3u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_839CEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CECu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CECu, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CEC LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CEF;
L_839CEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEFu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CEFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CEF BMI -> $839CE2
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_839CE2; }
    goto L_839CF1;
L_839CF1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x90u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CF1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x90u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CF3;
L_839CF3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CF3 ASL
    cpu.aslA();
    goto L_839CF4;
L_839CF4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF4u,cpu,0x7Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF4u, 5u + 1u, 3u, cpu.address("absx", 0x10BAu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CF4 ADC
    cpu.adc(hw.readW(cpu.address("absx", 0x10BAu), cpu.m8?8:16));
    goto L_839CF7;
L_839CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CF7 STY
    hw.write(cpu.address("dp", 0x8u), cpu.y, cpu.x8?8:16);
    goto L_839CF9;
L_839CF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CF9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CF9 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_839CFB;
L_839CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFBu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CFB TAY
    cpu.transfer("TAY");
    goto L_839CFC;
L_839CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFCu, 5u + 1u, 3u, cpu.address("absy", 0xD77Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839CFC LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0xD77Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_839CFF;
L_839CFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9CFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9CFFu, 8u, 4u, 0x80946Bu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $839CFF JSL -> $80946B stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x9D02u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x9D03u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80946Bu, 0x839CFFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_839D03;
L_839D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D03u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x9D03u,0x839D03u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D03u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D03u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $839D03 CLC
    cpu.setFlag('C', false);
    goto L_839D04;
L_839D04:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x9D04u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x9D04u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $839D04 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x839D04u);return;} hw.unresolvedReturn(0x839D04u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_83ABF7_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x83ABF7u: goto L_83ABF7;
    case 0x83ABF9u: goto L_83ABF9;
    case 0x83ABFCu: goto L_83ABFC;
    case 0x83ABFEu: goto L_83ABFE;
    case 0x83ABFFu: goto L_83ABFF;
    case 0x83AC01u: goto L_83AC01;
    case 0x83AC03u: goto L_83AC03;
    case 0x83AC05u: goto L_83AC05;
    case 0x83AC06u: goto L_83AC06;
    case 0x83AC08u: goto L_83AC08;
    case 0x83AC0Au: goto L_83AC0A;
    case 0x83AC0Du: goto L_83AC0D;
    case 0x83AC0Eu: goto L_83AC0E;
    case 0x83AC11u: goto L_83AC11;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_83ABF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF7 STA
    hw.write(cpu.address("dp", 0x8u), cpu.a, cpu.m8?8:16);
    goto L_83ABF9;
L_83ABF9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABF9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABF9u, 5u + 1u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABF9 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1090u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_83ABFC;
L_83ABFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFC BMI -> $83AC05
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_83AC05; }
    goto L_83ABFE;
L_83ABFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFE SEC
    cpu.setFlag('C', true);
    goto L_83ABFF;
L_83ABFF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xABFFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xABFFu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83ABFF SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC01;
L_83AC01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC01u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC01 BCS -> $83AC0E
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC03;
L_83AC03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC03u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC03 BCC -> $83AC0A
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0A; }
    goto L_83AC05;
L_83AC05:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC05u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC05u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC05 CLC
    cpu.setFlag('C', false);
    goto L_83AC06;
L_83AC06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u,cpu,0x65u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC06u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC06 ADC
    cpu.adc(hw.readW(cpu.address("dp", 0x8u), cpu.m8?8:16));
    goto L_83AC08;
L_83AC08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u,cpu,0x90u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC08u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC08 BCC -> $83AC0E
    if (!cpu.c) { hw.addCpuInternalCycles(1u); goto L_83AC0E; }
    goto L_83AC0A;
L_83AC0A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Au, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0A STZ
    hw.write(cpu.address("absx", 0x1090u), 0, cpu.m8?8:16);
    goto L_83AC0D;
L_83AC0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC0D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC0Du);return;} hw.unresolvedReturn(0x83AC0Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_83AC0E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC0Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC0Eu, 6u, 3u, cpu.address("absx", 0x1090u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $83AC0E STA
    hw.write(cpu.address("absx", 0x1090u), cpu.a, cpu.m8?8:16);
    goto L_83AC11;
L_83AC11:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xAC11u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xAC11u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $83AC11 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x83AC11u);return;} hw.unresolvedReturn(0x83AC11u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_848A5E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A5Eu: goto L_848A5E;
    case 0x848A61u: goto L_848A61;
    case 0x848A62u: goto L_848A62;
    case 0x848A65u: goto L_848A65;
    case 0x848A68u: goto L_848A68;
    case 0x848A6Au: goto L_848A6A;
    case 0x848A6Du: goto L_848A6D;
    case 0x848A71u: goto L_848A71;
    case 0x848A72u: goto L_848A72;
    case 0x848A75u: goto L_848A75;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 5u, 3u, cpu.address("abs", 0x05B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A61;
L_848A61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A61 CLC
    cpu.setFlag('C', false);
    goto L_848A62;
L_848A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A62 ADC
    cpu.adc(0x8u);
    goto L_848A65;
L_848A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A65 CMP
    cpu.compareA(0x81u);
    goto L_848A68;
L_848A68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A68 BPL -> $848A72
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848A72; }
    goto L_848A6A;
L_848A6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Au, 5u, 3u, cpu.address("abs", 0x05B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6A STA
    hw.write(cpu.address("abs", 0x5B6u), cpu.a, cpu.m8?8:16);
    goto L_848A6D;
L_848A6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du, 8u, 4u, 0x848C96u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A6D JSL -> $848C96 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A70u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A71u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848C96u, 0x848A6Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A71;
L_848A71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A71u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A71u,0x848A71u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A71u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A71u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A71 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A71u);return;} hw.unresolvedReturn(0x848A71u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848A72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A72 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848A75;
L_848A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A75 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A75u);return;} hw.unresolvedReturn(0x848A75u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

void sub_848A5E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x848A5Eu: goto L_848A5E;
    case 0x848A61u: goto L_848A61;
    case 0x848A62u: goto L_848A62;
    case 0x848A65u: goto L_848A65;
    case 0x848A68u: goto L_848A68;
    case 0x848A6Au: goto L_848A6A;
    case 0x848A6Du: goto L_848A6D;
    case 0x848A71u: goto L_848A71;
    case 0x848A72u: goto L_848A72;
    case 0x848A75u: goto L_848A75;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_848A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 5u, 3u, cpu.address("abs", 0x05B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A5E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x5B6u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_848A61;
L_848A61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A61 CLC
    cpu.setFlag('C', false);
    goto L_848A62;
L_848A62:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A62u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A62u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A62 ADC
    cpu.adc(0x8u);
    goto L_848A65;
L_848A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A65 CMP
    cpu.compareA(0x81u);
    goto L_848A68;
L_848A68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A68u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A68 BPL -> $848A72
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_848A72; }
    goto L_848A6A;
L_848A6A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Au, 5u, 3u, cpu.address("abs", 0x05B6u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A6A STA
    hw.write(cpu.address("abs", 0x5B6u), cpu.a, cpu.m8?8:16);
    goto L_848A6D;
L_848A6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du, 8u, 4u, 0x848C96u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A6D JSL -> $848C96 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8A70u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8A71u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x848C96u, 0x848A6Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_848A71;
L_848A71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A71u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8A71u,0x848A71u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A71u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A71u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A71 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A71u);return;} hw.unresolvedReturn(0x848A71u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_848A72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A72u, 8u, 3u, cpu.address("abs", 0x05A0u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $848A72 INC
    cpu.incMem(hw, cpu.address("abs", 0x5A0u), cpu.m8?8:16);
    goto L_848A75;
L_848A75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A75u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $848A75 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0x848A75u);return;} hw.unresolvedReturn(0x848A75u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

