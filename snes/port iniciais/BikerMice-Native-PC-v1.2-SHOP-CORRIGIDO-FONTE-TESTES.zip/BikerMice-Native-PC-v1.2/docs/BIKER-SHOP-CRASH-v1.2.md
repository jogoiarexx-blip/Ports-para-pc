# Biker Mice Native PC v1.2 — SHOP sem crash na rota testada

## Causa real
O menu da loja fazia o JMP indireto `$82:B43E` (`6C 08 00`) para destinos que o C++ não havia compilado. O primeiro replay falhava no frame 4608, em `$82:B43E -> $82:B46F`. Depois da correção apareceram outros destinos desta mesma rotina. Não foi uma falha confirmada de DMA, SRAM ou PPU.

## Correção implementada
O Forja65 v0.4.36 foi utilizado com a ponte `tools/legacy-cfg-bridge.js`, que executa o tradutor com a versão compatível ao cache histórico `0.4.24-audio-key-timing` e incorpora somente os trechos de CPU verificados. A ROM possui 23 valores contíguos à rotina; nove destinos foram realmente observados e são cobertos pelo dispatcher, sem inventar hints. O runtime do jogo foi mantido estável: as mudanças extensas no hardware do gerador novo não foram trocadas cegamente por cima dele.

## Replays validados
- `tests/biker-shop-v12.trace`: Baixo na opção RACE/SHOP e Start na loja; execução completou 5300 frames.
- `tests/biker-shop-dialog-v12.trace`: outro Start durante a mensagem de boas-vindas, abrindo ENGINE, TIRE, ARMOR e SHOT; completou 5700 frames.
- `tests/biker-shop-item-v12.trace`: tecla A em ENGINE; apareceu GOOD LUCK!!; completou 6500 frames. Dinheiro não foi comprovadamente debitado; **não declarar compra validada**.
- `tests/biker-v08-b_accel.trace`: corrida histórica concluída com 6800/6800 frames idênticos em framebuffer, WRAM e PC à versão v1.1.
- Quatro smokes C++ selecionados passaram.

## Testar no Windows
Compile `game.exe` com o script de build existente e execute `TESTAR-SHOP-V12-WINDOWS.cmd`; ele roda 6000 frames e compara cada frame ao golden gerado nesta versão. O programa e os scripts usam o cart-data.bin do projeto, não reconstroem a loja manualmente.

## Limites
O menu de SHOP, o catálogo e a resposta ao comando A estão demonstrados nos percursos acima. Ainda faltam compra efetiva/débito, os outros tipos de equipamento, retorno à corrida depois de GOOD LUCK!!, áudio, fidelidade com SNES original e versão Windows compilada. A nova lógica DMA/SRAM da v0.4.36 permanece no conversor entregue em separado até que uma migração de runtime passe nos replays sem divergências.
