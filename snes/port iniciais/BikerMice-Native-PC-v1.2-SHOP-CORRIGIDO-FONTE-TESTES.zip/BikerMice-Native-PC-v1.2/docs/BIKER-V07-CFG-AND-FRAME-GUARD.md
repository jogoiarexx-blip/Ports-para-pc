# Biker Mice Native PC — v0.7 progress and regression protection

## Verified source changes

- New CPU control-flow target `$83:9FF0 -> $83:A128` learned from the failing replay after frame 6049.
- Verified stack-return path `$83:A12E -> $83:A146` derived from runtime stack evidence.
- New CPU flow target `$83:A003 -> $83:AE22` from a later run of the same frame.
- The generator recompiles only affected shards; old CPU/PPU/SPC700 code is preserved.
- A generic Forja65 `--baseline-milestones tests/golden-milestones-v07.json` argument now protects seven historical screen/WRAM checkpoints against silent regressions on every converged replay attempt.

## Replaying

```sh
node /PATH/TO/FORJA65/tools/replay-converge.js --project /PATH/TO/BIKER --build /PATH/TO/BIKER/build --input /PATH/TO/BIKER/tests/biker-enter-track.trace --frames 6200 --iterations 10 --max 12000 --timeout 360000 --baseline-milestones /PATH/TO/BIKER/tests/golden-milestones-v07.json
```

No assertion about GO or actual movement should be made without post-countdown capture and input A/B testing. The ROM fingerprint is `5df32d6de53b7971` (this packaged ROM includes a Portuguese/cheat modification).

## Final v0.7 replay result

- 103 learned paths, 103 present in dispatcher; 28,905 translated instruction addresses.
- CFG variant capacity increased **explicitly** from 65,536 to 131,072.
- Six optimized Linux replay attempts with seven of seven historical framebuffer/WRAM checkpoints intact.
- Latest completed frame: 6049. The six replay attempts ended on validated but uncompiled RTS destinations (ITERATION_LIMIT).
- Next unlearned stack return: `$83:CDEC -> $83:D546`, observed with stack register S=$0189.
- No GO prompt, acceleration, steering, lap or win screen has been proved; do not present this as race playable.
- `-O1` GCC CMake build accelerated the local replay from ~90 seconds to ~23 seconds to frame 6049; this is a **test build profile**, not a new hardware-accuracy claim.

## Forja65 changes

The core 65C816/PPU/DMA/SPC700 remains unchanged. Tooling improvements: new ROM-scoped `--baseline-milestones` check in replay convergence, and validated `--cache-limit` for explicit monotonic cache expansion in `learn-crash` and `replay-converge`.
