# Biker Mice v0.3 — relatório técnico conciso

Data: 12/10/2026. ROM FNV-1a de trabalho `5df32d6de53b7971`.

| Marco | Resultado do replay |
|---|---|
| 950 | Abertura, teste de regressão nativo×referência PASS |
| 2400 | Normal confirmado, escurecimento da tela, PASS |
| 2600 | Tela PLAYER SELECT, PASS, 35.343.187 instruções |
| 3400 | Round 1 “ROCK & RIDE”, PASS, 45.854.048 instruções |
| 4500 | Tela STATUS e RACE/SHOP, PASS, 60.306.848 instruções |
| 5200 | CPU segue executando; imagem preta, forced_blank=1, nmi_services=4092 |
| 6500 | forced_blank=1, NMI permanece 4092, framebuffer ainda preto |
| 10000 | forced_blank=1, NMI permanece 4092, sem pista validada |

A análise reconhece 17.539 endereços únicos e 536 rotinas, contra 13.771 endereços do projeto v0.2. O cache CFG segue limitado em 65.536 variantes (não é uma correção de sincronização PPU/APU).

Evidências: `evidence/` guarda capturas reais da execução nativa; `reports/biker-largada-diagnostico.json` documenta `BLOCKED_LOAD` com `nmi_delta=0`. Comparação nativo×referência prova consistência do próprio Forja65, **não** equivalência com hardware original. `ppu_native_accesses=0`, `dsp_native_samples=0` no último replay: o host ainda depende de fallback virtual nesses subsistemas.

Próximo foco: analisar por que a CPU não libera `$2100` forced-blank nem reabilita NMI após confirmar RACE; extrair estado e endereços de WRAM ao longo da rotina `$82:ABxx–$82:ADxx`, comparar contra uma captura de hardware SNES e testar eventual bloqueio por carregamento de gráficos. Preservar replays, não forçar flags para esconder a tela preta.
