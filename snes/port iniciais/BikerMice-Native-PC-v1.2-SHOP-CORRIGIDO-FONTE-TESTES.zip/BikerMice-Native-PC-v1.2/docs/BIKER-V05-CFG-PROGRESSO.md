# Biker Mice Native PC v0.5 — Round 1: pista e countdown

## Comprovado no port nativo

- Abertura, menu de jogo, selecao de piloto, Round 1, RACE/SHOP preservados.
- Apos RACE, a pista, motos, HUD e largada aparecem nos frames 5900 e 6040 da ROM enviada.
- A captura de 5900 mostra a contagem 3; a de 6040 mostra 1. As imagens reais diferem em 1262 pixels.
- Novos CFGs ROM-guardados importados ate o frame 6049; retorno de pilha validado com evidencia.
- Compilacao C++ Linux: PASS; quatro CTests basicos: 4/4 PASS.
- O Forja65 gerador recebeu o CTest CPU 65C816 bank carry para todos os ports gerados.

## Aberto

- A CPU ainda encontra destinos CFG na saida da contagem regressiva, no frame 6049. Isso nao prova GO nem deslocamento jogavel.
- Pista e contagem regressiva sao evidencias visuais; audio, controles durante a corrida e chegada ainda nao foram verificados.
- Arquivos Windows sao de codigo-fonte para compilar, NAO incluem game.exe pronto.

## Reproduzir

No Windows, compile com `GERAR-GAME-EXE-WINDOWS.cmd` e rode `TESTAR-LARGADA-WINDOWS.cmd`.
O teste captura 5900 e 6040 em `capturas-largada/` como arquivos PPM.

## Validacao automatizada adicional

- Replay headless nativo do frame 0 ao 6040: PASS, sem hint novo ate esse ponto.
- 80.603.188 instrucoes; 5.375 NMI atendidas; forced blank=0 no frame 6040.
- Comparacoes com a CPU de referencia ou SNES original NAO foram repetidas nesta versao.
- `reports/BIKER-V05-QA-6040.txt` contem os indicadores registrados pelo proprio jogo.
