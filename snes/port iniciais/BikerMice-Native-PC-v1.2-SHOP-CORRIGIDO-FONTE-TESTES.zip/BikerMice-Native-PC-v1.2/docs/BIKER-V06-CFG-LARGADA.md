# Biker Mice Native PC v0.6 — investigacao da largada

## O que mudou

- CFG expandido de 21.628 para 25.186 enderecos de instrucao, a partir de novos rastros de execucao da ROM com fingerprint `5df32d6de53b7971`.
- Aprendizado de ramificacoes em `$83:85F6->$83:8D8D`, `$83:85F9->$83:8ED5`, `$83:8608->$80:90D5`, `$83:8492->$83:9E6C` e `$83:9FEA->$83:A50F`.
- Retorno de pilha `$83:CDEC->$83:F73B` validado pelo trace, sem inventar enderecos de retorno.
- 92 observacoes acumuladas, todas disponiveis no dispatcher no ultimo teste.
- `tools/validar-largada-v06.py` e `TESTAR-POS-LARGADA-WINDOWS.cmd` adicionados para auditar sequencia de frames e hashes de regressao v0.5.

## Preservado

- Abertura, selecao de personagem, apresentacao ROUND 1, tela RACE/SHOP e pista com contagem regressiva previamente capturada.
- O quadro 6040 conserva os hashes framebuffer `7d6ab2edeecda662` e WRAM `bafda2ade527ac08` da v0.5 nas execucoes de regressao.
- O nucleo Forja65 v0.4.27 com CPU bank carry e reset fix nao sofreu mudancas nessa rodada.

## Ainda pendente

- Contagem chegando a GO, avancar alem do frame 6049, comandos de aceleracao/direcao, audio, primeira volta e chegada.
- Validacao de equivalencia com o SNES original nesta etapa.
- Executavel Windows portatil compilado (o ZIP atual contem codigo-fonte e scripts).

## Verificar no Windows

1. Compile usando `GERAR-GAME-EXE-WINDOWS.cmd`.
2. Execute `TESTAR-LARGADA-WINDOWS.cmd` (frame 6040).
3. Execute `TESTAR-POS-LARGADA-WINDOWS.cmd` para tentar alcancar 6200, deixando relatorio e diagnosticos sob `diagnosticos-pos-largada/`.
4. Se ocorrer um novo CFG, nao repetir pulsos do controle nem inventar destino: encaminhar os arquivos de rastreamento para aprendizado.
