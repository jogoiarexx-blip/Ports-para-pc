# Cruzamento seletivo Biker / Forja65

Fontes: Forja65 Biker CFG Guard v0.9; Forja65 v0.4.34.1 reunificado.

## Por que nao trocar todo o runtime?
O C++ foi compilado, mas a comparacao real com replay historico
rejeitou a atualizacao integral: primeira diferenca de PC no frame
144, memoria no 392, video no 1044. Foram comparados 2586 frames
nessa prova experimental (2333 frames com alguma divergencia).
Esses dados NAO demonstram que o motor novo esteja errado: apenas
que nao preserva determinismo do port v0.9, requisito desta migracao.

## Versao principal
Os gerados da CPU e os dados originais continuam inalterados.
O runtime de Biker v0.9 foi mantido e recebeu exclusivamente o
Mode 7 de v0.4.34.1 em opt-in. O padrao usa os calculos originais.
O teste `mode7_crossfeed_v10_smoke` cobre escrita BG1, latches
independentes e coordenadas da matriz identidade.

## Limitacoes
Qualquer regeneracao usando diretamente o novo decoder precisa de
nova verificacao completa de video, WRAM e PC antes de substituir
este projeto. O C++ gerado nao reimplementa todas as dependencias
SNES como codigo nativo independente. Nenhuma mudanca artificial
foi introduzida na fisica, contagem regressiva ou controles.
