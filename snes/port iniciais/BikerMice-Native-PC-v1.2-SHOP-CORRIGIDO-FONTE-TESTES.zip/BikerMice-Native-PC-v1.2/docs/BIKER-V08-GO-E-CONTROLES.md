# Biker Mice v0.8 — GO e controles

Reproduzido o bloqueio `83:CDEC -> 83:D546` do frame 6049 (RTS de pilha). O Forja65 incorporou retornos e fluxos ROM-observados: primeiro 6050, depois 6110, 6126 e por fim 6200 frames completos. Nenhuma rotina foi substituida por animação artificial ou dado inventado.

A captura mostra `GO!` no frame 6070. A/B com o mesmo replay inicial de START: 
- Baseline sem botoes depois do frame 4586: 6200 frames; moto parada na linha, posicao da corrida cai.
- `B` pressionado do frame 6075 ao 6180: 6200 frames; a pista se desloca e o jogador avanca. Hash de WRAM diverge no 6075 e imagem no 6077; video e sprites comprovam deslocamento.
- `B + RIGHT` no mesmo intervalo: 6200 frames; caminho visual diferente, desvio lateral e indicacao grafica de colisao. Comparado a B isolado, framebuffer diverge no 6086. `RIGHT` isolado provocou diferenca em WRAM mas nenhum frame de video mudou ate 6200; direcao ativa foi comprovada sob aceleracao.

**Seguranca de regressao:** 7/7 goldens anteriores, replay sem input de 6200 frames identico antes e depois da ultima expansao CFG. `verify-learned-cfg` 110/110, 5/5 testes C++ selecionados, testes de regressao Forja e comparador de entrada aprovados.

**Forja65 separado:** corrigida a chave falsa de estagnacao dos retornos dinamicos e a revalidacao indevida de retornos historicos contra evidencias do replay atual; nenhuma instrucao CPU reimplementada nesta rodada.

**Pendencias:** comparar fisica, pistas e NMI com a ROM em hardware de referencia; som, colisoes longas, ultrapassagens e finish line; compilar e testar executavel Windows real.
