# Biker Mice Native PC v0.4 — CPU 65C816, transicao RACE

## Problema reproduzido
Depois do menu RACE / SHOP, o jogo entra no carregamento da pista, liga forced blank e suspende NMI. Na v0.3, o banco de dados e o indice podiam cruzar um limite de 64 KiB e atingir um banco incorreto.

Na rotina de preparacao (trace da ROM fornecida):
- Frame 4663 em `$82:A691`: contador em WRAM banco 7E, offset $0006, inicializado em $0020.
- Instrucao de acesso indexado com DB=$7E, base=$8006 e X=$8000: endereco esperado $7F0006; a v0.3 usava $7E0006, sobrescrevendo o contador.
- Frame 4663 em `$82:AD70`, antes da correcao: contador $0000, proximo DEC -> $FFFF (underflow).
- Mesma rotina com a correcao: contador $0020, depois $001F, $001E... Ate o frame 4689 continua decrementando sem o overflow anterior.

## Alteracao de codigo
Corrigidos os enderecamentos absolutos indexados `absx`, `absy` e indiretos indexados `dp_indirect_y`, `stack_indirect_y`: realizar soma 24 bits (com carry de banco) e aplicar mascara $FFFFFF. Enderecamentos `dp/dpx/dpy` continuam restringidos ao banco $00.

Alterado no gerador `forja65-core.js` e em `src/runtime.hpp` do port para nao divergir entre o motor e o codigo ja convertido. Nenhuma mudanca cosmética foi feita.

## Testes (executados no Linux)
- Red/green: novo teste `cpu_bank_cross_smoke` FALHA na v0.3 e PASSA na v0.4 (inclusive com `-DNDEBUG`).
- Compilacao de `game` em C++20: PASS, configuracao Release com `-O0` para validacao funcional, sem representar desempenho final.
- Replay real de entrada na pista com runtime alterado: PASS ate o frame 4700, mas `forced_blank=1`, `nmi_services=4092` — a corrida AINDA NAO foi validada.
- 4700 frames: 62.911.752 instrucoes, contra 62.945.690 na v0.3. Estas contagens diferem, portanto NAO existe equivalencia v0.3/v0.4 para esse replay.
- Capturas posteriores ao frame 4700 exigem validacao separada; nao alegamos que a primeira corrida esta jogavel.
- O replay estendido revelou tres novos CFGs: `$82:8635` -> `$82:867A` no frame **5662**, `$80:BC9D` -> `$80:C2AF` no frame **5666** e `$80:BC38` -> `$80:BCA9` no frame **5672** (na execucao anterior a cada integracao). Ambos foram incorporados a `analysis/runtime-hints.txt` e aos arquivos C++ gerados.
- A nova analise tem **17.604 enderecos decodificados** e **46.406 variantes**. Validacao ate a corrida ainda pendente.

## Reproduzir
1. Configure e compile a partir do codigo entregue usando `GERAR-GAME-EXE-WINDOWS.cmd` em Windows com as dependencias usuais do projeto.
2. Rode o teste unitario registrado no CTest com nome `cpu_bank_cross_smoke`.
3. Rode `DIAGNOSTICAR-LARGADA-WINDOWS.cmd` para verificar se o par NMI/forced blank volta a progredir.

## Pendencia principal
Verificar se outras rotinas de carregamento e sincronizacao mantem NMI desabilitada/forced blank apos completar os dados da pista. Nao contornar com ligacao artificial do PPU sem identificar o motivo.
