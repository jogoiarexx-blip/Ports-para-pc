#!/usr/bin/env python3
"""Audit deterministic milestones from native Forja65 replay (no gameplay claims).

Requires FORJA65_FRAME_HASHES=1. Examines actually recorded end-of-frame
hardware hashes. Never infers GO from a successful CPU compile alone.
"""
import argparse
import json
from pathlib import Path
import re
import sys

FRAME_RE = re.compile(r'^frame=(\d+) framebuffer=([0-9a-f]{1,16}) wram=([0-9a-f]{1,16}) pc=([0-9a-f]{1,6})$', re.I)
MILESTONES = (950, 2400, 2600, 3400, 4000, 5900, 6040, 6050, 6100, 6200)


def audit(path, status_path=None, baseline_status_path=None):
    if not path.is_file():
        raise ValueError(f'Arquivo de hashes ausente: {path}')
    counts, timeline = 0, {}
    before, last = None, None
    for lineno, raw in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        match = FRAME_RE.fullmatch(raw.strip())
        if not match:
            raise ValueError(f'Linha {lineno}: hash invalido')
        frame = int(match[1])
        if frame != counts:
            raise ValueError(f'Linha {lineno}: sequencia descontinua, esperava {counts} obteve {frame}')
        counts += 1
        last = {'frame': frame, 'framebuffer': match[2].lower(), 'wram': match[3].lower(), 'pc': match[4].lower()}
        if frame + 1 in MILESTONES:
            timeline[frame+1] = last.copy()
    if not counts:
        raise ValueError('Nenhum frame registrado')
    state = None
    if status_path and status_path.is_file():
        state = {}
        for line in status_path.read_text(encoding='utf-8').splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                state[k] = v
    # QA status is only authoritative for a complete replay, not a crash.
    complete = bool(state and state.get('runtime_started') == 'PASS' and state.get('frames') == str(counts))
    if complete:
        if state.get('framebuffer_hash', '').lower() != last['framebuffer'] or state.get('wram_hash', '').lower() != last['wram']:
            raise ValueError('Divergencia entre hashes do relatorio QA e timeline no ultimo frame')
    baseline_match = None
    if baseline_status_path is not None:
        if not baseline_status_path.is_file():
            raise ValueError(f'Baseline ausente: {baseline_status_path}')
        baseline = dict(line.split('=',1) for line in baseline_status_path.read_text(encoding='utf-8').splitlines() if '=' in line)
        if baseline.get('frames') != '6040' or baseline.get('rom') != '5df32d6de53b7971':
            raise ValueError('A baseline nao corresponde a ROM e ao marco 6040 esperados')
        if counts < 6040:
            raise ValueError('Nao chegou ao marco da baseline de 6040 frames')
        recorded = timeline[6040]
        baseline_match = (baseline.get('framebuffer_hash', '').lower() == recorded['framebuffer']
                          and baseline.get('wram_hash', '').lower() == recorded['wram'])
        if not baseline_match:
            raise ValueError('Regressao: hashes do quadro 6040 divergiram da v0.5')
    return {
        'schema': 1,
        'frames_completed': counts,
        'last_recorded_frame': last,
        'milestones': timeline,
        'milestones_passed': [frame for frame in MILESTONES if counts >= frame],
        'qa_complete': complete,
        'baseline_6040_identical': baseline_match,
        'go_confirmed': False,
        'movement_confirmed': False,
        'caveat': 'Hash/CPU demonstram progresso de execucao. GO e comandos exigem captura visual e teste A/B de input.'
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--frames', required=True, type=Path)
    parser.add_argument('--qa', type=Path)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--baseline-status', type=Path)
    args = parser.parse_args()
    try:
        report = audit(args.frames, args.qa, args.baseline_status)
        out = args.out or args.frames.with_name('biker-largada-v06-audit.json')
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print(f"BIKER_FRAME_AUDIT_PASS frames={report['frames_completed']} qa_complete={report['qa_complete']}")
        print('GO=NOT_VALIDATED CONTROLS=NOT_VALIDATED')
        return 0
    except (ValueError, OSError) as error:
        print('BIKER_FRAME_AUDIT_FAIL', error, file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
