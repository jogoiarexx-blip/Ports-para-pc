'use strict';
// Read-only regression for the ROM-bound, observed Biker Mice flow correction.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),assert=require('node:assert/strict');
function read(name){return fs.readFileSync(path.join(root,name),'utf8');}
const opts=JSON.parse(read('analysis/generation-options.json'));
const expected={rom:'5df32d6de53b7971',from:'838625',target:'838975',kind:'FLOW',e:'0',m:'0',x:'0',c:'0'};
assert.equal(opts.rom,expected.rom,'wrong game ROM');
const hints=read('analysis/runtime-hints.txt').split(/\r?\n/).filter(Boolean);
const trace=read('evidence/diagnostico-v11/forja65-crash-trace.txt');
const newHint=read('evidence/diagnostico-v11/forja65-runtime-hints.txt').trim();
for(const [k,v]of Object.entries(expected))assert.match(newHint,new RegExp('(?:^| )'+(k==='rom'||k==='target'||k==='from'||k==='kind'?k:' '+k).trim()+'='+v+'(?: |$)','i'),'trace does not match '+k);
assert.ok(hints.some(s=>s.trim().startsWith(newHint)),'observed hint missing from project');
assert.match(trace,/reason=unresolved-flow/,'invalid crash trace');
assert.match(trace,/(?:^|\n)838625 A=/,'wrong crash origin');
const re=new RegExp('^\\{0x'+expected.target+'u,false,false,false,(?:true|false),false,\\&','im');
assert.match(read('src/dispatch.cpp'),re,'compiled dispatcher missing target in 16-bit, carry-clear state');
assert.match(read('src/runtime.hpp'),/FORJA65_MODE7_PRECISE/,'stable Mode 7 runtime option missing');
console.log('PASS: Biker v1.1 ROM-bound flow $83:8625 -> $83:8975 compiled; stable runtime preserved');
