#!/usr/bin/env node
'use strict';
// Audits the ROM-backed indirect JMP $82:B43E and checks that *observed*
// SHOP destinations are compiled. It does not fabricate runtime hints.
const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const root=path.resolve(__dirname,'..');
const rom=fs.readFileSync(path.join(root,'assets/cart-data.bin'));
const cfg=JSON.parse(fs.readFileSync(path.join(root,'analysis/generation-options.json'),'utf8'));
assert.equal(cfg.rom,'5df32d6de53b7971','wrong Biker Mice ROM fingerprint');
const lo=(pc)=>(((pc>>>16)&0x7f)*0x8000+(pc&0x7fff));
assert.deepEqual([...rom.subarray(lo(0x82b43e),lo(0x82b43e)+3)],[0x6c,0x08,0x00],'SHOP indirect JMP opcode changed');
const table=[];
for(let addr=0x82b441;addr<0x82b46f;addr+=2){
 const off=lo(addr),target=0x820000|(rom[off]|(rom[off+1]<<8));
 assert.ok(target>=0x82b46f&&target<0x82b800,'SHOP indirect targets outside verified ROM table');
 table.push(target);
}
assert.equal(table.length,23);
const all=new Set(table);
const hints=fs.readFileSync(path.join(root,'analysis/runtime-hints.txt'),'utf8').split(/\r?\n/);
const seen=new Set();
for(const line of hints){
 if(!/\bfrom=82b43e\b/i.test(line))continue;
 const found=/\btarget=([0-9a-f]{6})\b/i.exec(line);if(!found)throw Error('invalid observed SHOP hint');
 const target=Number.parseInt(found[1],16);
 assert.ok(all.has(target),`observed indirect SHOP target $${target.toString(16)} outside ROM table`);
 seen.add(target);
}
const dispatch=fs.readFileSync(path.join(root,'src/dispatch.cpp'),'utf8');
const missing=[...seen].filter(t=>!new RegExp('\\{0x'+t.toString(16)+'u,false,false,false,(?:true|false),false,\\&','i').test(dispatch));
assert.equal(missing.length,0,'observed SHOP target not compiled: '+missing.map(t=>t.toString(16)));
const status={rom:cfg.rom,indirect_jmp:'82:B43E',rom_table_entries:table.length,observed_targets_compiled:seen.size,targets:[...seen].map(x=>x.toString(16)),passed:true,limits:'Unvisited shop branches and purchases beyond this replay are not validated.'};
console.log('PASS SHOP ROM table: '+status.observed_targets_compiled+' observed targets covered / '+status.rom_table_entries+' ROM-backed candidates');
if(process.argv.includes('--report')){const file=path.join(root,'reports/shop-v12-table-audit.json');fs.writeFileSync(file,JSON.stringify(status,null,2)+'\n');}
