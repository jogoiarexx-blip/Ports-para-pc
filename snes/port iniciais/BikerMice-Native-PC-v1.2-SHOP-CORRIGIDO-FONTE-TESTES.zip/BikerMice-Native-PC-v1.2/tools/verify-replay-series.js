#!/usr/bin/env node
'use strict';
// Forja65 full-prefix regression guard. Unlike sparse checkpoint validation,
// all completed frames in a user-selected reference interval must agree.
const fs = require('node:fs');
const path = require('node:path');
function readTrace(file, through) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const result = [];
  let expected = 0;
  for (const [index, line] of lines.entries()) {
    if (!line.trim()) continue;
    const m = line.match(/^frame=(\d+) framebuffer=([a-f\d]+) wram=([a-f\d]+) pc=([a-f\d]+)$/i);
    if (!m) throw new Error(`${file}:${index + 1}: invalid frame-hash row`);
    const frame = Number(m[1]);
    if (frame !== expected) throw new Error(`${file}:${index + 1}: expected frame ${expected}, got ${frame}`);
    if (frame < through) result.push({frame, framebuffer: m[2].toLowerCase(), wram: m[3].toLowerCase(), pc: m[4].toLowerCase()});
    expected++;
  }
  if (result.length !== through) throw new Error(`${file}: incomplete prefix (${result.length}/${through})`);
  return result;
}
function compare(baseline, current, through, fields = ['framebuffer','wram','pc']) {
  if (!Number.isSafeInteger(through) || through < 1) throw new Error('through must be a positive integer');
  for(const field of fields) if(!['framebuffer','wram','pc'].includes(field)) throw new Error('unsupported comparison field: '+field);
  const base = readTrace(baseline, through), next = readTrace(current, through);
  const mismatches = [];
  let first = null, divergent = 0;
  for (let i=0; i<through; i++) {
    const bad = fields.filter(key => base[i][key] !== next[i][key]);
    if (!bad.length) continue;
    divergent++;
    if (first === null) first = i;
    if (mismatches.length < 10) mismatches.push({frame: i, fields: bad, baseline: base[i], current: next[i]});
  }
  return {schema:'forja65.replay-series.v1', compared_frames:through, fields,
    passed: divergent === 0, divergent_frames:divergent, first_mismatch_frame:first, examples:mismatches};
}
function cli(argv) {
  const o={};
  for(let i=0;i<argv.length;i+=2) {
    if(!/^--[\w-]+$/.test(argv[i]||'')||!argv[i+1]) throw new Error('Usage: --baseline FILE --current FILE --through N [--fields framebuffer,wram,pc] [--out FILE]');
    o[argv[i].slice(2)] = argv[i+1];
  }
  if(!o.baseline||!o.current||!o.through) throw new Error('baseline, current, through are required');
  const result = compare(path.resolve(o.baseline),path.resolve(o.current),Number(o.through),o.fields?o.fields.split(','):undefined);
  if(o.out){fs.mkdirSync(path.dirname(path.resolve(o.out)),{recursive:true});fs.writeFileSync(o.out,JSON.stringify(result,null,2)+'\n');}
  console.log(`${result.passed?'PASS':'FAIL'}: ${result.compared_frames} frames, ${result.divergent_frames} divergent, fields=${result.fields.join(',')}`);
  return result.passed?0:1;
}
if(require.main===module){try{process.exitCode=cli(process.argv.slice(2));}catch(e){console.error(e.message);process.exitCode=2;}}
module.exports={readTrace,compare,cli};
