#!/usr/bin/env python3
"""Compare two deterministic replays without assuming that input means steering.

Both traces must start at frame zero with contiguous frame indices. Pre-input
hardware hashes must be identical. A framebuffer difference is evidence that
input affects the rendered execution, not proof of game physics or victory.
"""
import argparse
import json
from pathlib import Path
import re

ROW = re.compile(r'^frame=(\d+) framebuffer=([a-f0-9]{1,16}) wram=([a-f0-9]{1,16}) pc=([a-f0-9]{1,6})$', re.I)

def parse(path):
    rows = []
    for idx, line in enumerate(Path(path).read_text(encoding='utf-8').splitlines()):
        match = ROW.fullmatch(line)
        if not match or int(match[1]) != idx:
            raise ValueError(f'{path}: invalid/non-contiguous frame {idx}')
        rows.append(tuple(s.lower() for s in match.groups()[1:]))
    if not rows:
        raise ValueError(f'{path}: empty timeline')
    return rows

def compare(baseline, variant, input_frame):
    a, b = parse(baseline), parse(variant)
    if input_frame < 1 or min(len(a), len(b)) <= input_frame:
        raise ValueError('No overlapping frames after the injected input')
    shared = min(len(a), len(b))
    if any(a[i] != b[i] for i in range(input_frame)):
        raise ValueError('Replays diverged before injection; A/B comparison is invalid')
    first = {}
    counts = {}
    for name, field in [('framebuffer',0), ('wram',1), ('pc',2)]:
        changes = [i for i in range(input_frame, shared) if a[i][field] != b[i][field]]
        first[name] = changes[0] if changes else None
        counts[name] = len(changes)
    return {
        'schema': 'biker.input-differential.v08',
        'input_frame': input_frame, 'baseline_frames': len(a),
        'variant_frames': len(b), 'shared_frames': shared,
        'first_difference': first, 'different_frames': counts,
        'rendered_effect_observed': first['framebuffer'] is not None,
        'memory_effect_observed': first['wram'] is not None,
        'steering_confirmed': False, 'acceleration_confirmed': False,
        'caveat': 'Input-dependent frame hashes alone do not demonstrate correct acceleration or steering; verify sprite coordinates and reference behavior.'
    }

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',type=Path,required=True)
    parser.add_argument('--variant',type=Path,required=True)
    parser.add_argument('--input-frame',type=int,default=6075)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:
        report=compare(args.baseline,args.variant,args.input_frame)
    except (ValueError,OSError) as err:
        parser.error(str(err))
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':
    main()
