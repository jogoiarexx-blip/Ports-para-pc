#!/usr/bin/env python3
"""Generate deterministic exploratory input traces, preserving ROM-bound menus.

No gameplay validity is implied. The traces expose new states to the CFG learner.
"""
from pathlib import Path
import argparse
import re

def load_prefix(path):
    lines=Path(path).read_text(encoding='utf-8').splitlines()
    assert lines and lines[0].startswith('# FORJA65_INPUT_TRACE 1 rom='), 'missing ROM-bound trace header'
    prefix = [lines[0]]
    previous=-1
    for row in lines[1:]:
        m=re.fullmatch(r'frame=(\d+) joy1=([a-fA-F\d]{4}) joy2=([a-fA-F\d]{4})',row)
        if not m: raise ValueError(f'invalid trace row: {row!r}')
        frame=int(m[1]);
        if frame <= previous: raise ValueError('frames not strictly increasing')
        previous=frame
        if frame < 6075: prefix.append(row)
    if previous < 6075: raise ValueError('input does not contain tested acceleration section')
    return prefix

def write_trace(path,prefix,events):
    last = 6074
    out=list(prefix)
    for frame, mask in events:
        if frame<=last or not (0<=mask<=0xffff): raise ValueError('invalid event sequence')
        out.append(f'frame={frame} joy1={mask:04x} joy2=0000')
        last=frame
    Path(path).write_text('\n'.join(out)+'\n',encoding='utf-8')

if __name__=='__main__':
    a=argparse.ArgumentParser()
    a.add_argument('--source',required=True)
    a.add_argument('--output',required=True)
    p=a.parse_args(); directory=Path(p.output); directory.mkdir(parents=True,exist_ok=True)
    prefix=load_prefix(p.source)
    # SNES buttons: B=0x8000, Right=0x0100, Left=0x0200.
    write_trace(directory/'biker-v09-b-continuo.trace',prefix,[(6075,0x8000),(7000,0)])
    write_trace(directory/'biker-v09-b-curvas.trace',prefix,[(6075,0x8000),(6160,0x8100),(6220,0x8000),(6260,0x8200),(6310,0x8000),(7000,0)])
    print('Generated two ROM-bound experimental race traces; not gameplay-validated')
