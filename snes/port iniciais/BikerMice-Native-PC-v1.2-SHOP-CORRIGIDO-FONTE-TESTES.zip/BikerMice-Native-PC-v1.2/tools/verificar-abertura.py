#!/usr/bin/env python3
"""Regression: verify native and reference CPU replays remain equivalent.

Run from any working directory: python tools/verificar-abertura.py [--game PATH]
Exit 0 only if the native and reference runs both complete and agree on their
observable CPU/PPU/WRAM and interrupt results at the chosen frame.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ('rom', 'frames', 'instructions', 'nmi_services', 'irq_services',
          'framebuffer_hash', 'wram_hash')
BASELINE_950 = {
    'rom': '5df32d6de53b7971',
    'frames': '950',
    'framebuffer_hash': '5d447f11c4ed0266',
    'wram_hash': 'f0ac0a49683cb5f2',
}

def locate_game(path):
    if path:
        candidate = Path(path).resolve()
        if not candidate.is_file():
            raise RuntimeError(f'Executavel nao encontrado: {candidate}')
        return candidate
    for p in ('build/game', 'build/game.exe', 'bin/game.exe',
              'build-win/Release/game.exe', 'build-win/game.exe'):
        candidate = ROOT / p
        if candidate.is_file():
            return candidate.resolve()
    raise RuntimeError('Compile o jogo primeiro ou forneca --game PATH.')

def parse_qa(path):
    if not path.is_file():
        raise RuntimeError(f'Sem relatorio QA: {path}')
    fields = {}
    for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
        if '=' in line:
            key, val = line.split('=', 1)
            fields[key] = val
    return fields

def run_one(exe, mode, frames, replay, work):
    work.mkdir()
    (work / 'assets').mkdir()
    shutil.copy2(ROOT / 'assets' / 'cart-data.bin', work / 'assets' / 'cart-data.bin')
    env = dict(os.environ)
    # Neutralize stale options inherited from a developer's terminal.
    for name in tuple(env):
        if name.startswith('FORJA65_'):
            env.pop(name)
    env.update(FORJA65_HEADLESS='1', FORJA65_HEADLESS_FRAMES=str(frames),
               FORJA65_WATCHDOG_INSTRUCTIONS=str(max(18000000, frames * 50000)),
               FORJA65_ROM_MODE='cart', FORJA65_INPUT_REPLAY=str(replay),
               FORJA65_EXECUTION=mode)
    result = subprocess.run([str(exe)], cwd=work, env=env, capture_output=True,
                            text=True, errors='replace', timeout=120)
    (work / 'stdout.log').write_text(result.stdout + result.stderr, encoding='utf-8')
    qa = parse_qa(work / 'forja65-qa-status.txt')
    if result.returncode != 0 or qa.get('runtime_started') != 'PASS':
        raise RuntimeError(f'{mode}: exit={result.returncode}; '
                           f'error={qa.get("error", "unknown")}; see {work}/stdout.log')
    if int(qa.get('frames', 0)) != frames:
        raise RuntimeError(f'{mode}: expected {frames} frames, got {qa.get("frames")}')
    if qa.get('new_oracle_hints') != 'NO':
        raise RuntimeError(f'{mode}: novos caminhos de CPU pendentes')
    return qa

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--game', help='Path to already compiled game(.exe)')
    ap.add_argument('--frames', type=int, default=950)
    ap.add_argument('--trace', default='tests/biker-start.trace',
                    help='Replay relative to the project root, or an absolute path')
    ap.add_argument('--out', help='Optional JSON report file')
    args = ap.parse_args()
    if not 1 <= args.frames <= 100000:
        ap.error('--frames must be between 1 and 100000')
    exe = locate_game(args.game)
    replay = (ROOT / args.trace).resolve()
    if not replay.is_file():
        raise RuntimeError(f'Replay nao encontrado: {replay}')
    with tempfile.TemporaryDirectory(prefix='biker-regressao-') as tmp:
        work = Path(tmp)
        native = run_one(exe, 'native', args.frames, replay, work / 'native')
        reference = run_one(exe, 'reference', args.frames, replay, work / 'reference')
    mismatches = {field: {'native': native.get(field), 'reference': reference.get(field)}
                  for field in FIELDS if native.get(field) != reference.get(field)}
    expected = BASELINE_950 if replay.name == 'biker-start.trace' and args.frames == 950 else {}
    regression = {field: {'expected': value, 'actual': native.get(field)}
                  for field, value in expected.items() if native.get(field) != value}
    report = {
        'schema': 1, 'frames': args.frames, 'game': str(exe),
        'replay': str(replay),
        'native_vs_reference_equal': not mismatches,
        'opening_950_baseline_equal': not regression if expected else None,
        'native': {k: native.get(k) for k in FIELDS},
        'reference': {k: reference.get(k) for k in FIELDS},
        'mismatches': mismatches, 'regression': regression,
        'status': 'PASS' if not mismatches and not regression else 'FAIL'
    }
    text = json.dumps(report, indent=2, ensure_ascii=False) + '\n'
    if args.out:
        outfile = Path(args.out).resolve()
        outfile.parent.mkdir(parents=True, exist_ok=True)
        outfile.write_text(text, encoding='utf-8')
    print(text)
    return 0 if report['status'] == 'PASS' else 1

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (RuntimeError, subprocess.TimeoutExpired, OSError) as exc:
        print(f'ERRO: {exc}', file=sys.stderr)
        sys.exit(2)
