#!/usr/bin/env node
'use strict';
const fs=require('fs'),assert=require('assert/strict');
const p=process.argv[2];if(!p)throw Error('Usage: node tools/check-shop-qa-v12.js path/to/forja65-qa-status.txt');
const rows=Object.fromEntries(fs.readFileSync(p,'utf8').trim().split(/\r?\n/).filter(x=>x.includes('=')).map(x=>x.split(/=(.*)/s).slice(0,2)));
assert.equal(rows.rom,'5df32d6de53b7971');
assert.equal(rows.runtime_started,'PASS');
assert.ok(Number(rows.frames)>=6000,'SHOP replay must complete 6000 frames');
assert.equal(rows.ppu_forced_blank,'0');
assert.ok(Number(rows.nmi_services)>5000,'SHOP interrupts did not progress');
console.log(`PASS SHOP replay frames=${rows.frames} NMI=${rows.nmi_services} video-active`);
