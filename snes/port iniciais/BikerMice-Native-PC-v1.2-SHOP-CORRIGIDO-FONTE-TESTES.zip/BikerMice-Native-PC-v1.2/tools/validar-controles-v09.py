#!/usr/bin/env python3
"""Fail v0.9 controller QA if complete differential replay shows no effect."""
import argparse, json
from pathlib import Path

def validate(path):
    report=json.loads(Path(path).read_text(encoding='utf-8'))
    assert report['shared_frames']==6800, 'expected 6800 completed frames in each replay'
    assert report['input_frame']==6160, 'unexpected injection time'
    assert report['rendered_effect_observed'], 'no rendered controller effect'
    assert report['memory_effect_observed'], 'no WRAM controller effect'
    assert report['first_difference']['wram']>=6160, 'pre-input WRAM changed'
    assert report['first_difference']['framebuffer']>=6160, 'pre-input graphics changed'
    return report
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--report',required=True);o=p.parse_args()
    validate(o.report)
    print('PASS v09 input differential: 6800 frames, graphics+WRAM respond to steering')
