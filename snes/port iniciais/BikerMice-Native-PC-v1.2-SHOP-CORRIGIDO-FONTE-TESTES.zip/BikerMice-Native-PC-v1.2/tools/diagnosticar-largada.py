#!/usr/bin/env python3
"""Flag a black-screen + stalled-NMI load as blocked (not proof of playable racing).

This diagnostic is intentionally separate from CPU native/reference equivalence:
identical execution can still reproduce the same hardware/timing bug twice.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def run_frame(game, trace, frame, directory):
    directory.mkdir()
    (directory / 'assets').mkdir()
    shutil.copy2(ROOT / 'assets' / 'cart-data.bin', directory / 'assets' / 'cart-data.bin')
    env = {k: v for k, v in os.environ.items() if not k.startswith('FORJA65_')}
    env.update(FORJA65_HEADLESS='1', FORJA65_HEADLESS_FRAMES=str(frame),
               FORJA65_WATCHDOG_INSTRUCTIONS=str(max(18000000, frame * 30000)),
               FORJA65_ROM_MODE='cart', FORJA65_EXECUTION='native',
               FORJA65_INPUT_REPLAY=str(trace))
    process = subprocess.run([str(game)], cwd=directory, env=env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, errors='replace', timeout=120)
    (directory / 'run.log').write_text(process.stdout, encoding='utf-8')
    status = {}
    path = directory / 'forja65-qa-status.txt'
    if path.is_file():
        for line in path.read_text(encoding='utf-8').splitlines():
            if '=' in line:
                key, val = line.split('=', 1)
                status[key] = val
    if process.returncode or status.get('runtime_started') != 'PASS' or status.get('frames') != str(frame):
        raise RuntimeError(f'frame {frame}: falha no runtime exit={process.returncode}, QA={status}')
    return {k: status.get(k) for k in ('frames', 'instructions', 'nmi_services',
                                      'ppu_forced_blank', 'framebuffer_hash',
                                      'wram_hash', 'new_oracle_hints')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--game', required=True)
    parser.add_argument('--trace', default='tests/biker-enter-track.trace')
    parser.add_argument('--before', type=int, default=5200)
    parser.add_argument('--after', type=int, default=6500)
    parser.add_argument('--out', default='reports/biker-largada-diagnostico.json')
    args = parser.parse_args()
    game = Path(args.game).resolve()
    trace = (ROOT / args.trace).resolve()
    if not game.is_file() or not trace.is_file() or args.before <= 0 or args.after <= args.before:
        parser.error('game/trace validos e 0 < before < after sao obrigatorios')
    with tempfile.TemporaryDirectory(prefix='biker-largada-') as d:
        base = Path(d)
        before = run_frame(game, trace, args.before, base / 'before')
        after = run_frame(game, trace, args.after, base / 'after')
    stalled_nmi = int(after['nmi_services']) == int(before['nmi_services'])
    blank = after['ppu_forced_blank'] == '1'
    status = 'BLOCKED_LOAD' if (stalled_nmi and blank) else 'NO_STALL_DETECTED'
    result = {'schema': 1, 'status': status, 'before': before, 'after': after,
              'nmi_delta': int(after['nmi_services']) - int(before['nmi_services']),
              'forced_blank_after': blank,
              'note': 'NO_STALL_DETECTED nao significa corrida jogavel. Checar pixels e controles.'}
    out = (ROOT / args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 3 if status == 'BLOCKED_LOAD' else 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except (RuntimeError, OSError, subprocess.TimeoutExpired) as exc:
        print(f'ERRO: {exc}', file=sys.stderr)
        sys.exit(2)
