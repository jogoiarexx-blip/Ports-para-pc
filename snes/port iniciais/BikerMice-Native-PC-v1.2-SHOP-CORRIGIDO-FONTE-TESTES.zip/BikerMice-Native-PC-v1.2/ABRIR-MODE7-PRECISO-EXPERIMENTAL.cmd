@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_MODE7_PRECISE=1"
if exist "bin\game.exe" goto bin
if exist "build-win\Release\game.exe" goto release
echo Execute GERAR-GAME-EXE-WINDOWS.cmd antes de testar.
exit /b 2
:bin
"bin\game.exe"
exit /b %ERRORLEVEL%
:release
"build-win\Release\game.exe"
exit /b %ERRORLEVEL%
