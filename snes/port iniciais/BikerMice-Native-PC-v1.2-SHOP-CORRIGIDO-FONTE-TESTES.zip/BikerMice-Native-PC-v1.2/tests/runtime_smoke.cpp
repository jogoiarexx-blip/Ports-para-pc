#include "runtime.hpp"
#include <iostream>
int main(){try{SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"runtime-smoke.srm",1u,true);if(hw.cart.empty()||hw.framebuffer.empty())return 3;if(hw.cartHashHex()!="5df32d6de53b7971"){std::cerr<<"ROM fingerprint mismatch "<<hw.cartHashHex()<<" expected 5df32d6de53b7971\n";return 4;}std::cout<<"FORJA65_RUNTIME_SMOKE_OK cart="<<hw.cart.size()<<" refresh="<<hw.hostRefreshHz()<<" rom=5df32d6de53b7971\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
