#!/usr/bin/env python3
from pathlib import Path
import tempfile
import importlib.util
p=Path(__file__).resolve().parents[1]/'tools/validar-controles-v08.py'
spec=importlib.util.spec_from_file_location('controls_v08',p)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
with tempfile.TemporaryDirectory() as temp:
    a=Path(temp)/'a';b=Path(temp)/'b'
    def save(path,x):
        path.write_text(''.join(f'frame={i} framebuffer={x[i][0]} wram={x[i][1]} pc={x[i][2]}\n' for i in range(len(x))))
    save(a,[('aa','bb','80'),('aa','bb','80'),('aa','bb','80'),('aa','bb','80')])
    save(b,[('aa','bb','80'),('aa','bb','80'),('aa','cd','80'),('dd','ef','81')])
    r=mod.compare(a,b,2)
    assert r['first_difference']=={'framebuffer':3,'wram':2,'pc':3}
    assert r['rendered_effect_observed'] and not r['acceleration_confirmed']
    save(b,[('aa','bb','80'),('dd','bb','80'),('aa','cd','80'),('dd','ef','81')])
    try: mod.compare(a,b,2)
    except ValueError as e: assert 'before injection' in str(e)
    else: raise AssertionError('accepted divergence before input')
print('INPUT_DIFF_V08_PASS')
