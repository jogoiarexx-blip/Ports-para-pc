#include "runtime.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <iostream>
int main(){
  PpuState p;
  // Fidelity correction is explicitly opted in; default gameplay keeps v0.9.
  p.preciseMode7=false;
  p.writeScroll(0,0x34);p.writeScroll(0,0x12);
  assert(p.scrollX[0] != 0 || p.m7Hofs == 0);
  assert(p.m7Hofs==0);
  p.preciseMode7=true;
  p.m7Byte=0;
  p.writeScroll(0,0x34);p.writeScroll(0,0x12);
  assert(p.m7Hofs==0x1234u);
  p.writeScroll(1,0x56);p.writeScroll(1,0x78);
  assert(p.m7Vofs==0x7856u);
  const auto preserved=p.m7Byte;
  p.writeScroll(2,0xAB); // BG2 must not overwrite Mode 7 latch.
  assert(p.m7Byte==preserved);
  p.m7[0]=0x0100;p.m7[1]=0;p.m7[2]=0;p.m7[3]=0x0100;p.m7[4]=p.m7[5]=0;
  p.m7Hofs=p.m7Vofs=0;p.m7sel=0;
  assert(p.mode7Coordinates(12,18).first==12);
  assert(p.mode7Coordinates(12,18).second==18);
  p.m7sel=1;
  assert(p.mode7Coordinates(12,18).first==243);
  std::cout << "MODE7_CROSSFEED_V10_PASS default=legacy optin=hardware\n";
}
