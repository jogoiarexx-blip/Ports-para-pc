// Forja65 65C816 regression: absolute indexed and indirect indexed addresses
// must carry into the next 64 KiB data bank (but direct-page addressing wraps).
#include "runtime.hpp"
#include <cstdint>
#include <iostream>
#include <stdexcept>

static void require(bool condition, const char* message) {
  if (!condition) throw std::runtime_error(message);
}
int main() {
  try {
    CpuState cpu;
    SnesRuntime hw;
    cpu.db = 0x7E;
    cpu.x = 0x8000;
    require(cpu.address("abs", 0x8006) == 0x7E8006, "plain absolute DB");
    require(cpu.address("absx", 0x8006) == 0x7F0006, "absolute X bank carry");
    require(cpu.address("absx", 0x4001) == 0x7EC001, "absolute X without carry");
    hw.ram[6] = 0x20;
    hw.ram[7] = 0x00;
    hw.write8(cpu.address("absx", 0x8006), 0);
    require(hw.ram[6] == 0x20 && hw.ram[7] == 0, "WRAM loop counter clobbered across bank");
    require(hw.ram[0x10006] == 0, "bank 7F destination");
    cpu.y = 0x30;
    require(cpu.address("absy", 0xFFF0) == 0x7F0020, "absolute Y bank carry");
    cpu.d = 0;
    hw.ram[0x20] = 0xF0;
    hw.ram[0x21] = 0xFF;
    require(cpu.addressDpIndirectY(hw, 0x20) == 0x7F0020, "direct indirect Y bank carry");
    cpu.s = 0x180;
    hw.ram[0x190] = 0xF0;
    hw.ram[0x191] = 0xFF;
    require(cpu.addressStackIndirectY(hw, 0x10) == 0x7F0020, "stack indirect Y bank carry");
    cpu.x = 0x20;
    cpu.d = 0xFFF0;
    require(cpu.address("dpx", 0x20) == 0x30, "direct-page must wrap within bank 00");
    cpu.db = 0xFF;
    cpu.x = 0x30;
    require(cpu.address("absx", 0xFFF0) == 0x20, "24-bit address bus must wrap");
    std::cout << "CPU_BANK_CROSS_PASS absolute X/Y, indirect Y, stack indirect Y, WRAM isolation, bank 00/24bit wrap\n";
    return 0;
  } catch (const std::exception& exc) {
    std::cerr << "CPU_BANK_CROSS_FAIL " << exc.what() << '\n';
    return 1;
  }
}
