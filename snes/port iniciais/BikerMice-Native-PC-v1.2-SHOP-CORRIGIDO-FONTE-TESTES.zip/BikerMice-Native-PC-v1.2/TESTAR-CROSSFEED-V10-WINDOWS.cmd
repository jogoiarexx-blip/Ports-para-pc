@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GAME=%CD%\bin\game.exe"
if not exist "%GAME%" set "GAME=%CD%\build-win\Release\game.exe"
if not exist "%GAME%" (echo Compile primeiro com GERAR-GAME-EXE-WINDOWS.cmd & exit /b 2)
where node >nul 2>nul
if errorlevel 1 (echo Node.js nao encontrado. & exit /b 2)
set "RESULT=%CD%\diagnosticos-crossfeed-v10"
if not exist "%RESULT%\assets" mkdir "%RESULT%\assets"
copy /Y "%CD%\assets\cart-data.bin" "%RESULT%\assets\cart-data.bin" >nul
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6800"
set "FORJA65_WATCHDOG_INSTRUCTIONS=230000000"
set "FORJA65_MODE7_PRECISE=0"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-v08-b_accel.trace"
pushd "%RESULT%"
"%GAME%"
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" exit /b 3
node "%CD%\tools\verify-replay-series.js" --baseline "%CD%\evidence\replay-v08\b-aceleracao-6200-hashes.txt" --current "%RESULT%\forja65-frame-hashes.txt" --through 6200 --out "%RESULT%\regressao-v10.json"
if errorlevel 1 exit /b 4
echo PASS: 6800 frames completos e 6200 hashes preservados.
exit /b 0
