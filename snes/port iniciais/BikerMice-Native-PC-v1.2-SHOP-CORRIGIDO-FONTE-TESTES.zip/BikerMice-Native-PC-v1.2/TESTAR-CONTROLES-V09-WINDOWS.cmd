@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%CD%"
set "GAME=%ROOT%\bin\game.exe"
if not exist "%GAME%" set "GAME=%ROOT%\build-win\Release\game.exe"
if not exist "%GAME%" (echo ERRO: Compile primeiro com GERAR-GAME-EXE-WINDOWS.cmd & exit /b 2)
where node >nul 2>nul
if errorlevel 1 (echo ERRO: Node.js necessario para conferir regressao de todos os frames. & exit /b 2)
where python >nul 2>nul
if errorlevel 1 (echo ERRO: Python 3 necessario para comparar controles. & exit /b 2)
set "RESULT=%ROOT%\diagnosticos-controles-v09"
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6800"
set "FORJA65_WATCHDOG_INSTRUCTIONS=230000000"
set "FORJA65_CAPTURE_FRAMES=6200,6300,6600,6800"
call :replay b-temporario "%ROOT%\tests\biker-v08-b_accel.trace"
if errorlevel 1 exit /b 3
call :replay b-continuo "%ROOT%\tests\biker-v09-b-continuo.trace"
if errorlevel 1 exit /b 3
call :replay b-curvas "%ROOT%\tests\biker-v09-b-curvas.trace"
if errorlevel 1 exit /b 3
node "%ROOT%\tools\verify-replay-series.js" --baseline "%ROOT%\evidence\replay-v08\b-aceleracao-6200-hashes.txt" --current "%RESULT%\b-temporario\forja65-frame-hashes.txt" --through 6200 --out "%RESULT%\regressao-original-6200.json"
if errorlevel 1 exit /b 4
node "%ROOT%\tools\verify-replay-series.js" --baseline "%ROOT%\evidence\replay-v08\b-aceleracao-6200-hashes.txt" --current "%RESULT%\b-continuo\forja65-frame-hashes.txt" --through 6180 --out "%RESULT%\regressao-aceleracao-6180.json"
if errorlevel 1 exit /b 4
python "%ROOT%\tools\validar-controles-v08.py" --baseline "%RESULT%\b-continuo\forja65-frame-hashes.txt" --variant "%RESULT%\b-curvas\forja65-frame-hashes.txt" --input-frame 6160 --out "%RESULT%\comparacao-curvas.json"
if errorlevel 1 exit /b 4
python "%ROOT%\tools\validar-controles-v09.py" --report "%RESULT%\comparacao-curvas.json"
if errorlevel 1 exit /b 4
echo OK: 3 cenarios com 6800 frames completos; compare capturas em %RESULT%.
echo IMPORTANTE: nao demonstra fisica identica ao SNES original.
exit /b 0
:replay
set "DIR=%RESULT%\%~1"
if not exist "!DIR!\assets" mkdir "!DIR!\assets"
copy /Y "%ROOT%\assets\cart-data.bin" "!DIR!\assets\cart-data.bin" >nul
if errorlevel 1 exit /b 2
pushd "!DIR!"
set "FORJA65_INPUT_REPLAY=%~2"
set "FORJA65_CAPTURE_DIR=!CD!\captures"
"%GAME%"
set "RC=!ERRORLEVEL!"
popd
if not "!RC!"=="0" (echo Falha no replay %~1 codigo !RC! & exit /b 3)
exit /b 0
