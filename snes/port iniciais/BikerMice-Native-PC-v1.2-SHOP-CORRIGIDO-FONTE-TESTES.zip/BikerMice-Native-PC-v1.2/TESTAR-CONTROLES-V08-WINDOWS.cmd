@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "EXE=%~dp0bin\game.exe"
if not exist "%EXE%" set "EXE=%~dp0build-win\Release\game.exe"
if not exist "%EXE%" (echo ERRO: compile primeiro com GERAR-GAME-EXE-WINDOWS.cmd & exit /b 2)
where python >nul 2>nul
if errorlevel 1 (echo ERRO: Python 3 necessario para gerar o relatorio diferencial. & exit /b 2)
set "ROOT=%~dp0"
set "RESULT=%ROOT%diagnosticos-controles-v08"
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6200"
set "FORJA65_WATCHDOG_INSTRUCTIONS=180000000"
call :run baseline "%ROOT%tests\biker-enter-track.trace"
if errorlevel 1 exit /b 3
call :run acelerar-b "%ROOT%tests\biker-v08-b_accel.trace"
if errorlevel 1 exit /b 3
call :run b-direita "%ROOT%tests\biker-v08-b_right.trace"
if errorlevel 1 exit /b 3
python "%ROOT%tools\validar-controles-v08.py" --baseline "%RESULT%\baseline\forja65-frame-hashes.txt" --variant "%RESULT%\acelerar-b\forja65-frame-hashes.txt" --input-frame 6075 --out "%RESULT%\efeito-b.json"
if errorlevel 1 exit /b 4
python "%ROOT%tools\validar-controles-v08.py" --baseline "%RESULT%\acelerar-b\forja65-frame-hashes.txt" --variant "%RESULT%\b-direita\forja65-frame-hashes.txt" --input-frame 6075 --out "%RESULT%\efeito-direcao.json"
if errorlevel 1 exit /b 4
echo 3 replays de 6200 frames completos. Compare as capturas em %RESULT%.
echo Diferenca de hash por si so nao valida fisica SNES, veja as imagens.
exit /b 0
:run
set "DIR=%RESULT%\%~1"
if not exist "!DIR!\assets" mkdir "!DIR!\assets"
copy /Y "%ROOT%assets\cart-data.bin" "!DIR!\assets\cart-data.bin" >nul
if errorlevel 1 exit /b 2
pushd "!DIR!"
set "FORJA65_INPUT_REPLAY=%~2"
set "FORJA65_CAPTURE_FRAMES=6110,6150,6180,6200"
set "FORJA65_CAPTURE_DIR=!CD!\captures"
"%EXE%"
set "RC=!ERRORLEVEL!"
popd
if not "!RC!"=="0" (echo Falha no replay %~1 codigo !RC! & exit /b 3)
exit /b 0
