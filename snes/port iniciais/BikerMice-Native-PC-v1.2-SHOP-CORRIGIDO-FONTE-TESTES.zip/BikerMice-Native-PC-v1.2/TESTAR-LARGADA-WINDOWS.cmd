@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GAME=bin\game.exe"
if not exist "%GAME%" set "GAME=build-win\Release\game.exe"
if not exist "%GAME%" (echo Compile primeiro com GERAR-GAME-EXE-WINDOWS.cmd.& exit /b 2)
set "FORJA65_HEADLESS=1"
set "FORJA65_HEADLESS_FRAMES=6040"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-enter-track.trace"
set "FORJA65_CAPTURE_FRAMES=5900,6040"
set "FORJA65_CAPTURE_DIR=%CD%\capturas-largada"
"%GAME%"
if errorlevel 1 (echo Bloqueio no replay. Verifique forja65-crash-trace.txt.& exit /b 3)
if not exist "capturas-largada\frame-6040\preview.ppm" (echo Imagem da pista ausente.& exit /b 4)
echo PASS: pista e contagem regressiva capturadas.
echo Nao comprova movimentacao, controles ou conclusao da corrida.
exit /b 0
