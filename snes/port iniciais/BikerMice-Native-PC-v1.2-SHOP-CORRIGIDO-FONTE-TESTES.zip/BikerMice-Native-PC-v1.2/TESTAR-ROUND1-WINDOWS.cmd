@echo off
setlocal
cd /d "%~dp0"
set "EXE=bin\game.exe"
if not exist "%EXE%" set "EXE=build-win\Release\game.exe"
if not exist "%EXE%" (
  echo ERRO: game.exe nao encontrado. Rode GERAR-GAME-EXE-WINDOWS.cmd.
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 tools\verificar-abertura.py --game "%EXE%" --frames 4500 --trace tests/biker-race-start.trace --out reports\biker-qa-v03-4500.json
) else (
  python tools\verificar-abertura.py --game "%EXE%" --frames 4500 --trace tests/biker-race-start.trace --out reports\biker-qa-v03-4500.json
)
if errorlevel 1 exit /b 1
echo Teste de menus e RACE/SHOP passou. A largada ainda esta bloqueada; veja DIAGNOSTICAR-LARGADA-WINDOWS.cmd.
exit /b 0
