@echo off
setlocal
cd /d "%~dp0"
set "EXE=bin\game.exe"
if not exist "%EXE%" set "EXE=build-win\Release\game.exe"
if not exist "%EXE%" (
  echo ERRO: game.exe nao encontrado. Rode GERAR-GAME-EXE-WINDOWS.cmd.
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 tools\diagnosticar-largada.py --game "%EXE%"
) else (
  python tools\diagnosticar-largada.py --game "%EXE%"
)
echo.
echo BLOCKED_LOAD significa que a simulacao segue preta e a NMI nao progride.
echo O resultado NO_STALL_DETECTED nao prova corrida jogavel.
exit /b %errorlevel%
