# Biker Mice Native PC — v0.5

A primeira pista e os motociclistas agora aparecem apos confirmar RACE, inclusive a contagem regressiva 3->1.
A corrida depois do GO e seus controles ainda nao foram validados.

Para compilar no Windows, execute `GERAR-GAME-EXE-WINDOWS.cmd`.
Para comparar as imagens de referencia do port com sua compilacao: `TESTAR-LARGADA-WINDOWS.cmd`.
Para investigar possiveis bloqueios: `DIAGNOSTICAR-LARGADA-WINDOWS.cmd`.
Leia `docs/BIKER-V05-CFG-PROGRESSO.md`. Nao existe game.exe Windows precompilado neste ZIP.

## Atualizacao v0.6 (12/10/2026)

- Traducao CFG alcancou 25.186 enderecos; 92 hints aprendidos, 92 cobertos no dispatcher.
- Compilacao C++ Linux aprovada; frame 6040 continua identico ao da v0.5 (hash de framebuffer e WRAM).
- Replay de 6.150 frames solicitado, mas encerrou apos 6.049 quadros completos com novo salto `$83:9FF0->$83:A128` ainda nao integrado.
- Adicionados diagnostico automatico `tools/validar-largada-v06.py` e `TESTAR-POS-LARGADA-WINDOWS.cmd`. O segundo exige compilacao Windows previa.
- **Nao ha comprovacao de GO, movimento, audio correto nem primeira corrida concluida.**
- Consulte `reports/BIKER-V06-RESULTADO.json` e `docs/BIKER-V06-CFG-LARGADA.md`.
