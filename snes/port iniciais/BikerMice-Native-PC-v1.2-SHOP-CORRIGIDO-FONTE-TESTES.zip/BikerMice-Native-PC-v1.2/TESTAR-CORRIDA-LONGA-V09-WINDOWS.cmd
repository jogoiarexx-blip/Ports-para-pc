@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GAME=%CD%\bin\game.exe"
if not exist "%GAME%" set "GAME=%CD%\build-win\Release\game.exe"
if not exist "%GAME%" (
  echo Nao foi encontrado game.exe. Execute GERAR-GAME-EXE-WINDOWS.cmd.
  exit /b 2
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js necessario para conferir os 6200 frames historicos.
  exit /b 2
)
set "RESULT=%CD%\diagnosticos-corrida-v09"
if not exist "%RESULT%\assets" mkdir "%RESULT%\assets"
copy /Y "%CD%\assets\cart-data.bin" "%RESULT%\assets\cart-data.bin" >nul
if errorlevel 1 exit /b 2
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6800"
set "FORJA65_WATCHDOG_INSTRUCTIONS=230000000"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-v08-b_accel.trace"
set "FORJA65_CAPTURE_FRAMES=6200,6300,6600,6800"
set "FORJA65_CAPTURE_DIR=%RESULT%\captures"
pushd "%RESULT%"
"%GAME%"
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" (
  echo Falha antes de 6400 frames. Verifique %RESULT%\forja65-runtime-hints.txt
  exit /b 3
)
node "%CD%\tools\verify-replay-series.js" --baseline "%CD%\evidence\replay-v08\b-aceleracao-6200-hashes.txt" --current "%RESULT%\forja65-frame-hashes.txt" --through 6200 --out "%RESULT%\regressao-6200.json"
if errorlevel 1 (
  echo FALHA: regressao da v0.8 detectada!
  exit /b 4
)
echo OK: 6800 frames completos; 6200 frames iniciais preservados.
echo As rotas de direcao e a fisica SNES ainda exigem testes independentes.
exit /b 0
