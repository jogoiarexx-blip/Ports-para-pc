@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (echo Node.js nao encontrado. & exit /b 2)
node "%CD%\tools\validar-cfg-v11.js"
if errorlevel 1 (echo Erro no CFG da v1.1 & exit /b 3)
set "GAME=%CD%\bin\game.exe"
if not exist "%GAME%" set "GAME=%CD%\build-win\Release\game.exe"
if not exist "%GAME%" (echo Compile com GERAR-GAME-EXE-WINDOWS.cmd & exit /b 4)
set "RESULT=%CD%\diagnosticos-v11"
if not exist "%RESULT%\assets" mkdir "%RESULT%\assets"
copy /Y "%CD%\assets\cart-data.bin" "%RESULT%\assets\cart-data.bin" >nul
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_HEADLESS_FRAMES=6800"
set "FORJA65_WATCHDOG_INSTRUCTIONS=230000000"
set "FORJA65_MODE7_PRECISE=0"
set "FORJA65_INPUT_REPLAY=%CD%\tests\biker-v08-b_accel.trace"
pushd "%RESULT%"
"%GAME%"
set "RC=%ERRORLEVEL%"
popd
if not "%RC%"=="0" (echo Replay parou antes de completar 6800 frames. & exit /b 5)
node "%CD%\tools\verify-replay-series.js" --baseline "%CD%\evidence\replay-v11\aceleracao-6800-hashes.txt" --current "%RESULT%\forja65-frame-hashes.txt" --through 6800 --out "%RESULT%\comparacao-v11.json"
if errorlevel 1 (echo Divergencia de replay. Verifique diagnosticos-v11. & exit /b 6)
echo PASS: 6800 frames sem divergencia de imagem, WRAM e CPU.
exit /b 0
