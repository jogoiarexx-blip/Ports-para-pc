@echo off
setlocal
cd /d "%~dp0"
for /f "tokens=1 delims==" %%V in ('set FORJA65_ 2^>nul') do set "%%V="
set "FORJA65_AUDIO_MODE=native"
set "FORJA65_AUDIO_SYNC=1"
set "FORJA65_AUDIO_PACING=1"
set "FORJA65_UNCAPPED=0"
set "FORJA65_INPUT_RECORD=minha-partida.trace"
set "FORJA65_CPU_HOTSPOTS=1"
set "FORJA65_FRAME_PROGRESS_CSV=progresso.csv"
set "FORJA65_FRAME_PROGRESS_EVERY=300"
echo POWER RANGERS - REV039 - 9 VIDAS E 9 CONTINUES - TESTE WINDOWS X64
echo.
echo 1 - Jogar do inicio
echo 2 - Fase 2 (preparar por replay)
echo 3 - Fase 3 (preparar por replay)
echo 4 - Fase 4 (preparar por replay)
echo 5 - Fase 5 (preparar por replay)
echo 0 - Sair
echo.
echo As fases 6 e 7 sao alcancadas continuando a campanha.
echo A preparacao pode levar varios minutos. Nao feche o console.
echo Destinos baseados em capturas Linux; precisam do seu teste Windows.
choice /c 123450 /n /m "Escolha: "
if errorlevel 6 exit /b 0
if errorlevel 5 (set "FORJA65_PLAY_FROM_FRAME=140000"& goto replay)
if errorlevel 4 (set "FORJA65_PLAY_FROM_FRAME=103000"& goto replay)
if errorlevel 3 (set "FORJA65_PLAY_FROM_FRAME=83000"& goto replay)
if errorlevel 2 (set "FORJA65_PLAY_FROM_FRAME=39000"& goto replay)
goto run
:replay
set "FORJA65_INPUT_REPLAY=replays\REV008-185000-QA.trace"
:run
echo.
echo Setas: mover. X: pular. Z: atacar. S: especial/morph.
echo Q/W: trocar plano. Enter: iniciar/pausar. Shift: Select.
echo.
PowerRangers.exe
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
 echo O jogo encerrou com erro %RESULT%.
 if exist forja65-last-error.txt type forja65-last-error.txt
 echo Guarde os arquivos de relatorio e minha-partida.trace para analise.
 pause
)
exit /b %RESULT%
