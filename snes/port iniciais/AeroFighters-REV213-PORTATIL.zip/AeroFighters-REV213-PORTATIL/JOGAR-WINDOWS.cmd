@echo off
setlocal
cd /d "%~dp0"
if not defined FORJA65_SPC_PROFILE set FORJA65_SPC_PROFILE=legacy
if exist bin\windows\AeroFighters.exe (
  bin\windows\AeroFighters.exe
) else (
  echo Executavel ausente. Rode COMPILAR-WINDOWS.cmd primeiro.
  pause
  exit /b 2
)
