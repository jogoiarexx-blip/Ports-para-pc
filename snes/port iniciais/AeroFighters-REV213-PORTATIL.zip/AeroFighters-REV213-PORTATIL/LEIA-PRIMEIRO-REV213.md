# Aero Fighters — REV213

Continuação do port REV212, usando os fontes fornecidos de Aero Fighters e Forja65 REV204/REV203-R4. Esta revisão corrige retornos construídos e trocas de pilha entre tarefas, amplia a tradução C++ da CPU e expande o SPC700 AOT para 2.263 pares PC/opcode.

**A campanha completa ainda não foi concluída nem validada. Não há certificação de jogo inteiro 100% nativo.** Os números exatos, hashes dos executáveis e limites dos testes desta entrega estão em `REV213-VALIDACAO.json`.

## Jogar

Extraia o ZIP inteiro antes de abrir o jogo. Mantenha `assets/`, `bin/` e os lançadores juntos.

- Windows x64: abra `JOGAR-WINDOWS.cmd`. Executável: `bin/windows/AeroFighters.exe`. As bibliotecas C++ foram vinculadas estaticamente; as dependências obrigatórias restantes são DLLs do sistema. SDL2 é opcional para controles adicionais.
- Linux x86_64: execute `bash JOGAR-LINUX.sh`. Precisa de SDL2 (`libSDL2-2.0.so.0`) e bibliotecas de sistema compatíveis com a compilação Ubuntu 24.04. Este pacote não é independente de glibc.
- Não é necessário instalar Forja, Python ou Node para jogar.
- Teclado: setas movem; Enter é Start; Shift é Select; X/Z/A/S/Q/W correspondem a B/Y/A/X/L/R do controle SNES. F5 pausa; F8 captura. Tiro e bomba dependem da configuração do jogo.
- Os lançadores selecionam o perfil sonoro `legacy`, usado nas comparações.

O executável Windows foi compilado e seus imports foram inspecionados. Não foi executado em Windows real; o ambiente bloqueou Wine. Controles físicos, áudio em dispositivo real e desempenho em tempo real não foram certificados.

## Correções e cruzamento dos projetos

O runtime passa a associar retornos nativos à posição física da pilha. Ao retomar uma tarefa mais antiga, preserva os retornos de outras tarefas suspensas. Novas chamadas retiram o registro antigo do mesmo slot reutilizado.

Retornos RTS/RTL construídos para trampolins JML são aceitos somente após conferir passivamente o opcode de retorno em ROM, os bytes da pilha WRAM, o destino reconstruído e os quatro bytes contíguos do JML em ROM. A consulta não altera leituras de barramento nem ciclos. Destinos divergentes, bancos incorretos, WRAM e frames sem posição conhecida são recusados.

O gerador REV204 fornecido foi usado para integrar rotinas C++ a partir de logs vinculados ao cartucho `ee407db0b34b64eb`. As guardas M/X, os limites da análise e os avisos de convergência permanecem registrados em `analysis/aero213*/report.json`. Geração estática e quantidade de funções não provam cobertura de todas as partidas.

A REV203-R4 contém alterações SA-1. Este jogo usa LoROM sem esse coprocessador; o ramo SA-1 não foi transplantado. O cruzamento original e a identidade dos três ZIPs estão preservados em `analysis/` e na documentação REV212.

Uma unidade `runtime_hot.cpp`, ligada antes das demais, fornece implementações otimizadas de métodos compartilhados de temporização, eventos, SPC e renderização. A otimização não altera guardas, contadores ou semântica de instruções.

O SPC700 usa seletores PC/opcode com verificação do opcode atual e operandos lidos ao executar. Foram incorporadas três capturas, incluindo 24 pares que faltavam no percurso longo. A tradução e a referência interpretada compartilham a semântica de instruções; a comparação de áudio mede igualdade com esse runtime.

## Evidências e limites

`REV213-VALIDACAO.json` distingue a revisão de cada executável testado. Os relatórios detalhados ficam em `validation/rev213/`, com hashes do binário, cartucho e fita de entrada quando disponíveis. Resultados de versões intermediárias não são apresentados como testes do executável final.

- O trecho inicial de 2.000 frames atingiu zero instruções CPU interpretadas e zero ciclos SPC interpretados, inclusive com CPU estrita. Framebuffer, WRAM e contadores comparados coincidiram com a REV212.
- A comparação sonora de 2.000 frames produziu 1.066.246 amostras estéreo idênticas entre SPC AOT ligado e desligado, além de ARAM final idêntica. Não certifica fidelidade ao console original.
- CTest: 32 testes aprovados, um ignorado por ausência de vetores externos. O conjunto Python Aero contém 172 testes aprovados.
- As imagens do percurso de 22.880 frames mostram a transição da segunda para a terceira fase. Tentativas posteriores com comandos de controle terminaram em Game Over. Não há prova de quarta fase ou final da campanha.

As comparações de replay verificam estado final e contadores de CPU, NMI/IRQ, PPU e DMA; não comparam cada frame. PPU continua modelada em software. Percentual de acessos PPU nativos e percentual de bytes DMA nativos são medidas diferentes da cobertura de código CPU.

Permanecem necessários: cobrir rotas posteriores, personagens, chefes, finais e entradas alternativas; fechar destinos ainda descobertos em modo estrito; validar o executável no Windows e medir desempenho/áudio em hardware real. O fallback continua explícito. Não basta arredondar um percentual para declarar zero interpretação.

## Fonte, compilação e repetição

O ZIP fonte inclui C++ gerado, runtime, assets fornecidos, testes, scripts, logs e referências anteriores. O ZIP portátil contém os dois executáveis, assets, lançadores e relatório. WAVs grandes e cópias redundantes de executáveis intermediários são omitidos dos pacotes; os hashes e resultados permanecem nos relatórios.

Requer C++20 e CMake 3.20 ou superior para compilar. Foram usados GCC 13 e MinGW-w64 GCC 13-posix. Execute `bash COMPILAR-LINUX.sh` ou `COMPILAR-WINDOWS.cmd`. Os scripts solicitam Release; os executáveis distribuídos usam `-O0 -g0` nas unidades geradas e `-O2` em `runtime_hot.cpp`, com símbolos removidos. Não há promessa de FPS.

Para testes: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug`, `cmake --build build --parallel 2`, `ctest --test-dir build --output-on-failure`. Testes Python de imagem usam numpy e OpenCV; essas bibliotecas não são necessárias para jogar.

Para replay: `python3 tools/validate_rev213.py --frames 2000 --require-strict` ou `--frames 22880 --strict`. Para áudio: `python3 tools/validate_spc_audio_rev213.py --frames 2000`. Esses comandos gravam novas evidências locais. `tools/learn_rev212.js` precisa da pasta externa do Forja65 REV204 fornecido para repetir a geração; não é necessário para compilar o C++ já incluído.

`SHA256SUMS-REV213.txt` identifica os arquivos incluídos no fonte. Os manifestos e documentos de revisões anteriores são históricos.
