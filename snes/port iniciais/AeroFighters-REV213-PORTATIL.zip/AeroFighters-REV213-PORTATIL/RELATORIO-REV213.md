# Aero Fighters — relatório REV213

Entregues o fonte C++ e os executáveis portáteis Windows x64/Linux x86_64. **O jogo inteiro 100% nativo e a campanha completa ainda não estão certificados.**

## Resultado da compilação entregue

| Teste | Resultado |
|---|---|
| Replay de 2.000 frames, normal e CPU estrita | PASS; zero instruções CPU interpretadas e zero ciclos SPC interpretados |
| Comparação com REV212 | Framebuffer, WRAM, instruções totais, NMI/IRQ, PPU e DMA finais iguais |
| Áudio SPC AOT ligado/desligado, 2.000 frames | PASS; 1.066.246 amostras estéreo idênticas e ARAM final idêntica |
| CTest | 32 aprovados, um ignorado por ausência de vetores externos |
| Python Aero | 172 aprovados |
| Replay longo do binário entregue | Interrompido antes do resultado; não certificado |

Uma compilação anterior completou 22.880 frames com estados/contadores finais iguais à REV212 e apenas quatro instruções CPU interpretadas, contra 120.990.932 na REV212. O SPC700 ficou em zero ciclos interpretados. A variante restante foi integrada no executável entregue, mas o replay longo desse executável não terminou. Resultados anteriores não são apresentados como prova do binário atual.

## Mudanças

- Retornos nativos associados à posição física da pilha, preservando tarefas suspensas e tratando reutilização de slots.
- Retornos RTS/RTL construídos autenticados por ROM, pilha WRAM e trampolim JML, sem desligar as guardas.
- Ampliação das rotinas CPU C++ e do SPC AOT para 2.263 pares PC/opcode, usando três capturas.
- Métodos compartilhados do runtime compilados com otimização, preservando semântica e contadores nos testes concluídos.
- Cruzamento com Forja65 REV204 e REV203-R4; o ramo SA-1 não se aplica a este cartucho LoROM.

## Usar os pacotes

Extraia o ZIP portátil inteiro. No Windows, abra `JOGAR-WINDOWS.cmd`. No Linux, execute `bash JOGAR-LINUX.sh`; requer SDL2 e bibliotecas de sistema compatíveis. Não precisa instalar Forja, Python ou Node para jogar.

O ZIP fonte inclui C++, assets fornecidos, testes, scripts e evidências. `LEIA-PRIMEIRO-REV213.md` detalha compilação e controles. `REV213-VALIDACAO.json` vincula resultados e código aos hashes dos executáveis.

## Limites

As comparações verificam estado final contra o próprio runtime REV212; não certificam equivalência a cada frame ou fidelidade ao console original. A PPU continua modelada em software. Não foram certificados campanha completa, rotas alternativas, finais ou desempenho em tempo real. O executável Windows foi compilado e teve seus imports inspecionados, mas não foi executado em Windows real.
