@echo off
setlocal
cd /d "%~dp0"
if not exist "DKC3-ZERO.exe" (echo ERRO: extraia todo o ZIP antes de jogar. & pause & exit /b 1)
if not exist "assets\cart-data.bin" (echo ERRO: pasta assets ausente. Extraia todo o ZIP. & pause & exit /b 1)
rem Evita herdar configuracoes de testes ou replays de outra sessao.
for /f "tokens=1 delims==" %%V in ('set FORJA65_ 2^>nul') do set "%%V="
set "FORJA65_EXECUTION=reference"
set "FORJA65_SPC_PROFILE=reference"
set "FORJA65_SRAM_PATH=%~dp0save.srm"
"DKC3-ZERO.exe"
set "RESULTADO=%ERRORLEVEL%"
if not "%RESULTADO%"=="0" (
 echo.
 echo O jogo encerrou com erro %RESULTADO%.
 if exist "forja65-last-error.txt" type "forja65-last-error.txt"
 echo Guarde os arquivos forja65-*.txt desta pasta para diagnostico.
 pause
)
exit /b %RESULTADO%
