# DKC3-ZERO v0.47.1 (parcial): Kremwood Forest completa no Snes9x, com o Arich

**Data:** 20/10/2026. É uma entrega intermediária. Novidade desta versão: o chefe Arich foi vencido na rota de referência.

## 1. O que avançou

### Rota de referência no Snes9x (jogo normal, sem trapaça)
A rota vai do início da Doorstop Dash até a vitória sobre o Arich, que fecha a Kremwood Forest: 84.340 quadros, com 9 vidas no fim.

| Fase (Kremwood Forest) | Flag | Como foi concluída |
|---|---|---|
| Riverside Race (`0x32`) | `0x5B` | percurso completo, com o bônus 2 ("Bash the Baddies", 4 Re-Koils) |
| Squeals on Wheels (`0x29`) | `0x53` | 1º Sneek derrubado com o barril de aço; depois o Warp Barrel até a bandeira |
| Springin' Spiders (`0x2F`) | `0x53` | Warp Barrel até a bandeira |
| Bobbing Barrel Brawl (`0x34`) | `0x13` | Warp Barrel até a bandeira |
| Arich's Ambush (chefe, `0x1E`) | `0xC3` | 4 acertos de barril no queixo, sem perder vida; volta ao mapa |

Notas:
- **Warp Barrel:** é o atalho escondido do próprio jogo. A fase conta como concluída e libera o mapa. A pedido, esta rodada concluiu as fases sem os bônus.
- **Bônus pendentes:**
  - Riverside Race, bônus 1: fica no alto de um tronco; o quique do Kiddy na água não alcançou.
  - Squeals on Wheels, bônus 1: chegou a ser resolvido numa versão anterior da rota, mas ficou fora da rota atual.

### Como o Arich foi vencido
- **Correção:** os "acertos" 2 a 4 da versão anterior eram falsos. O barril batia na parede ou na perna, e o Arich não sofria dano.
- **Sinal confiável:** o byte de modo do Arich (`+0x38` no slot do objeto `2391`).
  | Modo | Significado |
  |---|---|
  | 1 / 10 | quicando no fio (o 10 é mais rápido, depois do 2º acerto) |
  | 2 | sobe e cospe veneno enquanto o Kong está no galho cortado |
  | 4 | acerto de verdade (golpe no queixo) |
  | 6 / 7 | cuspe de veneno depois de um acerto |
  | 11 a 14 | derrota (4º acerto) |
  | 16 | só recua; não conta como dano |
- **Como acertar:** com o barril nas mãos e o Arich quicando, o Kong fica no chão e pula por baixo dele, soltando o barril no queixo. Bater nele enquanto está no alto (modo 2) não conta.
- **Rota:** 1º barril nas costas da aranha; os outros no galho cortado. O veneno depois do 3º acerto (5 bolas quicando) foi atravessado sem dano.
- **Sem trapaça:** a invencibilidade só ajudou a descobrir o sinal. A rota final não usa nenhuma escrita na RAM.
- **Ferramentas:** `tools/rota-v047/arichlib.py` (modo do Arich, "segurando o barril" estável) e os segmentos `l12_*` em `build_route.py`.

### No port
- **Até o segundo mundo (v0.46):** conferido contra o Snes9x, incluindo a Barrel Shield Bust-Up. Traço e teste em `input/dkc3-ate-kremwood-v046.*`.
- **Riverside Race:** o port já fez a sala do bônus 2 ("Bash the Baddies", resolvida no próprio port) e voltou à fase. O trecho final ainda não fecha: perto do quadro 71.137 da referência o port se afasta da rota e o reparo local não reencontra o caminho. Fica pendente.
- **Squeals, Spiders e Bobbing:** ainda não conferidas no port. As receitas de mapa e do 1º Sneek são em malha fechada e servem para o port.

## 2. Melhorias nas ferramentas (`tools/rota-v047/`)

### `ge2.py` (busca no Snes9x e no port)
| Opção | O que faz |
|---|---|
| `POSX`/`POSY` | Escolhe o slot do personagem (a Ellie usa outro endereço) |
| `BONUS_BIAS` | Favorece as tentativas que derrotaram mais inimigos nas salas de bônus |
| `PROGRESS_OBJ` | Mede o progresso pelos inimigos que restam na sala |
| `UPBIAS` / `XBIAS` | Favorece quem subiu mais (fases verticais) ou avançou mais (horizontais) |
| `XMIN` / `XMAX` / `YMAX` | Proíbe sair de uma região (por exemplo, o Warp Barrel quando se quer o percurso completo) |
| `PAIR_REQ` | Descarta tentativas que perdem o parceiro (o Kiddy é obrigatório em alguns bônus) |
| `GOAL_ROOM` | Objetivo: entrar numa sala |
| `GOAL_BOX` | Objetivo: chegar a uma região |
| `GOAL_X` | Objetivo: passar de uma coordenada X |
| `GOAL_PY` | Objetivo: qualquer condição em Python, como "segurando o barril" (`$04CB` = 64) ou "barril novo surgiu no galho" |
| `CELLRAM` (+ `CELLRAM_UP`) | Bytes de RAM entram na célula de busca, com prioridade por ordem de valor (por exemplo, o indicador de objeto segurado) |
| `OBJSIG` | Usa o estado de objetos (medidores) como sinal de progresso |
| `INVULN` | Só para reconhecimento: força invencibilidade com os códigos `7E08B301`/`7E092101`. Nunca é usada na rota final |
| Novas jogadas | Quique do Kiddy na água; carregar, soltar e arremessar o barril de aço; arremesso em dupla para cima |

### `port_route.py` (conferência no port)
- Checkpoint automático a cada 8 blocos, para não perder progresso quando a tarefa atinge o limite de 2 horas.
- O reparo não pode pular o fim do trecho. A flag da fase é exigida explicitamente (`espera:<flag>:02`).
- `receita:<segmento>`: executa no port as mesmas receitas em malha fechada da referência (mapa, Belcha, Sneek).
- `mapaentra:<fase>:<índice>`: volta a uma fase pelo mapa e ressincroniza com a referência.
- A perda de vida conta só dentro do bloco. Antes, uma vida extra que o Snes9x pegou travava os reparos.
- Salas de "derrote os inimigos" usam a contagem de objetos (`PROGRESS_OBJ`).

### `portemu.py` e `refemu`
- `portemu.py`: tempo limite de resposta e registro do stderr. Se o processo ativo do port morrer, o erro aparece em vez de travar.
- `refemu`: novo comando `poke`, que escreve na RAM. É usado só no reconhecimento.

## 3. Arquivos
- `tools/rota-v047/rota-snes9x-v0471.txt`: as entradas da referência até a vitória sobre o Arich e os marcos de cada segmento.
- `input/dkc3-ate-kremwood-v046.trace` / `.golden` e `TESTAR-ATE-KREMWOOD-v046-*`: o último traço completo conferido no port, até o segundo mundo.

## 4. Próximos passos
- Seguir para o próximo mundo (Cotton-Top Cove) no Snes9x.
- Conferir no port: fim da Riverside Race, Squeals on Wheels, Springin' Spiders, Bobbing Barrel Brawl e Arich.
- Gerar o traço e os marcos da v0.47.
