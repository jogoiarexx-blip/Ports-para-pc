@echo off
setlocal
rem Igual ao JOGAR.cmd, mas com o interpretador da CPU desligado (FORJA65_CPU_AOT_ONLY=1).
rem Do inicio ate vencer o Arich tudo ja e codigo nativo. Alem disso, um trecho ainda nao convertido para o jogo com erro.
cd /d "%~dp0"
set FORJA65_CPU_AOT_ONLY=1
set "FORJA65_SRAM_PATH=%~dp0saves\save.srm"
game.exe
if errorlevel 1 (echo. & echo O jogo encerrou com erro. & type forja65-last-error.txt 2>nul & pause)
