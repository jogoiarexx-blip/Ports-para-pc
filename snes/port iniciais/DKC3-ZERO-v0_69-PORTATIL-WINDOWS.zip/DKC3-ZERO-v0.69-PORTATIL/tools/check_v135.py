#!/usr/bin/env python3
"""DKC3-ZERO v0.45.0 / Forja65 REV135: confere o replay ate o primeiro chefe (Belcha's Barn).

Uso: python tools/check_v135.py <pasta-do-replay> [golden]

A pasta precisa ter frame-hashes.txt (FORJA65_FRAME_HASHES=1). Compara o hash da WRAM nos
marcos de input/dkc3-ate-belcha-v135.golden: Lakeside 100%, Banana Bird, Doorstop Dash, Tidal Trouble,
Skidda's Row, Murky Mill e o chefe Belcha derrotado. A WRAM so depende da execucao do jogo (CPU/SPC/DMA), nao do
desenho da PPU nem do audio, entao o teste e estavel entre Linux e Windows.
"""
import pathlib
import sys


def load(path):
    rows = {}
    for line in pathlib.Path(path).read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if not line.startswith("frame="):
            continue
        fields = dict(part.split("=", 1) for part in line.split() if "=" in part)
        rows[int(fields["frame"])] = fields.get("wram", "").lower()
    return rows


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    run = pathlib.Path(sys.argv[1])
    root = pathlib.Path(__file__).resolve().parents[1]
    golden = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else root / "input" / "dkc3-ate-belcha-v135.golden"
    hashes = run / "frame-hashes.txt"
    if not hashes.is_file():
        print(f"FALHA: {hashes} nao existe (rode com FORJA65_FRAME_HASHES=1)")
        return 1
    got, want = load(hashes), load(golden)
    notes = {int(l.split()[0][6:]): l.split("#", 1)[1].strip() for l in golden.read_text(encoding="utf-8").splitlines() if l.startswith("frame=") and "#" in l}
    last = max(got) if got else -1
    print(f"quadros executados: {last + 1}")
    ok = True
    for frame, value in sorted(want.items()):
        actual = got.get(frame)
        state = "OK" if actual == value else ("AUSENTE" if actual is None else "DIFERENTE")
        if state != "OK":
            ok = False
        print(f"  quadro {frame:6d}: {state}  {notes.get(frame, '')}")
    interp = run / "forja65-cpu-interpreter.txt"
    if interp.is_file():
        head = dict(l.split("=", 1) for l in interp.read_text(encoding="utf-8").splitlines()[1:3] if "=" in l)
        print(f"interpretador 65C816 de fallback: {head.get('blocks', '?')} blocos, {head.get('instructions', '?')} instrucoes")
    print(("PASS: todos os marcos de "+golden.name+(" (Lakeside 100%, Banana Bird, Doorstop Dash, Tidal Trouble, Skidda's Row, Murky Mill e chefe Belcha derrotado)" if "belcha" in golden.name else (" (mundo 1 completo, Barrel Shield Bust-Up, Riverside Race, Squeals on Wheels, Springin' Spiders, Bobbing Barrel Brawl e chefe Arich derrotado: Kremwood Forest completa)" if "arich" in golden.name else " (Doorstop Dash, Tidal Trouble, Skidda's Row e Murky Mill com os dois bonus; Belcha derrotado; Barrel Shield Bust-Up concluida no mundo 2)"))) if ok else "FALHA: a execucao divergiu do replay validado")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
