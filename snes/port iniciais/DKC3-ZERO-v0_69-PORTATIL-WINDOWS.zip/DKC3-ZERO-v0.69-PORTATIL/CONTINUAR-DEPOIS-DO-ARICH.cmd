@echo off
setlocal
rem Avanca rapido pela rota validada (mundo 1 e Kremwood Forest completos, Arich vencido) e passa o controle
rem para voce no mapa da Kremwood Forest. A tela atualiza de vez em quando e sem som durante o avanco.
rem Usa um save proprio (saves\continuar.srm); o saves\save.srm do JOGAR.cmd nao e tocado.
cd /d "%~dp0"
set FORJA65_EXECUTION=reference
set FORJA65_SPC_PROFILE=reference
set FORJA65_REPLAY_TURBO=1
if exist "%~dp0saves\continuar.srm" del /Q "%~dp0saves\continuar.srm"
set "FORJA65_SRAM_PATH=%~dp0saves\continuar.srm"
set "FORJA65_INPUT_REPLAY=%~dp0input\dkc3-ate-arich-v0472.trace"
game.exe
if errorlevel 1 (echo. & echo O jogo encerrou com erro. & type forja65-last-error.txt 2>nul & pause)
