@echo off
setlocal
rem Teste automatico (sem janela, alguns minutos): roda a rota ate vencer o Arich com o interpretador DESLIGADO
rem e confere a memoria do jogo no fim. Resultado: PASS ou FALHA.
cd /d "%~dp0"
set "OUT=%~dp0teste"
if exist "%OUT%" rmdir /S /Q "%OUT%"
mkdir "%OUT%"
xcopy /E /I /Y "%~dp0assets" "%OUT%\assets" >nul
set FORJA65_EXECUTION=reference
set FORJA65_SPC_PROFILE=reference
set FORJA65_CPU_AOT_ONLY=1
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=119960
set FORJA65_WATCHDOG_INSTRUCTIONS=0
set FORJA65_FRAME_HASHES=1
set "FORJA65_FRAME_HASH_PATH=%OUT%\frame-hashes.txt"
set "FORJA65_INPUT_REPLAY=%~dp0input\dkc3-ate-arich-v0472.trace"
set "FORJA65_SRAM_PATH=%OUT%\teste.srm"
echo Rodando a rota completa sem interpretador... aguarde.
pushd "%OUT%"
"%~dp0game.exe" > replay.log 2>&1
popd
set OK=1
findstr /C:"interpretation_used=NO" "%OUT%\forja65-cpu-migration.txt" >nul
if errorlevel 1 set OK=0
findstr /C:"wram=b7f508bf1f6b16f3" "%OUT%\frame-hashes.txt" >nul
if errorlevel 1 set OK=0
python --version >nul 2>nul
if not errorlevel 1 python "%~dp0tools\check_v135.py" "%OUT%" "%~dp0input\dkc3-ate-arich-v0472.golden"
echo.
if "%OK%"=="1" (echo PASS: rota ate vencer o Arich sem interpretar nenhuma instrucao, memoria do jogo conferida.) else (echo FALHA: veja %OUT%\replay.log)
pause
