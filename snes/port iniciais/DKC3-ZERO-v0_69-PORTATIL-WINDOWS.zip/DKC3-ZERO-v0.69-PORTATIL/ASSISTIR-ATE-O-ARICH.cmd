@echo off
setlocal
rem Assiste a rota validada em tempo real (cerca de 33 minutos) e, no fim, o controle passa para voce.
cd /d "%~dp0"
set FORJA65_EXECUTION=reference
set FORJA65_SPC_PROFILE=reference
if exist "%~dp0saves\assistir.srm" del /Q "%~dp0saves\assistir.srm"
set "FORJA65_SRAM_PATH=%~dp0saves\assistir.srm"
set "FORJA65_INPUT_REPLAY=%~dp0input\dkc3-ate-arich-v0472.trace"
game.exe
if errorlevel 1 (echo. & echo O jogo encerrou com erro. & type forja65-last-error.txt 2>nul & pause)
