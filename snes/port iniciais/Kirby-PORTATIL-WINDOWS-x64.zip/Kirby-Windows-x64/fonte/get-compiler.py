from pathlib import Path
import urllib.request,concurrent.futures,subprocess
w=Path('winbuild');cache=w/'packages';cache.mkdir(exist_ok=True);root=w/'toolchain';root.mkdir(exist_ok=True)
items=[('binutils-mingw-w64','binutils-mingw-w64-x86-64_2.41.90.20240122-1ubuntu1+11.4_amd64.deb'),('mingw-w64','mingw-w64-common_11.0.1-3build1_all.deb'),('mingw-w64','mingw-w64-x86-64-dev_11.0.1-3build1_all.deb')]+[('gcc-mingw-w64',n+'_13.2.0-6ubuntu1+26.1_amd64.deb') for n in ['gcc-mingw-w64-base','gcc-mingw-w64-x86-64-posix-runtime','gcc-mingw-w64-x86-64-posix','g++-mingw-w64-x86-64-posix']]
def get(item):
 source,name=item;p=cache/name;u='https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/pool/universe/'+source[0]+'/'+source+'/'+name
 with urllib.request.urlopen(u,timeout=90) as r,p.open('wb') as f:
  while True:
   b=r.read(1024*1024)
   if not b:break
   f.write(b)
 subprocess.run(['dpkg-deb','--info',str(p)],check=True,stdout=subprocess.DEVNULL);print('DOWNLOADED',name,flush=True);return p
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:paths=list(pool.map(get,items))
for p in paths:subprocess.run(['dpkg-deb','-x',str(p),str(root)],check=True)
print('COMPILER_READY',flush=True)
