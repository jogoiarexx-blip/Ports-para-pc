from pathlib import Path
import shutil,subprocess,concurrent.futures,json,re,struct,hashlib,zipfile
r=Path.cwd();w=r/'winbuild';g=r/'active/Kirby-Dream-Land-3-Port-v0.3-FULLGAME';inc=w/'include';src=w/'src';obj=w/'obj'
for p in [inc,src,obj]:p.mkdir(exist_ok=True)
for p in (g/'src').glob('*.hpp'):shutil.copy2(p,inc/p.name)
for n in ['main.cpp','native_hooks.cpp','forja_observed_cpu.cpp','forja_stack.cpp']:shutil.copy2(g/'src'/n,src/n)
cxx=w/'toolchain/usr/bin/x86_64-w64-mingw32-g++-posix'
flags=['-std=c++20','-O1','-DFORJA65_ENABLE_TRACE=0','-DFORJA65_VERIFY_AOT=1','-DFORJA65_SA1_NO_INTERPRETER=1','-I'+str(inc)]
subprocess.run([str(cxx),*flags,'-x','c++-header',str(inc/'generated.hpp'),'-o',str(inc/'generated.hpp.gch')],check=True)
cat=g/'evidence/fullgame/aot-expanded/source'
sources=[src/n for n in ['main.cpp','native_hooks.cpp','forja_observed_cpu.cpp','forja_stack.cpp']]+[cat/'forja_sa1_runner_campaign.cpp']+[p for p in sorted(cat.glob('*.cpp')) if p.name!='forja_sa1_runner_campaign.cpp']
(w/'build-plan.json').write_text(json.dumps({'flags':flags,'sources':list(map(str,sources))},indent=2))
def compile_one(item):
 i,p=item;out=obj/(str(i)+'-'+p.stem+'.o');tmp=out.with_suffix('.tmp');log=out.with_suffix('.log')
 with log.open('w') as stream:ret=subprocess.run([str(cxx),*flags,'-c',str(p),'-o',str(tmp)],stdout=stream,stderr=subprocess.STDOUT)
 if ret.returncode or not tmp.exists() or not tmp.stat().st_size:raise RuntimeError(str(p)+'\n'+log.read_text()[-4000:])
 tmp.replace(out);print('COMPILED',i,p.name,flush=True);return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:objects=list(pool.map(compile_one,enumerate(sources)))
exe=w/'Kirby.exe';subprocess.run([str(cxx),'-O1','-static','-static-libgcc','-static-libstdc++','-Wl,--stack,1073741824',*map(str,objects),'-luser32','-lgdi32','-lxinput9_1_0','-lwinmm','-o',str(exe)],check=True)
data=exe.read_bytes();assert data[:2]==b'MZ';pe=struct.unpack_from('<I',data,0x3c)[0];assert data[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',data,pe+4)[0]==0x8664 and struct.unpack_from('<H',data,pe+24)[0]==0x20b
bin=w/'toolchain/usr/bin';nm=subprocess.check_output([str(bin/'x86_64-w64-mingw32-nm'),'-C',str(exe)],text=True)
assert 'forja65_interpret_step(' not in nm;assert 'forja65_scpu_aot' in nm and 'scpu_pc_8000_0(' in nm and 'forja65_sa1_addon_step(' in nm
headers=subprocess.check_output([str(bin/'x86_64-w64-mingw32-objdump'),'-p',str(exe)],text=True);dlls=re.findall(r'DLL Name: (\S+)',headers);assert dlls and not any(re.search('libstdc|libgcc|winpthread|SDL',n,re.I) for n in dlls)
p=w/'portable/Kirby-Windows-x64';(p/'assets').mkdir(parents=True,exist_ok=True);(p/'fonte').mkdir(exist_ok=True);shutil.copy2(exe,p/'Kirby.exe');shutil.copy2(g/'assets/cart-data.bin',p/'assets/cart-data.bin');shutil.copy2(w/'build.py',p/'fonte/build.py');shutil.copy2(w/'get-compiler.py',p/'fonte/get-compiler.py')
(p/'JOGAR.bat').write_bytes(('''@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_HEADLESS="
set "FORJA65_HEADLESS_FRAMES="
set "FORJA65_INPUT_REPLAY="
set "FORJA65_INPUT_POLL="
set "FORJA65_CHECKPOINT_LOAD="
set "FORJA65_CPU_INTERPRETER=0"
set "FORJA65_SA1_MODE=strict"
Kirby.exe
if errorlevel 1 (
 echo.
 echo O jogo parou. Veja forja65-last-error.txt nesta pasta.
 pause
)
endlocal
''').replace('\n','\r\n').encode('ascii'))
(p/'forja65-video.ini').write_text('filter=sharp\nresolution=auto\naspect=4:3\nfullscreen=0\n')
(p/'LEIA-ME.txt').write_text('''KIRBY / FORJA65 - WINDOWS 64 BITS - EXPERIMENTAL

Extraia TODO o ZIP. Abra JOGAR.bat, que inicia Kirby.exe na pasta correta.
Mantenha assets junto do executável. Não requer instalar Forja ou Python.

CONTROLES: setas = mover; X = B/pular; Z = Y/aspirar; Enter = Start;
Shift = Select; A/S = botões A/X; Q/W = L/R.
F7 = filtro; F8 = resolução; F10 = proporção; F11 = tela cheia; F12 = captura.
Suporte existente a controles XInput/WinMM, não validado nesta entrega.
Para sair, feche a janela.

Executável PE x86_64 compilado com MinGW-w64, runtime C++ estático.
Inclui a correção do HUD e o catálogo AOT atual. As instruções SCPU/SA1
não usam intérprete. Caminhos sem cobertura AOT ainda podem parar o jogo.
A campanha nativa completa NÃO foi validada. A rota Linux anterior chegou
a 145517 frames; isso não comprova a mesma execução no Windows.

Não foi possível executar o teste de Windows neste ambiente: Wine bloqueado
na criação de socket. Compilação e inspeção estática não substituem teste
num Windows real. Esta é uma entrega experimental para testar.

Se parar, envie forja65-last-error.txt e forja65-native-dependency-report.txt.

FONTES: os scripts desta compilação estão em fonte/. Para reproduzir,
use o pacote Kirby-Port-v0.3-FONTE.zip versão 59 em active/, a partir da
pasta de trabalho, e execute python3 winbuild/get-compiler.py e
python3 winbuild/build.py com os scripts copiados para winbuild/.
''',encoding='utf-8')
info={'platform':'Windows x86_64','compiler':subprocess.check_output([str(cxx),'--version'],text=True).splitlines()[0],'source_game_version':59,'source_count':len(sources),'instruction_interpreter_symbol_absent':True,'static_cpp_runtime':True,'runtime_hud_fix':True,'windows_runtime_tested':False,'full_campaign_native_verified':False,'exe_sha256':hashlib.sha256(data).hexdigest(),'exe_size':len(data),'system_dll_imports':dlls}
(p/'build-info.json').write_text(json.dumps(info,indent=2)+'\n');(w/'verification.json').write_text(json.dumps(info,indent=2)+'\n')
out=r/'deliverables/Kirby-PORTATIL-WINDOWS-x64.zip';out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in p.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(p.parent))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print('WINDOWS_BUILD_PASS; PE_X64_PASS; AOT_SYMBOL_AUDIT_PASS; SYSTEM_DLLS_ONLY_PASS; ZIP_PASS',flush=True)
print(out,flush=True)
upload={'uploads':[{'local_path':str(out),'purpose':'create_library_file','library_artifact_type':'other'}]}
ret=subprocess.run(['python3',str(r/'.librarywin/library_upload.py')],input=json.dumps(upload),text=True,stdout=(w/'upload-result.log').open('w'),stderr=subprocess.STDOUT);print('UPLOAD_EXIT',ret.returncode,flush=True)
if ret.returncode:raise RuntimeError('upload failed; inspect upload-result.log')
