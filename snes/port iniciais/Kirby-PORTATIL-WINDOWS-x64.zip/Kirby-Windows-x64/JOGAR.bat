@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_HEADLESS="
set "FORJA65_HEADLESS_FRAMES="
set "FORJA65_INPUT_REPLAY="
set "FORJA65_INPUT_POLL="
set "FORJA65_CHECKPOINT_LOAD="
set "FORJA65_CPU_INTERPRETER=0"
set "FORJA65_SA1_MODE=strict"
Kirby.exe
if errorlevel 1 (
 echo.
 echo O jogo parou. Veja forja65-last-error.txt nesta pasta.
 pause
)
endlocal
