@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js necessario. & pause & exit /b 1)
where g++ >nul 2>nul || (echo g++ MSYS2/MinGW64 necessario para os testes C++. & pause & exit /b 1)
for %%T in (tetris-hardware-v0397 tetris-obj-crossfeed-v0398 tetris-obj-limits-v0399 tetris-hdma-v0400 tetris-ppu-dma-v0401 tetris-ppu-raster-v0402 tetris-dma-vram-v0403 tetris-vram-access-v0404 tetris-apu-dsp-v0405) do (
 node "tests/%%T-regression.js" || goto :fail
)
echo NOVE REGRESSOES APROVADAS
pause
exit /b 0
:fail
echo Falha em uma regressao do Forja65.
pause
exit /b 1
