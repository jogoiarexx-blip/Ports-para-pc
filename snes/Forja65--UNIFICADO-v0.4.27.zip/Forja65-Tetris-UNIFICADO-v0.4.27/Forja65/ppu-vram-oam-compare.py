#!/usr/bin/env python3
"""Compare two SNES PPU memory captures without modifying either one.

Accepts Forja65 scene capture folders (vram.bin/oam.bin/cgram.bin).
An external reference may be used only when it contains these same raw byte dumps.
This is a diagnostic tool, not an emulator-accuracy certification.
"""
import argparse
import json
from collections import Counter
from pathlib import Path

SIZES = {'vram.bin': 65536, 'oam.bin': 544, 'cgram.bin': 512}

def spans(indices):
    if not indices: return []
    out=[]; start=end=indices[0]
    for index in indices[1:]:
        if index==end+1: end=index
        else: out.append([start,end]); start=end=index
    out.append([start,end]); return out

def describe_oam(data):
    sprites=[]
    for i in range(128):
        off=i*4; pair=(data[512+i//4] >> ((i%4)*2))&3
        x=data[off]+(256 if pair&1 else 0)
        if x>=256: x-=512
        sprites.append({'slot':i,'x':x,'y':data[off+1],
                        'tile':data[off+2] | ((data[off+3]&1)<<8),
                        'palette':(data[off+3]>>1)&7,
                        'priority':(data[off+3]>>4)&3,
                        'hflip':bool(data[off+3]&64),'vflip':bool(data[off+3]&128),
                        'large':bool(pair&2)})
    return sprites

def compare(base, current):
    result={'format':'forja65.ppu-memory-diff.v1','reference':str(base), 'candidate':str(current),
            'memory':{},'oam_changed_slots':[], 'limitations':[
                'Matching PPU memory is not proof that CPU/PPU timing or composite pixels match.',
                'Mismatched screenshots can also result from CPU state, line timing, DMA/HDMA or renderer priority.',
                'Reference and candidate must be captured at the same logical frame.']}
    for name, size in SIZES.items():
        p,q=base/name,current/name
        if not p.is_file() or not q.is_file():
            result['memory'][name]={'status':'missing', 'reference_exists':p.is_file(),'candidate_exists':q.is_file()}
            continue
        a,b=p.read_bytes(),q.read_bytes()
        if len(a)!=size or len(b)!=size:
            result['memory'][name]={'status':'invalid_size','expected':size,'reference_size':len(a),'candidate_size':len(b)}
            continue
        different=[i for i in range(size) if a[i]!=b[i]]
        result['memory'][name]={'status':'same' if not different else 'different',
                                'different_bytes':len(different), 'first_offset':different[0] if different else None,
                                'first_spans':spans(different)[:32]}
        if name=='vram.bin':
            result['memory'][name]['affected_32byte_tiles'] = len({i//32 for i in different})
            result['memory'][name]['changed_8kb_banks'] = sorted({i//8192 for i in different})
        if name=='cgram.bin':
            result['memory'][name]['affected_colors'] = sorted({i//2 for i in different})[:80]
        if name=='oam.bin':
            sa,sb=describe_oam(a),describe_oam(b)
            result['oam_changed_slots']=[{'reference':sa[i], 'candidate':sb[i]} for i in range(128) if sa[i]!=sb[i]][:128]
    checks=[v['status'] for v in result['memory'].values()]
    result['comparison_complete']=bool(checks) and all(s in ('same','different') for s in checks)
    if result['comparison_complete']:
        result['suggested_next_check']=(
            'Inspect CPU/WRAM and OAM/VRAM/CGRAM transfers first' if 'different' in checks
            else 'Check PPU registers, per-line HDMA and compositing, then compare final pixels')
    else: result['suggested_next_check']='Collect all three raw dumps at the same frame'
    return result

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('reference',type=Path);ap.add_argument('candidate',type=Path)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args();result=compare(args.reference,args.candidate)
    data=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(data,encoding='utf-8')
    print(data,end='')
    return 0 if result['comparison_complete'] else 2
if __name__=='__main__':raise SystemExit(main())
