# Histórico da execução interrompida

A sessão anterior registrou um replay de 14.809 frames, com os 14.420 frames da referência idênticos. A conclusão de Lakeside Limbo não foi comprovada. A pasta transitória dessa sessão ficou indisponível e não foi recuperada; os ZIPs persistidos ainda eram os arquivos de entrada.

Esse número histórico NÃO é uma validação desta entrega. As provas reproduzidas desta entrega estão em reports/recovery-checkpoint. As correções de retorno de pilha e NMI da sessão interrompida ainda não foram reconstruídas nesta entrega.

Os endereços mencionados anteriormente podem orientar a investigação, mas devem ser novamente observados no replay antes de importar pistas de execução: B9AB24, 00CA45, 80832B, 808337, 808332, B68140, BED2FE, BED303, BED41B, BBDD96, BBDDB6, BBDE22, BEC000, BBDE42, BCE58E, BEC8E0, BEC8FD, BB85CD, BECF8F, BEC8C8, BEC9AA, BECBF9, BED010, BED02E, B9BC5B, B69F47, B69F52, B6F262, B69F65, B69F62, B9F531, B6A065.

Não aplicar autorizações amplas de retorno. A análise anterior corrigiu o offset físico de BED2FE para 3ED2FE; 00D2FE seria incorreto. Qualquer futura autorização precisa de prova do opcode, estado observado, identidade da ROM e mapeamento real.
