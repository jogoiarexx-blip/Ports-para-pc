# Scooby-Doo Native PC v0.12 — checkpoint de 5.000 quadros

- ROM original: Scooby-Doo Mystery (USA), SHA256 `7fb5236d10852125f0f37c2188b907d636647400a57bccbdb2f63098ffae8b2d`.
- Conversor Forja65 com **19.518 enderecos 65816 decodificados** (mesmo CFG da ultima recompilacao v0.11). Nenhuma rotina ROM inventada.
- Novo replay de `New Game` / A / Direita **5.000/5.000 quadros, exit 0** em Linux, 75.162 ms, 66,52 fps simulados.
- 2.602 hashes graficos distintos, 4.924 hashes de WRAM distintos e **361 transicoes de hash visual entre os quadros 4.384 e 4.999**.
- Capturas reais em 4.400, 4.600, 4.800 e 4.990, com ROM FNV `278768332a4ffc4a`, mostram progressao de uma conversa a deslocamento de Shaggy/Scooby, com scroll para outra parte da area.
- Ferramenta `tools/frame-milestone-audit.js` detecta replay incompleto, hash de sessao misturado, frame fora de ordem, divergencia de ROM nas capturas e tela estagnada.
- `TESTAR-5000-QUADROS.cmd` oferece reproducao do teste no Windows **apos compilacao local**.
- Primeira fase, colisoes, objetivos e equivalencia pixel a pixel com SNES de referencia ainda NAO validados.
