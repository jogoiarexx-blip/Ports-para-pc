# Scooby-Doo Mystery Native PC v0.12 — marco de 5.000 quadros

Data: 2026-10-10. ROM do usuario SHA256 `7fb5236d10852125f0f37c2188b907d636647400a57bccbdb2f63098ffae8b2d`.

## Resultado reproduzido

- Replay deterministico `tests/scooby-v10-dialogue-right.input.trace` concluido **5.000/5.000 quadros** (`exit=0`, status `FRAMES_REACHED`), no executavel Linux C++ produzido pela ultima compilacao da v0.11.
- Duracao medida: **75.162 ms** no ambiente de diagnostico, ou **66,52 quadros simulados por segundo**; nao e benchmark de FPS visual no Windows.
- Hashes graficos distintos: **2,602**; estados WRAM distintos: **4,924**; **361 transicoes graficas detectadas nos frames 4.384–4.999**.
- Quatro capturas reais (4.400, 4.600, 4.800 e 4.990) com fingerprint de ROM `278768332a4ffc4a`. No fim da sequencia, a camera ja mostra outra regiao do corredor com caixas e uma porta. Capturas disponiveis em `QA-SCOOBY/v12-qa/frames-4400-4990.png`.
- `tools/frame-milestone-audit.js` passou na verificacao do marco, incluindo sequencia consecutiva de 5.000 hashes, identidade da ROM nas capturas e alteracoes visuais apos o limite anterior. Evidencia: `QA-SCOOBY/v12-qa/milestone-5000.json`.
- **CPU: 19,518 enderecos decodificados**, inalterados em relacao a ultima recompilacao v0.11. Esta rodada nao precisou inserir novos destinos CFG nem modificar a semantica da CPU/PPU.
- Regressao: **23/23 testes JavaScript direcionados** (22 anteriores + auditor novo, com 12 asserts) e **3/3 CTest nativos selecionados**. A suite integral e o `game.exe` Windows nao foram executados aqui.
- Auditoria historica de CFG antes do replay: **76/76** registros cobertos (nao significa todas as rotinas do cartucho).

## Como reproduzir no Windows

1. Extraia os dois ZIPs em pastas irmas, preservando os nomes internos.
2. Instale Node.js e CMake/Visual Studio Build Tools, conforme `BUILD-WINDOWS.cmd`.
3. Compile o port pelo `BUILD-WINDOWS.cmd`.
4. Rode `TESTAR-5000-QUADROS.cmd` para repetir o replay, registrar capturas e auditar a contagem; o script informa falha se nao chegar ao quadro 5.000.

## Limites honestos

O alvo **de 5.000 quadros foi alcancado**, mas **a primeira fase nao foi concluida**. O replay comprova execucao C++ e video mudando; nao substitui uma comparacao com um SNES de referencia nem demonstra colisoes, coletaveis, puzzles ou objetivo de fim de fase. A execucao ainda requer assets da ROM e subsistemas SNES parcialmente virtualizados. O ZIP nao contem `game.exe` de Windows precompilado.
