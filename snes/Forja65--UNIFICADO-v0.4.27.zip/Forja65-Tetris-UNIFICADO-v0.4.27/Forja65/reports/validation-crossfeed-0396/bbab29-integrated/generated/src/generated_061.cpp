#include "generated.hpp"
void sub_0080C4_E1M1X1CQ_part0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x0080C4u: goto L_0080C4;
    case 0x0080C5u: goto L_0080C5;
    case 0x0080C7u: goto L_0080C7;
    case 0x0080CAu: goto L_0080CA;
    case 0x0080CCu: goto L_0080CC;
    case 0x0080CFu: goto L_0080CF;
    case 0x0080D2u: goto L_0080D2;
    case 0x0080D3u: goto L_0080D3;
    case 0x0080D6u: goto L_0080D6;
    case 0x0080D7u: goto L_0080D7;
    case 0x0080D8u: goto L_0080D8;
    case 0x0080DAu: goto L_0080DA;
    case 0x0080DBu: goto L_0080DB;
    case 0x0080DEu: goto L_0080DE;
    case 0x0080E0u: goto L_0080E0;
    case 0x0080E3u: goto L_0080E3;
    case 0x0080E4u: goto L_0080E4;
    case 0x0080E7u: goto L_0080E7;
    case 0x0080EAu: goto L_0080EA;
    case 0x0080ECu: goto L_0080EC;
    case 0x0080EFu: goto L_0080EF;
    case 0x0080F1u: goto L_0080F1;
    case 0x0080F4u: goto L_0080F4;
    case 0x0080F6u: goto L_0080F6;
    case 0x0080F8u: goto L_0080F8;
    case 0x0080FAu: goto L_0080FA;
    case 0x0080FCu: goto L_0080FC;
    case 0x0080FEu: goto L_0080FE;
    case 0x008100u: goto L_008100;
    case 0x008101u: goto L_008101;
    case 0x008103u: goto L_008103;
    case 0x008105u: goto L_008105;
    case 0x008109u: goto L_008109;
    case 0x00810Au: goto L_00810A;
    case 0x00810Eu: goto L_00810E;
    case 0x008112u: goto L_008112;
    case 0x008114u: goto L_008114;
    case 0x008115u: goto L_008115;
    case 0x008119u: goto L_008119;
    case 0x00811Cu: goto L_00811C;
    case 0x00811Fu: goto L_00811F;
    case 0x008122u: goto L_008122;
    case 0x008124u: goto L_008124;
    case 0x008126u: goto L_008126;
    case 0x008128u: goto L_008128;
    case 0x00812Bu: goto L_00812B;
    case 0x00812Eu: goto L_00812E;
    case 0x008130u: goto L_008130;
    case 0x008132u: goto L_008132;
    case 0x008134u: goto L_008134;
    case 0x008136u: goto L_008136;
    case 0x008139u: goto L_008139;
    case 0x00813Bu: goto L_00813B;
    case 0x00813Eu: goto L_00813E;
    case 0x008140u: goto L_008140;
    case 0x008143u: goto L_008143;
    case 0x008146u: goto L_008146;
    case 0x008148u: goto L_008148;
    case 0x00814Au: goto L_00814A;
    case 0x00814Cu: goto L_00814C;
    case 0x00814Du: goto L_00814D;
    case 0x008150u: goto L_008150;
    case 0x008152u: goto L_008152;
    case 0x008153u: goto L_008153;
    case 0x008154u: goto L_008154;
    case 0x008156u: goto L_008156;
    case 0x008158u: goto L_008158;
    case 0x008159u: goto L_008159;
    case 0x00815Au: goto L_00815A;
    case 0x00815Du: goto L_00815D;
    case 0x008160u: goto L_008160;
    case 0x008163u: goto L_008163;
    case 0x008165u: goto L_008165;
    case 0x008166u: goto L_008166;
    case 0x008167u: goto L_008167;
    case 0x008169u: goto L_008169;
    case 0x00816Bu: goto L_00816B;
    case 0x00816Eu: goto L_00816E;
    case 0x008171u: goto L_008171;
    case 0x008174u: goto L_008174;
    case 0x008177u: goto L_008177;
    case 0x00817Bu: goto L_00817B;
    case 0x00817Du: goto L_00817D;
    case 0x00817Eu: goto L_00817E;
    case 0x008182u: goto L_008182;
    case 0x008183u: goto L_008183;
    case 0x008184u: goto L_008184;
    case 0x008186u: goto L_008186;
    case 0x008187u: goto L_008187;
    case 0x008189u: goto L_008189;
    case 0x00818Cu: goto L_00818C;
    case 0x00818Eu: goto L_00818E;
    case 0x008191u: goto L_008191;
    case 0x008194u: goto L_008194;
    case 0x008195u: goto L_008195;
    case 0x008198u: goto L_008198;
    case 0x008199u: goto L_008199;
    case 0x00819Cu: goto L_00819C;
    case 0x00819Fu: goto L_00819F;
    case 0x0081A1u: goto L_0081A1;
    case 0x0081A2u: goto L_0081A2;
    case 0x0081A3u: goto L_0081A3;
    case 0x0081A6u: goto L_0081A6;
    case 0x0081A9u: goto L_0081A9;
    case 0x0081ACu: goto L_0081AC;
    case 0x0081AEu: goto L_0081AE;
    case 0x0081AFu: goto L_0081AF;
    case 0x0081B0u: goto L_0081B0;
    case 0x0081B2u: goto L_0081B2;
    case 0x0081B4u: goto L_0081B4;
    case 0x0081B7u: goto L_0081B7;
    case 0x0081BBu: goto L_0081BB;
    case 0x0081BEu: goto L_0081BE;
    case 0x0081BFu: goto L_0081BF;
    case 0x0081C2u: goto L_0081C2;
    case 0x0081C5u: goto L_0081C5;
    case 0x0081C7u: goto L_0081C7;
    case 0x0081C9u: goto L_0081C9;
    case 0x0081CCu: goto L_0081CC;
    case 0x0081CFu: goto L_0081CF;
    case 0x0081D0u: goto L_0081D0;
    case 0x0081D2u: goto L_0081D2;
    case 0x0081D4u: goto L_0081D4;
    case 0x0081D6u: goto L_0081D6;
    case 0x0081D9u: goto L_0081D9;
    case 0x0081DAu: goto L_0081DA;
    case 0x0081DCu: goto L_0081DC;
    case 0x0081DEu: goto L_0081DE;
    case 0x0081E0u: goto L_0081E0;
    case 0x0081E3u: goto L_0081E3;
    case 0x0081E5u: goto L_0081E5;
    case 0x0081E8u: goto L_0081E8;
    case 0x0081EBu: goto L_0081EB;
    case 0x0081EDu: goto L_0081ED;
    case 0x0081F0u: goto L_0081F0;
    case 0x0081F3u: goto L_0081F3;
    case 0x0081F6u: goto L_0081F6;
    case 0x0081F9u: goto L_0081F9;
    case 0x0081FBu: goto L_0081FB;
    case 0x0081FEu: goto L_0081FE;
    case 0x008200u: goto L_008200;
    case 0x008203u: goto L_008203;
    case 0x008205u: goto L_008205;
    case 0x008208u: goto L_008208;
    case 0x00820Au: goto L_00820A;
    case 0x00820Du: goto L_00820D;
    case 0x008210u: goto L_008210;
    case 0x008213u: goto L_008213;
    case 0x008216u: goto L_008216;
    case 0x008219u: goto L_008219;
    case 0x00821Cu: goto L_00821C;
    case 0x00821Fu: goto L_00821F;
    case 0x008221u: goto L_008221;
    case 0x008224u: goto L_008224;
    case 0x008227u: goto L_008227;
    case 0x00822Au: goto L_00822A;
    case 0x00822Du: goto L_00822D;
    case 0x008230u: goto L_008230;
    case 0x008233u: goto L_008233;
    case 0x008235u: goto L_008235;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_0080C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C4u,cpu,0x78u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C4 SEI
    cpu.setFlag('I', true);
    goto L_0080C5;
L_0080C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C5u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C5 LDA
    cpu.setA(0x80u, 8);
    goto L_0080C7;
L_0080C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C7u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C7 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0080CA;
L_0080CA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080CA LDA
    cpu.setA(0x1u, 8);
    goto L_0080CC;
L_0080CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CCu, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080CC STA
    hw.write(cpu.address("abs", 0x4200u), cpu.a, cpu.m8?8:16);
    goto L_0080CF;
L_0080CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80CFu, 4u, 3u, cpu.address("abs", 0x420Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080CF STA
    hw.write(cpu.address("abs", 0x420Du), cpu.a, cpu.m8?8:16);
    goto L_0080D2;
L_0080D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D2u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D2 DEC
    cpu.decReg('A');
    goto L_0080D3;
L_0080D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D3u, 4u, 3u, cpu.address("abs", 0x420Cu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D3 STA
    hw.write(cpu.address("abs", 0x420Cu), cpu.a, cpu.m8?8:16);
    goto L_0080D6;
L_0080D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D6 CLC
    cpu.setFlag('C', false);
    goto L_0080D7;
L_0080D7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u,cpu,0xFBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D7u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D7 XCE
    cpu.xce();
    goto L_0080D8;
L_0080D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80D8u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080D8 REP
    cpu.rep(0x30u);
    goto L_0080DA;
L_0080DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DAu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080DA TDC
    cpu.tdc();
    goto L_0080DB;
L_0080DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DBu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080DB ADC
    cpu.adc(0xFFFFu);
    goto L_0080DE;
L_0080DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080DE BEQ -> $0080E3
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_0080E3; }
    goto L_0080E0;
L_0080E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u,cpu,0x82u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E0u, 4u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E0 BRL -> $00818E
    goto L_00818E;
L_0080E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u,cpu,0xBAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E3u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E3 TSX
    cpu.transfer("TSX");
    goto L_0080E4;
L_0080E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E4 LDA
    cpu.setA(0x80C3u, 16);
    goto L_0080E7;
L_0080E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80E7u, 5u + 1u, 3u, cpu.address("absx", 0xFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080E7 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0xFFFFu), cpu.m8?8:16));
    goto L_0080EA;
L_0080EA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080EA BEQ -> $008158
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008158; }
    goto L_0080EC;
L_0080EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080EC LDY
    cpu.setY(0x1FFDu, 16);
    goto L_0080EF;
L_0080EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80EFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080EF SEP
    cpu.sep(0x20u);
    goto L_0080F1;
L_0080F1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F1u, 4u + 1u, 3u, cpu.address("absy", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080F1 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0080F4;
L_0080F4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080F4 CMP
    cpu.compareA(0x4Cu);
    goto L_0080F6;
L_0080F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080F6 BEQ -> $008126
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008126; }
    goto L_0080F8;
L_0080F8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80F8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80F8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080F8 CMP
    cpu.compareA(0x6Cu);
    goto L_0080FA;
L_0080FA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FA BEQ -> $008134
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008134; }
    goto L_0080FC;
L_0080FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FC CMP
    cpu.compareA(0x60u);
    goto L_0080FE;
L_0080FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080FE BEQ -> $00814C
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00814C; }
    goto L_008100;
L_008100:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8100u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8100u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008100 DEY
    cpu.decReg('Y');
    goto L_008101;
L_008101:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8101u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8101u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008101 BPL -> $0080F1
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0080F1; }
    goto L_008103;
L_008103:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8103u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8103u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008103 REP
    cpu.rep(0x20u);
    goto L_008105;
L_008105:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8105u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u,cpu,0xAFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8105u, 6u, 4u, 0xB06000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008105 LDA
    cpu.loadA(hw.readW(0xB06000u, cpu.m8?8:16), cpu.m8?8:16);
    goto L_008109;
L_008109:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8109u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8109u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008109 INC
    cpu.inc('A');
    goto L_00810A;
L_00810A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Au, 6u, 4u, 0xB06000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00810A STA
    hw.write(0xB06000u, cpu.a, cpu.m8?8:16);
    goto L_00810E;
L_00810E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x810Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu,cpu,0xCFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x810Eu, 6u, 4u, 0xB06000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00810E CMP
    cpu.compareA(hw.readW(0xB06000u, cpu.m8?8:16));
    goto L_008112;
L_008112:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8112u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8112u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008112 BNE -> $00818E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00818E; }
    goto L_008114;
L_008114:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8114u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u,cpu,0x3Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8114u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008114 DEC
    cpu.decReg('A');
    goto L_008115;
L_008115:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8115u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8115u, 6u, 4u, 0xB06000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008115 STA
    hw.write(0xB06000u, cpu.a, cpu.m8?8:16);
    goto L_008119;
L_008119:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8119u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8119u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008119 LDY
    cpu.setY(0x11u, 16);
    goto L_00811C;
L_00811C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Cu, 5u, 3u, cpu.address("abs", 0x213Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811C LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x213Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00811F;
L_00811F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x811Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x811Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00811F AND
    cpu.logicAnd(0x10u);
    goto L_008122;
L_008122:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8122u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8122u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008122 BNE -> $008191
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008191; }
    goto L_008124;
L_008124:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8124u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8124u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008124 BRA -> $0081A1
    goto L_0081A1;
L_008126:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8126u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8126u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008126 REP
    cpu.rep(0x20u);
    goto L_008128;
L_008128:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8128u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u,cpu,0xB9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8128u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008128 LDA
    cpu.loadA(hw.readW(cpu.address("absy", 0x1u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_00812B;
L_00812B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Bu,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812B CMP
    cpu.compareA(0x80C4u);
    goto L_00812E;
L_00812E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x812Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x812Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00812E BEQ -> $008158
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008158; }
    goto L_008130;
L_008130:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8130u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8130u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008130 SEP
    cpu.sep(0x20u);
    goto L_008132;
L_008132:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8132u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8132u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008132 BRA -> $008100
    goto L_008100;
L_008134:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8134u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8134u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008134 REP
    cpu.rep(0x20u);
    goto L_008136;
L_008136:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8136u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8136u, 5u + 1u, 3u, cpu.address("absy", 0x0001u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008136 LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_008139;
L_008139:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8139u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8139u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008139 BMI -> $008140
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_008140; }
    goto L_00813B;
L_00813B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00813B CPX
    cpu.compareX(0x2000u);
    goto L_00813E;
L_00813E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x813Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x813Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00813E BPL -> $008148
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008148; }
    goto L_008140;
L_008140:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8140u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8140u, 5u + 1u, 3u, cpu.address("absx", 0x0000u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008140 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008143;
L_008143:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8143u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8143u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008143 CMP
    cpu.compareA(0x80C4u);
    goto L_008146;
L_008146:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8146u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8146u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008146 BEQ -> $008158
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_008158; }
    goto L_008148;
L_008148:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8148u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8148u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008148 SEP
    cpu.sep(0x20u);
    goto L_00814A;
L_00814A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814A BRA -> $008100
    goto L_008100;
L_00814C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Cu,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814C TYX
    cpu.transfer("TYX");
    goto L_00814D;
L_00814D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x814Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x814Du, 4u + 1u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00814D CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x0u), cpu.m8?8:16));
    goto L_008150;
L_008150:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8150u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8150u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8150u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008150 BNE -> $008100
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_008100; }
    goto L_008152;
L_008152:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8152u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8152u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008152 INX
    cpu.inc('X');
    goto L_008153;
L_008153:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8153u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8153u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008153 INC
    cpu.inc('A');
    goto L_008154;
L_008154:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8154u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8154u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008154 BPL -> $00814D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00814D; }
    goto L_008156;
L_008156:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8156u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8156u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008156 REP
    cpu.rep(0x20u);
    goto L_008158;
L_008158:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8158u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8158u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8158u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008158 PHK
    cpu.push("PHK", hw);
    goto L_008159;
L_008159:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8159u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8159u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $008159 PLB
    cpu.pop("PLB", hw);
    goto L_00815A;
L_00815A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00815A LDX
    cpu.setX(0x6u, 16);
    goto L_00815D;
L_00815D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x815Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x815Du, 5u + 1u, 3u, cpu.address("absx", 0x06A3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00815D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6A3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008160;
L_008160:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8160u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8160u, 5u + 1u, 3u, cpu.address("absx", 0x808Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008160 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x808Du), cpu.m8?8:16));
    goto L_008163;
L_008163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8163u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008163 BNE -> $00816B
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00816B; }
    goto L_008165;
L_008165:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8165u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8165u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008165 DEX
    cpu.decReg('X');
    goto L_008166;
L_008166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8166u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8166u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008166 DEX
    cpu.decReg('X');
    goto L_008167;
L_008167:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8167u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8167u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008167 BPL -> $00815D
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00815D; }
    goto L_008169;
L_008169:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8169u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8169u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8169u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008169 BRA -> $0081B4
    goto L_0081B4;
L_00816B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816B LDX
    cpu.setX(0x6u, 16);
    goto L_00816E;
L_00816E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x816Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x816Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00816E LDY
    cpu.setY(0x4u, 16);
    goto L_008171;
L_008171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8171u, 5u + 1u, 3u, cpu.address("absx", 0x8095u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008171 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x8095u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_008174;
L_008174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8174u, 6u, 3u, cpu.address("absx", 0x06A3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008174 STA
    hw.write(cpu.address("absx", 0x6A3u), cpu.a, cpu.m8?8:16);
    goto L_008177;
L_008177:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8177u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u,cpu,0xDFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8177u, 6u, 4u, ((0xB06000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008177 CMP
    cpu.compareA(hw.readW(((0xB06000u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16));
    goto L_00817B;
L_00817B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817B BNE -> $00817E
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_00817E; }
    goto L_00817D;
L_00817D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817D DEY
    cpu.decReg('Y');
    goto L_00817E;
L_00817E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x817Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x817Eu, 6u, 4u, ((0xB06000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00817E STA
    hw.write(((0xB06000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_008182;
L_008182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8182u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008182 DEX
    cpu.decReg('X');
    goto L_008183;
L_008183:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8183u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8183u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008183 DEX
    cpu.decReg('X');
    goto L_008184;
L_008184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8184u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008184 BPL -> $008171
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_008171; }
    goto L_008186;
L_008186:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8186u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8186u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008186 TYA
    cpu.transfer("TYA");
    goto L_008187;
L_008187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8187u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008187 BEQ -> $00818E
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_00818E; }
    goto L_008189;
L_008189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8189u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008189 LDY
    cpu.setY(0xFu, 16);
    goto L_00818C;
L_00818C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Cu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818C BRA -> $008191
    goto L_008191;
L_00818E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x818Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x818Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00818E LDY
    cpu.setY(0x10u, 16);
    goto L_008191;
L_008191:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8191u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8191u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008191 LDA
    cpu.setA(0x0u, 16);
    goto L_008194;
L_008194:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8194u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u,cpu,0x5Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8194u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008194 TCD
    cpu.tcd();
    goto L_008195;
L_008195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8195u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008195 LDX
    cpu.setX(0x1FFu, 16);
    goto L_008198;
L_008198:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8198u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8198u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008198 TXS
    cpu.transfer("TXS");
    goto L_008199;
L_008199:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8199u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8199u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8199u, 5u, 3u, cpu.address("abs", 0x809Cu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008199 PEA
    cpu.push16Value(hw, 0x809Cu);
    goto L_00819C;
L_00819C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Cu, 5u, 3u, cpu.address("abs", 0x825Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $00819C PEA
    cpu.push16Value(hw, 0x825Du);
    goto L_00819F;
L_00819F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x819Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x819Fu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x819Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00819F BRA -> $0081C5
    goto L_0081C5;
L_0081A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u,cpu,0x4Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A1u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0081A1 PHK
    cpu.push("PHK", hw);
    goto L_0081A2;
L_0081A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A2u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A2u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $0081A2 PLB
    cpu.pop("PLB", hw);
    goto L_0081A3;
L_0081A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A3u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A3 LDX
    cpu.setX(0x6u, 16);
    goto L_0081A6;
L_0081A6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A6u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A6u, 5u + 1u, 3u, cpu.address("absx", 0x06A3u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A6 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x6A3u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_0081A9;
L_0081A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81A9u,cpu,0xDDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81A9u, 5u + 1u, 3u, cpu.address("absx", 0x8095u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081A9 CMP
    cpu.compareA(hw.readW(cpu.address("absx", 0x8095u), cpu.m8?8:16));
    goto L_0081AC;
L_0081AC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81ACu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81ACu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AC BNE -> $0081B4
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0081B4; }
    goto L_0081AE;
L_0081AE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AEu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AE DEX
    cpu.decReg('X');
    goto L_0081AF;
L_0081AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81AFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081AF DEX
    cpu.decReg('X');
    goto L_0081B0;
L_0081B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B0 BPL -> $0081A6
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_0081A6; }
    goto L_0081B2;
L_0081B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B2u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B2 BRA -> $00818E
    goto L_00818E;
L_0081B4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B4u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B4 LDA
    cpu.setA(0x0u, 16);
    goto L_0081B7;
L_0081B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81B7u, 6u, 4u, 0xB06000u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081B7 STA
    hw.write(0xB06000u, cpu.a, cpu.m8?8:16);
    goto L_0081BB;
L_0081BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BBu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BB LDX
    cpu.setX(0x1FFu, 16);
    goto L_0081BE;
L_0081BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu,cpu,0x9Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BEu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081BE TXS
    cpu.transfer("TXS");
    goto L_0081BF;
L_0081BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81BFu,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81BFu, 5u, 3u, cpu.address("abs", 0x8285u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081BF PEA
    cpu.push16Value(hw, 0x8285u);
    goto L_0081C2;
L_0081C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C2u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C2u, 5u, 3u, cpu.address("abs", 0x825Du), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $0081C2 PEA
    cpu.push16Value(hw, 0x825Du);
    goto L_0081C5;
L_0081C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C5 SEP
    cpu.sep(0x30u);
    goto L_0081C7;
L_0081C7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C7 LDX
    cpu.setX(0x0u, 8);
    goto L_0081C9;
L_0081C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81C9u, 5u, 3u, cpu.address("absx", 0x2101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081C9 STZ
    hw.write(cpu.address("absx", 0x2101u), 0, cpu.m8?8:16);
    goto L_0081CC;
L_0081CC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CCu, 5u, 3u, cpu.address("absx", 0x2101u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CC STZ
    hw.write(cpu.address("absx", 0x2101u), 0, cpu.m8?8:16);
    goto L_0081CF;
L_0081CF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81CFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81CFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081CF INX
    cpu.inc('X');
    goto L_0081D0;
L_0081D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D0 CPX
    cpu.compareX(0x34u);
    goto L_0081D2;
L_0081D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D2 BNE -> $0081C9
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0081C9; }
    goto L_0081D4;
L_0081D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D4u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D4 LDX
    cpu.setX(0x0u, 8);
    goto L_0081D6;
L_0081D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D6u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D6u, 5u, 3u, cpu.address("absx", 0x4202u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D6 STZ
    hw.write(cpu.address("absx", 0x4202u), 0, cpu.m8?8:16);
    goto L_0081D9;
L_0081D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81D9u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081D9 INX
    cpu.inc('X');
    goto L_0081DA;
L_0081DA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu,cpu,0xE0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DA CPX
    cpu.compareX(0xBu);
    goto L_0081DC;
L_0081DC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DC BNE -> $0081D6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_0081D6; }
    goto L_0081DE;
L_0081DE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81DEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81DEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081DE LDA
    cpu.setA(0x8Fu, 8);
    goto L_0081E0;
L_0081E0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E0u, 4u, 3u, cpu.address("abs", 0x2100u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E0 STA
    hw.write(cpu.address("abs", 0x2100u), cpu.a, cpu.m8?8:16);
    goto L_0081E3;
L_0081E3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E3u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E3 LDA
    cpu.setA(0x80u, 8);
    goto L_0081E5;
L_0081E5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E5u, 4u, 3u, cpu.address("abs", 0x2115u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E5 STA
    hw.write(cpu.address("abs", 0x2115u), cpu.a, cpu.m8?8:16);
    goto L_0081E8;
L_0081E8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81E8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81E8u, 4u, 3u, cpu.address("abs", 0x211Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081E8 STA
    hw.write(cpu.address("abs", 0x211Au), cpu.a, cpu.m8?8:16);
    goto L_0081EB;
L_0081EB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081EB LDA
    cpu.setA(0x1u, 8);
    goto L_0081ED;
L_0081ED:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81EDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81EDu, 4u, 3u, cpu.address("abs", 0x420Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081ED STA
    hw.write(cpu.address("abs", 0x420Du), cpu.a, cpu.m8?8:16);
    goto L_0081F0;
L_0081F0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F0u, 4u, 3u, cpu.address("abs", 0x2131u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F0 STZ
    hw.write(cpu.address("abs", 0x2131u), 0, cpu.m8?8:16);
    goto L_0081F3;
L_0081F3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F3u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F3u, 4u, 3u, cpu.address("abs", 0x2133u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F3 STZ
    hw.write(cpu.address("abs", 0x2133u), 0, cpu.m8?8:16);
    goto L_0081F6;
L_0081F6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F6u, 4u, 3u, cpu.address("abs", 0x4200u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F6 STZ
    hw.write(cpu.address("abs", 0x4200u), 0, cpu.m8?8:16);
    goto L_0081F9;
L_0081F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81F9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081F9 LDA
    cpu.setA(0xFFu, 8);
    goto L_0081FB;
L_0081FB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FBu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FBu, 4u, 3u, cpu.address("abs", 0x4201u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FB STA
    hw.write(cpu.address("abs", 0x4201u), cpu.a, cpu.m8?8:16);
    goto L_0081FE;
L_0081FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x81FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x81FEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0081FE LDA
    cpu.setA(0xE0u, 8);
    goto L_008200;
L_008200:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8200u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8200u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8200u, 4u, 3u, cpu.address("abs", 0x2132u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008200 STA
    hw.write(cpu.address("abs", 0x2132u), cpu.a, cpu.m8?8:16);
    goto L_008203;
L_008203:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8203u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8203u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008203 LDA
    cpu.setA(0x30u, 8);
    goto L_008205;
L_008205:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8205u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8205u, 4u, 3u, cpu.address("abs", 0x2130u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008205 STA
    hw.write(cpu.address("abs", 0x2130u), cpu.a, cpu.m8?8:16);
    goto L_008208;
L_008208:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8208u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8208u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008208 LDA
    cpu.setA(0x0u, 8);
    goto L_00820A;
L_00820A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Au, 4u, 3u, cpu.address("abs", 0x2106u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00820A STA
    hw.write(cpu.address("abs", 0x2106u), cpu.a, cpu.m8?8:16);
    goto L_00820D;
L_00820D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x820Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x820Du, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00820D STZ
    hw.write(cpu.address("abs", 0x210Du), 0, cpu.m8?8:16);
    goto L_008210;
L_008210:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8210u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8210u, 4u, 3u, cpu.address("abs", 0x210Du), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008210 STZ
    hw.write(cpu.address("abs", 0x210Du), 0, cpu.m8?8:16);
    goto L_008213;
L_008213:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8213u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8213u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008213 STZ
    hw.write(cpu.address("abs", 0x210Fu), 0, cpu.m8?8:16);
    goto L_008216;
L_008216:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8216u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8216u, 4u, 3u, cpu.address("abs", 0x210Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008216 STZ
    hw.write(cpu.address("abs", 0x210Fu), 0, cpu.m8?8:16);
    goto L_008219;
L_008219:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8219u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8219u,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8219u, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008219 STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_00821C;
L_00821C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Cu,cpu,0x9Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Cu, 4u, 3u, cpu.address("abs", 0x2111u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00821C STZ
    hw.write(cpu.address("abs", 0x2111u), 0, cpu.m8?8:16);
    goto L_00821F;
L_00821F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x821Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x821Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00821F LDA
    cpu.setA(0xFFu, 8);
    goto L_008221;
L_008221:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8221u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8221u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008221 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008224;
L_008224:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8224u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8224u, 4u, 3u, cpu.address("abs", 0x210Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008224 STA
    hw.write(cpu.address("abs", 0x210Eu), cpu.a, cpu.m8?8:16);
    goto L_008227;
L_008227:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8227u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8227u, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008227 STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_00822A;
L_00822A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Au, 4u, 3u, cpu.address("abs", 0x2110u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822A STA
    hw.write(cpu.address("abs", 0x2110u), cpu.a, cpu.m8?8:16);
    goto L_00822D;
L_00822D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x822Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x822Du, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00822D STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_008230;
L_008230:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8230u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8230u, 4u, 3u, cpu.address("abs", 0x2112u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008230 STA
    hw.write(cpu.address("abs", 0x2112u), cpu.a, cpu.m8?8:16);
    goto L_008233;
L_008233:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8233u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8233u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8233u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008233 REP
    cpu.rep(0x30u);
    goto L_008235;
L_008235:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8235u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8235u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008235 SEP
    cpu.sep(0x20u);
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8237u,0x008235u); return;
}

