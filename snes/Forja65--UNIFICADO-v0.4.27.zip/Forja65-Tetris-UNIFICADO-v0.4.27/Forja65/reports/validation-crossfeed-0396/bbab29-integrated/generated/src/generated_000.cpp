#include "generated.hpp"
void sub_BB8001_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xBB8001u: goto L_BB8001;
    case 0xBB8692u: goto L_BB8692;
    case 0xBB8694u: goto L_BB8694;
    case 0xBB8695u: goto L_BB8695;
    case 0xBB8697u: goto L_BB8697;
    case 0xBB8699u: goto L_BB8699;
    case 0xBB869Au: goto L_BB869A;
    case 0xBB869Bu: goto L_BB869B;
    case 0xBB869Du: goto L_BB869D;
    case 0xBB869Fu: goto L_BB869F;
    case 0xBB86BAu: goto L_BB86BA;
    case 0xBB86BCu: goto L_BB86BC;
    case 0xBB86BEu: goto L_BB86BE;
    case 0xBB86C0u: goto L_BB86C0;
    case 0xBB86C2u: goto L_BB86C2;
    case 0xBB86C4u: goto L_BB86C4;
    case 0xBB86C5u: goto L_BB86C5;
    case 0xBB86C8u: goto L_BB86C8;
    case 0xBB86C9u: goto L_BB86C9;
    case 0xBB86CBu: goto L_BB86CB;
    case 0xBB86CDu: goto L_BB86CD;
    case 0xBB86D0u: goto L_BB86D0;
    case 0xBB86D2u: goto L_BB86D2;
    case 0xBB86D3u: goto L_BB86D3;
    case 0xBB86D4u: goto L_BB86D4;
    case 0xBB86D5u: goto L_BB86D5;
    case 0xBB86D6u: goto L_BB86D6;
    case 0xBB86D8u: goto L_BB86D8;
    case 0xBB86D9u: goto L_BB86D9;
    case 0xBB86DBu: goto L_BB86DB;
    case 0xBB86DDu: goto L_BB86DD;
    case 0xBB86DFu: goto L_BB86DF;
    case 0xBB86E2u: goto L_BB86E2;
    case 0xBB86E4u: goto L_BB86E4;
    case 0xBB86E7u: goto L_BB86E7;
    case 0xBB86E9u: goto L_BB86E9;
    case 0xBB86ECu: goto L_BB86EC;
    case 0xBB86EFu: goto L_BB86EF;
    case 0xBB86F2u: goto L_BB86F2;
    case 0xBB86F5u: goto L_BB86F5;
    case 0xBB86F7u: goto L_BB86F7;
    case 0xBB86F9u: goto L_BB86F9;
    case 0xBB86FCu: goto L_BB86FC;
    case 0xBB86FEu: goto L_BB86FE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_BB8001:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8001u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8001u, 3u, 3u, cpu.address("abs", 0x86BAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8001 JMP -> $BB86BA
    goto L_BB86BA;
L_BB8692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB8692 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8694;
L_BB8694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8694 INY
    cpu.inc('Y');
    goto L_BB8695;
L_BB8695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8695 STA
    hw.write(cpu.address("dp", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_BB8697;
L_BB8697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8697 AND
    cpu.logicAnd(0xF0u);
    goto L_BB8699;
L_BB8699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8699 LSR
    cpu.lsrA();
    goto L_BB869A;
L_BB869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB869A LSR
    cpu.lsrA();
    goto L_BB869B;
L_BB869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB869B STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_BB869D;
L_BB869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB869D PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0x36u),16));
    goto L_BB869F;
L_BB869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB869F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xBB869Fu);return;} hw.unresolvedReturn(0xBB869Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_BB86BA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86BA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86BC;
L_BB86BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86BC AND
    cpu.logicAnd(0xFu);
    goto L_BB86BE;
L_BB86BE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86BEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86BEu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86BE BEQ -> $BB86D0
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_BB86D0; }
    goto L_BB86C0;
L_BB86C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C0u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C0u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86C0 STA
    hw.write(cpu.address("dp", 0x24u), cpu.a, cpu.m8?8:16);
    goto L_BB86C2;
L_BB86C2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C2u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB86C2 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86C4;
L_BB86C4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86C4 INY
    cpu.inc('Y');
    goto L_BB86C5;
L_BB86C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C5u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86C5 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_BB86C8;
L_BB86C8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86C8 INX
    cpu.inc('X');
    goto L_BB86C9;
L_BB86C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86C9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u,cpu,0xC6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86C9u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86C9 DEC
    cpu.decMem(hw, cpu.address("dp", 0x24u), cpu.m8?8:16);
    goto L_BB86CB;
L_BB86CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86CB BNE -> $BB86C2
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_BB86C2; }
    goto L_BB86CD;
L_BB86CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86CDu,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86CDu, 3u, 3u, cpu.address("abs", 0x8692u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86CD JMP -> $BB8692
    goto L_BB8692;
L_BB86D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D0 REP
    cpu.rep(0x20u);
    goto L_BB86D2;
L_BB86D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D2u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB86D2 PLY
    cpu.pop("PLY", hw);
    goto L_BB86D3;
L_BB86D3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D3u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB86D3 PLB
    cpu.pop("PLB", hw);
    goto L_BB86D4;
L_BB86D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D4u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D4 TXA
    cpu.transfer("TXA");
    goto L_BB86D5;
L_BB86D5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D5u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D5 SEC
    cpu.setFlag('C', true);
    goto L_BB86D6;
L_BB86D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u,cpu,0xE5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D6u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D6 SBC
    cpu.sbc(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16));
    goto L_BB86D8;
L_BB86D8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D8u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D8 TAX
    cpu.transfer("TAX");
    goto L_BB86D9;
L_BB86D9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86D9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86D9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86D9 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x1Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86DB;
L_BB86DB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86DB BMI -> $BB86FE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_BB86FE; }
    goto L_BB86DD;
L_BB86DD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x40u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86DD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x40u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86DF;
L_BB86DF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86DFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86DFu, 5u, 3u, cpu.address("abs", 0x2116u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86DF STA
    hw.write(cpu.address("abs", 0x2116u), cpu.a, cpu.m8?8:16);
    goto L_BB86E2;
L_BB86E2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E2u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86E2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x20u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86E4;
L_BB86E4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E4u, 5u, 3u, cpu.address("abs", 0x4302u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86E4 STA
    hw.write(cpu.address("abs", 0x4302u), cpu.a, cpu.m8?8:16);
    goto L_BB86E7;
L_BB86E7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E7u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86E7 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86E9;
L_BB86E9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86E9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86E9u, 5u, 3u, cpu.address("abs", 0x4304u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86E9 STA
    hw.write(cpu.address("abs", 0x4304u), cpu.a, cpu.m8?8:16);
    goto L_BB86EC;
L_BB86EC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu,cpu,0x8Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ECu, 5u, 3u, cpu.address("abs", 0x4305u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86EC STX
    hw.write(cpu.address("abs", 0x4305u), cpu.x, cpu.x8?8:16);
    goto L_BB86EF;
L_BB86EF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86EFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86EFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86EF LDA
    cpu.setA(0x1801u, 16);
    goto L_BB86F2;
L_BB86F2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F2u, 5u, 3u, cpu.address("abs", 0x4300u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86F2 STA
    hw.write(cpu.address("abs", 0x4300u), cpu.a, cpu.m8?8:16);
    goto L_BB86F5;
L_BB86F5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F5u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86F5 SEP
    cpu.sep(0x20u);
    goto L_BB86F7;
L_BB86F7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86F7 LDA
    cpu.setA(0x1u, 8);
    goto L_BB86F9;
L_BB86F9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86F9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86F9u, 4u, 3u, cpu.address("abs", 0x420Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86F9 STA
    hw.write(cpu.address("abs", 0x420Bu), cpu.a, cpu.m8?8:16);
    goto L_BB86FC;
L_BB86FC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FCu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86FC REP
    cpu.rep(0x20u);
    goto L_BB86FE;
L_BB86FE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86FEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86FEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $BB86FE RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0xBB86FEu);return;} hw.unresolvedReturn(0xBB86FEu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

