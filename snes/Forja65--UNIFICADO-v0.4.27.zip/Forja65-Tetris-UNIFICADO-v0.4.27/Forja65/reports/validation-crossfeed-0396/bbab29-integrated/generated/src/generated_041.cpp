#include "generated.hpp"
void sub_BB8A3F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xBB8A3Fu: goto L_BB8A3F;
    case 0xBB8A40u: goto L_BB8A40;
    case 0xBB8A41u: goto L_BB8A41;
    case 0xBB8A42u: goto L_BB8A42;
    case 0xBB8A45u: goto L_BB8A45;
    case 0xBB8A46u: goto L_BB8A46;
    case 0xBB8A47u: goto L_BB8A47;
    case 0xBB8A49u: goto L_BB8A49;
    case 0xBB8A4Du: goto L_BB8A4D;
    case 0xBB8A4Eu: goto L_BB8A4E;
    case 0xBB8A50u: goto L_BB8A50;
    case 0xBB8A52u: goto L_BB8A52;
    case 0xBB8A53u: goto L_BB8A53;
    case 0xBB8A54u: goto L_BB8A54;
    case 0xBB8A56u: goto L_BB8A56;
    case 0xBB8A59u: goto L_BB8A59;
    case 0xBB8A5Cu: goto L_BB8A5C;
    case 0xBB8A5Du: goto L_BB8A5D;
    case 0xBB8A5Eu: goto L_BB8A5E;
    case 0xBB8A5Fu: goto L_BB8A5F;
    case 0xBB8A60u: goto L_BB8A60;
    case 0xBB8A61u: goto L_BB8A61;
    case 0xBB8A65u: goto L_BB8A65;
    case 0xBB8A66u: goto L_BB8A66;
    case 0xBB8A67u: goto L_BB8A67;
    case 0xBB8A69u: goto L_BB8A69;
    case 0xBB8A6Bu: goto L_BB8A6B;
    case 0xBB8A6Cu: goto L_BB8A6C;
    case 0xBB8A6Du: goto L_BB8A6D;
    case 0xBB8A6Eu: goto L_BB8A6E;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_BB8A3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Fu,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A3Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A3F PHA
    cpu.push("PHA", hw);
    goto L_BB8A40;
L_BB8A40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A40u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A40 PHX
    cpu.push("PHX", hw);
    goto L_BB8A41;
L_BB8A41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A41u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A41 PHY
    cpu.push("PHY", hw);
    goto L_BB8A42;
L_BB8A42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A42u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A42u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A42 LDY
    cpu.setY(0x100u, 16);
    goto L_BB8A45;
L_BB8A45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u,cpu,0x7Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A45u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A45 TDC
    cpu.tdc();
    goto L_BB8A46;
L_BB8A46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A46u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A46 TAX
    cpu.transfer("TAX");
    goto L_BB8A47;
L_BB8A47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A47u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A47 SEP
    cpu.sep(0x20u);
    goto L_BB8A49;
L_BB8A49:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A49u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A49u, 5u, 4u, ((0x7E2100u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A49 STA
    hw.write(((0x7E2100u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_BB8A4D;
L_BB8A4D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A4D CLC
    cpu.setFlag('C', false);
    goto L_BB8A4E;
L_BB8A4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Eu,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A4Eu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A4E ADC
    cpu.adc(0x10u);
    goto L_BB8A50;
L_BB8A50:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A50u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A50u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A50 AND
    cpu.logicAnd(0xF0u);
    goto L_BB8A52;
L_BB8A52:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A52u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A52u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A52 INX
    cpu.inc('X');
    goto L_BB8A53;
L_BB8A53:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A53u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A53u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A53u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A53 DEY
    cpu.decReg('Y');
    goto L_BB8A54;
L_BB8A54:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A54u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A54u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A54u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A54 BNE -> $BB8A49
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_BB8A49; }
    goto L_BB8A56;
L_BB8A56:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A56u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A56u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A56 LDY
    cpu.setY(0x100u, 16);
    goto L_BB8A59;
L_BB8A59:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A59u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A59u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A59 LDX
    cpu.setX(0x0u, 16);
    goto L_BB8A5C;
L_BB8A5C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A5C TXA
    cpu.transfer("TXA");
    goto L_BB8A5D;
L_BB8A5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Du,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A5D LSR
    cpu.lsrA();
    goto L_BB8A5E;
L_BB8A5E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A5E LSR
    cpu.lsrA();
    goto L_BB8A5F;
L_BB8A5F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A5Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A5Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A5F LSR
    cpu.lsrA();
    goto L_BB8A60;
L_BB8A60:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A60u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A60u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A60 LSR
    cpu.lsrA();
    goto L_BB8A61;
L_BB8A61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A61u, 5u, 4u, ((0x7E2000u + cpu.x) & 0xFFFFFFu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A61 STA
    hw.write(((0x7E2000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_BB8A65;
L_BB8A65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A65u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A65 INX
    cpu.inc('X');
    goto L_BB8A66;
L_BB8A66:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A66u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A66u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A66 DEY
    cpu.decReg('Y');
    goto L_BB8A67;
L_BB8A67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A67u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A67u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A67 BNE -> $BB8A5C
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_BB8A5C; }
    goto L_BB8A69;
L_BB8A69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A69u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8A69 REP
    cpu.rep(0x20u);
    goto L_BB8A6B;
L_BB8A6B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu,cpu,0x7Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A6B PLY
    cpu.pop("PLY", hw);
    goto L_BB8A6C;
L_BB8A6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Cu,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Cu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A6C PLX
    cpu.pop("PLX", hw);
    goto L_BB8A6D;
L_BB8A6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Du, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8A6D PLA
    cpu.pop("PLA", hw);
    goto L_BB8A6E;
L_BB8A6E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8A6Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8A6Eu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $BB8A6E RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0xBB8A6Eu);return;} hw.unresolvedReturn(0xBB8A6Eu,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
}

