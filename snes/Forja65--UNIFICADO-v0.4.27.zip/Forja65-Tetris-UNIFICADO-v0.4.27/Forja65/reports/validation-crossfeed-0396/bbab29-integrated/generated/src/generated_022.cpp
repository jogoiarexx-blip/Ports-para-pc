#include "generated.hpp"
void sub_00809D_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x00809Du: goto L_00809D;
    case 0x00809Eu: goto L_00809E;
    case 0x0080A2u: goto L_0080A2;
    case 0x0080A5u: goto L_0080A5;
    case 0x0080A8u: goto L_0080A8;
    case 0x0080ABu: goto L_0080AB;
    case 0x0080AFu: goto L_0080AF;
    case 0x0080B2u: goto L_0080B2;
    case 0x0080B5u: goto L_0080B5;
    case 0x0080B8u: goto L_0080B8;
    case 0x0080BCu: goto L_0080BC;
    case 0x0080BFu: goto L_0080BF;
    case 0x0080C3u: goto L_0080C3;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_00809D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du,cpu,0x98u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00809D TYA
    cpu.transfer("TYA");
    goto L_00809E;
L_00809E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x809Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x809Eu, 8u, 4u, 0xBB8567u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $00809E JSL -> $BB8567 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80A1u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80A2u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0xBB8567u, 0x00809Eu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0080A2;
L_0080A2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A2u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80A2u,0x0080A2u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A2u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A2 LDA
    cpu.setA(0x1Du, 16);
    goto L_0080A5;
L_0080A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A5 LDY
    cpu.setY(0x0u, 16);
    goto L_0080A8;
L_0080A8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80A8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80A8u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080A8 LDX
    cpu.setX(0x20u, 16);
    goto L_0080AB;
L_0080AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80ABu, 8u, 4u, 0xBB856Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0080AB JSL -> $BB856D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80AEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80AFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0xBB856Du, 0x0080ABu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0080AF;
L_0080AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80AFu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80AFu,0x0080AFu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80AFu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080AF LDA
    cpu.setA(0x1Fu, 16);
    goto L_0080B2;
L_0080B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B2u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B2 LDY
    cpu.setY(0x0u, 16);
    goto L_0080B5;
L_0080B5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B5u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B5u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080B5 LDX
    cpu.setX(0x1u, 16);
    goto L_0080B8;
L_0080B8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80B8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80B8u, 8u, 4u, 0xBB856Du, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0080B8 JSL -> $BB856D stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80BBu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80BCu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0xBB856Du, 0x0080B8u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0080BC;
L_0080BC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BCu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80BCu,0x0080BCu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BCu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BCu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080BC LDA
    cpu.setA(0xFu, 16);
    goto L_0080BF;
L_0080BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80BFu, 8u, 4u, 0xBB856Au, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $0080BF JSL -> $BB856A stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x80C2u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x80C3u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0xBB856Au, 0x0080BFu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_0080C3;
L_0080C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x80C3u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x80C3u,0x0080C3u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u,cpu,0xDBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x80C3u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $0080C3 STP
    hw.stopped=true; return;
}

