#include "generated.hpp"
void sub_0080C4_E1M1X1CQ_part1(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x008237u: goto L_008237;
    case 0x00823Au: goto L_00823A;
    case 0x00823Du: goto L_00823D;
    case 0x008240u: goto L_008240;
    case 0x008243u: goto L_008243;
    case 0x008246u: goto L_008246;
    case 0x008249u: goto L_008249;
    case 0x00824Cu: goto L_00824C;
    case 0x00824Fu: goto L_00824F;
    case 0x008252u: goto L_008252;
    case 0x008253u: goto L_008253;
    case 0x008255u: goto L_008255;
    case 0x008257u: goto L_008257;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_008237:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8237u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8237u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008237 LDX
    cpu.setX(0xAu, 16);
    goto L_00823A;
L_00823A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Au, 5u, 3u, cpu.address("absx", 0x4300u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00823A STZ
    hw.write(cpu.address("absx", 0x4300u), 0, cpu.m8?8:16);
    goto L_00823D;
L_00823D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x823Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x823Du, 5u, 3u, cpu.address("absx", 0x4310u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00823D STZ
    hw.write(cpu.address("absx", 0x4310u), 0, cpu.m8?8:16);
    goto L_008240;
L_008240:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8240u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8240u, 5u, 3u, cpu.address("absx", 0x4320u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008240 STZ
    hw.write(cpu.address("absx", 0x4320u), 0, cpu.m8?8:16);
    goto L_008243;
L_008243:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8243u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8243u, 5u, 3u, cpu.address("absx", 0x4330u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008243 STZ
    hw.write(cpu.address("absx", 0x4330u), 0, cpu.m8?8:16);
    goto L_008246;
L_008246:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8246u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8246u, 5u, 3u, cpu.address("absx", 0x4340u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008246 STZ
    hw.write(cpu.address("absx", 0x4340u), 0, cpu.m8?8:16);
    goto L_008249;
L_008249:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8249u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8249u,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8249u, 5u, 3u, cpu.address("absx", 0x4350u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008249 STZ
    hw.write(cpu.address("absx", 0x4350u), 0, cpu.m8?8:16);
    goto L_00824C;
L_00824C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Cu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Cu, 5u, 3u, cpu.address("absx", 0x4360u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824C STZ
    hw.write(cpu.address("absx", 0x4360u), 0, cpu.m8?8:16);
    goto L_00824F;
L_00824F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x824Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x824Fu,cpu,0x9Eu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x824Fu, 5u, 3u, cpu.address("absx", 0x4370u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $00824F STZ
    hw.write(cpu.address("absx", 0x4370u), 0, cpu.m8?8:16);
    goto L_008252;
L_008252:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8252u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u,cpu,0xCAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8252u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008252 DEX
    cpu.decReg('X');
    goto L_008253;
L_008253:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8253u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8253u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008253 BPL -> $00823A
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_00823A; }
    goto L_008255;
L_008255:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8255u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8255u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $008255 REP
    cpu.rep(0x20u);
    goto L_008257;
L_008257:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8257u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8257u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $008257 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x008257u);return;} hw.unresolvedReturn(0x008257u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

