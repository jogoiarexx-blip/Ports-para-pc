#include "generated.hpp"
void sub_BB8567_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xBB8567u: goto L_BB8567;
    case 0xBB8CF6u: goto L_BB8CF6;
    case 0xBB8CF7u: goto L_BB8CF7;
    case 0xBB8CFAu: goto L_BB8CFA;
    case 0xBB8CFBu: goto L_BB8CFB;
    case 0xBB8CFCu: goto L_BB8CFC;
    case 0xBB8CFDu: goto L_BB8CFD;
    case 0xBB8CFEu: goto L_BB8CFE;
    case 0xBB8D01u: goto L_BB8D01;
    case 0xBB8D03u: goto L_BB8D03;
    case 0xBB8D06u: goto L_BB8D06;
    case 0xBB8D08u: goto L_BB8D08;
    case 0xBB8D0Bu: goto L_BB8D0B;
    case 0xBB8D0Du: goto L_BB8D0D;
    case 0xBB8D10u: goto L_BB8D10;
    case 0xBB8D12u: goto L_BB8D12;
    case 0xBB8D14u: goto L_BB8D14;
    case 0xBB8D16u: goto L_BB8D16;
    case 0xBB8D1Au: goto L_BB8D1A;
    case 0xBB8D1Cu: goto L_BB8D1C;
    case 0xBB8D1Fu: goto L_BB8D1F;
    case 0xBB8D23u: goto L_BB8D23;
    case 0xBB8D26u: goto L_BB8D26;
    case 0xBB8D28u: goto L_BB8D28;
    case 0xBB8D2Bu: goto L_BB8D2B;
    case 0xBB8D2Fu: goto L_BB8D2F;
    case 0xBB8D30u: goto L_BB8D30;
    case 0xBB8D33u: goto L_BB8D33;
    case 0xBB8D34u: goto L_BB8D34;
    case 0xBB8D37u: goto L_BB8D37;
    case 0xBB8D38u: goto L_BB8D38;
    case 0xBB8D39u: goto L_BB8D39;
    case 0xBB8D3Bu: goto L_BB8D3B;
    case 0xBB8D3Fu: goto L_BB8D3F;
    case 0xBB8D40u: goto L_BB8D40;
    case 0xBB8D41u: goto L_BB8D41;
    case 0xBB8D42u: goto L_BB8D42;
    case 0xBB8D44u: goto L_BB8D44;
    case 0xBB8D45u: goto L_BB8D45;
    case 0xBB8D47u: goto L_BB8D47;
    case 0xBB8D4Au: goto L_BB8D4A;
    case 0xBB8D4Eu: goto L_BB8D4E;
    case 0xBB8D51u: goto L_BB8D51;
    case 0xBB8D55u: goto L_BB8D55;
    case 0xBB8D57u: goto L_BB8D57;
    case 0xBB8D5Bu: goto L_BB8D5B;
    case 0xBB8D5Du: goto L_BB8D5D;
    case 0xBB8D61u: goto L_BB8D61;
    case 0xBB8D65u: goto L_BB8D65;
    case 0xBB8D67u: goto L_BB8D67;
    case 0xBB8D68u: goto L_BB8D68;
    case 0xBB8D69u: goto L_BB8D69;
    case 0xBB8D6Cu: goto L_BB8D6C;
    case 0xBB8D6Du: goto L_BB8D6D;
    case 0xBB8D6Fu: goto L_BB8D6F;
    case 0xBB8D71u: goto L_BB8D71;
    case 0xBB8D72u: goto L_BB8D72;
    case 0xBB8D73u: goto L_BB8D73;
    case 0xBB8D75u: goto L_BB8D75;
    case 0xBB8D78u: goto L_BB8D78;
    case 0xBB8D7Bu: goto L_BB8D7B;
    case 0xBB8D7Eu: goto L_BB8D7E;
    case 0xBB8D7Fu: goto L_BB8D7F;
    case 0xBB8D80u: goto L_BB8D80;
    case 0xBB8D81u: goto L_BB8D81;
    case 0xBB8D82u: goto L_BB8D82;
    case 0xBB8D83u: goto L_BB8D83;
    case 0xBB8D84u: goto L_BB8D84;
    case 0xBB8D85u: goto L_BB8D85;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_BB8567:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8567u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8567u, 3u, 3u, cpu.address("abs", 0x8CF6u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8567 JMP -> $BB8CF6
    goto L_BB8CF6;
L_BB8CF6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF6u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF6u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB8CF6 PHB
    cpu.push("PHB", hw);
    goto L_BB8CF7;
L_BB8CF7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CF7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CF7u, 5u, 3u, cpu.address("abs", 0xFD1Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8CF7 PEA
    cpu.push16Value(hw, 0xFD1Bu);
    goto L_BB8CFA;
L_BB8CFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFAu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB8CFA PLB
    cpu.pop("PLB", hw);
    goto L_BB8CFB;
L_BB8CFB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFBu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB8CFB PLB
    cpu.pop("PLB", hw);
    goto L_BB8CFC;
L_BB8CFC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFCu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8CFC ASL
    cpu.aslA();
    goto L_BB8CFD;
L_BB8CFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFDu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8CFD TAY
    cpu.transfer("TAY");
    goto L_BB8CFE;
L_BB8CFE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8CFEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFEu,cpu,0xBEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8CFEu, 5u + 1u, 3u, cpu.address("absy", 0x1B03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8CFE LDX
    cpu.setX(hw.readW(cpu.address("absy", 0x1B03u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_BB8D01;
L_BB8D01:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D01u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D01u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D01 SEP
    cpu.sep(0x20u);
    goto L_BB8D03;
L_BB8D03:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D03u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D03u, 4u + 1u, 3u, cpu.address("absx", 0x1B03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D03 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B03u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D06;
L_BB8D06:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D06u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D06u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D06 BEQ -> $BB8D6F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_BB8D6F; }
    goto L_BB8D08;
L_BB8D08:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D08u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D08u, 4u + 1u, 3u, cpu.address("absx", 0x1B07u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D08 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B07u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D0B;
L_BB8D0B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D0B BMI -> $BB8D73
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_BB8D73; }
    goto L_BB8D0D;
L_BB8D0D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D0Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D0Du, 4u + 1u, 3u, cpu.address("absx", 0x1B03u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D0D LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B03u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D10;
L_BB8D10:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D10u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u,cpu,0x09u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D10u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D10 ORA
    cpu.logicOr(0xC0u);
    goto L_BB8D12;
L_BB8D12:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D12u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D12u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x44u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D12 STA
    hw.write(cpu.address("dp", 0x44u), cpu.a, cpu.m8?8:16);
    goto L_BB8D14;
L_BB8D14:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D14u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D14u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D14 LDA
    cpu.setA(0x7Fu, 8);
    goto L_BB8D16;
L_BB8D16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D16u, 5u, 4u, 0x004304u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D16 STA
    hw.write(0x4304u, cpu.a, cpu.m8?8:16);
    goto L_BB8D1A;
L_BB8D1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Au, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D1A REP
    cpu.rep(0x20u);
    goto L_BB8D1C;
L_BB8D1C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D1C LDA
    cpu.setA(0x0u, 16);
    goto L_BB8D1F;
L_BB8D1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D1Fu, 6u, 4u, 0x004302u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D1F STA
    hw.write(0x4302u, cpu.a, cpu.m8?8:16);
    goto L_BB8D23;
L_BB8D23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D23u, 5u + 1u, 3u, cpu.address("absx", 0x1B04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D23 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B04u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D26;
L_BB8D26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D26u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x42u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D26 STA
    hw.write(cpu.address("dp", 0x42u), cpu.a, cpu.m8?8:16);
    goto L_BB8D28;
L_BB8D28:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D28u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D28u, 5u + 1u, 3u, cpu.address("absx", 0x1B06u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D28 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B06u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D2B;
L_BB8D2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Bu, 6u, 4u, 0x002116u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D2B STA
    hw.write(0x2116u, cpu.a, cpu.m8?8:16);
    goto L_BB8D2F;
L_BB8D2F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D2Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D2Fu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8D2F PHX
    cpu.push("PHX", hw);
    goto L_BB8D30;
L_BB8D30:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D30u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D30u, 5u + 1u, 3u, cpu.address("absx", 0x1B08u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D30 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B08u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D33;
L_BB8D33:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D33u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u,cpu,0x1Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D33u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D33 INC
    cpu.inc('A');
    goto L_BB8D34;
L_BB8D34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D34u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D34 AND
    cpu.logicAnd(0xFFFEu);
    goto L_BB8D37;
L_BB8D37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u,cpu,0xA8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D37u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D37 TAY
    cpu.transfer("TAY");
    goto L_BB8D38;
L_BB8D38:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D38u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D38u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D38 TAX
    cpu.transfer("TAX");
    goto L_BB8D39;
L_BB8D39:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D39u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D39u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x42u) & 0xFFFFu), 3u, 0u);
    // $BB8D39 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x42u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D3B;
L_BB8D3B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu,cpu,0x9Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Bu, 6u, 4u, ((0x7F0000u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D3B STA
    hw.write(((0x7F0000u + cpu.x) & 0xFFFFFFu), cpu.a, cpu.m8?8:16);
    goto L_BB8D3F;
L_BB8D3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D3Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D3F DEY
    cpu.decReg('Y');
    goto L_BB8D40;
L_BB8D40:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D40u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u,cpu,0x88u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D40u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D40 DEY
    cpu.decReg('Y');
    goto L_BB8D41;
L_BB8D41:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D41u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u,cpu,0xBBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D41u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D41 TYX
    cpu.transfer("TYX");
    goto L_BB8D42;
L_BB8D42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D42u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u,cpu,0x10u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D42u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D42 BPL -> $BB8D39
    if (!cpu.n) { hw.addCpuInternalCycles(1u); goto L_BB8D39; }
    goto L_BB8D44;
L_BB8D44:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D44u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u,cpu,0xFAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D44u, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8D44 PLX
    cpu.pop("PLX", hw);
    goto L_BB8D45;
L_BB8D45:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D45u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D45u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D45 SEP
    cpu.sep(0x20u);
    goto L_BB8D47;
L_BB8D47:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D47u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D47u, 4u + 1u, 3u, cpu.address("absx", 0x1B08u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D47 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B08u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D4A;
L_BB8D4A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Au, 5u, 4u, 0x004305u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D4A STA
    hw.write(0x4305u, cpu.a, cpu.m8?8:16);
    goto L_BB8D4E;
L_BB8D4E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D4Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D4Eu, 4u + 1u, 3u, cpu.address("absx", 0x1B09u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D4E LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B09u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D51;
L_BB8D51:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D51u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D51u, 5u, 4u, 0x004306u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D51 STA
    hw.write(0x4306u, cpu.a, cpu.m8?8:16);
    goto L_BB8D55;
L_BB8D55:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D55u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D55u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D55 LDA
    cpu.setA(0x18u, 8);
    goto L_BB8D57;
L_BB8D57:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D57u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D57u, 5u, 4u, 0x004301u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D57 STA
    hw.write(0x4301u, cpu.a, cpu.m8?8:16);
    goto L_BB8D5B;
L_BB8D5B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D5B LDA
    cpu.setA(0x1u, 8);
    goto L_BB8D5D;
L_BB8D5D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D5Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D5Du, 5u, 4u, 0x004300u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D5D STA
    hw.write(0x4300u, cpu.a, cpu.m8?8:16);
    goto L_BB8D61;
L_BB8D61:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D61u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u,cpu,0x8Fu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D61u, 5u, 4u, 0x00420Bu, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D61 STA
    hw.write(0x420Bu, cpu.a, cpu.m8?8:16);
    goto L_BB8D65;
L_BB8D65:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D65u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D65u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D65 REP
    cpu.rep(0x20u);
    goto L_BB8D67;
L_BB8D67:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D67u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u,cpu,0x8Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D67u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D67 TXA
    cpu.transfer("TXA");
    goto L_BB8D68;
L_BB8D68:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D68u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u,cpu,0x18u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D68u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D68 CLC
    cpu.setFlag('C', false);
    goto L_BB8D69;
L_BB8D69:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D69u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u,cpu,0x69u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D69u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D69 ADC
    cpu.adc(0x7u);
    goto L_BB8D6C;
L_BB8D6C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D6C TAX
    cpu.transfer("TAX");
    goto L_BB8D6D;
L_BB8D6D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Du, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D6D BRA -> $BB8D01
    goto L_BB8D01;
L_BB8D6F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D6Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D6Fu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D6F REP
    cpu.rep(0x20u);
    goto L_BB8D71;
L_BB8D71:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D71u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D71u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB8D71 PLB
    cpu.pop("PLB", hw);
    goto L_BB8D72;
L_BB8D72:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D72u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u,cpu,0x6Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D72u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $BB8D72 RTL stack real
    { auto raw=cpu.peekStack16(hw); auto bank=cpu.peekStack8(hw,3u); auto dst=(std::uint32_t(bank)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,true,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,true);cpu.pop16Value(hw);cpu.pop8Value(hw);cpu.pb=bank;hw.requestDispatch(dst,0xBB8D72u);return;} hw.unresolvedReturn(0xBB8D72u,dst,cpu,"STACK-RTL"); } cpu.pop16Value(hw); cpu.pop8Value(hw); cpu.pb=bank; hw.popNativeReturn(); return; }
L_BB8D73:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D73u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D73u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D73 REP
    cpu.rep(0x20u);
    goto L_BB8D75;
L_BB8D75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u,cpu,0xBCu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D75u, 5u + 1u, 3u, cpu.address("absx", 0x1B04u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D75 LDY
    cpu.setY(hw.readW(cpu.address("absx", 0x1B04u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_BB8D78;
L_BB8D78:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D78u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u,cpu,0xBDu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D78u, 5u + 1u, 3u, cpu.address("absx", 0x1B03u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D78 LDA
    cpu.loadA(hw.readW(cpu.address("absx", 0x1B03u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8D7B;
L_BB8D7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D7B AND
    cpu.logicAnd(0xC0u);
    goto L_BB8D7E;
L_BB8D7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Eu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Eu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D7E LSR
    cpu.lsrA();
    goto L_BB8D7F;
L_BB8D7F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D7Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D7Fu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D7F LSR
    cpu.lsrA();
    goto L_BB8D80;
L_BB8D80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D80u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D80 LSR
    cpu.lsrA();
    goto L_BB8D81;
L_BB8D81:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D81u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D81u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D81u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D81 LSR
    cpu.lsrA();
    goto L_BB8D82;
L_BB8D82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D82u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D82 LSR
    cpu.lsrA();
    goto L_BB8D83;
L_BB8D83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u,cpu,0xDAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D83u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8D83 PHX
    cpu.push("PHX", hw);
    goto L_BB8D84;
L_BB8D84:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D84u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D84u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8D84 TAX
    cpu.transfer("TAX");
    goto L_BB8D85;
L_BB8D85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8D85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u,cpu,0x7Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8D85u, 6u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, ((std::uint32_t(cpu.pb)<<16) | ((0x8D88u + cpu.x) & 0xFFFFu)), 2u, 0u);
    // $BB8D85 JMP (8D88,X) dinamico
    { auto p=(std::uint32_t(cpu.pb)<<16)|((0x8D88u+cpu.x)&0xFFFFu); auto dst=(std::uint32_t(cpu.pb)<<16)|hw.read16BankWrap(p); hw.requestDispatch(dst,0xBB8D85u); return; }
}

