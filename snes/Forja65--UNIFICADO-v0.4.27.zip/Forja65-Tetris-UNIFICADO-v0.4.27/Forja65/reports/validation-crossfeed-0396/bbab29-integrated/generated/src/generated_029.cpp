#include "generated.hpp"
void sub_BB8005_E0M1X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xBB8005u: goto L_BB8005;
    case 0xBB86ADu: goto L_BB86AD;
    case 0xBB86AFu: goto L_BB86AF;
    case 0xBB86B1u: goto L_BB86B1;
    case 0xBB8726u: goto L_BB8726;
    case 0xBB8728u: goto L_BB8728;
    case 0xBB872Au: goto L_BB872A;
    case 0xBB872Cu: goto L_BB872C;
    case 0xBB872Du: goto L_BB872D;
    case 0xBB872Fu: goto L_BB872F;
    case 0xBB8731u: goto L_BB8731;
    case 0xBB8733u: goto L_BB8733;
    case 0xBB8736u: goto L_BB8736;
    case 0xBB8737u: goto L_BB8737;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_BB8005:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8005u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8005u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8005u, 3u, 3u, cpu.address("abs", 0x8726u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8005 JMP -> $BB8726
    goto L_BB8726;
L_BB86AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86ADu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86AD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x2Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB86AF;
L_BB86AF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86AFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86AFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86AF AND
    cpu.logicAnd(0xFu);
    goto L_BB86B1;
L_BB86B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x86B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x86B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB86B1 ASL
    cpu.aslA();
    hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x86B2u,0xBB86B1u); return;
L_BB8726:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8726u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u,cpu,0xA7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8726u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x2Eu) & 0xFFFFu), 3u, 0u);
    // $BB8726 LDA
    cpu.loadA(hw.readW(cpu.addressDpLong(hw, 0x2Eu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8728;
L_BB8728:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8728u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8728u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8728 STA
    hw.write(cpu.address("dp", 0x26u), cpu.a, cpu.m8?8:16);
    goto L_BB872A;
L_BB872A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Au, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB872A LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB872C;
L_BB872C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Cu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB872C INY
    cpu.inc('Y');
    goto L_BB872D;
L_BB872D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Du, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB872D STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_BB872F;
L_BB872F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x872Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x872Fu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB872F LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x26u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8731;
L_BB8731:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8731u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u,cpu,0x07u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8731u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x2Au) & 0xFFFFu), 3u, 0u);
    // $BB8731 ORA
    cpu.logicOr(hw.readW(cpu.addressDpLong(hw, 0x2Au), cpu.m8?8:16));
    goto L_BB8733;
L_BB8733:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8733u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u,cpu,0x9Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8733u, 5u, 3u, cpu.address("absx", 0x0000u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8733 STA
    hw.write(cpu.address("absx", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_BB8736;
L_BB8736:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8736u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u,cpu,0xE8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8736u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8736 INX
    cpu.inc('X');
    goto L_BB8737;
L_BB8737:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8737u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u,cpu,0x4Cu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8737u, 3u, 3u, cpu.address("abs", 0x86ADu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8737 JMP -> $BB86AD
    goto L_BB86AD;
}

