#include "generated.hpp"
void sub_BB862F_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0xBB862Fu: goto L_BB862F;
    case 0xBB8632u: goto L_BB8632;
    case 0xBB8636u: goto L_BB8636;
    case 0xBB8639u: goto L_BB8639;
    case 0xBB863Bu: goto L_BB863B;
    case 0xBB863Cu: goto L_BB863C;
    case 0xBB863Eu: goto L_BB863E;
    case 0xBB8640u: goto L_BB8640;
    case 0xBB8642u: goto L_BB8642;
    case 0xBB8643u: goto L_BB8643;
    case 0xBB8644u: goto L_BB8644;
    case 0xBB8647u: goto L_BB8647;
    case 0xBB8649u: goto L_BB8649;
    case 0xBB864Cu: goto L_BB864C;
    case 0xBB864Eu: goto L_BB864E;
    case 0xBB8651u: goto L_BB8651;
    case 0xBB8653u: goto L_BB8653;
    case 0xBB8655u: goto L_BB8655;
    case 0xBB8658u: goto L_BB8658;
    case 0xBB865Au: goto L_BB865A;
    case 0xBB865Du: goto L_BB865D;
    case 0xBB865Fu: goto L_BB865F;
    case 0xBB8662u: goto L_BB8662;
    case 0xBB8664u: goto L_BB8664;
    case 0xBB8666u: goto L_BB8666;
    case 0xBB8669u: goto L_BB8669;
    case 0xBB866Bu: goto L_BB866B;
    case 0xBB866Du: goto L_BB866D;
    case 0xBB866Eu: goto L_BB866E;
    case 0xBB866Fu: goto L_BB866F;
    case 0xBB8671u: goto L_BB8671;
    case 0xBB8673u: goto L_BB8673;
    case 0xBB8674u: goto L_BB8674;
    case 0xBB8676u: goto L_BB8676;
    case 0xBB8678u: goto L_BB8678;
    case 0xBB8679u: goto L_BB8679;
    case 0xBB867Bu: goto L_BB867B;
    case 0xBB867Du: goto L_BB867D;
    case 0xBB867Eu: goto L_BB867E;
    case 0xBB8680u: goto L_BB8680;
    case 0xBB8682u: goto L_BB8682;
    case 0xBB8683u: goto L_BB8683;
    case 0xBB8685u: goto L_BB8685;
    case 0xBB8687u: goto L_BB8687;
    case 0xBB8689u: goto L_BB8689;
    case 0xBB868Cu: goto L_BB868C;
    case 0xBB868Eu: goto L_BB868E;
    case 0xBB8690u: goto L_BB8690;
    case 0xBB8692u: goto L_BB8692;
    case 0xBB8694u: goto L_BB8694;
    case 0xBB8695u: goto L_BB8695;
    case 0xBB8697u: goto L_BB8697;
    case 0xBB8699u: goto L_BB8699;
    case 0xBB869Au: goto L_BB869A;
    case 0xBB869Bu: goto L_BB869B;
    case 0xBB869Du: goto L_BB869D;
    case 0xBB869Fu: goto L_BB869F;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_BB862F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x862Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x862Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB862F LDA
    cpu.setA(0x0u, 16);
    goto L_BB8632;
L_BB8632:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8632u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8632u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8632u, 8u, 4u, 0xBB8A3Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $BB8632 JSL -> $BB8A3F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0x8635u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0x8636u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0xBB8A3Fu, 0xBB8632u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_BB8636;
L_BB8636:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8636u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0x8636u,0xBB8636u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u,cpu,0xF4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8636u, 5u, 3u, cpu.address("abs", 0x007Fu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8636 PEA
    cpu.push16Value(hw, 0x7Fu);
    goto L_BB8639;
L_BB8639:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8639u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8639u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8639 STA
    hw.write(cpu.address("dp", 0x20u), cpu.a, cpu.m8?8:16);
    goto L_BB863B;
L_BB863B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Bu,cpu,0x68u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Bu, 5u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB863B PLA
    cpu.pop("PLA", hw);
    goto L_BB863C;
L_BB863C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB863C STA
    hw.write(cpu.address("dp", 0x22u), cpu.a, cpu.m8?8:16);
    goto L_BB863E;
L_BB863E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x863Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x863Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB863E STX
    hw.write(cpu.address("dp", 0x1Cu), cpu.x, cpu.x8?8:16);
    goto L_BB8640;
L_BB8640:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8640u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u,cpu,0x84u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8640u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8640 STY
    hw.write(cpu.address("dp", 0x1Eu), cpu.y, cpu.x8?8:16);
    goto L_BB8642;
L_BB8642:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8642u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u,cpu,0x8Bu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8642u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB8642 PHB
    cpu.push("PHB", hw);
    goto L_BB8643;
L_BB8643:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8643u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u,cpu,0x5Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8643u, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB8643 PHY
    cpu.push("PHY", hw);
    goto L_BB8644;
L_BB8644:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8644u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8644u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8644 LDA
    cpu.setA(0xFFFFu, 16);
    goto L_BB8647;
L_BB8647:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8647u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8647u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x1Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8647 STA
    hw.write(cpu.address("dp", 0x1Au), cpu.a, cpu.m8?8:16);
    goto L_BB8649;
L_BB8649:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8649u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8649u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8649 LDA
    cpu.setA(0x2100u, 16);
    goto L_BB864C;
L_BB864C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB864C STA
    hw.write(cpu.address("dp", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_BB864E;
L_BB864E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x864Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x864Eu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB864E LDA
    cpu.setA(0x7Eu, 16);
    goto L_BB8651;
L_BB8651:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8651u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8651u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x30u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8651 STA
    hw.write(cpu.address("dp", 0x30u), cpu.a, cpu.m8?8:16);
    goto L_BB8653;
L_BB8653:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8653u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8653u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8653 STA
    hw.write(cpu.address("dp", 0x2Cu), cpu.a, cpu.m8?8:16);
    goto L_BB8655;
L_BB8655:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8655u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8655u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8655 LDA
    cpu.setA(0x2000u, 16);
    goto L_BB8658;
L_BB8658:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8658u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8658u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8658 STA
    hw.write(cpu.address("dp", 0x2Au), cpu.a, cpu.m8?8:16);
    goto L_BB865A;
L_BB865A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Au, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB865A LDA
    cpu.setA(0x8001u, 16);
    goto L_BB865D;
L_BB865D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB865D STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_BB865F;
L_BB865F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x865Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x865Fu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB865F LDA
    cpu.setA(0x8040u, 16);
    goto L_BB8662;
L_BB8662:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8662u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8662u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x32u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8662 STA
    hw.write(cpu.address("dp", 0x32u), cpu.a, cpu.m8?8:16);
    goto L_BB8664;
L_BB8664:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8664u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8664u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x20u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8664 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x20u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_BB8666;
L_BB8666:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8666u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8666u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8666 LDY
    cpu.setY(0x1u, 16);
    goto L_BB8669;
L_BB8669:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8669u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8669u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8669u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8669 SEP
    cpu.sep(0x20u);
    goto L_BB866B;
L_BB866B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x22u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB866B LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x22u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB866D;
L_BB866D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du,cpu,0x48u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Du, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB866D PHA
    cpu.push("PHA", hw);
    goto L_BB866E;
L_BB866E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu,cpu,0xABu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Eu, 4u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 1u);
    // $BB866E PLB
    cpu.pop("PLB", hw);
    goto L_BB866F;
L_BB866F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x866Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x866Fu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB866F LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8671;
L_BB8671:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8671u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8671u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8671 STA
    hw.write(cpu.address("dp", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_BB8673;
L_BB8673:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8673u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8673u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8673 INY
    cpu.inc('Y');
    goto L_BB8674;
L_BB8674:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8674u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8674u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB8674 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8676;
L_BB8676:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8676u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8676u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8676 STA
    hw.write(cpu.address("dp", 0x3Bu), cpu.a, cpu.m8?8:16);
    goto L_BB8678;
L_BB8678:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8678u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8678u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8678 INY
    cpu.inc('Y');
    goto L_BB8679;
L_BB8679:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8679u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8679u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8679u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB8679 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB867B;
L_BB867B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB867B STA
    hw.write(cpu.address("dp", 0x3Eu), cpu.a, cpu.m8?8:16);
    goto L_BB867D;
L_BB867D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Du, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB867D INY
    cpu.inc('Y');
    goto L_BB867E;
L_BB867E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x867Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x867Eu, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB867E LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8680;
L_BB8680:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8680u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8680u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Fu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8680 STA
    hw.write(cpu.address("dp", 0x3Fu), cpu.a, cpu.m8?8:16);
    goto L_BB8682;
L_BB8682:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8682u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8682u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8682 INY
    cpu.inc('Y');
    goto L_BB8683;
L_BB8683:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8683u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8683u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8683 REP
    cpu.rep(0x20u);
    goto L_BB8685;
L_BB8685:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8685u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8685u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB8685 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8687;
L_BB8687:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8687u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8687u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8687 STA
    hw.write(cpu.address("dp", 0x3Cu), cpu.a, cpu.m8?8:16);
    goto L_BB8689;
L_BB8689:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8689u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u,cpu,0xA0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8689u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8689 LDY
    cpu.setY(0x27u, 16);
    goto L_BB868C;
L_BB868C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Cu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x24u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB868C STZ
    hw.write(cpu.address("dp", 0x24u), 0, cpu.m8?8:16);
    goto L_BB868E;
L_BB868E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x868Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x868Eu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x26u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB868E STZ
    hw.write(cpu.address("dp", 0x26u), 0, cpu.m8?8:16);
    goto L_BB8690;
L_BB8690:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8690u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8690u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8690 SEP
    cpu.sep(0x20u);
    goto L_BB8692;
L_BB8692:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8692u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u,cpu,0xB7u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8692u, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, ((cpu.d + 0x1Cu) & 0xFFFFu), 3u, 0u);
    // $BB8692 LDA
    cpu.loadA(hw.readW(cpu.addressDpLongY(hw, 0x1Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_BB8694;
L_BB8694:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8694u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u,cpu,0xC8u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8694u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8694 INY
    cpu.inc('Y');
    goto L_BB8695;
L_BB8695:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8695u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8695u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x2Eu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8695 STA
    hw.write(cpu.address("dp", 0x2Eu), cpu.a, cpu.m8?8:16);
    goto L_BB8697;
L_BB8697:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8697u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8697u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8697 AND
    cpu.logicAnd(0xF0u);
    goto L_BB8699;
L_BB8699:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x8699u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x8699u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB8699 LSR
    cpu.lsrA();
    goto L_BB869A;
L_BB869A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au,cpu,0x4Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Au, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB869A LSR
    cpu.lsrA();
    goto L_BB869B;
L_BB869B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Bu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $BB869B STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_BB869D;
L_BB869D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du,cpu,0xD4u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Du, 6u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB869D PEI
    cpu.push16Value(hw, hw.readW(cpu.address("dp", 0x36u),16));
    goto L_BB869F;
L_BB869F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0x869Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0x869Fu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $BB869F RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0xBB869Fu);return;} hw.unresolvedReturn(0xBB869Fu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

