# ROM Trace → Native Map

ROM: `3a574807afbad761` — HiROM

Trace events: 0; dropped: 0. Native score: unmeasured.

| Address | Symbol | Level observed | Category | Evidence | Instructions | Host calls |
|---|---|---|---|---|---:|---:|
| 00809D | fn_00809D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| 0080C4 | fn_0080C4 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| 00825E | fn_00825E | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| 008286 | fn_008286 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8001 | fn_BB8001 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8005 | fn_BB8005 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8009 | fn_BB8009 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB800D | fn_BB800D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8011 | fn_BB8011 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8015 | fn_BB8015 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8019 | fn_BB8019 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB801D | fn_BB801D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8021 | fn_BB8021 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8025 | fn_BB8025 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8029 | fn_BB8029 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB802D | fn_BB802D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8031 | fn_BB8031 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8035 | fn_BB8035 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8039 | fn_BB8039 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB803D | fn_BB803D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8567 | fn_BB8567 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB856A | fn_BB856A | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB856D | fn_BB856D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB862F | fn_BB862F | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8A3F | fn_BB8A3F | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8D90 | fn_BB8D90 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8DCC | fn_BB8DCC | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BB8DE4 | fn_BB8DE4 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BBAB29 | fn_BBAB29 | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |
| BBAB2D | fn_BBAB2D | TRANSLATED | UNKNOWN | UNKNOWN | 0 | 0 |

- No automatic gameplay reconstruction
- Heuristic confidence is a ranking weight, not a calibrated probability
- Trace counts do not establish whole-game coverage
- State-only PPU, DMA register replay, SPC/DSP simulation and ROM packs remain hardware/data dependencies
