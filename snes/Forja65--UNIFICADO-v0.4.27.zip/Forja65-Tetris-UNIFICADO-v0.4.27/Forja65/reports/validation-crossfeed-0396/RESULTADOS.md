# Validação independente — importação Forja65/DKC3 ZERO/Native

- Forja65 v0.3.96: novo subcomando `import-replay`, com confrontação de identidade SHA-256/FNV-1a64/tamanho e verificação dos erros/estado de CPU contra os arquivos de trace.
- ROM fornecida: 4.194.304 bytes, SHA-256 `2277a2d8dddb01fe5cb0ae9a0fa225d42b3a11adccaeafa18e3c339b3794a32b`.
- Foram convertidos em hints **três** eventos de execução com E/M/X/C observados. As **4.724** entradas do catálogo Native permanecem estáticas, não equivalência.
- A regressão nova `cross-project-replay-v0397-regression.js` passou, inclusive rejeição de ROM incorreta, divergência de PC, FLOW forjado, flags divergentes e prova semântica indevida.
- Suíte direcionada confirmada no ambiente: `cross-project-replay-v0397-regression.js`, `cross-project-knowledge-v0337-regression.js`, `carry-aware-cfg-v0321-regression.js`, `unknown-carry-state-regression.js`, `writer-domain-crossfeed-v0340-regression.js`, `rom-indexed-vector-writer-v0396-regression.js` e `native-dispatch-plan-v0342-regression.js` passaram. A suíte geral e os testes de longa duração **não** foram concluídos aqui.
- Com ROM real e max=4.500, o gerador descobriu 3.199 endereços / 178 variantes de função, criando as variantes compiláveis `B8:A6A6/C0`, `B8:D795/C1`, `BE:C394/C0`.
- Checagem sintática C++ de `src/dispatch.cpp` e shards dessas três rotinas passou.
- Compilação completa do **projeto experimental** em `forja-regeneration-probe` foi interrompida pelo timeout de execução a aproximadamente 47%. Sem resultado de replay para essa geração.

**Atenção:** mudanças no Forja65 melhoram a reprodução de conhecimento da CPU 65816, não comprovam 100% da fase, áudio, PPU ou callbacks Native PC.

## Próxima fronteira após BE:C394 (análise estática)

A rotina traduzida termina em `JMP (C3B4,X)` no banco BE. Cruzando os words da ROM com o catálogo do Native, os cinco primeiros destinos apontam para entradas de código conhecidas: `BE:C4BB`, `BE:C69E`, `BE:C51D`, `BE:C63C`, `BE:C5DA`. A sequência seguinte começa com bytes `AD 58 18` que também decodificam como código (LDA), não prova de sexto handler. O índice dinâmico **não** está fechado: não há autorização para inventar mais destinos ou declarar equivalência. Um replay com registro de X deve determinar qual desses destinos ocorre de fato.

## Retorno do replay integrado

O ZERO v0.41 com `BE:C394` gerado e incorporado foi compilado completamente e executado no replay: 14.417 frames, 14.417 hashes prefixo preservados, novo fluxo não resolvido `BE:C3B1 → BE:C69E` ainda dentro do mesmo frame. Isso é diferente da tentativa de compilar a **regeneração experimental integral**, que permaneceu interrompida por tempo. O comando `import-replay` passou a aceitar também `--followup-trace` e `--followup-error`, validando o log real do novo salto. Agora são **quatro** observações CPU exportadas, incluindo `BE:C69E/C0`. O catálogo de 4.724 candidatos continua não sendo prova semântica.
