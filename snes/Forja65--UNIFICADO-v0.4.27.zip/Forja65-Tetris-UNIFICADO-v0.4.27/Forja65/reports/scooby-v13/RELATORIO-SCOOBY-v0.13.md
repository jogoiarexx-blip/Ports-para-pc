# Scooby-Doo Mystery Native PC v0.13 — 6.000 quadros e controle após a porta

Data: 2026-10-10. ROM fornecida pelo usuário, SHA-256 `7fb5236d10852125f0f37c2188b907d636647400a57bccbdb2f63098ffae8b2d`.

## Resultados reproduzidos no executável C++ Linux do Forja65

- Replay determinístico de New Game `scooby-v10-dialogue-right.input.trace`: **6.000/6.000 quadros, exit=0, status FRAMES_REACHED**. Duração: **91,651 segundos** (65,47 quadros simulados/s, não FPS gráfico medido no Windows).
- Hashes gráficos distintos em todo o replay: **2.602**; hashes WRAM distintos: **5.924**. O auditor do marco conferiu 6.000 linhas consecutivas, quatro capturas dos quadros 5.200, 5.500, 5.800 e 5.990 e a identidade da ROM. Relatório: `QA-SCOOBY/v13-qa/milestone-6000.json`.
- **Regressão exata:** quadros 0–4.999 idênticos à evidência v0.12 nas três métricas: framebuffer, WRAM e PC (`prefix-5000-to-6000.json`).
- **Limitação visual:** último quadro com alteração no framebuffer no replay principal: **4.952**. O quadro fica idêntico nos 1.047 quadros seguintes; de 5.000 a 5.999 a CPU troca de PC em 999 transições e a WRAM tem 1.000 hashes distintos. **Não** interpretar os 6.000 quadros como 6.000 quadros de gameplay contínuo.
- Capturas do replay principal em `QA-SCOOBY/v13-qa/capturas-5200-5990.png` mostram Shaggy e Scooby junto à porta, com o direcional Direito sendo segurado até o quadro 5.500. Trata-se de um aparente limite de movimento, não de prova formal de colisão correta.

## Teste alternativo: inversão de direção a partir do quadro 5.000

- Novo input: `tests/scooby-v13-door-reverse-left.input.trace`. Tudo antes do quadro 5.000 é idêntico ao replay padrão (188 eventos idênticos e a mesma ROM). Do quadro 5.000 ao 5.499, segura Esquerda, depois libera.
- Replay alternativo: **5.600 quadros**, exit=0. Primeira diferença WRAM **5.000**; primeira diferença visual **5.002**; **598/600 quadros** visualmente distintos entre 5.000–5.599 em comparação com o replay padrão.
- Capturas de 5.100, 5.300 e 5.590 (`reverse-left-5100-5590.png`) mostram Shaggy e Scooby se deslocando para a esquerda pelo corredor, demonstrando controle funcional após o trecho estático.
- Evidências: `door-input-prefix.json`, `door-direction-differential.json`, `reverse-5600.log`.

## Alterações em código e ferramental

- Forja65: novo `tools/replay-prefix-audit.js` com checagem exata do prefixo entre replays, contador de quadros adicionais e diagnóstico da última alteração visual. Novo teste `tests/replay-prefix-audit-v13-regression.js` (16 assertions).
- Scooby: `TESTAR-6000-QUADROS.cmd` e `TESTAR-CONTROLE-APOS-5000.cmd`; input de inversão; evidências, logs, capturas. O auditor anterior de marco permanece estrito: precisa detectar alguma mudança visual **desde 4.384**, mas o relatório separado registra que **não houve alteração no framebuffer após 5.000**.
- CPU decodificada permanece em **19.518 endereços**; não foram necessários novos destinos de CFG e a implementação da CPU/PPU não foi alterada nesta rodada.
- Regressões: **24/24 testes JavaScript direcionados** e **3/3 CTest nativos selecionados** aprovados. **Não** executada a suíte integral, nem compilado/testado `game.exe` Windows.

## Reproduzir

1. Extraia os pacotes Forja65 e Scooby em pastas irmãs, mantendo o nome de pasta interno.
2. Compile `Scooby-Native-PC/BUILD-WINDOWS.cmd` com as dependências documentadas no projeto.
3. Execute `TESTAR-6000-QUADROS.cmd` para comprovar 6.000 quadros e comparar os 5.000 originais. Execute `TESTAR-CONTROLE-APOS-5000.cmd` para repetir o teste alternativo de Esquerda. Ambos podem levar vários minutos.

## Pendências importantes

A primeira fase **não foi concluída**. Precisamos determinar se a porta é interativa/bloqueada, identificar os comandos/itens corretos e validar colisão com o SNES original, além de seguir os objetivos da fase. O port usa código CPU 65816 traduzido para C++ e ainda depende dos dados da ROM e de partes virtuais de PPU/DMA/SPC700. Ainda **não** contém um `game.exe` Windows pronto.
