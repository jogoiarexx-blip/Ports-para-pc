# Validação SPC700 DIV v0.21

- Teste novo de DIV: PASS, 67.108.864 combinações e 5 vetores fixos.
- SPC/APU: 14/16 testes passaram. Os dois que falharam exigem a família 0.3.x e já falham na base 0.4.19.
- Suíte completa: 170/208 passaram; 38 falharam.
- Cada um dos 38 testes com falha foi executado também no ZIP original v0.20: todos falharam no original. Não foi observada regressão nova nesta suíte.
- A suíte não está completamente verde. As falhas incluem dependência CMake ausente, restrições antigas de versão, cache de CFG e verificações de PPU/renderer. Esta entrega não altera esses componentes.
- Escopo: correção de DIV apenas em FORJA65_SPC_SEMANTICS=corrected. Comportamento legado preservado, inclusive sua temporização anterior.
- Nenhuma ROM real ou captura de áudio de jogo foi validada. Esta entrega não certifica o áudio completo.

## Logs

- SPC-DIV-v021-exhaustive.log: DIV e vetores fixos.
- SPC-DIV-v021-focused.log: 16 regressões SPC/APU.
- SPC-DIV-v021-full-suite.log: suíte geral atualizada.
- SPC-DIV-v021-baseline-failures.log e SPC-DIV-v021-baseline-results.json: reprodução das falhas no original.

## Testes com falha, também reproduzida no original

- cli-trace-framework-regression.js
- convergence-metadata-v0372-regression.js
- convergence-pipeline-regression.js
- cpu-ppu-v016-regression.js
- cross-game-cpu-flow-v028-regression.js
- dma-forensics-v0386-regression.js
- hd-integer-scale-v032-regression.js
- inline-indexed-table-v0312-regression.js
- instruction-mastercycles-v031-regression.js
- interrupt-stack-v039-regression.js
- local-computed-jump-run-v0311-regression.js
- long-controlflow-pb-v0314-regression.js
- master-cycle-irq-hdma-v029-regression.js
- native-dependency-audit-v0327-regression.js
- native-hardware-cutover-v0329-regression.js
- native-hardware-migration-v0328-regression.js
- native-host-foundation-v0322-regression.js
- native-oracle-v0350-regression.js
- native-scene-capture-v0323-regression.js
- obj-bank-v0380-regression.js
- obj-oam-order-v0389-regression.js
- oracle-runtime-learning-v0325-regression.js
- ppu-priority-hires-v027-regression.js
- ppu-sprite-row-regression.js
- renderer-timing-flow-v023-regression.js
- resumable-dispatch-v037-regression.js
- rom-mirror-spc-state-v038-regression.js
- runtime-progress-v035-regression.js
- snes9x-reference-v026-regression.js
- spc-port-isolation-v0313-regression.js
- stack-trampoline-summary-v0310-regression.js
- stackless-coroutine-regression.js
- state-aware-cfg-v022-regression.js
- state-summary-v036-regression.js
- subscanline-raster-v030-regression.js
- tail-vector-propagation-v0315-regression.js
- tetris-hardware-v0397-regression.js
- tetris-obj-crossfeed-v0398-regression.js
