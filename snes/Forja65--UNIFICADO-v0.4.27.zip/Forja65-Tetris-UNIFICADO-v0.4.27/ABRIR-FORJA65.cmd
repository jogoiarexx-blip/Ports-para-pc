@echo off
setlocal
cd /d "%~dp0Forja65"
call ABRIR-FORJA65.cmd
