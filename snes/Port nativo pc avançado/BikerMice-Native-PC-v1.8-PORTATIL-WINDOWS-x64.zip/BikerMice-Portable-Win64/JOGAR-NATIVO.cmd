@echo off
call "%~dp0JOGAR.cmd" --native-only
