@echo off
setlocal
cd /d "%~dp0"
for /f "tokens=1 delims==" %%V in ('set FORJA65_ 2^>nul') do set "%%V="
set "FORJA65_SPC_SEMANTICS=corrected"
set "FORJA65_HEADLESS=0"
set "FORJA65_UNCAPPED=0"
set "FORJA65_CPU_INTERPRETER=1"
if "%~1"=="--native-only" set "FORJA65_CPU_INTERPRETER=0"
game.exe
set "bikerExitCode=%errorlevel%"
if not "%bikerExitCode%"=="0" (
 echo O jogo registrou uma falha. Preserve os arquivos forja65-*.txt desta pasta.
 pause
)
endlocal & exit /b %bikerExitCode%
