@echo off
setlocal
rem DKC3-ZERO v0.74 portatil: jogar normalmente (janela, som, teclado ou controle).
rem O progresso fica em saves\save.srm (Wrinkly's Save Cave do jogo).
cd /d "%~dp0"
set FORJA65_EXECUTION=reference
set FORJA65_SPC_PROFILE=reference
set "FORJA65_SRAM_PATH=%~dp0saves\save.srm"
game.exe
if errorlevel 1 (echo. & echo O jogo encerrou com erro. & type forja65-last-error.txt 2>nul & pause)
