# DKC3-ZERO v0.74 — Relatório

## Corrigido
1. **Imagem piscando/sumindo com o filtro HD.** A janela era apagada para preto, o filtro HD rodava (8–14 ms ou mais) e só depois a imagem era desenhada, direto na tela: nesse intervalo aparecia preto. Agora o filtro roda primeiro e o quadro é montado fora da tela e copiado de uma vez. Vale também sem HD.
2. **Tecla F9** (jogo pausado ou não): salva `forja65-quadro-original.ppm` e `forja65-quadro-hd.ppm`. Serve para investigar a linha ciano vista no mapa do Krevice Kreepers: se ainda aparecer, mande os dois arquivos.
3. **Mundo 4:** 507 pontos aprendidos do seu log (88.997 quadros, 3,14% interpretado), 559 rotinas novas (u304). Mais 31 rotinas (u303) da sessão anterior. Retorno de pilha `B6E30C` verificado na ROM (vem após `JSL $B9E000`) incluído na tabela (3080 entradas).

## Regressão
Rota até o Arich, 119.960 quadros, salvar/carregar estado no meio, no Linux e no Wine (exe Windows): 28/28 marcos, 0 instruções interpretadas, `save.srm` idêntico. Teste em janela (Wine) com HD estilo 3: imagem estável nos 4 quadros capturados e F9 gravou os arquivos.

## Não verificado
Windows real; se a linha ciano é do filtro, do desenho do quadro ou do próprio jogo; o mundo 4 em diante no lado do port (só o aprendizado pelo seu log).
