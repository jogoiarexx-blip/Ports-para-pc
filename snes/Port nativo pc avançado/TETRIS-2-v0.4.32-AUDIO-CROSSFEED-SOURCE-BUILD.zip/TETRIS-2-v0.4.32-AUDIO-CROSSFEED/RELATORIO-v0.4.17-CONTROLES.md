# Tetris 2 v0.4.17 — Relatorio de gameplay

## Confirmado com jogo real

Testamos 5 execucoes deterministicas em Linux: baseline, LEFT, RIGHT, A (girar) e DOWN.
Todas executaram 1860 quadros sem erro. A primeira alteracao extra de controle foi no frame 1835, liberada em 1841.
No frame 1834, as 5 imagens eram identicas. Nos frames 1843, 1850 e 1860 houve diferenca exclusivamente na area da peca em queda.

| Entrada extra | Pixels diferentes no frame 1843 |
| --- | ---: |
| LEFT | 384 |
| RIGHT | 384 |
| A / rotate | 442 |
| DOWN | 512 |

O validador bloqueia a aprovacao quando nao encontra uma alteracao ou quando ha divergencia fora da area da peca. Exige tambem LEFT diferente de RIGHT e ROTATE diferente de DOWN.
**Interpretacao:** comprovada resposta visual da peca aos controles nesse trecho; direcao e orientacao observadas nas capturas. Nao e prova de colisoes, eliminacao de linhas, todas as rodadas ou equivalencia 1:1 ao SNES original.

## Testes de regressao

- CTest Tetris: 3/3 selecionados aprovados (gameplay_input_smoke, scene_timeline_smoke, gameplay_controls_qa_smoke).
- Gerador Forja65: 6/6 regressões selecionadas aprovadas (inputs, timeline, transicoes, controles, PPU/DMA, SPC700 registros).
- Runtime: v0.4.15 em Linux foi utilizado para os replays, cujo codigo de gameplay/hardware foi preservado nas v0.4.16 e v0.4.17; na v0.4.17 foram adicionados ferramentas/testes, nao mudancas nos algoritmos C++ do jogo.
- O executavel Windows NAO foi compilado nesta rodada. O ZIP nao inclui game.exe precompilado.

## Como repetir no Windows

1. BUILD-WINDOWS.cmd (gera bin\game.exe)
2. VALIDAR-CONTROLES-GAMEPLAY.cmd (requer Python 3)
3. Ver `validation\v0417-controls-qa\resultado-controles.json` e os PPM individuais.

## Pendencias

Colisoes com bordas/blocos, limpeza de linhas, pontuacao, derrota/vitoria, modo versus e fidelidade visual/sonora contra referencia SNES.
PPU/SPC700/DSP ainda possuem fallback de hardware no runtime; nao afirmar independencia completa de emulacao.
