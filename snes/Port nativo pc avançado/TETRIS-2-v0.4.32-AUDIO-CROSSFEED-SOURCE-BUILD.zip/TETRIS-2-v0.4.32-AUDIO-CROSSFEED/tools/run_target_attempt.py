#!/usr/bin/env python3
"""Replay a recorded playthrough, dump final WRAM, and check flashing targets.
No direct memory writes; the gameplay and target removal are performed by the port.
"""
import argparse,os,subprocess,sys,json
from pathlib import Path
from tetris2_target_qa import report

def main():
    ap=argparse.ArgumentParser(description='Reproduz a tentativa e conta os alvos piscantes')
    ap.add_argument('--game',required=True,type=Path)
    ap.add_argument('--cart',required=True,type=Path)
    ap.add_argument('--trace',required=True,type=Path)
    ap.add_argument('--frames',type=int,default=3000)
    ap.add_argument('--out',required=True,type=Path)
    a=ap.parse_args();a.game=a.game.resolve();a.cart=a.cart.resolve();a.trace=a.trace.resolve();a.out=a.out.resolve()
    if a.frames<=0:ap.error('numero de quadros invalido')
    if not a.game.is_file() or not a.cart.is_file() or not a.trace.is_file():ap.error('game, cart e trace devem existir')
    w=a.out;w.mkdir(parents=True,exist_ok=True);(w/'assets').mkdir(exist_ok=True)
    dest=w/'assets'/'cart-data.bin'
    if not dest.exists():
        import shutil;shutil.copyfile(a.cart,dest)
    env=os.environ.copy();env.update(FORJA65_HEADLESS='1',FORJA65_HEADLESS_FRAMES=str(a.frames),FORJA65_INPUT_REPLAY=str(a.trace),FORJA65_GAMEPLAY_RAM_FINAL=str(w/'wram-final.bin'))
    result=subprocess.run([str(a.game)],cwd=str(w),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (w/'replay.log').write_text(result.stdout,encoding='utf-8')
    print(result.stdout[-1500:])
    if result.returncode:
        print('ERRO: replay falhou. Logs em',w,file=sys.stderr);return result.returncode
    mem=w/'wram-final.bin'
    if not mem.exists():
        print('ERRO: executavel sem suporte FORJA65_GAMEPLAY_RAM_FINAL; recompilar versao v0.4.21',file=sys.stderr);return 3
    data=report(mem)
    (w/'targets.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (w/'board.txt').write_text(data['board']+'\n',encoding='utf-8')
    print('ALVOS RESTANTES:',data['remaining_flashing_targets'],'/ 3 no inicio da fase')
    for t in data['targets']:print(t)
    print('Tabuleiro salvo em',w/'board.txt')
    return 0
if __name__=='__main__':raise SystemExit(main())
