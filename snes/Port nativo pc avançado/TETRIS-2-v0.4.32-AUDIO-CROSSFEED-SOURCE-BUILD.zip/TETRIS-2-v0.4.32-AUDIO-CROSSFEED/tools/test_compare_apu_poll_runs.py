#!/usr/bin/env python3
"""Regression for run-length aware CPU/APU trace comparisons (no ROM needed)."""
import tempfile
from pathlib import Path
from compare_apu_ports import load

def test():
    with tempfile.TemporaryDirectory() as work:
        file=Path(work)/'trace.csv'
        file.write_text('sequence,master_cycles,spc_cycles,spc_pc,side,port,value,polls,last_master_cycles\n'
                        '1,100,22,65470,Q,0,170,11,130\n'
                        '# dropped=0 (timestamps are instruction-boundary approximations)\n'
                        '# cpu_reads=11,0,0,0\n', encoding='utf-8')
        events,dropped,reads,rle=load(file)
        assert events[0]['polls']==11 and events[0]['last_master_cycles']==130
        assert dropped==0 and reads==(11,0,0,0) and rle
        file.write_text('sequence,master_cycles,spc_cycles,spc_pc,side,port,value,polls,last_master_cycles,cpu_pc,last_cpu_pc\n'
                        '1,100,22,65470,Q,0,170,2,130,8431405,8431405\n# dropped=0\n', encoding='utf-8')
        events,dropped,reads,rle=load(file)
        assert rle and dropped==0 and events[0]['cpu_pc']==8431405
        assert events[0]['last_cpu_pc']==8431405 and events[0]['polls']==2
        file.write_text('sequence,master_cycles,spc_cycles,spc_pc,side,port,value\n'
                        '1,100,22,65470,Q,0,170\n# dropped=0\n', encoding='utf-8')
        events,dropped,reads,rle=load(file)
        assert events[0]['polls']==1 and events[0]['last_master_cycles']==100
        assert not rle
    print('COMPARE_APU_POLL_RUNS_PASS new_csv=1 legacy_csv=1')

if __name__=='__main__':test()
