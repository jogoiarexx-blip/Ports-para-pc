#!/usr/bin/env python3
"""Compare event order and approximate instruction-boundary timing of CPU/APU I/O."""
import csv
import sys
from pathlib import Path


def load(path):
    events=[]
    dropped=0
    has_poll_runs=False
    cpu_reads=None
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith('# dropped='):
            dropped=int(line.split('=',1)[1].split(' ',1)[0])
            continue
        if line.startswith('# cpu_reads='):
            cpu_reads=tuple(int(x) for x in line.split('=',1)[1].strip().split(','))
    with path.open(newline='', encoding='utf-8') as f:
        for event in csv.DictReader(f):
            if not event.get('sequence') or event['sequence'].startswith('#'):
                continue
            has_poll_runs=has_poll_runs or bool(event.get('polls'))
            events.append({**event, **{key:int(event[key]) for key in ('sequence','master_cycles','spc_cycles','spc_pc','port','value')},
                           'polls':int(event.get('polls') or 1),
                           'last_master_cycles':int(event.get('last_master_cycles') or event['master_cycles']),
                           'cpu_pc':int(event.get('cpu_pc') or 4294967295),
                           'last_cpu_pc':int(event.get('last_cpu_pc') or 4294967295)})
    return events,dropped,cpu_reads,has_poll_runs


def fmt(e):
    return f"{e['side']} port{e['port']}=${e['value']:02X} SPC_PC=${e['spc_pc']:04X} master={e['master_cycles']} spc_cycles={e['spc_cycles']}"


def main():
    if len(sys.argv) not in (1,3):
        print('Uso: python tools/compare_apu_ports.py [estavel.csv experimental.csv]')
        return 2
    paths=[Path(p) for p in sys.argv[1:]] if len(sys.argv)==3 else [Path('spc-capture-stable/apu-ports.csv'),Path('spc-capture-timing/apu-ports.csv')]
    if not all(p.is_file() for p in paths):
        print('Tracos ausentes. Ative FORJA65_APU_IPL_TRACE=1 antes de capturar:',*paths)
        return 2
    (a,da,ra,has_ra),(b,db,rb,has_rb)=[load(p) for p in paths]
    print('Port events: stable',len(a),'experimental',len(b),'dropped',da,db)
    if da or db:print('AVISO: captura truncada. Sequencia parcial; nao conclua equivalencia completa.')
    if ra is not None or rb is not None:
        print('CPU poll counts:', 'stable',ra,'experimental',rb)
    matching=0
    for ea,eb in zip(a,b):
        if (ea['side'],ea['port'],ea['value'])!=(eb['side'],eb['port'],eb['value']):break
        matching+=1
    if matching<min(len(a),len(b)):
        print('Primeira diferenca de sequencia no evento',matching+1)
        print('  Estavel:',fmt(a[matching]))
        print('  Experimental:',fmt(b[matching]))
    elif len(a)!=len(b):
        print('Sequencia comum coincide ate',matching,'eventos; comprimentos diferentes')
    else:
        print('Ordem e valores das mensagens coincidem em',matching,'eventos')
    # Q marks the observable value returned by a CPU-side port poll, not an SPC write.
    qa=[e for e in a if e['side']=='Q']
    qb=[e for e in b if e['side']=='Q']
    print('Observable CPU reads:',len(qa),'vs',len(qb))
    same_reads=0
    for ea,eb in zip(qa,qb):
        if (ea['port'],ea['value'])!=(eb['port'],eb['value']):break
        same_reads+=1
    # Values alone are insufficient: two modes can return the same sequence
    # after polling wildly different numbers of times. Compare the RLE runs.
    # Old v0.4.09 traces lack 'polls' and are interpreted as one event per run,
    # not as evidence of an equal number of raw polls.
    run_mismatch=next((i for i,(ea,eb) in enumerate(zip(qa,qb))
                       if ea['polls']!=eb['polls']),None) if has_ra and has_rb else None
    print('Recorded Q runs:',len(qa),'vs',len(qb),
          '| represented polls:',sum(e['polls'] for e in qa),
          'vs',sum(e['polls'] for e in qb))
    if not (has_ra and has_rb):
        print('Legacy trace without RLE: raw polling cadence is unknown.')
    if run_mismatch is not None:
        ea,eb=qa[run_mismatch],qb[run_mismatch]
        print('First CPU poll-count divergence at Q-run',run_mismatch+1,
              f"(port {ea['port']}, value ${ea['value']:02X}): stable",ea['polls'],'polls, experimental',eb['polls'],'polls')
        print('  Stable clock interval:',ea['master_cycles'],'..',ea['last_master_cycles'])
        print('  Experimental clock interval:',eb['master_cycles'],'..',eb['last_master_cycles'])
        if ea['cpu_pc'] != 4294967295 or eb['cpu_pc'] != 4294967295:
            print(f"  Polling CPU PCs: stable ${ea['cpu_pc']:06X}..${ea['last_cpu_pc']:06X}, experimental ${eb['cpu_pc']:06X}..${eb['last_cpu_pc']:06X}")
    elif qa and qb and has_ra and has_rb:
        print('Common Q-run poll counts equal across',min(len(qa),len(qb)),'runs')
    if same_reads<min(len(qa),len(qb)):
        print('First observable read divergence at Q-event',same_reads+1)
        print('  Estavel:',fmt(qa[same_reads]))
        print('  Experimental:',fmt(qb[same_reads]))
    elif len(qa)!=len(qb):
        print('Observable reads have the same common prefix but different lengths:',same_reads)
    elif qa:
        print('Observable CPU port values agree across',len(qa),'captured reads')
    else:
        print('No observable reads in this trace. Capture with FORJA65_APU_TRACE_READS=changes.')
    for i in range(min(12,matching)):
        ea,eb=a[i],b[i]
        delta=eb['spc_cycles']-ea['spc_cycles']
        if delta:
            print(f"Evento {i+1}: delta SPC={delta:+d} ciclos; {fmt(ea)} / {fmt(eb)}")
    print('OBS: tempo registrado no limite das instrucoes, nao no ciclo exato do barramento.')
    print('OBS: diferencas entre os modos nao determinam qual equivale ao SNES original.')
    return 0

if __name__=='__main__':raise SystemExit(main())
