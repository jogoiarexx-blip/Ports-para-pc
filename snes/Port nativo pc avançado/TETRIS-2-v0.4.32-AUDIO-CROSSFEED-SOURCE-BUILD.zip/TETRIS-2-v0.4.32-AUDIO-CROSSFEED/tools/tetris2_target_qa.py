#!/usr/bin/env python3
"""Tetris 2 / Forja65 WRAM board inspection (not a gameplay cheat).
Read-only extraction of the 11-word stride board at WRAM 7E:2000.
The special color targets carry type 0F and colors 41/42/43.
"""
import argparse
import json
from collections import deque
from pathlib import Path

OFFSET = 0x2000
ROWS = 23
COLUMNS = 10
STRIDE = 22
COLORS = {0x41: 'Y', 0x42: 'R', 0x43: 'B'}
NAMES = {'Y':'amarelo', 'R':'vermelho/rosa', 'B':'azul'}

def read_board(data: bytes):
    if len(data) != 0x20000:
        raise ValueError(f'Captura WRAM invalida: esperado 131072 bytes, recebido {len(data)}')
    board=[]
    for row in range(ROWS):
        sentinel = OFFSET+row*STRIDE
        if data[sentinel:sentinel+2] != b'\xff\xff':
            raise ValueError(f'WRAM nao parece conter tabuleiro do Tetris 2 na linha {row}')
        cells=[]
        for col in range(1,COLUMNS+1):
            i=sentinel+col*2
            typ,color=data[i:i+2]
            cells.append({'row':row,'column':col,'type':typ,'color_byte':color,
                          'color':COLORS.get(color), 'flashing':typ==0x0f and color in COLORS,
                          'occupied':(typ!=0 or color!=0) and typ!=0xff})
        board.append(cells)
    return board

def targets(board):
    return [{'row':cell['row'],'column':cell['column'], 'color':NAMES[cell['color']]}
            for row in board for cell in row if cell['flashing']]

def color_groups(board):
    used=set();res=[]
    for row in range(22):
        for col in range(COLUMNS):
            c=board[row][col]
            if not c['color'] or (row,col) in used or not c['occupied']:
                continue
            queue=deque([(row,col)]);used.add((row,col));members=[];has_target=False
            while queue:
                y,x=queue.popleft();v=board[y][x]
                members.append({'row':y,'column':x+1});has_target |= v['flashing']
                for yy,xx in [(y-1,x),(y+1,x),(y,x-1),(y,x+1)]:
                    if 0<=yy<22 and 0<=xx<COLUMNS and (yy,xx) not in used:
                        other=board[yy][xx]
                        if other['occupied'] and other['color']==c['color']:
                            queue.append((yy,xx));used.add((yy,xx))
            if len(members)>=2 or has_target:
                res.append({'color':NAMES[c['color']], 'size':len(members), 'flashing_in_group':has_target, 'cells':members})
    return res

def line_matches(board, min_length=3):
    """Actual Tetris 2 rule: contiguous same-color HORIZONTAL or VERTICAL lines."""
    found=[]
    for direction, dr, dc in [('horizontal',0,1), ('vertical',1,0)]:
        for row in range(22):
            for col in range(COLUMNS):
                start=board[row][col]
                if not (start['occupied'] and start['color']):
                    continue
                pr,pc=row-dr,col-dc
                if 0<=pr<22 and 0<=pc<COLUMNS:
                    previous=board[pr][pc]
                    if previous['occupied'] and previous['color']==start['color']:
                        continue
                cells=[]
                r,c=row,col
                while 0<=r<22 and 0<=c<COLUMNS:
                    cell=board[r][c]
                    if not cell['occupied'] or cell['color']!=start['color']:break
                    cells.append(cell)
                    r+=dr;c+=dc
                if len(cells)>=min_length:
                    found.append(dict(color=NAMES[start['color']],direction=direction,length=len(cells),
                            flashes=sum(int(cell['flashing']) for cell in cells),
                            cells=[{'row':v['row'],'column':v['column']} for v in cells]))
    return found

def target_line_opportunities(board):
    """Identify exact 3-cell lines through a flashing target, not just connected blobs.
    These are goals, not guaranteed reachable move placements: piece physics, support
    and collision must still be validated in a real replay.
    """
    result=[]
    for target in (cell for row in board[:22] for cell in row if cell['flashing']):
        possibilities=[]
        for direction,dr,dc in [('horizontal',0,1),('vertical',1,0)]:
            for position in range(3):
                r0=target['row']-position*dr
                c0=target['column']-position*dc
                coords=[(r0+k*dr,c0+k*dc) for k in range(3)]
                if any(not(0<=r<22 and 1<=c<=10) for r,c in coords):continue
                same=[];empty=[];blocked=[]
                for r,c in coords:
                    cell=board[r][c-1]
                    xy={'row':r,'column':c}
                    if not cell['occupied']:empty.append(xy)
                    elif cell['color']==target['color']:same.append(xy)
                    else:blocked.append(xy)
                if not blocked:
                    possibilities.append({'direction':direction,'already_matching':len(same),
                        'missing':len(empty),'empty_cells':empty,'coordinates':[{'row':r,'column':c} for r,c in coords]})
        possibilities.sort(key=lambda v:(v['missing'],v['direction']!='vertical'))
        result.append({'target':{'row':target['row'],'column':target['column'],'color':NAMES[target['color']]},
                       'lines':possibilities[:8]})
    return result

def display(board):
    out=['colunas: '+''.join(f'{x:>3}' for x in range(1,11))]
    for i,row in enumerate(board):
        parts=[]
        for c in row:
            if not c['occupied']:ch=' .'
            elif c['flashing']:ch='*'+c['color']
            elif c['color']:ch=' '+c['color']
            else:ch=' ?'
            parts.append(ch)
        out.append(f'{i:02d}:  '+''.join(' '+c for c in parts))
    return '\n'.join(out)

def report(path:Path):
    board=read_board(path.read_bytes());star=targets(board);groups=color_groups(board)
    unknown=sum(1 for row in board[:22] for c in row if c['occupied'] and c['color'] is None)
    board_looks_active = unknown < 8
    return {'capture':str(path), 'remaining_flashing_targets':len(star),
            'targets':star,'same_color_groups_not_line_matches':groups, 'line_matches':line_matches(board), 'target_line_opportunities':target_line_opportunities(board),
            'cleared_all_flashing_targets':not bool(star) and board_looks_active, 'unrecognized_gameplay_cells':unknown,
            'board_looks_active':board_looks_active,
            'zero_targets_during_active_board':board_looks_active and not bool(star),
            'zero_targets_requires_scene_confirmation':not bool(star),
            'board':display(board)}

def main():
    ap=argparse.ArgumentParser(description='Inspeciona alvos piscantes nas capturas reais da WRAM do Tetris 2')
    ap.add_argument('capture', nargs='+', type=Path,help='Arquivos WRAM de 128 KiB')
    ap.add_argument('--json',type=Path,help='Caminho para salvar relatorio JSON')
    args=ap.parse_args();reports=[report(f) for f in args.capture]
    for r in reports:
        print('\nCAPTURA:',r['capture']);print('ALVOS PISCANTES RESTANTES:',r['remaining_flashing_targets'])
        for t in r['targets']:print(f"  {t['color']}: linha={t['row']} coluna={t['column']}")
        print(r['board'])
        print('VITORIA_POR_ALVOS:', 'SIM' if r['cleared_all_flashing_targets'] else 'NAO')
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True)
        args.json.write_text(json.dumps(reports,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return 0
if __name__=='__main__':
    raise SystemExit(main())
