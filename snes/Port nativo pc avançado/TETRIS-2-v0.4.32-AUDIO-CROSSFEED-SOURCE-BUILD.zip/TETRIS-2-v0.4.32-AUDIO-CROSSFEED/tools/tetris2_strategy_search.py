#!/usr/bin/env python3
"""Reproducible REAL replay exploration; never changes game memory or forces victory.
Requires the executable compiled from this package. Each candidate is replayed
from the title screen, so a successful result is a genuinely executed match.
"""
import argparse, concurrent.futures, json, os, shutil, subprocess, sys, time
from pathlib import Path
from tetris2_target_qa import report

def load_input(path):
    lines=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.strip().startswith('frame='):
            pairs=dict(t.split('=',1) for t in line.split())
            lines.append((int(pairs['frame']), int(pairs['joy1'],16),int(pairs['joy2'],16)))
    return lines

def generate(traces, directory):
    before=[entry for entry in traces if entry[0]<1750]
    # Actions: A=0x0080; B=0x8000; left=0x0200; right=0x0100; down=0x0400.
    actions={'straight':[], 'left_8':[(1750,0x0200),(1758,0)],
      'left_18':[(1750,0x0200),(1768,0)],'right_8':[(1750,0x0100),(1758,0)],
      'right_18':[(1750,0x0100),(1768,0)],'rotate_A':[(1750,0x0080),(1754,0)],
      'rotate_B':[(1750,0x8000),(1754,0)],
      'rotate_right':[(1750,0x0080),(1754,0),(1756,0x0100),(1772,0)]}
    jobs={}
    for name, events in actions.items():
        path=directory/(name+'.txt')
        entries=before+[(f,b,0) for f,b in events]+[(1780,0x0400,0),(2260,0,0)]
        entries.sort(key=lambda p:p[0]); assert len(set(f for f,_,_ in entries))==len(entries)
        path.write_text('# Tetris 2 candidate '+name+'\n'+''.join(f'frame={f} joy1={b:04x} joy2={b2:04x}\n' for f,b,b2 in entries),encoding='utf-8')
        jobs[name]=path
    return jobs

def play(args, job, out):
    name,inputs=job;directory=out/name;directory.mkdir(parents=True,exist_ok=True)
    assets=directory/'assets';assets.mkdir(exist_ok=True)
    cart=assets/'cart-data.bin'
    if not cart.exists():shutil.copy2(args.cart,cart)
    env=os.environ.copy();env.update(FORJA65_HEADLESS='1',FORJA65_HEADLESS_FRAMES=str(args.frames),FORJA65_INPUT_REPLAY=str(inputs),
         FORJA65_GAMEPLAY_RAM_FINAL=str(directory/'wram.bin'),FORJA65_TARGET_PROGRESS_CSV=str(directory/'targets-progress.csv'))
    start=time.monotonic()
    try:
        p=subprocess.run([str(args.game)],cwd=directory,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=args.timeout)
        (directory/'run.log').write_text(p.stdout,encoding='utf-8')
        result={'candidate':name,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,2)}
        if p.returncode==0 and (directory/'wram.bin').is_file():
            r=report(directory/'wram.bin')
            result['remaining_flashing_targets']=r['remaining_flashing_targets']
            result['remaining_colors']=[t['color'] for t in r['targets']]
            result['board_file']=str(directory/'board.txt')
            (directory/'board.txt').write_text(r['board']+'\n',encoding='utf-8')
            result['line_matches']=r['line_matches']
            result['board_looks_active']=r['board_looks_active']
            result['unrecognized_gameplay_cells']=r['unrecognized_gameplay_cells']
        else:result['error']=p.stdout[-450:]
        return result
    except subprocess.TimeoutExpired:
        return {'candidate':name,'error':'timeout','seconds':round(time.monotonic()-start,2)}

def main():
    ap=argparse.ArgumentParser(description='Explora replays da primeira fase e mede alvos que realmente sumiram')
    ap.add_argument('--game',type=Path,required=True);ap.add_argument('--cart',type=Path,required=True)
    ap.add_argument('--baseline',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--frames',type=int,default=2400);ap.add_argument('--workers',type=int,default=2)
    ap.add_argument('--timeout',type=int,default=180)
    args=ap.parse_args()
    for k in ('game','cart','baseline'):
        p=getattr(args,k).resolve()
        if not p.is_file():ap.error(f'arquivo ausente: {p}')
        setattr(args,k,p)
    args.out=args.out.resolve();args.out.mkdir(parents=True,exist_ok=True)
    jobs=generate(load_input(args.baseline),args.out)
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(args.workers,8))) as pool:
        for r in pool.map(lambda job:play(args,job,args.out),jobs.items()):
            results.append(r)
            print(f"{r['candidate']}: {r.get('remaining_flashing_targets','ERRO')} alvo(s) restante(s), {r['seconds']}s",flush=True)
    results.sort(key=lambda r:(r.get('remaining_flashing_targets',999) if r.get('board_looks_active',False) else 998,r.get('exit_code',99),r['seconds']))
    (args.out/'ranking.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Melhor tentativa:',json.dumps(results[0],ensure_ascii=False))
    print('AVISO: zero alvos com tabuleiro invalido pode indicar troca de cena, derrota ou vitoria; confirmar imagem.')
    return 0 if any(r.get('exit_code')==0 for r in results) else 2
if __name__=='__main__':raise SystemExit(main())
