#!/usr/bin/env python3
"""Compare no-input and deterministic input runs. Never claim a level was finished."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HASH_RE = re.compile(r"^frame=(\d+) framebuffer=([0-9a-f]+) wram=([0-9a-f]+) pc=([0-9a-f]+)$")


def parse_trace(path):
    events = []
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith(("#", ";")):
            continue
        fields = dict(part.split("=", 1) for part in line.split())
        if set(fields) != {"frame", "joy1", "joy2"}:
            raise ValueError(f"{path}:{n}: expected frame, joy1, joy2")
        item = (int(fields["frame"], 10), int(fields["joy1"], 16), int(fields["joy2"], 16))
        if any(x < 0 or x > 65535 for x in item[1:]):
            raise ValueError(f"{path}:{n}: button state out of range")
        if events and item[0] <= events[-1][0]:
            raise ValueError(f"{path}:{n}: frames must be increasing")
        events.append(item)
    if not events:
        raise ValueError(f"No commands in {path}")
    return events


def parse_hashes(path):
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        m = HASH_RE.fullmatch(line.strip())
        if not m:
            raise ValueError(f"Unexpected frame hash: {line!r}")
        rows.append((int(m[1]), m[2], m[3], m[4]))
    if not rows or any(row[0] != i for i, row in enumerate(rows)):
        raise ValueError(f"Non-sequential or empty frame hashes in {path}")
    return rows


def execute_game(game, output, frames, trace, timeout):
    output.mkdir(parents=True, exist_ok=True)
    target = output / "forja65-frame-hashes.txt"
    target.unlink(missing_ok=True)
    observed = output / "recorded-input.trace"
    observed.unlink(missing_ok=True)
    cwd = game.parent
    env = os.environ.copy()
    env.update(FORJA65_HEADLESS="1", FORJA65_UNCAPPED="1",
               FORJA65_HEADLESS_FRAMES=str(frames), FORJA65_FRAME_HASHES="1",
               FORJA65_FRAME_HASH_PATH=str(target), FORJA65_WATCHDOG_INSTRUCTIONS="500000000")
    env.pop("FORJA65_INPUT_REPLAY", None)
    env.pop("FORJA65_INPUT_RECORD", None)
    if trace is not None:
        env["FORJA65_INPUT_REPLAY"] = str(trace)
        env["FORJA65_INPUT_RECORD"] = str(observed)
    try:
        process = subprocess.run([str(game)], cwd=cwd, env=env, text=True,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 timeout=timeout)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"Game timeout after {timeout}s: {exc}") from exc
    (output / "runtime.log").write_text(process.stdout, encoding="utf-8")
    for source_name in ("forja65-qa-status.txt", "forja65-last-error.txt"):
        source = cwd / source_name
        if source.exists():
            shutil.copy2(source, output / source_name)
    if process.returncode:
        raise RuntimeError(f"Game exit {process.returncode}; see {output / 'runtime.log'}")
    rows = parse_hashes(target)
    if len(rows) != frames:
        raise RuntimeError(f"Replay stopped at {len(rows)}, expected {frames} frames")
    return rows


def compare(base, scenario, events, recorded):
    if len(base) != len(scenario):
        raise ValueError("Frame count differs")
    first_active = min((frame for frame, a, b in events if a or b), default=None)
    if first_active is None:
        raise ValueError("Input file has no button press")
    observed = parse_trace(recorded)
    states = []
    current = (0, 0)
    cursor = 0
    for frame in range(len(base)):
        while cursor < len(events) and events[cursor][0] <= frame:
            current = events[cursor][1:]; cursor += 1
        states.append((frame, *current))
    if observed[:len(states)] != states:
        raise ValueError("Runtime did not record the requested controls")
    keys = ("framebuffer", "wram", "pc")
    first = {key: None for key in keys}
    count = {key: 0 for key in keys}
    unique_frames = len({r[1] for r in scenario})
    for a, b in zip(base, scenario):
        for i, key in enumerate(keys, 1):
            if a[i] != b[i]:
                count[key] += 1
                if first[key] is None:
                    first[key] = a[0]
    early = [key for key, value in first.items() if value is not None and value < first_active]
    changed = any(n > 0 for n in count.values())
    return {"frames":len(base), "first_pressed_frame":first_active,
            "first_difference":first, "different_frames":count,
            "distinct_framebuffer_hashes":unique_frames,
            "pre_input_mismatch":early, "input_affected_runtime":changed,
            "proof_of_gameplay_completion":False}


def main():
    parser = argparse.ArgumentParser(description="Gameplay input A/B verification")
    parser.add_argument("--game", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--frames", type=int, default=2000)
    parser.add_argument("--output", type=Path, default=Path("validation/gameplay-ab"))
    parser.add_argument("--timeout", type=int, default=600)
    args = parser.parse_args()
    game = args.game.resolve(strict=True)
    trace = args.inputs.resolve(strict=True)
    output = args.output.resolve()
    events = parse_trace(trace)
    if args.frames <= max(x[0] for x in events if x[1] or x[2]):
        raise ValueError("Frame limit is shorter than input script")
    baseline = execute_game(game, output / "baseline", args.frames, None, args.timeout)
    scripted = execute_game(game, output / "controls", args.frames, trace, args.timeout)
    result = compare(baseline, scripted, events, output / "controls" / "recorded-input.trace")
    result["scenario"] = str(trace)
    result["reference"] = "same native runtime without controller inputs (not original SNES)"
    (output / "report.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if result["pre_input_mismatch"]:
        print("FAIL: states differ before any button press", file=sys.stderr)
        return 2
    if not result["input_affected_runtime"]:
        print("FAIL: controller input produced no observed change", file=sys.stderr)
        return 3
    print("PASS: input affected the native runtime; actual menu/level completion is not yet proven")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, ValueError) as exc:
        print(f"GAMEPLAY_QA_ERROR: {exc}", file=sys.stderr)
        sys.exit(2)
