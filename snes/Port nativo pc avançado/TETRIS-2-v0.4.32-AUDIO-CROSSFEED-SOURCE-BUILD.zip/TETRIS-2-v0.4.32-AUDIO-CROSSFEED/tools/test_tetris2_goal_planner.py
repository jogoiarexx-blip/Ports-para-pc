#!/usr/bin/env python3
import unittest
from tetris2_target_qa import line_matches,target_line_opportunities,read_board,report
class Tetris2GoalTests(unittest.TestCase):
    def make_board(self):
        data=bytearray(0x20000)
        for row in range(23):data[0x2000+row*22:0x2000+row*22+2]=b'\xff\xff'
        def cell(row,col,typ,color):data[0x2000+row*22+col*2:0x2000+row*22+col*2+2]=bytes([typ,color])
        cell(20,7,4,0x41);cell(20,8,15,0x41);cell(21,7,5,0x41);cell(20,9,15,0x42)
        return data,cell
    def test_L_not_valid_match(self):
        data,_=self.make_board();self.assertEqual(line_matches(read_board(data)),[])
    def test_three_horizontal_valid(self):
        data,cell=self.make_board();cell(20,6,8,0x41)
        matches=line_matches(read_board(data))
        self.assertEqual(len(matches),1)
        self.assertEqual(matches[0]['direction'],'horizontal')
        self.assertEqual(matches[0]['flashes'],1)
    def test_opportunity_one_missing_cell(self):
        data,_=self.make_board();lines=target_line_opportunities(read_board(data))
        self.assertEqual(lines[0]['lines'][0]['missing'],1)
        self.assertIn({'row':20,'column':6},lines[0]['lines'][0]['empty_cells'])
    def test_three_vertical(self):
        data,cell=self.make_board();cell(19,8,8,0x41);cell(18,8,8,0x41)
        self.assertTrue(any(m['direction']=='vertical' and m['flashes']==1 for m in line_matches(read_board(data))))
    def test_blocked_opportunity(self):
        data,cell=self.make_board();cell(20,6,8,0x42)
        lines=target_line_opportunities(read_board(data))
        self.assertFalse(any(p['direction']=='horizontal' and p['missing']==1 for p in lines[0]['lines']))
    def test_game_over_not_win(self):
        from pathlib import Path
        from tetris2_target_qa import report
        evidence=Path(__file__).resolve().parent.parent/'validation'/'v0422-search'/'gameover-straight-3000.bin'
        state=report(evidence)
        self.assertEqual(state['remaining_flashing_targets'],0)
        self.assertFalse(state['board_looks_active'])
        self.assertFalse(state['cleared_all_flashing_targets'])
    def test_strict_wram_length(self):
        with self.assertRaises(ValueError):read_board(b'\0'*12)
if __name__=='__main__':unittest.main()
