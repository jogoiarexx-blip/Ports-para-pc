"""Standalone tests for the read-only board decoder."""
import tempfile
import unittest
from pathlib import Path
from tetris2_target_qa import OFFSET,STRIDE,read_board,targets,color_groups,report

class BoardTests(unittest.TestCase):
    def make(self):
        data=bytearray(0x20000)
        for row in range(23):
            i=OFFSET+row*STRIDE
            data[i:i+2]=b'\xff\xff'
        return data
    def cell(self,b,row,col,typ,color):
        i=OFFSET+row*STRIDE+2*col;b[i:i+2]=bytes([typ,color])
    def test_target_detection(self):
        b=self.make();self.cell(b,20,2,15,0x43);self.cell(b,20,8,15,0x41);self.cell(b,20,9,15,0x42)
        star=targets(read_board(b));self.assertEqual(len(star),3)
        self.assertEqual([x['color'] for x in star],['azul','amarelo','vermelho/rosa'])
    def test_no_false_win_on_flash_animation(self):
        b=self.make();self.cell(b,20,8,15,0x41);self.cell(b,19,8,1,0x41)
        board=read_board(b); self.assertEqual(len(targets(board)),1)
        self.assertEqual(len(color_groups(board)),1)
        self.assertEqual(color_groups(board)[0]['size'],2)
    def test_absent_targets(self):
        b=self.make();self.assertEqual(targets(read_board(b)),[])
    def test_non_board_rejected(self):
        with self.assertRaises(ValueError):read_board(bytes(0x20000))
        with self.assertRaises(ValueError):read_board(bytes(12))
    def test_real_capture(self):
        f=Path(__file__).parents[1]/'validation/ram-evidencias/no1843.bin'
        self.assertEqual(report(f)['remaining_flashing_targets'],3)
if __name__=='__main__':unittest.main()
