#!/usr/bin/env python3
"""Compare two raw SPC RAM snapshots created by the Forja65 frame capture."""
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) not in (1, 3):
        print('Uso: python tools/compare_spc_snapshots.py [pasta_modo_estavel pasta_modo_experimental]')
        return 2
    roots = [Path(x) for x in sys.argv[1:]] if len(sys.argv) == 3 else [Path('spc-capture-stable'), Path('spc-capture-timing')]
    blobs = []
    for root in roots:
        src = root / 'spc-ram.bin'
        if not src.is_file():
            print('Arquivo ausente:', src)
            return 2
        data = src.read_bytes()
        if len(data) != 65536:
            print('SPC RAM deveria ter 65536 bytes:', src, len(data))
            return 2
        blobs.append(data)
        manifest = root / 'spc-capture.txt'
        if manifest.is_file():
            details = dict(line.split('=', 1) for line in manifest.read_text().splitlines() if '=' in line)
            print(root, 'PC:', details.get('pc', '?'), 'A:', details.get('a', '?'), 'X:', details.get('x', '?'), 'Y:', details.get('y', '?'))
    changes = [i for i, (a, b) in enumerate(zip(*blobs)) if a != b]
    print('Bytes SPC RAM diferentes:', len(changes))
    for idx in changes[:50]:
        print(f'  ${idx:04X}  ${blobs[0][idx]:02X} -> ${blobs[1][idx]:02X}')
    if len(changes) > 50:
        print('... restantes omitidos:', len(changes)-50)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
