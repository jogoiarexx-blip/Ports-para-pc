@echo off
setlocal
cd /d "%~dp0"
if exist bin\game.exe cd bin
if not exist game.exe (
  echo Compile o jogo primeiro com BUILD-WINDOWS.cmd
  pause
  exit /b 1
)
set FORJA65_APU_IPL_TRACE=1
rem 0.4.09: record only changed values actually seen by CPU, not every repeated poll.
set FORJA65_APU_TRACE_READS=window
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=60
set FORJA65_CAPTURE_SPC_FRAME=59
set FORJA65_CAPTURE_SPC_STOP=1
set FORJA65_SPC_SEMANTICS=
set FORJA65_SPC_TIMING=
set FORJA65_SPC_CLOCK=
set FORJA65_CAPTURE_SPC_DIR=spc-capture-stable
if exist "%FORJA65_CAPTURE_SPC_DIR%" rmdir /S /Q "%FORJA65_CAPTURE_SPC_DIR%"
echo Capturando SPC700 estavel no quadro 59...
game.exe
if errorlevel 1 goto :error
set FORJA65_SPC_TIMING=accurate
set FORJA65_CAPTURE_SPC_DIR=spc-capture-timing
if exist "%FORJA65_CAPTURE_SPC_DIR%" rmdir /S /Q "%FORJA65_CAPTURE_SPC_DIR%"
echo Capturando SPC700 experimental no quadro 59...
game.exe
if errorlevel 1 goto :error
where py >nul 2>&1
if not errorlevel 1 (
  py -3 tools\compare_spc_snapshots.py
) else (
  python tools\compare_spc_snapshots.py
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 tools\compare_apu_ports.py
) else (
  python tools\compare_apu_ports.py
)
rem Capture optional rational NTSC SPC timing as a third independent comparison.
set FORJA65_SPC_CLOCK=ntsc
set FORJA65_CAPTURE_SPC_DIR=spc-capture-ntsc
if exist "%FORJA65_CAPTURE_SPC_DIR%" rmdir /S /Q "%FORJA65_CAPTURE_SPC_DIR%"
echo Capturando SPC700 com clock NTSC racional no quadro 59...
game.exe
if errorlevel 1 goto :error
where py >nul 2>&1
if not errorlevel 1 (
  py -3 tools\compare_apu_ports.py spc-capture-timing\apu-ports.csv spc-capture-ntsc\apu-ports.csv
) else (
  python tools\compare_apu_ports.py spc-capture-timing\apu-ports.csv spc-capture-ntsc\apu-ports.csv
)
echo.
echo Capturas guardadas em spc-capture-stable e spc-capture-timing.
pause
exit /b 0
:error
echo Falha no processo de captura.
pause
exit /b 1
