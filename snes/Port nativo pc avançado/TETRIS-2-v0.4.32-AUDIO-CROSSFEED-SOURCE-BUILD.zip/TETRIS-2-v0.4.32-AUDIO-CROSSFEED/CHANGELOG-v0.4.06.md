# Tetris 2 v0.4.06 — Temporizacao SPC700

Importante: a v0.4.05 fica como modo padrao estavel. Para testar a nova temporizacao execute `RUN-SPC-TIMING-EXPERIMENTAL.cmd` ou defina `FORJA65_SPC_TIMING=accurate`. No replay de 2.000 quadros o modo experimental diverge a partir do quadro 59 na CPU e mais tarde no video e na WRAM; o teste nao define qual lado e fiel ao SNES.

Implementado:
- `kSpcOpcodeCycles[256]`: custo nominal de cada opcode em ciclos SPC700.
- +2 ciclos ao desvio condicional tomado (incluindo deslocamento zero); BRA mantem ciclo fixo.
- `forja65AdvanceSpcTimers`: temporizadores utilizam custo real da instrucao, em vez de 4 ciclos artificiais por passo.
- Divisor de base T0/T1 de 128 ciclos e T2 de 16 ciclos permanece ativo enquanto o timer estiver desligado.
- Stage2 passa a contar em 8 bits e respeitar alvo 0 como 256 ticks.
- Scheduler mantem credito/divida de ciclos entre fatias de 65816, com 21 clocks master nominais por ciclo SPC700.
- Teste `spc_cycle_timers_smoke` cobrindo instrucoes curtas/longas, branches, timers, leitura do latch e scheduler.
- A mesma correcao incorporada ao gerador Forja65 v0.4.05.

AVISO: Ainda nao e emulacao cycle-exact: bus accesses ocorrem durante o passo da instrucao; clock do APU e nominal, DSP continua simplificado. Mudancas na musica/comunicacao CPU-APU podem alterar o replay. Equivalencia de PCM com o SNES original nao foi testada. Nenhum modo completo do jogo foi certificado.

Fontes tecnicas:
- https://snes.nesdev.org/wiki/SPC-700_instruction_set
- https://snes.nesdev.org/wiki/S-SMP
- https://wiki.superfamicom.org/timing
- Tabela de ciclos historica: https://sources.debian.org/src/snes9x/1.26-1/globals.cpp
