@echo off
setlocal
cd /d "%~dp0"
set "GAME=%~dp0bin\game.exe"
set "CART=%~dp0bin\assets\cart-data.bin"
if not exist "%GAME%" (set "GAME=%~dp0game.exe" & set "CART=%~dp0assets\cart-data.bin")
if not exist "%GAME%" (echo Compile com BUILD-WINDOWS.cmd primeiro & pause & exit /b 2)
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
%PY% tools\tetris2_strategy_search.py --game "%GAME%" --cart "%CART%" --baseline "%~dp0validation\input-primeira-fase-alvos.txt" --out "%~dp0validation\busca-alvos" --frames 2400 --workers 2
if errorlevel 1 echo Nao foi possivel completar as tentativas. Verifique os logs.
echo Resultado: validation\busca-alvos\ranking.json
pause
