# Correção MSVC C2280 (testes SPC700)

Base: TETRIS-2-v0.4.31-DSP-SPC-INTERLEAVE.zip

Correção: três testes criavam `ApuBridge` em uma função auxiliar e retornavam por valor. Isso exigia copiar ou mover `ApuBridge`, mas seu membro `PcmAudioOutput` proíbe cópia e impede o construtor de cópia implícito. O MSVC apresentava C2280.

Arquivos ajustados:
- `tests/spc_cycle_timers_smoke.cpp`
- `tests/spc_semantics_smoke.cpp`
- `tests/spc_strict_scheduler_smoke.cpp`

Agora cada teste constrói `ApuBridge` localmente e passa uma referência para a função de configuração, sem cópia e sem alterar `runtime.hpp` nem o DSP.

Para compilar no Windows: extraia em nova pasta, execute `BUILD-WINDOWS.cmd`, depois `RUN-WINDOWS-AUDIO.cmd`. A verificação Windows/MSVC requer execução no computador com MSVC; a validação automática Linux está descrita na conversa.
