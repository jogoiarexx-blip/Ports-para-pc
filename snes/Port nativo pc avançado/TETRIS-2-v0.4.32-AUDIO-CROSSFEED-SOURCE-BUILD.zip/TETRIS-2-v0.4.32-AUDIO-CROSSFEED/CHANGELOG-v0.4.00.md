# Tetris 2 v0.4.00 — regras HDMA e registro $420C

- HDMA: descritor de tabela `$80` agora representa 128 linhas com uma única transferência; `$81` até `$FF` transferem a cada linha. Antes, o bit 7 era interpretado isoladamente, fazendo `$80` repetir 128 vezes indevidamente.
- HDMA: escrita em `$420C` no meio do quadro preserva os registradores `A2A` e `NTRL` pré-configurados pelo jogo. A inicialização normal continua em `startHdmaFrame()` no início do quadro.
- Mantidos CPU 65C816, PPU, DMA, SPC700/DSP e todas as correções OAM já integradas na v0.3.99.
- Novo teste `tests/hdma_descriptor_smoke.cpp`, incluído em CMake/CTest e `TESTAR-HARDWARE.cmd`.
- `forja-tooling/forja65-core.js` atualizado para manter o gerador embutido no jogo sincronizado com o pacote Forja65 novo.

## Execução e limites

- CMake em Linux: compilação completa do jogo e dos targets de testes, sem erros.
- CTest: 11 aprovados de 12 entradas; `equivalence_vectors` ignorado, sem vetor externo.
- Regressão Forja65 com projeto gerado de ROM sintética: PASS.
- Replay de 2.000 quadros com `validation/input-normal.txt`: concluído e **0 diferenças** de hashes de framebuffer, WRAM e PC contra o replay arquivado v0.3.99.
- O replay **não executou transferências HDMA** (`hdma_bytes=0`), portanto a alteração de HDMA é validada pelos testes sintéticos, não pelo fluxo normal de gameplay.
- Ainda não foi confrontado contra uma captura pixel-a-pixel de hardware SNES real. Não conclui todas as fases/modos. Sem `game.exe` Windows pré-compilado.
