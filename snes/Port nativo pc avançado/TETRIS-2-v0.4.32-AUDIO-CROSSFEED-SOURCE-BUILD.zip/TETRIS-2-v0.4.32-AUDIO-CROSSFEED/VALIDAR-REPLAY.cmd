@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3 nao encontrado. & exit /b 1)
set "SCENARIO=%~1"
if "%SCENARIO%"=="" set "SCENARIO=validation\input-normal.txt"
if not exist "%SCENARIO%" (echo Roteiro nao encontrado: %SCENARIO% & exit /b 2)
set "FRAMES=%~2"
if "%FRAMES%"=="" set "FRAMES=2000"
if exist bin\game.exe (set "GAME=bin\game.exe") else if exist game.exe (set "GAME=game.exe") else (echo Execute BUILD-WINDOWS.cmd primeiro. & exit /b 1)
python tools\validate_gameplay_replay.py --game "%GAME%" --inputs "%SCENARIO%" --frames %FRAMES% --output "validation\gameplay-ab"
exit /b %ERRORLEVEL%
