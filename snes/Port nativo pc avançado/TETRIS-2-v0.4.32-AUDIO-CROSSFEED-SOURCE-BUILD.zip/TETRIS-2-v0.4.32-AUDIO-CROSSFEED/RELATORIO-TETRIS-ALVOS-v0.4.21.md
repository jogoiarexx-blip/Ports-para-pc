# Tetris 2 v0.4.21 — instrumentação de alvos da primeira fase

## Diagnóstico

A WRAM do Tetris 2 contém o tabuleiro em `$7E:2000` (linhas de 22 bytes, células de 2 bytes, 10 colunas jogáveis). As células piscantes são identificadas pelo byte de tipo `0x0F`; no estágio analisado, as cores são `0x43` (azul), `0x41` (amarelo) e `0x42` (rosa/vermelho). Foi possível conferir os valores com a imagem real da primeira fase.

Os três alvos do estágio inicial aparecem em (linha 20, coluna 2, azul), (linha 20, coluna 8, amarelo) e (linha 20, coluna 9, rosa). Os roteiros exploratórios registrados em `validation/` NÃO comprovaram vitória: o contador permaneceu em 3 alvos. Efeitos gráficos de brilho não bastam para confirmar eliminação.

## Mudanças

- Runtime: `FORJA65_GAMEPLAY_RAM_FINAL=/caminho/arquivo.bin` grava a WRAM (128 KiB) ao término do replay, sem afetar a RAM durante a partida (mudança opt-in no `src/main.cpp`).
- `tools/tetris2_target_qa.py`: interpreta o tabuleiro, lista cores e posição dos alvos, detecta grupos de mesma cor e produz JSON.
- `tools/run_target_attempt.py`: reproduz inputs e compara o estado real do tabuleiro sem modificar memória ou forçar vitória.
- `TESTAR-ALVOS-PRIMEIRA-FASE.cmd`: executa o roteiro de referência no Windows após compilação.

## Validação e limites

Compilação incremental Linux de `game`: APROVADA. Captura WRAM real de replays: APROVADA. A vitória real (remoção dos 3 alvos e passagem para a segunda fase): NÃO CONFIRMADA. O port continua sujeito a eventuais caminhos ainda não traduzidos no fim da fase; os consertos da v0.4.20 foram preservados. A alteração de diagnóstico não modifica CPU, PPU, DMA, SPC700 ou DSP.
