# Tetris 2 v0.4.16 — pausa/retomada verificadas com comparacao A/B

## Evidencia comprovada

Foram executadas duas reproducoes headless deterministicas de 2.400 quadros,
com roteiro inicial IDENTICO. Na segunda, START foi pressionado nos quadros
1850–1853 (pausa) e 2180–2183 (retomada). A referencia nao recebeu esses dois comandos.

Quadros capturados: 1750, 1830, 1900, 2050, 2150, 2250 e 2400.

- 1750 e 1830: pixels identicos entre os percursos (antes da pausa).
- 1900, 2050 e 2150: diferencas visuais frente ao percurso sem pausa.
- 2050 e 2150: imagem da partida pausada identica pixel a pixel.
- 2250 e 2400: imagem volta a mudar depois de START de retomada.
- Inspecao visual: PAUSE! no tabuleiro durante a parada, ausente apos retomar.
- Ambos completaram 2.400 quadros, sem encerramento por erro.

O verificador independente `tools/gameplay_transition_qa.py` aceita regras
JSON de equivalencia, diferenca, congelamento e progresso. Ele valida
capturas binárias P6 sem bibliotecas externas; falha em imagem truncada,
ausente, formato inesperado ou regra nao satisfeita. O relatorio calculado
esta em `validation/v0416-pause-qa/pause-qa-report.json`.

Use `VALIDAR-PAUSA-GAMEPLAY.cmd` depois de `BUILD-WINDOWS.cmd` para gerar
as capturas no Windows e confrontar os dois percursos. O comando remove
capturas antigas, evita falsos positivos e retorna erro em falha.

A ferramenta tambem e disponibilizada no Forja65 v0.4.15 e no runtime
gerado para ser usada com qualquer outro jogo de SNES.

## Escopo e limites

**Confirmados:** entrada no gameplay, pausa, congelamento da tela,
retomada e continuidade no quadro 2400. CPU, PPU, DMA/HDMA, DSP e os modos
de SPC700 existentes nao foram alterados por esta atualizacao.

**Ainda nao confirmados nesta atualizacao:** rotacao e colisao de pecas,
eliminacao de linhas, vitoria/fim de partida, todos os modos de jogo,
equivalencia ao SNES original e compilacao Windows neste ambiente.
A ferramenta de comparacao detecta propriedades visuais, nao equivalencia
total do hardware.
