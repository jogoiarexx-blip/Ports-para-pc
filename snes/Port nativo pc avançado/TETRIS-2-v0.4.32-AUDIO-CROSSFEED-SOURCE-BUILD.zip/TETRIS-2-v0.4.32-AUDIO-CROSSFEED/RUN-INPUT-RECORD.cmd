@echo off
setlocal
cd /d "%~dp0"
set "TRACE=%~1"
if "%TRACE%"=="" set "TRACE=forja65-input.trace"
for %%I in ("%TRACE%") do set "FORJA65_INPUT_RECORD=%%~fI"
set FORJA65_FRAME_HASHES=1
if exist game.exe goto rootRun
if exist bin\game.exe goto binRun
echo Execute BUILD-WINDOWS.cmd primeiro.
exit /b 1
:rootRun
game.exe
exit /b %ERRORLEVEL%
:binRun
pushd bin
game.exe
set "EXITCODE=%ERRORLEVEL%"
popd
exit /b %EXITCODE%
