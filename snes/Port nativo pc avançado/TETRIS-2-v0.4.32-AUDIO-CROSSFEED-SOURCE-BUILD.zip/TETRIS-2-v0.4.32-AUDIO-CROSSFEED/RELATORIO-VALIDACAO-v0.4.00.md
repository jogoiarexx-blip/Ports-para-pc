# Relatório QA — Tetris 2 v0.4.00 / Forja65 v0.3.99

| Verificação | Resultado |
|---|---|
| Build CMake Linux (game e targets de teste; g++ C++20) | PASS |
| CTest completo | 11 PASS, 1 SKIP, 0 FAIL |
| HDMA `$80`, `$82` e `$420C` (Tetris) | PASS |
| Forja65 projeto gerado + fixture HDMA compilada e executada | PASS |
| Forja65 QA anterior CPU/PPU/DMA/SPC | PASS |
| Forja65 QA OBJ crossfeed + limites | PASS |
| Replay headless normal com entrada arquivada (2.000 quadros) | PASS |
| Divergências vs hashes v0.3.99 — framebuffer/WRAM/PC | 0/0/0 |
| Transferências HDMA no replay normal | 0 (não exercitado) |
| Vetores de equivalência contra oracle | SKIP — não incluídos |
| Compilação e apresentação visual Windows | NÃO TESTADO |
| Correção contra pixels reais do SNES | NÃO TESTADO |

**Nota:** taxas de dependência seguem altas no replay: 4.774.122 acessos PPU em fallback, 4.715.520 bytes DMA em fallback, 714.736.008 master cycles de APU fallback e 1.065.180 amostras DSP fallback. Essas contagens vêm do `forja65-qa-status.txt` gravado no replay atual, e comprovam que o projeto ainda não é nativo 100%.

Referência de regras HDMA: https://snes.nesdev.org/wiki/DMA_registers e https://snes.nesdev.org/wiki/HDMA_examples .
