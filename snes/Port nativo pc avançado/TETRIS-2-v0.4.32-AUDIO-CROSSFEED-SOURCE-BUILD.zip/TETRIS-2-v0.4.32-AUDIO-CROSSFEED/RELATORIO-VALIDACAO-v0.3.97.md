# Relatório técnico — Tetris 2 v0.3.97

## Testes realizados neste ambiente

- Build integral CMake/Ninja em Linux, modo Release e `FORJA65_STRICT=ON`: **aprovado**.
- CTest: **8 testes aprovados**, **1 ignorado** (`equivalence_vectors`, depende de vetores externos). O novo `hardware_fixes_smoke` executou assertions reais sobre CPU, PPU, DMA/HDMA, SPC700, DSP e ROM.
- Teste sintético de regressão do emissor de código do Forja65 (`tests/tetris-hardware-v0397-regression.js`): **aprovado**. Também aprovados, após adequar expectativas de versão/PPU, `cfg-cache-compatible-v0369-regression.js`, `convergence-metadata-v0372-regression.js` e `snes9x-reference-v026-regression.js`.
- Reprodução headless de 300 quadros: **concluída**, framebuffer hash de cada quadro idêntico ao build anterior neste trecho, porém houve divergência de estado interno (RAM/PC) em parte dos quadros.
- Replay de **12.000 quadros** (`validation/input-normal.txt`): execução **concluída com exit code 0** no build anterior e no build atualizado; em ambos `runtime_started=PASS`, 12.000 quadros e 11.696 serviços NMI. Nenhum quadro forçado em branco ao fim.

## Diferenças medidas no replay de 12.000 quadros

| Medida | Referência anterior | Atualizado |
|---|---:|---:|
| Instruções | 166.514.624 | 166.498.873 |
| Hash final framebuffer | `353d57c24e401964` | `79eed651cd4cc9a4` |
| Hash final WRAM | `2fb1b59bc27aaf9f` | `77a6158fa876c5c5` |
| Acessos PPU virtuais | 31.076.230 | 31.076.230 |
| Bytes DMA | 30.627.744 | 30.627.744 |
| Acessos APU | 944.422 | 943.381 |

**Interpretação:** a nova semântica de SPC700/PPU altera trajetórias observáveis. O teste comprova ausência de travamento neste replay, **não** valida equivalência com um SNES real, não prova fidelidade gráfica em quadros posteriores, nem comprova todas as fases/modos do jogo. A divergência visual final requer comparação quadro a quadro com gravação do SNES antes de declarar conclusão.

## Débitos técnicos

- PPU, SPC700, DSP, DMA ainda têm chamadas de fallback; esta revisão melhora fidelidade da implementação existente, não remove todo hardware virtual.
- A captura de equivalência com ROM/SNES original precisa de dados de referência confiáveis; o teste de equivalência externa ficou ignorado.
- Não houve compilação nem verificação visual de executável Windows neste ambiente. Execute `BUILD-WINDOWS.cmd` e `TESTAR-HARDWARE.cmd` no Windows.
- Gerador `forja-tooling` sincronizado com o Forja65 v0.3.97, mas a geração integral do Tetris a partir da ROM não foi refeita nesta revisão para preservar o port já existente.
