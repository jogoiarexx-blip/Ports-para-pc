# Tetris 2 v0.4.24 — correção do fluxo 82:CFC4 → 82:BDBA

## Diagnóstico confirmado pelo log enviado
- ROM SNES: **Tetris 2**, fingerprint FNV1a64 `8c0b44eecc03e2e1` (conferido contra `assets/cart-data.bin`).
- `unresolved-flow` no **frame 5.774**, após **81.076.587 instruções** (log do usuário).
- Origem `$82:CFC4`: chamada `JSR $BDBA` gerada em `src/forja_82cfa0.cpp`; destino não estava na tabela de despacho `src/dispatch.cpp` da v0.4.23.

## Alterações aplicadas
- Adicionados dez handlers compilados em `src/tetris_bdba_cfg_v0424.cpp` usando a ROM do Tetris como fonte, não placeholders: rotina `$82:BDBA` com variantes `E=0 M=0 X=0 C=0/?`; continuação `$82:BDC8` (`RTS`); sete braços de tabela `$82:BDD7`, `$82:BDF2`, `$82:BDFC`, `$82:BE05`, `$82:BE22`, `$82:BEA9`, `$82:BF0A`.
- Adicionados **143 registros de dispatch** e **135 aliases** gerados para os novos handlers, preservando o despacho ordenado por endereço. A rotina conserva a leitura da WRAM `$0176`, `PEA $BDC7`, `JMP ($BDC9,X)`, retornos pela pilha e temporização de instruções.
- `CMakeLists.txt` inclui o novo arquivo nas builds de Windows e Linux; registro do teste nativo autônomo de fluxo.
- `analysis/runtime-hints.txt` recebe exatamente o hint observado vinculado ao fingerprint da ROM; evidências anteriores preservadas.
- Não foram alterados `src/runtime.hpp`, PCM/waveOut, SPC700/DSP, PPU, DMA, outros arquivos de `src/generated_*.cpp`, sprites ou controles. Nenhum arquivo original do ZIP do Tetris foi removido.

## Verificações executadas neste ambiente (Linux)
- `g++ -std=c++20 -fsyntax-only` para os novos handlers e o `src/dispatch.cpp`: **APROVADO**.
- Teste C++ `tetris_bdba_dispatch_smoke`: **7/7** índices `$0176 = 0..6` alcançaram os destinos corretos, verificando endereço original da chamada, ponteiro da pilha e valor `PEA $BDC7`.
- Mesmo teste: **3/3** primeiros braços sem dependências externas completaram `PEA → RTS (braço) → RTS (continuação)` e retornaram ao frame nativo original (`$82:CFC7`), sem consumir incorretamente o frame da chamada.
- CMake/CTest: `runtime_smoke`, `pcm_audio_output_smoke`, `audio_signal_smoke`, `tetris_bdba_dispatch_smoke`: **4/4 APROVADOS**.
- Compilação integral de `game` iniciada em Linux com GCC Release e Debug, mas **não concluída** dentro dos limites de execução deste ambiente. Por isso **não** há prova de replay completo até ou além do frame 5.774, de primeira fase vencida nem prova de funcionamento do áudio no Windows.

## Como testar no Windows
1. Extraia o ZIP em nova pasta.
2. Execute `BUILD-WINDOWS.cmd` com CMake e toolchain C++ do Visual Studio instalados.
3. Execute `RUN-WINDOWS-AUDIO.cmd` e repita os comandos da sessão que antes travava no frame 5.774.
4. Se aparecer outro `unresolved-flow`, compartilhe os novos `forja65-runtime-hints.txt` e `forja65-crash-trace.txt`; não significa que o bloqueio anterior permaneceu.

A correção foi incorporada somente ao **port Tetris 2**. O **Forja65 multigame v0.19** enviado antes não foi modificado neste pacote, e **Soldiers of Fortune** permanece independente.
