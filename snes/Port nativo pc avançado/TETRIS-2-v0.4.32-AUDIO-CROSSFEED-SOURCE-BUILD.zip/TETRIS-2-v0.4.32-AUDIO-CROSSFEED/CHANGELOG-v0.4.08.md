# Tetris 2 Native PC v0.4.08 — SPC700 IPL, CPU/APU trace, rational NTSC clock

## Resumo

Esta versao preserva o comportamento de execucao padrao da v0.4.07 e adiciona duas ferramentas para investigar a divergencia que o modo SPC700 experimental apresenta a partir do quadro 59: (1) captura de mensagens CPU↔APU e (2) relogio racional NTSC opt-in. Nenhum desses modos experimentais foi ativado por padrao.

## Alteracoes implementadas

- Captura opcional `FORJA65_APU_IPL_TRACE=1`: grava mensagens CPU→SPC (`C`), SPC→CPU (`S`) e limpeza de portas pelo controle (`R`), com numero sequencial, valores, PC SPC e carimbos aproximados de ciclos. Guarda no maximo 32.768 eventos e relata quantos foram descartados. Durante `FORJA65_CAPTURE_SPC_FRAME=59`, gera `apu-ports.csv` na pasta de captura.
- Novo comparador `tools/compare_apu_ports.py`: compara a ordem/valores das mensagens e ressalta diferencas de instante. Reconhece capturas truncadas.
- Relogio racional experimental: `FORJA65_SPC_TIMING=accurate` junto de `FORJA65_SPC_CLOCK=ntsc` passa a usar 21.477.272 master clocks/s e 1.024.000 ciclos SPC/s com credito fracionario persistente. O modo padrão e o experimental anterior de razao inteira continuam disponiveis e inalterados.
- Teste `spc_ipl_handshake_smoke`: duas temporizacoes, boot `AA/BB`, comando `CC`, confirmacoes de bytes, transferencia de dois bytes para `$0200`, separacao dos latches de porta e verificacao do relogio NTSC.
- Comandos Windows atualizados: `CAPTURAR-SPC-QUADRO-59.cmd` compara tres execucoes, `RUN-SPC-NTSC-EXPERIMENTAL.cmd` permite experimentar a nova razao de clocks. Os novos testes foram inseridos em `BUILD-WINDOWS.cmd` e `TESTAR-HARDWARE.cmd`.
- Forja65 gerador recebeu as mesmas alteracoes e um teste que gera, compila e executa o runtime sintetico.

## Conclusoes medidas (Linux, captura apos quadro 59)

| Medida | Padrão v0.4.08 | SPC_TIMING=accurate |
|---|---:|---:|
| Primeiro sinal IPL `$AA`, master cycles | 30286 | 50320 |
| Segundo sinal IPL `$BB`, master cycles | 30332 | 50448 |
| Eventos CPU/SPC nas portas | 14844 | 8511 |
| Eventos descartados | 0 | 0 |

- Os valores e a ordem dos 8.511 eventos compartilhados coincidiram; o modo com instrucoes mais longas concluiu menos eventos ate o mesmo quadro.
- Ativar `FORJA65_SPC_SEMANTICS=corrected` junto de `FORJA65_SPC_TIMING=accurate` **nao mudou** o trace de portas desse trecho, frente a ativar apenas `SPC_TIMING=accurate`.
- O modo NTSC racional registrou 8.523 eventos nesse mesmo ponto, versus 8.511 no modo de razao inteira. Nao significa automaticamente maior fidelidade: falta referencia do hardware.
- Replay padrao de **500 quadros**: hashes de framebuffer, WRAM e PC identicos ao arquivo `forja65-frame-hashes.txt` da v0.4.07.
- Compilacao completa Linux: passou. CTest: **20 aprovados, 1 ignorado** (vetores externos ausentes), nenhum falhou. Forja65: **12/12 testes de regressao** passaram, incluindo runtime recem-gerado.

## Limites da evidencia

- A captura usa carimbos em limites de instrucao, nao instantes exatos de leitura/escrita no barramento.
- Os caminhos da CPU, PPU, DMA, SPC e DSP ainda nao foram totalmente substituidos por um port host independente de hardware virtual. Esta entrega nao comprova Tetris 2 completo ou equivalencia de audio PCM com o SNES.
- Nao foi compilado um `game.exe` Windows neste ambiente Linux. Os scripts Windows continuam exigindo CMake e Visual Studio com C++.

## Proximo alvo

Comparar a troca exata dos sinais CPU→SPC e SPC→CPU com uma referencia SNES (bsnes/snes9x instrumentado), refinando sincronizacao de leitura/escrita das portas em ciclos individuais. Depois validar transferencia completa IPL e som com captura PCM.
