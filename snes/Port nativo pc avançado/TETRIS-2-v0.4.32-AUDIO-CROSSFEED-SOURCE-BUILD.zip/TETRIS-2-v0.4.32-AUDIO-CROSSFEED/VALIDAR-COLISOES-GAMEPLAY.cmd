@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "GAME=%~dp0bin\game.exe"
set "CART=%~dp0bin\assets\cart-data.bin"
if not exist "%GAME%" (set "GAME=%~dp0game.exe" & set "CART=%~dp0assets\cart-data.bin")
if not exist "%GAME%" (echo ERRO: compile usando BUILD-WINDOWS.cmd & exit /b 2)
if not exist "%CART%" (echo ERRO: cart-data.bin ausente & exit /b 2)
set "PY=python"
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
%PY% --version >nul 2>nul
if errorlevel 1 (echo ERRO: Python 3 necessario & exit /b 2)
%PY% tools\gameplay_wall_qa.py --game "%GAME%" --cart "%CART%" --trace validation\input-control-v0416.txt --output validation\v0418-wall-qa --tiles 2,3,11,5 --left-wall 88 --right-wall 144
if errorlevel 1 (echo FALHA em colisao lateral OAM & exit /b 3)
%PY% tools\gameplay_lock_qa.py --game "%GAME%" --cart "%CART%" --trace validation\input-control-v0416.txt --output validation\v0418-lock-qa --frames 1875,1900,1925 --start 1835 --stop 2380 --old-tiles 2,3,11,5 --new-tiles 2,13,5,4 --board 88,32,170,200
if errorlevel 1 (echo FALHA em passagem entre pecas & exit /b 3)
echo APROVADO: colisao lateral e transicao entre pecas para este roteiro.
echo NAO foram testadas limpeza de linhas, vitoria, nem equivalencia com SNES original.
exit /b 0
