# Tetris 2 v0.4.30 — relógio fracionário DSP (jogo independente)

Base: Tetris 2 v0.4.29. Preservados o código nativo, o fluxo `$82:BDBA`, a emulação SPC700, os modos KON/KOFF, ADSR/GAIN, BRR, Gaussian/Linear, eco e a saída PCM/WAV.

## Correção

- O DSP antigo usava 671 ciclos do relógio mestre por quadro estéreo. A equivalência nominal correta é **1.024.000 ciclos SPC700 por segundo / 32 = 32.000 quadros estéreo por segundo**.
- Novo acumulador inteiro: a cada N ciclos mestres, soma `N * 32000`; uma amostra é emitida ao ultrapassar `21477272`. O resto é preservado entre chamadas, inclusive quando elas têm tamanhos variados ou o áudio está desativado.
- Evita arredondamento sistemático e desvio acumulado de cadência; não modifica a frequência do arquivo WAV (continua 32.000 Hz) nem o gerador de envelopes.
- `FORJA65_DSP_CLOCK=legacy` mantém o relógio fixo de 671 ciclos, para comparação de regressões.
- `RUN-WINDOWS-AUDIO-LEGACY-CLOCK.cmd`: alternância fácil sem alterar o executável do jogo.

## Evidências de testes

- Teste unitário de 1 segundo: 32.000 amostras no novo relógio, 32.007 no legado.
- Igualdade de PCM e estado do DSP, alimentando o acumulador de uma vez ou em milhares de blocos com comprimentos variados.
- Compilação completa Linux do jogo e seis testes C++ de áudio selecionados passaram.
- Replay normal de 1.200 frames: 17.224.552 instruções, framebuffer `6613cefdf0d2091`, WRAM `70263db67c0c3ea` em ambos os relógios.
- PCM novo: 638.951 quadros estéreo, PCM legado: 639.108 quadros estéreo durante os mesmos 1.200 frames.
- Captura sonora obtida com saída WAV headless; o áudio do dispositivo Windows precisa ser conferido localmente.

## Limitações

A frequência de 32 kHz é uma aproximação nominal para relógios independentes de CPU principal e APU, não uma simulação dos microciclos do S-DSP. Não foi comparada a onda sonora bit a bit com o console real. O Forja65 continua em pacote separado.

## Replay de 6.000 frames

Concluído no modo fracionário, sem erro: 83.644.643 instruções CPU, 3.194.756 quadros estéreo, hash framebuffer `79eed651cd4cc9a4`, WRAM `ea3656653d701bec`. O teste passou pelo antigo bloqueio do frame 5.774.
