# Tetris 2 v0.4.13 — correção SPC700 F1/F2

## Mudanças verificadas
- $F1: escrita com temporizador já ligado **não** zera estágio 2 nem latch do contador. Reinício somente na transição 0→1. Corrige regressão introduzida no modo experimental da v0.4.12.
- $F2: DSPADDR aceita bit 7 em escrita (bloqueio de escrita $F3), mas a leitura retorna apenas os 7 bits de endereço, com bit 7 igual a zero.
- Mesma máscara aplicada ao acesso sem efeitos colaterais usado pelo preditor de ciclos SPC700.
- Novos testes `spc_register_edges_smoke`; atualizados os testes históricos `spc_strict_scheduler_smoke` e `apu_dsp_registers_smoke` que esperavam os comportamentos incorretos.
- Gerador Forja65 v0.4.12 atualizado separadamente; **o diretório histórico `forja-tooling/` deste port não foi substituído automaticamente**.

## Validação efetivamente executada
- Compilação C++ integral em Linux: sucesso (Debug, GCC).
- CTest: 24 aprovados, 1 ignorado (`equivalence_vectors`: vetores externos indisponíveis), nenhum reprovado.
- Replay do modo padrão, sem entradas adicionais: 500 quadros, 500 hashes **idênticos** ao registro estável `validation/v0410-cpu-apu-poll-runs/stable-500-frame-hashes.txt`.
- Replay com `validation/input-normal.txt`: 2.000 quadros, concluído sem erro; não foi declarado equivalente ao replay sem entradas nem ao do SNES original.
- Modo `accurate+strict`: 300 quadros concluídos sem erro; continua experimental.
- Forja65: 17 regressões específicas do Tetris aprovadas, incluindo compilação de código recém-gerado.
- Windows/MSVC: não compilado nesta rodada; o ZIP contém código-fonte e scripts para compilar no Windows.

## Fontes de hardware
- https://snes.nesdev.org/wiki/S-SMP — CONTROL ($F1) reinicia temporizador somente ao transitar de 0 para 1; DSPADDR ($F2) retorna bit 7 zerado.
- https://snes.nesdev.org/wiki/S-DSP_registers — escrita em $F2 com bit 7 impede gravação pelo $F3.

## Limitações
Os testes de replay não comprovam fim das partidas, equivalência visual/sonora com o SNES nem ausência de hardware virtual. O modo estável mantém temporização simplificada. `strict` permanece opt-in.
