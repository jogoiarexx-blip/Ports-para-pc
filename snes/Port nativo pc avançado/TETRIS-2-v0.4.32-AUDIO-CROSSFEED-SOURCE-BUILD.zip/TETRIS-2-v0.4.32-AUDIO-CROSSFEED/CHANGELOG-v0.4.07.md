# Tetris 2 Native PC v0.4.07 — SPC700 memory semantics / IPL trace

## Implementado

- Corrigidas, em modo experimental opt-in, operacoes SPC700 ADC/SBC com destino em RAM (89, 98, 99, A9 e B9), preservando A e atualizando os flags corretos.
- Revisados operandos fonte/destino de OR/AND/EOR/CMP dp,dp.
- Corrigida leitura indireta de byte alto do ponteiro em pagina direta (ex. [dp+X], [dp]+Y), que faz wrap dentro da pagina selecionada por PSW.P.
- Corrigidos acessos indiretos (X)/(Y) com PSW.P e operacoes de palavra em DP atravessando $FF -> $00.
- Rotas anteriores preservadas por padrao. Aplique FORJA65_SPC_SEMANTICS=corrected para ativar o grupo de correcoes.
- A temporizacao v0.4.06 continua independente em FORJA65_SPC_TIMING=accurate.
- Novo teste spc_semantics_smoke e versao gerada pelo Forja65.
- Comando CAPTURAR-SPC-QUADRO-59.cmd e tools/compare_spc_snapshots.py para diagnosticar a rotina IPL.

## Resultado verificado neste ambiente

- Compilacao integral Linux: passou.
- CTest: 19 aprovados, 1 ignorado (vetores externos ausentes), nenhum reprovado.
- Forja65: 11 testes de crossfeed de Tetris aprovados, incluido compilacao e execucao de runtime sintetico para este patch.
- 500 quadros: v0.4.06 e v0.4.07, ambas estaveis e nas mesmas configuracoes de execucao, tiveram hashes frame a frame IDENTICOS de framebuffer, WRAM e PC.
- Nos primeiros 120 quadros, somente semantica nova: zero divergencias nos hashes. Somente temporizacao experimental: primeiro PC divergente em 59 e WRAM em 109; imagem igual no periodo. Ambas: mesmo resultado no periodo.
- Captura RAM SPC no quadro 59: modo estavel PC=$FFDE, Y=$3F; modo temporizacao experimental PC=$FFE0, Y=$00. As 65536 posicoes de RAM diferem somente em $0001 ($15->$0D) e $00F4 ($3E->$FF). Pontos da IPL, ainda nao equivalencia com SNES real.

## Restricoes / proximas investigacoes

- Nenhuma comparacao PCM/AUDIO ou trace original SNES validou as alteracoes experimentais.
- O desvio na temporizacao durante a IPL nao significa necessariamente erro da versao experimental. A verificacao contra o SNES original continua pendente.
- Apenas as situacoes exercitadas pelos testes foram validadas, nao todos os opcodes do SPC700 nem todos os modos do Tetris.
- O ZIP inclui fontes C++ e scripts de compilacao Windows; nao inclui game.exe do Windows.

Fontes de referencia para opcodes: https://snes.nesdev.org/wiki/SPC-700_instruction_set ; https://wiki.superfamicom.org/spc700-reference
