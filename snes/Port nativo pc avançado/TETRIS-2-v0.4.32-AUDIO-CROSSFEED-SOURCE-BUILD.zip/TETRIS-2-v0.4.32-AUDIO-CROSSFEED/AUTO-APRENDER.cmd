@echo off
setlocal
cd /d "%~dp0"
rem O jogo Tetris 2 nao precisa do Forja65 para abrir ou ser compilado.
rem Convergencia/geracao: configure FORJA65_HOME (pasta do Forja65 separado).
if not defined FORJA65_HOME set "FORJA65_HOME=%~dp0..\Forja65-v0.4.21-DSP-ECHO-NON-PMON"
if not exist "%FORJA65_HOME%\tools\forja65.js" (
 echo Ferramenta de desenvolvimento opcional nao encontrada.
 echo Extraia Forja65-v0.4.21-DSP-ECHO-NON-PMON.zip ao lado deste projeto ou defina FORJA65_HOME.
 pause
 exit /b 2
)
node "%FORJA65_HOME%\tools\forja65.js" converge "%~dp0." --frames 1200 --rounds 32
set "CODE=%ERRORLEVEL%"
pause
exit /b %CODE%
