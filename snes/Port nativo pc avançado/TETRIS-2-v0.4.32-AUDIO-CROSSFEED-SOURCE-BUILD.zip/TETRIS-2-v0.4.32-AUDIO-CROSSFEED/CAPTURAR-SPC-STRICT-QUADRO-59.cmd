@echo off
setlocal
cd /d "%~dp0"
if exist bin\game.exe cd bin
if not exist game.exe (echo Execute BUILD-WINDOWS.cmd primeiro. & pause & exit /b 1)
set FORJA65_HEADLESS=1
set FORJA65_HEADLESS_FRAMES=60
set FORJA65_APU_IPL_TRACE=1
set FORJA65_APU_TRACE_READS=window
set FORJA65_CAPTURE_SPC_FRAME=59
set FORJA65_CAPTURE_SPC_STOP=1
set FORJA65_SPC_TIMING=accurate
set FORJA65_SPC_CLOCK=
set FORJA65_SPC_SEMANTICS=
set FORJA65_SPC_SCHEDULER=
set FORJA65_CAPTURE_SPC_DIR=spc-capture-timing
if exist "%FORJA65_CAPTURE_SPC_DIR%" rmdir /S /Q "%FORJA65_CAPTURE_SPC_DIR%"
game.exe || goto :fail
set FORJA65_SPC_SCHEDULER=strict
set FORJA65_CAPTURE_SPC_DIR=spc-capture-strict
if exist "%FORJA65_CAPTURE_SPC_DIR%" rmdir /S /Q "%FORJA65_CAPTURE_SPC_DIR%"
game.exe || goto :fail
where py >nul 2>&1
if not errorlevel 1 (py -3 tools\compare_apu_ports.py spc-capture-timing\apu-ports.csv spc-capture-strict\apu-ports.csv) else (python tools\compare_apu_ports.py spc-capture-timing\apu-ports.csv spc-capture-strict\apu-ports.csv)
echo Capturas em spc-capture-timing e spc-capture-strict.
pause
exit /b 0
:fail
echo Falha ao capturar o SPC700.
pause
exit /b 1
