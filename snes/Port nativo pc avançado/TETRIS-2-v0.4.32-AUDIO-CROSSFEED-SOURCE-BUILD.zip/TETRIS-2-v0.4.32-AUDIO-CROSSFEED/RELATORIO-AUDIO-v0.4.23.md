# Tetris 2 v0.4.23 — saída de áudio em tempo real

## Problema encontrado
Na base v0.4.22, o SPC700 e o DSP produziam amostras, mas elas só eram acumuladas em `ApuBridge::nativePcm`; não havia ligação com a placa de áudio do Windows. `RUN-NATIVE-AUDIO.cmd` apenas exportava WAV e os primeiros 600 quadros eram silenciosos.

## Alterações
- `src/pcm_audio_output.hpp`: transporte PCM estéreo de 16 bits, 32 kHz, com `waveOut` (WinMM) no Windows, 12 blocos de 512 quadros, fila não bloqueante, registro de erros e contador de perdas.
- Arquivo WAV escrito por streaming em blocos com cabeçalho RIFF corrigido no fechamento; não retém a partida inteira em RAM.
- `ApuBridge::tickDspMasterCycles`: envia cada amostra do DSP diretamente ao transporte. Captura em vetor antigo passa a ser opt-in apenas para testes.
- `SnesRuntime`: áudio nativo habilitado por padrão na janela interativa; headless mantém DSP desligado por padrão, salvo se houver captura/ativação explícita. Saída de áudio não muda flags, estado da CPU nem regras da partida.
- `FORJA65_AUDIO_GAIN` permite volume do host de 0 a 400 por cento, padrão 100. O script de áudio define 200.
- `forja65-audio-report.txt` informa amostras produzidas, amostras não silenciosas, pico, quadro de reprodução, perda de blocos e erros de dispositivo.
- `RUN-WINDOWS-AUDIO.cmd` joga com áudio ao vivo. `RUN-NATIVE-AUDIO.cmd` cria WAV headless por padrão até o quadro 2.200.

## Validação real concluída (Linux)
- Compilação completa de `game` em Linux: aprovada.
- Regressões PCM, SPC/DSP e áudio integrado: 3/3 aprovadas por CTest.
- `native_migration_smoke` compilado e aprovado manualmente.
- Replay de 2.200 quadros, com WAV capturado: 1.171.698 quadros PCM estéreo; 380.894 não silenciosos; pico de 4.862 com ganho de 200%; nenhum erro de runtime.
- Replay A/B de 600 quadros, com/sem captura DSP: instruções, framebuffer e hash da WRAM iguais.
- Amostra WAV de 5 segundos extraída do intervalo de 12 a 17 segundos da execução: validada.

## Pendências honestas
- Não foi possível reproduzir em um dispositivo de áudio Windows nesta sessão Linux, nem compilar `game.exe` para Windows. `waveOut` utiliza a biblioteca WinMM já vinculada pelo CMake da base.
- A síntese DSP é preliminar (`BRR_BASIC_8VOICE`): faltam ADSR preciso, interpolação gaussiana, eco, ruído, pitch modulation e referência PCM do SNES original. Música e efeitos podem diferir do hardware original.
- Temporização SPC700 estrita continua experimental. Não foi ativada como padrão.
- O gameplay e a validação da primeira fase permanecem inalterados; esta etapa não declara a fase vencida.

## Testar no Windows
1. Extraia em nova pasta e execute `BUILD-WINDOWS.cmd` (CMake/Visual Studio 2022 C++).
2. Execute `RUN-WINDOWS-AUDIO.cmd`, jogue até passar a abertura e confira se aparece som.
3. Se não houver som, execute `RUN-NATIVE-AUDIO.cmd`. Confirme `nonzero_frames > 0` e `peak > 0` em `bin/forja65-audio-report.txt`, e teste `bin/forja65-native-audio.wav`.
4. Se o WAV tiver som e o jogo ao vivo não, examine `backend_error`, `live_ready` e `frames_dropped`. Não significa automaticamente bug do SPC700: pode ser dispositivo/driver/fila.
