# Tetris 2 v0.4.04 — VRAM access & read latch

## Correções realizadas

- `$2139/$213A`: agora a PPU recarrega o latch de leitura **antes** de incrementar VMADD. A antiga sequência adiantava indevidamente a palavra seguinte. Atualizados testes de incrementos por 1/32, leitura baixa/alta e wrap.
- `$2118/$2119`: em display ativo e HBlank, a nova verificação no runtime descarta os bytes de escrita e mantém o incremento de VMADD. Durante VBlank e forced blank, as escritas permanecem válidas. **Quando o timing do quadro não foi inicializado**, o runtime mantém comportamento anterior (acesso liberado), para casos de boot/offline.
- DMA e HDMA usam a mesma guarda, sem poder contornar a limitação da PPU pelo caminho nativo rápido. Ciclos e atualização de registros seguem por byte.
- Perfil opcional `FORJA65_PPU_REGISTER_PROFILE=1` inclui `vram_blocked_writes`.
- `vram_access_smoke.cpp` cobre pipeline, incrementos, wrap, display ativo, HBlank, forced blank, VBlank e DMA.
- Regressões antigas de sprite/PPU/migração atualizadas para fazer upload de VRAM em período permitido.
- `BUILD-WINDOWS.cmd` e `TESTAR-HARDWARE.cmd` incluem o teste novo.

## Validação executada nesta entrega

- Compilação integral do `game` em Linux (CMake, `-O0 -DNDEBUG`) concluída.
- Tetris CTest: **16 aprovados / 1 ignorado / 0 falhas**. O ignorado depende de vetores externos não disponíveis.
- Forja65: **8/8 regressões Tetris aprovadas**, incluindo geração de runtime C++ sintético e execução real dos casos PPU/DMA.
- Replay `validation/input-normal.txt`: **2.000/2.000 quadros completos**, hashes idênticos à v0.4.03 para framebuffer, WRAM e PC.
- Replay ampliado de 5.000 quadros iniciado com perfil PPU: chegou a gerar **2.382 hashes** antes do limite de execução da ferramenta; a parte de 2.000 já comparável segue idêntica. **Não declarar 5.000 concluídos.**

## Limitações

- Ainda não foi executada comparação quadro a quadro com captura do hardware SNES original.
- Leitura de VRAM durante display ativo/HBlank ainda não simula com precisão o valor elétrico inválido do latch; a correção nesta rodada é do pipeline no acesso permitido e das restrições de ESCRITA.
- CGRAM/OAM sob contenção do raster exigem estudo próprio.
- O áudio SPC700/DSP e a remoção do fallback PPU continuam pendentes.
- Não há `game.exe` Windows pré-compilado nem teste Windows; executar `BUILD-WINDOWS.cmd` no computador do usuário.
- Executar replay não equivale a concluir 100% dos modos/fases do jogo; o port ainda é híbrido.

## Referências técnicas

- https://snes.nesdev.org/wiki/PPU_registers
- https://snes.nesdev.org/wiki/Reading_and_writing_PPU_memory
