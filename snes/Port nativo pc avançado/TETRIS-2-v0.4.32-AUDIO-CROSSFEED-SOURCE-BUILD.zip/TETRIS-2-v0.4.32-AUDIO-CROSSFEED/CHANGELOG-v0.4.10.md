# TETRIS 2 v0.4.10 — CPU/APU observabilidade de consultas

## Implementado
- `FORJA65_APU_TRACE_READS=changes` agora armazena `polls` e `last_master_cycles` por evento `Q`, mantendo a contagem exata de polls CPU por porta no mesmo valor; não precisa emitir todas as consultas no CSV.
- Identidade de evento guardada por índice, sem invalidar a referência quando o vetor realoca, suportando intercalamento de portas.
- Modo `all` continua sem compressão; quando o limite de 32768 eventos é alcançado, o contador bruto por porta continua avançando.
- CSV estendido compatível com leitores antigos que ignoram colunas extras; comparador agora aceita formatos antigo/novo e detecta divergência de quantidade de polls mesmo com valores iguais.
- Novo teste C++ `spc_cpu_poll_runs_smoke`; teste antigo de cabeçalho IPL atualizado; teste Python de retrocompatibilidade CSV.
- Mantido o mesmo comportamento de SPC700/CPU/PPU/DMA e de vídeo no modo estável, sem ativar `FORJA65_SPC_TIMING=accurate` por padrão.

## Resultados de regressão
- Compilação completa do port em Linux: PASS.
- CTest: 22 aprovados, 1 ignorado (`equivalence_vectors` sem vetores externos).
- Forja65 (pacote complementar v0.4.09): 14/14 regressões selecionadas de Tetris passaram, incluindo geração e compilação de C++.
- Replay v0.4.09 vs v0.4.10: 500 quadros idênticos em vídeo/WRAM/PC, arquivo SHA256 `39e82283a865a409ecb28ec8ed22a113211c2eff97503730f2b720b6af4c2b2e`.
- Duas capturas quadro 59: nenhum evento perdido. Prefixo comum de valores Q continua igual, mas a primeira Q-run da porta 0 com valor $AA contém 11 polls no estável e 20 no experimental. Ciclo final registrado 19604012 vs 19604390 (timestamp no limite da instrução).
- Consultas porta 0 totais: 24367 estável vs 28589 experimental; porta 1: 44 vs 44.

## Limitações
- A divergência do timing SPC é observável mas sem oracle do SNES original não significa defeito comprovado de um modo específico. O relógio experimental permanece desligado por padrão.
- `last_master_cycles` são timestamps de limite de instrução, não uma captura de fase exata do acesso na CPU 65C816.
- Os testes de 500 quadros não provam gameplay completo; o `game.exe` não foi construído ou testado no Windows.
- O ZIP entrega fonte, assets, Windows build/test scripts e rastros CSV, não executável pré-compilado.

## Repetir
No Windows: `BUILD-WINDOWS.cmd`, `TESTAR-HARDWARE.cmd`, `RUN-WINDOWS.cmd`, e `CAPTURAR-SPC-QUADRO-59.cmd`.
Comparar os dados incluídos: `python tools/compare_apu_ports.py validation/v0410-cpu-apu-poll-runs/stable-ports.csv validation/v0410-cpu-apu-poll-runs/accurate-ports.csv`.
