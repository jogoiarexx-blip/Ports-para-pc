# Tetris 2 v0.4.02 — sincronização seletiva da PPU e auditoria por registrador

## Alterações no runtime

- Escritas de endereço/configuração dos ports $2115, $2116, $2117 e $2121 deixam de invocar `syncPpuBeforeMutation()`. São latches/ponteiros: somente as **escritas de dados posteriores** modificam os pixels.
- Escritas em $2118/$2119 (VRAM), $2122 (CGRAM), $2104 (OAM) e demais registradores continuam sincronizadas; $2102/$2103 mantêm sincronização por causa da rotação de prioridade OAM.
- `FORJA65_PPU_REGISTER_PROFILE=1` ativa contadores reais de leituras/escritas por porta PPU de $2100 a $213F e gera `forja65-ppu-register-profile.csv` ao término normal do jogo.
- O perfil mede **acessos a portas em runtime**, sem alegar eliminação da emulação PPU.

## Testes e scripts

- `ppu_raster_sync_smoke` compara framebuffer e memória ao comportamento anterior, além de conferir os contadores do perfil.
- `BUILD-WINDOWS.cmd` agora constrói os testes HDMA/PPU/DMA acrescentados em v0.4.00/v0.4.01 e o novo teste antes de executar o CTest.
- Novo `PERFILAR-PPU-WINDOWS.cmd` faz replay determinístico de 2.000 quadros e salva CSV e hashes.
- Forja65 v0.4.01 espelha a mudança no código de runtime que gera para qualquer jogo.

## Limites

- A otimização evita chamadas de sincronização para registradores de endereço; **não** elimina hardware virtual nem garante aumento perceptível de FPS.
- Os contadores de PPU ainda sinalizam leitura/escrita via `PpuState`, e o DMA continua executando seus efeitos registrados.
- A comparação de frames prova ausência de divergência frente à versão anterior no trecho reproduzido, **não** equivalência total ao SNES físico, nem conclusão de todas as fases.
