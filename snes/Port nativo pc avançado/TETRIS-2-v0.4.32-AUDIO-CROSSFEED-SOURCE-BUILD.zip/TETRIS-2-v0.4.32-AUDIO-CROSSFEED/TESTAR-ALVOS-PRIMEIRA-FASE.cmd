@echo off
setlocal
cd /d "%~dp0"
set "GAME=%~dp0bin\game.exe"
set "CART=%~dp0bin\assets\cart-data.bin"
if not exist "%GAME%" (set "GAME=%~dp0game.exe" & set "CART=%~dp0assets\cart-data.bin")
if not exist "%GAME%" (echo ERRO: execute BUILD-WINDOWS.cmd antes & pause & exit /b 2)
where py >nul 2>nul && (set "PY=py -3") || (set "PY=python")
%PY% tools\run_target_attempt.py --game "%GAME%" --cart "%CART%" --trace "%~dp0validation\input-primeira-fase-alvos.txt" --frames 2600 --out "%~dp0validation\resultado-blocos-piscantes"
if errorlevel 1 (echo Falha na tentativa; examine os logs. & pause & exit /b 2)
echo Analise completa. Consulte validation\resultado-blocos-piscantes\board.txt
pause
