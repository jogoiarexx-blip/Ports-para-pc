# Tetris 2 v0.4.17 — QA de controles reais

- Cinco replays headless com a MESMA sequencia ate o quadro 1834; em 1835 injeta-se somente LEFT, RIGHT, A (rotacao) ou DOWN; liberacao no quadro 1841.
- Compara-se framebuffer PPM em 1834, 1843, 1850 e 1860, garantindo igualdade antes da entrada, divergencia depois e modificacoes restritas ao retangulo configuravel da peca.
- Os dados reais da v0.4.15 deram 384 pixels alterados por movimento lateral, 442 por rotacao e 512 por descida em 1843. Nao existem divergencias fora da regiao monitorada.
- O validador nao interpreta a colisao ou a limpeza de linhas; esses comportamentos NAO foram validados.
- Testes unitarios sinteticos cobrem false positives, arquivos PPM truncados, entradas malformadas e replay com quadros duplicados.
- O runtime C++ e hardware PPU/CPU/DMA/SPC700/DSP nao tiveram seus algoritmos alterados nesta versao; modo SPC strict continua experimental.
- Para repetir no Windows, compile (BUILD-WINDOWS.cmd) e execute VALIDAR-CONTROLES-GAMEPLAY.cmd. Python 3 necessario para analise.
- O arquivo ZIP contem fontes e assets, NAO inclui game.exe compilado para Windows.
