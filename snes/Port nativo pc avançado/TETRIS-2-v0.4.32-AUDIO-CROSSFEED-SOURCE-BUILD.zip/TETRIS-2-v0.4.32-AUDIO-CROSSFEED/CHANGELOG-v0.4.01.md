# Tetris 2 v0.4.01 — PPU snapshot row + DMA B-bus direto

## Motor gráfico (PPU)

- `PpuState::renderScanline()` agora compartilha os caches de BG e OBJ com o compositor de linhas usado no raster ao vivo.
- Cada linha de captura monta os sprites apenas uma vez (`buildSpriteRow`) em vez de reevaluar os 128 slots de OAM para cada pixel.
- Cache limitado à linha, sem reutilização de VRAM, CGRAM ou registradores após futuras alterações.
- Fastpath de `forced blank` preenche a linha sem calcular composição de cores.
- Nenhuma alteração no fluxo CPU 65C816 compilado nem na semântica da sincronização de raster durante o jogo.

## DMA

- `FORJA65_DMA_MODE=auto` agora é o padrão quando a variável não está definida; a rota B-bus direta já existente é usada nos endereços reconhecidos da PPU, APU e porta WRAM.
- Acesso a B-bus não suportado continua no fallback comum; use `FORJA65_DMA_MODE=virtual` para comparação/diagnóstico com o comportamento anterior.
- Essa mudança otimiza o despacho de DMA; **não** elimina a emulação funcional dos registradores PPU, nem transforma SPC700/DSP em 100% nativos.

## Novos testes

- `ppu_snapshot_row_smoke`: compara renderização acelerada com o caminho escalar em 8 modos PPU, 3 configurações e diversas linhas; valida quadro completo e forced blank.
- `dma_native_parity_smoke`: confronta PPU/WRAM/OAM/CGRAM, endereço de leitura da VRAM, master clock, SPC/DSP e contadores de DMA entre rota genérica e B-bus direta.
- Testes adicionados ao CTest e ao `TESTAR-HARDWARE.cmd` Windows.
- Forja65 v0.4.00 atualizado para regenerar ambas as alterações.

## Limites

- Não há confirmação visual contra capturas do SNES físico nesta versão.
- Os replays automáticos não garantem conclusão de todas as fases, multiplayer ou modos especiais.
- Este pacote contém fontes e scripts; a compilação de `game.exe` Windows ainda precisa ser feita localmente.
