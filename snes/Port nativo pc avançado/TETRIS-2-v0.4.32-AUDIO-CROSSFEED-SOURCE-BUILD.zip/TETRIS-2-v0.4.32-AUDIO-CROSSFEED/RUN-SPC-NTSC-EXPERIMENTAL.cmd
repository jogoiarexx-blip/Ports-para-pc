@echo off
setlocal
rem Experimental: SPC instruction cycles + rational NTSC master/SPC clock.
rem Not selected in the normal game and not yet verified against hardware PCM.
set FORJA65_SPC_TIMING=accurate
set FORJA65_SPC_CLOCK=ntsc
set FORJA65_SPC_SEMANTICS=corrected
call "%~dp0RUN-WINDOWS.cmd"
exit /b %ERRORLEVEL%
