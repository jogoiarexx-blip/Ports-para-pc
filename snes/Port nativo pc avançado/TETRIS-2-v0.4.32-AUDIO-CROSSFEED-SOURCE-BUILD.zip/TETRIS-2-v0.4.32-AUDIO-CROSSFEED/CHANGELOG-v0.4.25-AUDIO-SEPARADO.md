# Tetris 2 v0.4.25 — áudio e independência do Forja65

- Sem a pasta `forja-tooling/` no pacote do jogo. Execução e compilação do C++ independentes do gerador Forja.
- Quatro scripts opcionais de convergência passam a procurar `FORJA65_HOME` ou a pasta irmã `Forja65-v0.4.20-AUDIO-DSP`.
- DSP BRR com histórico de predição em 15 bits; interpolação linear para reduzir ruído de sample-and-hold.
- Envoltórias ADSR (attack, decay, sustain, release) e GAIN nos quatro modos dinâmicos; KOFF executa release por amostra, não corte instantâneo.
- Registrador ENVX (`$x8`) reporta nível atual. O comportamento de ENDX e mute foi conservado.
- Áudio WinMM/WAV PCM estéreo de 16 bits a 32 kHz, iniciadores com ganho padrão de 100% para evitar clipping do ganho anterior de 200%.
- Correções do dispatcher Tetris `$82:BDBA` da v0.4.24 preservadas. Nenhuma mudança nas fontes `generated_*.cpp`, fluxo 65C816, PPU e DMA.

## Testes

- CMake: seis testes C++ escolhidos 6/6 (runtime, registers DSP, PCM/WAV, sinal áudio, BDBA, ADSR/interpolação).
- Compilação completa do alvo `game` em Linux com GCC Debug O0: concluída.
- Execução headless do port em Linux até frame 1200, replay normal e WAV: exit code 0; `generated_frames=639108`, `nonzero_frames=284989`, `peak=11808`, `dsp_samples=639108` e sem erro de backend.
- Não foi possível compilar o `game.exe` Windows / ouvir a saída WinMM em um dispositivo.
- Não houve reprodução até o frame 5774, nem validação de vitória da fase.

## Limites

Ainda sem filtro gaussiano autêntico do SNES, eco FIR, LFSR de ruído e modulação de pitch. O ADSR/GAIN é aproximado: melhoria objetiva frente ao estado fixo anterior, mas não equivalência comprovada ao S-DSP.

O Forja65 separado não deve ser usado para regenerar o Tetris sem preservar patches específicos do port; `AUTO-APRENDER` e `VALIDAR-*.cmd` são ferramentas opcionais de engenharia que alteram o projeto.
