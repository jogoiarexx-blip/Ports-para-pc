#include "generated.hpp"
void sub_82CE75_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CE75u: goto L_82CE75;
    case 0x82CE77u: goto L_82CE77;
    case 0x82CE79u: goto L_82CE79;
    case 0x82CE7Bu: goto L_82CE7B;
    case 0x82CE7Eu: goto L_82CE7E;
    case 0x82CE80u: goto L_82CE80;
    case 0x82CE82u: goto L_82CE82;
    case 0x82CE83u: goto L_82CE83;
    case 0x82CE85u: goto L_82CE85;
    case 0x82CE89u: goto L_82CE89;
    case 0x82CE8Cu: goto L_82CE8C;
    case 0x82CE8Eu: goto L_82CE8E;
    case 0x82CE91u: goto L_82CE91;
    case 0x82CE93u: goto L_82CE93;
    case 0x82CE95u: goto L_82CE95;
    case 0x82CE97u: goto L_82CE97;
    case 0x82CE99u: goto L_82CE99;
    case 0x82CE9Bu: goto L_82CE9B;
    case 0x82CE9Du: goto L_82CE9D;
    case 0x82CEA0u: goto L_82CEA0;
    case 0x82CEA2u: goto L_82CEA2;
    case 0x82CEA4u: goto L_82CEA4;
    case 0x82CEA6u: goto L_82CEA6;
    case 0x82CEA8u: goto L_82CEA8;
    case 0x82CEABu: goto L_82CEAB;
    case 0x82CEADu: goto L_82CEAD;
    case 0x82CEAFu: goto L_82CEAF;
    case 0x82CEB1u: goto L_82CEB1;
    case 0x82CEB3u: goto L_82CEB3;
    case 0x82CEB7u: goto L_82CEB7;
    case 0x82CEBBu: goto L_82CEBB;
    case 0x82CEBFu: goto L_82CEBF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE75u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE75u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE75 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE77;
L_82CE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE77 BNE -> $82CEBF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEBF; }
    goto L_82CE79;
L_82CE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE79 BNE -> $82CEBF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEBF; }
    goto L_82CE7B;
L_82CE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE7B INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CE7E;
L_82CE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE7E SEP
    cpu.sep(0x20u);
    goto L_82CE80;
L_82CE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE80 LDA
    cpu.setA(0x81u, 8);
    goto L_82CE82;
L_82CE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE82 XBA
    cpu.xba();
    goto L_82CE83;
L_82CE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE83 LDA
    cpu.setA(0x1u, 8);
    goto L_82CE85;
L_82CE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CE85 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCE88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE89u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x82CE85u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CE89;
L_82CE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE89u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE89u,0x82CE89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE89u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE89u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE89 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE8C;
L_82CE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE8C BNE -> $82CE9D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE9D; }
    goto L_82CE8E;
L_82CE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu, 4u, 3u, cpu.address("abs", 0x02CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE8E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE91;
L_82CE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE91u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE91 CMP
    cpu.compareA(0x4Fu);
    goto L_82CE93;
L_82CE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE93 BNE -> $82CE99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE99; }
    goto L_82CE95;
L_82CE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE95 LDA
    cpu.setA(0x11u, 8);
    goto L_82CE97;
L_82CE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE97 BRA -> $82CEB3
    goto L_82CEB3;
L_82CE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE99 LDA
    cpu.setA(0x9u, 8);
    goto L_82CE9B;
L_82CE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE9B BRA -> $82CEB3
    goto L_82CEB3;
L_82CE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du, 4u, 3u, cpu.address("abs", 0x02CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEA0;
L_82CEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA0 CMP
    cpu.compareA(0x63u);
    goto L_82CEA2;
L_82CEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA2 BNE -> $82CEA8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEA8; }
    goto L_82CEA4;
L_82CEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA4 LDA
    cpu.setA(0x11u, 8);
    goto L_82CEA6;
L_82CEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA6 BRA -> $82CEB3
    goto L_82CEB3;
L_82CEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u, 4u, 3u, cpu.address("abs", 0x0802u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEAB;
L_82CEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAB BMI -> $82CEB1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82CEB1; }
    goto L_82CEAD;
L_82CEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAD LDA
    cpu.setA(0x11u, 8);
    goto L_82CEAF;
L_82CEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAF BRA -> $82CEB3
    goto L_82CEB3;
L_82CEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEB1 LDA
    cpu.setA(0xFu, 8);
    goto L_82CEB3;
L_82CEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEB3 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82CEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEB7;
L_82CEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEB7u,0x82CEB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB7u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEB7 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82CEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEBB;
L_82CEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEBBu,0x82CEBBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEBB JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEBEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEBFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82CEBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEBF;
L_82CEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEBFu);return;} hw.unresolvedReturn(0x82CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEBFu);return;} hw.unresolvedReturn(0x82CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEBFu,0x82CEBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82CE75_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CE75u: goto L_82CE75;
    case 0x82CE77u: goto L_82CE77;
    case 0x82CE79u: goto L_82CE79;
    case 0x82CE7Bu: goto L_82CE7B;
    case 0x82CE7Eu: goto L_82CE7E;
    case 0x82CE80u: goto L_82CE80;
    case 0x82CE82u: goto L_82CE82;
    case 0x82CE83u: goto L_82CE83;
    case 0x82CE85u: goto L_82CE85;
    case 0x82CE89u: goto L_82CE89;
    case 0x82CE8Cu: goto L_82CE8C;
    case 0x82CE8Eu: goto L_82CE8E;
    case 0x82CE91u: goto L_82CE91;
    case 0x82CE93u: goto L_82CE93;
    case 0x82CE95u: goto L_82CE95;
    case 0x82CE97u: goto L_82CE97;
    case 0x82CE99u: goto L_82CE99;
    case 0x82CE9Bu: goto L_82CE9B;
    case 0x82CE9Du: goto L_82CE9D;
    case 0x82CEA0u: goto L_82CEA0;
    case 0x82CEA2u: goto L_82CEA2;
    case 0x82CEA4u: goto L_82CEA4;
    case 0x82CEA6u: goto L_82CEA6;
    case 0x82CEA8u: goto L_82CEA8;
    case 0x82CEABu: goto L_82CEAB;
    case 0x82CEADu: goto L_82CEAD;
    case 0x82CEAFu: goto L_82CEAF;
    case 0x82CEB1u: goto L_82CEB1;
    case 0x82CEB3u: goto L_82CEB3;
    case 0x82CEB7u: goto L_82CEB7;
    case 0x82CEBBu: goto L_82CEBB;
    case 0x82CEBFu: goto L_82CEBF;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CE75:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE75u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE75u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE75u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE75 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE77;
L_82CE77:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE77u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE77u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE77 BNE -> $82CEBF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEBF; }
    goto L_82CE79;
L_82CE79:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE79u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE79u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE79 BNE -> $82CEBF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEBF; }
    goto L_82CE7B;
L_82CE7B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Bu, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE7B INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CE7E;
L_82CE7E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE7Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE7Eu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE7E SEP
    cpu.sep(0x20u);
    goto L_82CE80;
L_82CE80:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE80u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE80u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE80 LDA
    cpu.setA(0x81u, 8);
    goto L_82CE82;
L_82CE82:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE82u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u,cpu,0xEBu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE82u, 3u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE82 XBA
    cpu.xba();
    goto L_82CE83;
L_82CE83:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE83u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE83u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE83 LDA
    cpu.setA(0x1u, 8);
    goto L_82CE85;
L_82CE85:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE85u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE85u, 8u, 4u, 0x808700u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CE85 JSL -> $808700 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCE88u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCE89u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808700u, 0x82CE85u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CE89;
L_82CE89:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE89u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCE89u,0x82CE89u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE89u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE89u, 4u, 3u, cpu.address("abs", 0x0135u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE89 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE8C;
L_82CE8C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Cu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Cu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE8C BNE -> $82CE9D
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE9D; }
    goto L_82CE8E;
L_82CE8E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE8Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE8Eu, 4u, 3u, cpu.address("abs", 0x02CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE8E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CE91;
L_82CE91:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE91u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE91u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE91u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE91 CMP
    cpu.compareA(0x4Fu);
    goto L_82CE93;
L_82CE93:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE93u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE93u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE93 BNE -> $82CE99
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CE99; }
    goto L_82CE95;
L_82CE95:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE95u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE95u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE95u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE95 LDA
    cpu.setA(0x11u, 8);
    goto L_82CE97;
L_82CE97:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE97u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE97u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE97 BRA -> $82CEB3
    goto L_82CEB3;
L_82CE99:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE99u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE99u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE99 LDA
    cpu.setA(0x9u, 8);
    goto L_82CE9B;
L_82CE9B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Bu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE9B BRA -> $82CEB3
    goto L_82CEB3;
L_82CE9D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCE9Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCE9Du, 4u, 3u, cpu.address("abs", 0x02CEu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CE9D LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2CEu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEA0;
L_82CEA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA0u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA0u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA0 CMP
    cpu.compareA(0x63u);
    goto L_82CEA2;
L_82CEA2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA2u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA2u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA2 BNE -> $82CEA8
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEA8; }
    goto L_82CEA4;
L_82CEA4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA4u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA4 LDA
    cpu.setA(0x11u, 8);
    goto L_82CEA6;
L_82CEA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA6u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA6 BRA -> $82CEB3
    goto L_82CEB3;
L_82CEA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEA8u, 4u, 3u, cpu.address("abs", 0x0802u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEA8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEAB;
L_82CEAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAB BMI -> $82CEB1
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82CEB1; }
    goto L_82CEAD;
L_82CEAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEADu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAD LDA
    cpu.setA(0x11u, 8);
    goto L_82CEAF;
L_82CEAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAFu,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEAFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEAF BRA -> $82CEB3
    goto L_82CEB3;
L_82CEB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEB1 LDA
    cpu.setA(0xFu, 8);
    goto L_82CEB3;
L_82CEB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB3u, 8u, 4u, 0x80A6BDu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEB3 JSL -> $80A6BD stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEB6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEB7u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6BDu, 0x82CEB3u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEB7;
L_82CEB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEB7u))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEB7u,0x82CEB7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB7u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEB7u, 8u, 4u, 0x80A6A5u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEB7 JSL -> $80A6A5 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEBAu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEBBu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80A6A5u, 0x82CEB7u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEBB;
L_82CEBB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBBu))return;
  if (!(cpu.e==false && cpu.m8==true && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEBBu,0x82CEBBu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBBu, 8u, 4u, 0x808D2Fu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82CEBB JSL -> $808D2F stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xCEBEu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEBFu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x808D2Fu, 0x82CEBBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEBF;
L_82CEBF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEBFu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEBFu);return;} hw.unresolvedReturn(0x82CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==true && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEBFu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEBF RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEBFu);return;} hw.unresolvedReturn(0x82CEBFu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEBFu,0x82CEBFu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

