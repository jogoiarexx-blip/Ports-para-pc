#include "generated.hpp"
void sub_82CEC0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CEC0u: goto L_82CEC0;
    case 0x82CEC2u: goto L_82CEC2;
    case 0x82CEC4u: goto L_82CEC4;
    case 0x82CEC6u: goto L_82CEC6;
    case 0x82CEC8u: goto L_82CEC8;
    case 0x82CECAu: goto L_82CECA;
    case 0x82CECCu: goto L_82CECC;
    case 0x82CECFu: goto L_82CECF;
    case 0x82CED1u: goto L_82CED1;
    case 0x82CED4u: goto L_82CED4;
    case 0x82CED6u: goto L_82CED6;
    case 0x82CED9u: goto L_82CED9;
    case 0x82CEDBu: goto L_82CEDB;
    case 0x82CEDEu: goto L_82CEDE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC0 SEP
    cpu.sep(0x20u);
    goto L_82CEC2;
L_82CEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEC4;
L_82CEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC4 BNE -> $82CECF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CECF; }
    goto L_82CEC6;
L_82CEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC6 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_82CEC8;
L_82CEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC8 LDA
    cpu.setA(0x12u, 8);
    goto L_82CECA;
L_82CECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECA STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_82CECC;
L_82CECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu, 6u, 3u, cpu.address("abs", 0x017Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECC INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CECF;
L_82CECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECF REP
    cpu.rep(0x20u);
    goto L_82CED1;
L_82CED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CED4;
L_82CED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED4 BEQ -> $82CEDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEDE; }
    goto L_82CED6;
L_82CED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CED9;
L_82CED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED9 BMI -> $82CEDE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82CEDE; }
    goto L_82CEDB;
L_82CEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu, 6u, 3u, cpu.address("abs", 0xD2C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEDB JSR -> $82D2C9 stack real
    { cpu.push16Value(hw,0xCEDDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEDEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2C9u), 0x82CEDBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEDE;
L_82CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEDEu,0x82CEDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEDE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEDEu);return;} hw.unresolvedReturn(0x82CEDEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CEC0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CEC0u: goto L_82CEC0;
    case 0x82CEC2u: goto L_82CEC2;
    case 0x82CEC4u: goto L_82CEC4;
    case 0x82CEC6u: goto L_82CEC6;
    case 0x82CEC8u: goto L_82CEC8;
    case 0x82CECAu: goto L_82CECA;
    case 0x82CECCu: goto L_82CECC;
    case 0x82CECFu: goto L_82CECF;
    case 0x82CED1u: goto L_82CED1;
    case 0x82CED4u: goto L_82CED4;
    case 0x82CED6u: goto L_82CED6;
    case 0x82CED9u: goto L_82CED9;
    case 0x82CEDBu: goto L_82CEDB;
    case 0x82CEDEu: goto L_82CEDE;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CEC0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC0u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC0 SEP
    cpu.sep(0x20u);
    goto L_82CEC2;
L_82CEC2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC2u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x78u), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC2 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x78u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CEC4;
L_82CEC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC4 BNE -> $82CECF
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CECF; }
    goto L_82CEC6;
L_82CEC6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC6u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Bu), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC6 STZ
    hw.write(cpu.address("dp", 0x7Bu), 0, cpu.m8?8:16);
    goto L_82CEC8;
L_82CEC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC8u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEC8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CEC8 LDA
    cpu.setA(0x12u, 8);
    goto L_82CECA;
L_82CECA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECAu, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECA STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_82CECC;
L_82CECC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECCu, 6u, 3u, cpu.address("abs", 0x017Bu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECC INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CECF;
L_82CECF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCECFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu,cpu,0xC2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCECFu, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CECF REP
    cpu.rep(0x20u);
    goto L_82CED1;
L_82CED1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED1u, 5u, 3u, cpu.address("abs", 0x0135u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED1 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x135u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CED4;
L_82CED4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED4u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED4 BEQ -> $82CEDE
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CEDE; }
    goto L_82CED6;
L_82CED6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED6u, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED6 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CED9;
L_82CED9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCED9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCED9u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CED9 BMI -> $82CEDE
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82CEDE; }
    goto L_82CEDB;
L_82CEDB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDBu, 6u, 3u, cpu.address("abs", 0xD2C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEDB JSR -> $82D2C9 stack real
    { cpu.push16Value(hw,0xCEDDu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCEDEu,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2C9u), 0x82CEDBu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CEDE;
L_82CEDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCEDEu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCEDEu,0x82CEDEu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCEDEu, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CEDE RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CEDEu);return;} hw.unresolvedReturn(0x82CEDEu,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

