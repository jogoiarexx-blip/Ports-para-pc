#include "generated.hpp"
void sub_82CFC8_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CFC8u: goto L_82CFC8;
    case 0x82CFCBu: goto L_82CFCB;
    case 0x82CFCDu: goto L_82CFCD;
    case 0x82CFCFu: goto L_82CFCF;
    case 0x82CFD1u: goto L_82CFD1;
    case 0x82CFD3u: goto L_82CFD3;
    case 0x82CFD5u: goto L_82CFD5;
    case 0x82CFD7u: goto L_82CFD7;
    case 0x82CFDAu: goto L_82CFDA;
    case 0x82CFDCu: goto L_82CFDC;
    case 0x82CFDEu: goto L_82CFDE;
    case 0x82CFE1u: goto L_82CFE1;
    case 0x82CFE3u: goto L_82CFE3;
    case 0x82CFE6u: goto L_82CFE6;
    case 0x82CFE7u: goto L_82CFE7;
    case 0x82CFEAu: goto L_82CFEA;
    case 0x82CFECu: goto L_82CFEC;
    case 0x82CFEFu: goto L_82CFEF;
    case 0x82CFF2u: goto L_82CFF2;
    case 0x82CFF5u: goto L_82CFF5;
    case 0x82CFF8u: goto L_82CFF8;
    case 0x82CFFAu: goto L_82CFFA;
    case 0x82CFFDu: goto L_82CFFD;
    case 0x82D000u: goto L_82D000;
    case 0x82D002u: goto L_82D002;
    case 0x82D004u: goto L_82D004;
    case 0x82D006u: goto L_82D006;
    case 0x82D007u: goto L_82D007;
    case 0x82D00Au: goto L_82D00A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CFC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u, 5u, 3u, cpu.address("abs", 0x0189u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x189u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFCB;
L_82CFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCB BNE -> $82CFDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFDA; }
    goto L_82CFCD;
L_82CFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFCF;
L_82CFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCF BNE -> $82CFE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE6; }
    goto L_82CFD1;
L_82CFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFD3;
L_82CFD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD3 BNE -> $82CFDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFDA; }
    goto L_82CFD5;
L_82CFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD5 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_82CFD7;
L_82CFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u, 8u, 3u, cpu.address("abs", 0x0189u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD7 INC
    cpu.incMem(hw, cpu.address("abs", 0x189u), cpu.m8?8:16);
    goto L_82CFDA;
L_82CFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFDC;
L_82CFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDC BNE -> $82CFE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE6; }
    goto L_82CFDE;
L_82CFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFE1;
L_82CFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE1 BEQ -> $82CFE7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE7; }
    goto L_82CFE3;
L_82CFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE3 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82CFE6;
L_82CFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CFE6u);return;} hw.unresolvedReturn(0x82CFE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFEA;
L_82CFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEA BEQ -> $82D007
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D007; }
    goto L_82CFEC;
L_82CFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEC LDA
    cpu.setA(0x7u, 16);
    goto L_82CFEF;
L_82CFEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEF STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82CFF2;
L_82CFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82CFF5;
L_82CFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFF8;
L_82CFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF8 BEQ -> $82CFFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFFD; }
    goto L_82CFFA;
L_82CFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFAu, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFFA DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82CFFD;
L_82CFFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFDu, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFFD JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xCFFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD000u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82CFFDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D000;
L_82D000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD000u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD000u,0x82D000u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D000 SEP
    cpu.sep(0x20u);
    goto L_82D002;
L_82D002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D002 LDA
    cpu.setA(0x12u, 8);
    goto L_82D004;
L_82D004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D004 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_82D006;
L_82D006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D006 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D006u);return;} hw.unresolvedReturn(0x82D006u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D007 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82D00A;
L_82D00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D00A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D00Au);return;} hw.unresolvedReturn(0x82D00Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CFC8_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CFC8u: goto L_82CFC8;
    case 0x82CFCBu: goto L_82CFCB;
    case 0x82CFCDu: goto L_82CFCD;
    case 0x82CFCFu: goto L_82CFCF;
    case 0x82CFD1u: goto L_82CFD1;
    case 0x82CFD3u: goto L_82CFD3;
    case 0x82CFD5u: goto L_82CFD5;
    case 0x82CFD7u: goto L_82CFD7;
    case 0x82CFDAu: goto L_82CFDA;
    case 0x82CFDCu: goto L_82CFDC;
    case 0x82CFDEu: goto L_82CFDE;
    case 0x82CFE1u: goto L_82CFE1;
    case 0x82CFE3u: goto L_82CFE3;
    case 0x82CFE6u: goto L_82CFE6;
    case 0x82CFE7u: goto L_82CFE7;
    case 0x82CFEAu: goto L_82CFEA;
    case 0x82CFECu: goto L_82CFEC;
    case 0x82CFEFu: goto L_82CFEF;
    case 0x82CFF2u: goto L_82CFF2;
    case 0x82CFF5u: goto L_82CFF5;
    case 0x82CFF8u: goto L_82CFF8;
    case 0x82CFFAu: goto L_82CFFA;
    case 0x82CFFDu: goto L_82CFFD;
    case 0x82D000u: goto L_82D000;
    case 0x82D002u: goto L_82D002;
    case 0x82D004u: goto L_82D004;
    case 0x82D006u: goto L_82D006;
    case 0x82D007u: goto L_82D007;
    case 0x82D00Au: goto L_82D00A;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CFC8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC8u, 5u, 3u, cpu.address("abs", 0x0189u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFC8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x189u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFCB;
L_82CFCB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCBu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCB BNE -> $82CFDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFDA; }
    goto L_82CFCD;
L_82CFCD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFCF;
L_82CFCF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFCFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFCFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFCF BNE -> $82CFE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE6; }
    goto L_82CFD1;
L_82CFD1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFD3;
L_82CFD3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD3u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD3 BNE -> $82CFDA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFDA; }
    goto L_82CFD5;
L_82CFD5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD5 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_82CFD7;
L_82CFD7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFD7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFD7u, 8u, 3u, cpu.address("abs", 0x0189u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFD7 INC
    cpu.incMem(hw, cpu.address("abs", 0x189u), cpu.m8?8:16);
    goto L_82CFDA;
L_82CFDA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFDC;
L_82CFDC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDC BNE -> $82CFE6
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE6; }
    goto L_82CFDE;
L_82CFDE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFDEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFDEu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFDE LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFE1;
L_82CFE1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE1u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE1 BEQ -> $82CFE7
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFE7; }
    goto L_82CFE3;
L_82CFE3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE3u, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE3 DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82CFE6;
L_82CFE6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFE6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CFE6u);return;} hw.unresolvedReturn(0x82CFE6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CFE7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFE7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFE7u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFE7 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFEA;
L_82CFEA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEAu,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEAu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEA BEQ -> $82D007
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D007; }
    goto L_82CFEC;
L_82CFEC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFECu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFECu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEC LDA
    cpu.setA(0x7u, 16);
    goto L_82CFEF;
L_82CFEF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFEFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFEFu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFEF STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82CFF2;
L_82CFF2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF2u, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF2 DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82CFF5;
L_82CFF5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF5u, 5u, 3u, cpu.address("abs", 0x017Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF5 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFF8;
L_82CFF8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFF8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFF8u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFF8 BEQ -> $82CFFD
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFFD; }
    goto L_82CFFA;
L_82CFFA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFAu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFAu, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFFA DEC
    cpu.decMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82CFFD;
L_82CFFD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFFDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFDu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFFDu, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFFD JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xCFFFu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD000u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82CFFDu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D000;
L_82D000:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD000u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD000u,0x82D000u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD000u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD000u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D000 SEP
    cpu.sep(0x20u);
    goto L_82D002;
L_82D002:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD002u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD002u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D002 LDA
    cpu.setA(0x12u, 8);
    goto L_82D004;
L_82D004:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD004u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD004u, 3u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x7Au), 1u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D004 STA
    hw.write(cpu.address("dp", 0x7Au), cpu.a, cpu.m8?8:16);
    goto L_82D006;
L_82D006:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD006u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD006u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D006 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D006u);return;} hw.unresolvedReturn(0x82D006u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82D007:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD007u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD007u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D007 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82D00A;
L_82D00A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD00Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD00Au, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D00A RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D00Au);return;} hw.unresolvedReturn(0x82D00Au,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

