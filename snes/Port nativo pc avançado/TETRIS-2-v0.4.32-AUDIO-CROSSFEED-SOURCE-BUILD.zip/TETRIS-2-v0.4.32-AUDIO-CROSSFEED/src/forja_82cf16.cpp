#include "generated.hpp"
void sub_82CF16_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CF16u: goto L_82CF16;
    case 0x82CF18u: goto L_82CF18;
    case 0x82CF1Au: goto L_82CF1A;
    case 0x82CF1Du: goto L_82CF1D;
    case 0x82CF1Fu: goto L_82CF1F;
    case 0x82CF22u: goto L_82CF22;
    case 0x82CF23u: goto L_82CF23;
    case 0x82CF26u: goto L_82CF26;
    case 0x82CF29u: goto L_82CF29;
    case 0x82CF2Bu: goto L_82CF2B;
    case 0x82CF2Eu: goto L_82CF2E;
    case 0x82CF31u: goto L_82CF31;
    case 0x82CF34u: goto L_82CF34;
    case 0x82CF37u: goto L_82CF37;
    case 0x82CF3Au: goto L_82CF3A;
    case 0x82CF3Cu: goto L_82CF3C;
    case 0x82CF3Fu: goto L_82CF3F;
    case 0x82CF42u: goto L_82CF42;
    case 0x82CF43u: goto L_82CF43;
    case 0x82CF46u: goto L_82CF46;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF18;
L_82CF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF18 BNE -> $82CF22
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF22; }
    goto L_82CF1A;
L_82CF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF1D;
L_82CF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1D BEQ -> $82CF23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF23; }
    goto L_82CF1F;
L_82CF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1F DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82CF22;
L_82CF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF22 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF22u);return;} hw.unresolvedReturn(0x82CF22u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF23u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF26;
L_82CF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF26 CMP
    cpu.compareA(0x3u);
    goto L_82CF29;
L_82CF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF29 BCS -> $82CF43
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82CF43; }
    goto L_82CF2B;
L_82CF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF2B LDA
    cpu.setA(0xAu, 16);
    goto L_82CF2E;
L_82CF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF2E STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82CF31;
L_82CF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF31u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF31u, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF31 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82CF34;
L_82CF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF34u, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF37;
L_82CF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF37 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16));
    goto L_82CF3A;
L_82CF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF3A BEQ -> $82CF3F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF3F; }
    goto L_82CF3C;
L_82CF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF3C INC
    cpu.incMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82CF3F;
L_82CF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF3F JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xCF41u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF42u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82CF3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CF42;
L_82CF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF42u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF42u,0x82CF42u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF42 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF42u);return;} hw.unresolvedReturn(0x82CF42u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF43 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CF46;
L_82CF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF46u);return;} hw.unresolvedReturn(0x82CF46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82CF16_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CF16u: goto L_82CF16;
    case 0x82CF18u: goto L_82CF18;
    case 0x82CF1Au: goto L_82CF1A;
    case 0x82CF1Du: goto L_82CF1D;
    case 0x82CF1Fu: goto L_82CF1F;
    case 0x82CF22u: goto L_82CF22;
    case 0x82CF23u: goto L_82CF23;
    case 0x82CF26u: goto L_82CF26;
    case 0x82CF29u: goto L_82CF29;
    case 0x82CF2Bu: goto L_82CF2B;
    case 0x82CF2Eu: goto L_82CF2E;
    case 0x82CF31u: goto L_82CF31;
    case 0x82CF34u: goto L_82CF34;
    case 0x82CF37u: goto L_82CF37;
    case 0x82CF3Au: goto L_82CF3A;
    case 0x82CF3Cu: goto L_82CF3C;
    case 0x82CF3Fu: goto L_82CF3F;
    case 0x82CF42u: goto L_82CF42;
    case 0x82CF43u: goto L_82CF43;
    case 0x82CF46u: goto L_82CF46;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CF16:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF16u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF16u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF16 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF18;
L_82CF18:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF18u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF18u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF18 BNE -> $82CF22
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF22; }
    goto L_82CF1A;
L_82CF1A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Au, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1A LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x13Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF1D;
L_82CF1D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Du, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1D BEQ -> $82CF23
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF23; }
    goto L_82CF1F;
L_82CF1F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF1Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu,cpu,0xCEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF1Fu, 8u, 3u, cpu.address("abs", 0x013Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF1F DEC
    cpu.decMem(hw, cpu.address("abs", 0x13Du), cpu.m8?8:16);
    goto L_82CF22;
L_82CF22:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF22u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF22u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF22 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF22u);return;} hw.unresolvedReturn(0x82CF22u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CF23:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF23u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF23u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF23u, 5u, 3u, cpu.address("abs", 0x017Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF23 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x17Du), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF26;
L_82CF26:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF26u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u,cpu,0xC9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF26u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF26 CMP
    cpu.compareA(0x3u);
    goto L_82CF29;
L_82CF29:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF29u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u,cpu,0xB0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF29u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF29 BCS -> $82CF43
    if (cpu.c) { hw.addCpuInternalCycles(1u); goto L_82CF43; }
    goto L_82CF2B;
L_82CF2B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Bu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF2B LDA
    cpu.setA(0xAu, 16);
    goto L_82CF2E;
L_82CF2E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF2Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF2Eu, 5u, 3u, cpu.address("abs", 0x013Du), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF2E STA
    hw.write(cpu.address("abs", 0x13Du), cpu.a, cpu.m8?8:16);
    goto L_82CF31;
L_82CF31:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF31u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF31u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF31u, 8u, 3u, cpu.address("abs", 0x017Du), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF31 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Du), cpu.m8?8:16);
    goto L_82CF34;
L_82CF34:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF34u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF34u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF34u, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF34 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CF37;
L_82CF37:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF37u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u,cpu,0x0Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF37u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF37 ORA
    cpu.logicOr(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16));
    goto L_82CF3A;
L_82CF3A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Au, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF3A BEQ -> $82CF3F
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CF3F; }
    goto L_82CF3C;
L_82CF3C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Cu, 8u, 3u, cpu.address("abs", 0x017Fu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF3C INC
    cpu.incMem(hw, cpu.address("abs", 0x17Fu), cpu.m8?8:16);
    goto L_82CF3F;
L_82CF3F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF3Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF3Fu, 6u, 3u, cpu.address("abs", 0xD05Bu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF3F JSR -> $82D05B stack real
    { cpu.push16Value(hw,0xCF41u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCF42u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD05Bu), 0x82CF3Fu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CF42;
L_82CF42:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF42u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCF42u,0x82CF42u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF42u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF42 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF42u);return;} hw.unresolvedReturn(0x82CF42u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
L_82CF43:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF43u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF43u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CF43 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82CF46;
L_82CF46:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCF46u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCF46u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCF46u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CF46 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CF46u);return;} hw.unresolvedReturn(0x82CF46u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

