#include "generated.hpp"
void sub_82CFA0_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CFA0u: goto L_82CFA0;
    case 0x82CFA3u: goto L_82CFA3;
    case 0x82CFA6u: goto L_82CFA6;
    case 0x82CFA8u: goto L_82CFA8;
    case 0x82CFABu: goto L_82CFAB;
    case 0x82CFADu: goto L_82CFAD;
    case 0x82CFAFu: goto L_82CFAF;
    case 0x82CFB1u: goto L_82CFB1;
    case 0x82CFB3u: goto L_82CFB3;
    case 0x82CFB5u: goto L_82CFB5;
    case 0x82CFB7u: goto L_82CFB7;
    case 0x82CFBAu: goto L_82CFBA;
    case 0x82CFBCu: goto L_82CFBC;
    case 0x82CFBEu: goto L_82CFBE;
    case 0x82CFC1u: goto L_82CFC1;
    case 0x82CFC4u: goto L_82CFC4;
    case 0x82CFC7u: goto L_82CFC7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFA3;
L_82CFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA3 AND
    cpu.logicAnd(0xFFu);
    goto L_82CFA6;
L_82CFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA6 BNE -> $82CFC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFC7; }
    goto L_82CFA8;
L_82CFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u, 5u, 3u, cpu.address("abs", 0x0189u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x189u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFAB;
L_82CFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAB BNE -> $82CFBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFAD;
L_82CFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFAF;
L_82CFAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAF BNE -> $82CFBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFB1;
L_82CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFB3;
L_82CFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB3 BEQ -> $82CFBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFB5;
L_82CFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB5 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_82CFB7;
L_82CFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u, 8u, 3u, cpu.address("abs", 0x0189u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB7 INC
    cpu.incMem(hw, cpu.address("abs", 0x189u), cpu.m8?8:16);
    goto L_82CFBA;
L_82CFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFBC;
L_82CFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBC BNE -> $82CFC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFC7; }
    goto L_82CFBE;
L_82CFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBE LDA
    cpu.setA(0x800u, 16);
    goto L_82CFC1;
L_82CFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC1u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFC1 STA
    hw.write(cpu.address("abs", 0x13Fu), cpu.a, cpu.m8?8:16);
    goto L_82CFC4;
L_82CFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u, 6u, 3u, cpu.address("abs", 0xBDBAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFC4 JSR -> $82BDBA stack real
    { cpu.push16Value(hw,0xCFC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFC7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBDBAu), 0x82CFC4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CFC7;
L_82CFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFC7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CFC7u);return;} hw.unresolvedReturn(0x82CFC7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFC7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CFC7u);return;} hw.unresolvedReturn(0x82CFC7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFC7u,0x82CFC7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82CFA0_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82CFA0u: goto L_82CFA0;
    case 0x82CFA3u: goto L_82CFA3;
    case 0x82CFA6u: goto L_82CFA6;
    case 0x82CFA8u: goto L_82CFA8;
    case 0x82CFABu: goto L_82CFAB;
    case 0x82CFADu: goto L_82CFAD;
    case 0x82CFAFu: goto L_82CFAF;
    case 0x82CFB1u: goto L_82CFB1;
    case 0x82CFB3u: goto L_82CFB3;
    case 0x82CFB5u: goto L_82CFB5;
    case 0x82CFB7u: goto L_82CFB7;
    case 0x82CFBAu: goto L_82CFBA;
    case 0x82CFBCu: goto L_82CFBC;
    case 0x82CFBEu: goto L_82CFBE;
    case 0x82CFC1u: goto L_82CFC1;
    case 0x82CFC4u: goto L_82CFC4;
    case 0x82CFC7u: goto L_82CFC7;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82CFA0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA0u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA0 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFA3;
L_82CFA3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA3u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA3 AND
    cpu.logicAnd(0xFFu);
    goto L_82CFA6;
L_82CFA6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA6u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA6 BNE -> $82CFC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFC7; }
    goto L_82CFA8;
L_82CFA8:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFA8u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFA8u, 5u, 3u, cpu.address("abs", 0x0189u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFA8 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x189u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFAB;
L_82CFAB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFABu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAB BNE -> $82CFBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFAD;
L_82CFAD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFADu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x71u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x71u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFAF;
L_82CFAF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFAFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAFu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFAFu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFAF BNE -> $82CFBA
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFB1;
L_82CFB1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFB3;
L_82CFB3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB3u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB3 BEQ -> $82CFBA
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFBA; }
    goto L_82CFB5;
L_82CFB5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u,cpu,0x64u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB5 STZ
    hw.write(cpu.address("dp", 0x6Fu), 0, cpu.m8?8:16);
    goto L_82CFB7;
L_82CFB7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFB7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFB7u, 8u, 3u, cpu.address("abs", 0x0189u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFB7 INC
    cpu.incMem(hw, cpu.address("abs", 0x189u), cpu.m8?8:16);
    goto L_82CFBA;
L_82CFBA:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBAu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBAu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBA LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82CFBC;
L_82CFBC:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBCu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBCu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBC BNE -> $82CFC7
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82CFC7; }
    goto L_82CFBE;
L_82CFBE:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFBEu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFBEu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFBE LDA
    cpu.setA(0x800u, 16);
    goto L_82CFC1;
L_82CFC1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC1u,cpu,0x8Du);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC1u, 5u, 3u, cpu.address("abs", 0x013Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82CFC1 STA
    hw.write(cpu.address("abs", 0x13Fu), cpu.a, cpu.m8?8:16);
    goto L_82CFC4;
L_82CFC4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC4u, 6u, 3u, cpu.address("abs", 0xBDBAu), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFC4 JSR -> $82BDBA stack real
    { cpu.push16Value(hw,0xCFC6u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xCFC7u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xBDBAu), 0x82CFC4u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82CFC7;
L_82CFC7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xCFC7u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xCFC7u,0x82CFC7u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xCFC7u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82CFC7 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82CFC7u);return;} hw.unresolvedReturn(0x82CFC7u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

