#include "generated.hpp"
void sub_82D15E_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D15Eu: goto L_82D15E;
    case 0x82D161u: goto L_82D161;
    case 0x82D163u: goto L_82D163;
    case 0x82D166u: goto L_82D166;
    case 0x82D16Au: goto L_82D16A;
    case 0x82D16Cu: goto L_82D16C;
    case 0x82D16Fu: goto L_82D16F;
    case 0x82D171u: goto L_82D171;
    case 0x82D174u: goto L_82D174;
    case 0x82D176u: goto L_82D176;
    case 0x82D179u: goto L_82D179;
    case 0x82D17Bu: goto L_82D17B;
    case 0x82D17Fu: goto L_82D17F;
    case 0x82D182u: goto L_82D182;
    case 0x82D184u: goto L_82D184;
    case 0x82D187u: goto L_82D187;
    case 0x82D189u: goto L_82D189;
    case 0x82D18Du: goto L_82D18D;
    case 0x82D190u: goto L_82D190;
    case 0x82D192u: goto L_82D192;
    case 0x82D195u: goto L_82D195;
    case 0x82D197u: goto L_82D197;
    case 0x82D19Au: goto L_82D19A;
    case 0x82D19Cu: goto L_82D19C;
    case 0x82D19Fu: goto L_82D19F;
    case 0x82D1A1u: goto L_82D1A1;
    case 0x82D1A3u: goto L_82D1A3;
    case 0x82D1A5u: goto L_82D1A5;
    case 0x82D1A7u: goto L_82D1A7;
    case 0x82D1A9u: goto L_82D1A9;
    case 0x82D1ABu: goto L_82D1AB;
    case 0x82D1ADu: goto L_82D1AD;
    case 0x82D1B0u: goto L_82D1B0;
    case 0x82D1B1u: goto L_82D1B1;
    case 0x82D1B2u: goto L_82D1B2;
    case 0x82D1B6u: goto L_82D1B6;
    case 0x82D1B7u: goto L_82D1B7;
    case 0x82D1BBu: goto L_82D1BB;
    case 0x82D1BDu: goto L_82D1BD;
    case 0x82D1BFu: goto L_82D1BF;
    case 0x82D1C0u: goto L_82D1C0;
    case 0x82D1C3u: goto L_82D1C3;
    case 0x82D1C5u: goto L_82D1C5;
    case 0x82D1C9u: goto L_82D1C9;
    case 0x82D1CBu: goto L_82D1CB;
    case 0x82D1CDu: goto L_82D1CD;
    case 0x82D1D0u: goto L_82D1D0;
    case 0x82D1D2u: goto L_82D1D2;
    case 0x82D1D4u: goto L_82D1D4;
    case 0x82D1D6u: goto L_82D1D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu, 5u, 3u, cpu.address("abs", 0x0181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D15E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x181u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D161;
L_82D161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD161u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D161 BEQ -> $82D1D6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D1D6; }
    goto L_82D163;
L_82D163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D163 LDX
    cpu.setX(0xCu, 16);
    goto L_82D166;
L_82D166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D166 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D16A;
L_82D16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D16C;
L_82D16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D16F;
L_82D16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D171;
L_82D171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D171 LDA
    cpu.setA(0x70u, 16);
    goto L_82D174;
L_82D174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D174 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D176;
L_82D176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD176u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD176u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D176 LDA
    cpu.setA(0x80u, 16);
    goto L_82D179;
L_82D179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D179 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D17B;
L_82D17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D17B JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD17Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD17Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D17Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D17F;
L_82D17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD17Fu,0x82D17Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D17F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D182;
L_82D182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D182 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82D184;
L_82D184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D184 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D187;
L_82D187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD187u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D187 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_82D189;
L_82D189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u, 8u, 4u, 0x80935Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D189 JSL -> $80935E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD18Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD18Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80935Eu, 0x82D189u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D18D;
L_82D18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD18Du,0x82D18Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D18D LDX
    cpu.setX(0x0u, 16);
    goto L_82D190;
L_82D190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D190 STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_82D192;
L_82D192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D192 LDA
    cpu.setA(0x80u, 16);
    goto L_82D195;
L_82D195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD195u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD195u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D195 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D197;
L_82D197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD197u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD197u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D197 LDA
    cpu.setA(0x94u, 16);
    goto L_82D19A;
L_82D19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D19C;
L_82D19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D19F;
L_82D19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D1A1;
L_82D1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A1u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1A3;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1A3;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A1u,0x82D1A1u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A3u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_82D1A5;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_82D1A5;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A3u,0x82D1A3u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A5u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16));
    goto L_82D1A7;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16));
    goto L_82D1A7;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A5u,0x82D1A5u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A7u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A7 BEQ -> $82D1D6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D1D6; }
    goto L_82D1A9;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A7 BEQ -> $82D1D6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D1D6; }
    goto L_82D1A9;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A7u,0x82D1A7u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A9u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D1AB;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D1AB;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1A9u,0x82D1A9u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ABu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1AD;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1AD;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1ABu,0x82D1ABu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ADu))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AD AND
    cpu.logicAnd(0xFFu);
    goto L_82D1B0;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AD AND
    cpu.logicAnd(0xFFu);
    goto L_82D1B0;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1ADu,0x82D1ADu); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B0u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B0 ASL
    cpu.aslA();
    goto L_82D1B1;
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B0 ASL
    cpu.aslA();
    goto L_82D1B1;
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1B0u,0x82D1B0u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
L_82D1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B1 TAX
    cpu.transfer("TAX");
    goto L_82D1B2;
L_82D1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B2 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1B6;
L_82D1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B6 TAX
    cpu.transfer("TAX");
    goto L_82D1B7;
L_82D1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B7 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1BB;
L_82D1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D1BD;
L_82D1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1BF;
L_82D1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BF SEC
    cpu.setFlag('C', true);
    goto L_82D1C0;
L_82D1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C0 SBC
    cpu.sbc(0x8u);
    goto L_82D1C3;
L_82D1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C3 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D1C5;
L_82D1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C5u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D1C5 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D1C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D1C9;
L_82D1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C9u,0x82D1C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D1CB;
L_82D1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1CB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1CD;
L_82D1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1CD AND
    cpu.logicAnd(0xFF00u);
    goto L_82D1D0;
L_82D1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D0 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_82D1D2;
L_82D1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D2 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D1D4;
L_82D1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D4 BRA -> $82D1A1
    goto L_82D1A1;
L_82D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
  // 2 variantes de decodificacao M/X para este endereco; 2 corpos distintos.
  if (cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D1D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D1D6u);return;} hw.unresolvedReturn(0x82D1D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  if (cpu.e==false && cpu.m8==false && cpu.x8==false) {
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D1D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D1D6u);return;} hw.unresolvedReturn(0x82D1D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
  }
  hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1D6u,0x82D1D6u); return; // sem variante local: tenta outra funcao/estado pelo dispatcher
}

void sub_82D15E_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D15Eu: goto L_82D15E;
    case 0x82D161u: goto L_82D161;
    case 0x82D163u: goto L_82D163;
    case 0x82D166u: goto L_82D166;
    case 0x82D16Au: goto L_82D16A;
    case 0x82D16Cu: goto L_82D16C;
    case 0x82D16Fu: goto L_82D16F;
    case 0x82D171u: goto L_82D171;
    case 0x82D174u: goto L_82D174;
    case 0x82D176u: goto L_82D176;
    case 0x82D179u: goto L_82D179;
    case 0x82D17Bu: goto L_82D17B;
    case 0x82D17Fu: goto L_82D17F;
    case 0x82D182u: goto L_82D182;
    case 0x82D184u: goto L_82D184;
    case 0x82D187u: goto L_82D187;
    case 0x82D189u: goto L_82D189;
    case 0x82D18Du: goto L_82D18D;
    case 0x82D190u: goto L_82D190;
    case 0x82D192u: goto L_82D192;
    case 0x82D195u: goto L_82D195;
    case 0x82D197u: goto L_82D197;
    case 0x82D19Au: goto L_82D19A;
    case 0x82D19Cu: goto L_82D19C;
    case 0x82D19Fu: goto L_82D19F;
    case 0x82D1A1u: goto L_82D1A1;
    case 0x82D1A3u: goto L_82D1A3;
    case 0x82D1A5u: goto L_82D1A5;
    case 0x82D1A7u: goto L_82D1A7;
    case 0x82D1A9u: goto L_82D1A9;
    case 0x82D1ABu: goto L_82D1AB;
    case 0x82D1ADu: goto L_82D1AD;
    case 0x82D1B0u: goto L_82D1B0;
    case 0x82D1B1u: goto L_82D1B1;
    case 0x82D1B2u: goto L_82D1B2;
    case 0x82D1B6u: goto L_82D1B6;
    case 0x82D1B7u: goto L_82D1B7;
    case 0x82D1BBu: goto L_82D1BB;
    case 0x82D1BDu: goto L_82D1BD;
    case 0x82D1BFu: goto L_82D1BF;
    case 0x82D1C0u: goto L_82D1C0;
    case 0x82D1C3u: goto L_82D1C3;
    case 0x82D1C5u: goto L_82D1C5;
    case 0x82D1C9u: goto L_82D1C9;
    case 0x82D1CBu: goto L_82D1CB;
    case 0x82D1CDu: goto L_82D1CD;
    case 0x82D1D0u: goto L_82D1D0;
    case 0x82D1D2u: goto L_82D1D2;
    case 0x82D1D4u: goto L_82D1D4;
    case 0x82D1D6u: goto L_82D1D6;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D15E:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD15Eu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD15Eu, 5u, 3u, cpu.address("abs", 0x0181u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D15E LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x181u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D161;
L_82D161:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD161u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD161u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD161u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D161 BEQ -> $82D1D6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D1D6; }
    goto L_82D163;
L_82D163:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD163u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD163u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D163 LDX
    cpu.setX(0xCu, 16);
    goto L_82D166;
L_82D166:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD166u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD166u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D166 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D16A;
L_82D16A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16A STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D16C;
L_82D16C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D16F;
L_82D16F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD16Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD16Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D16F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D171;
L_82D171:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD171u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD171u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D171 LDA
    cpu.setA(0x70u, 16);
    goto L_82D174;
L_82D174:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD174u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD174u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D174 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D176;
L_82D176:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD176u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD176u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD176u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D176 LDA
    cpu.setA(0x80u, 16);
    goto L_82D179;
L_82D179:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD179u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD179u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D179 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D17B;
L_82D17B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Bu, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D17B JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD17Eu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD17Fu,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D17Bu); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D17F;
L_82D17F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD17Fu))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD17Fu,0x82D17Fu); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD17Fu, 5u, 3u, cpu.address("abs", 0x0156u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D17F LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x156u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D182;
L_82D182:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD182u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD182u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x36u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D182 STA
    hw.write(cpu.address("dp", 0x36u), cpu.a, cpu.m8?8:16);
    goto L_82D184;
L_82D184:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD184u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD184u, 5u, 3u, cpu.address("abs", 0x0158u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D184 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x158u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D187;
L_82D187:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD187u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD187u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD187u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x38u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D187 STA
    hw.write(cpu.address("dp", 0x38u), cpu.a, cpu.m8?8:16);
    goto L_82D189;
L_82D189:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD189u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD189u, 8u, 4u, 0x80935Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D189 JSL -> $80935E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD18Cu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD18Du,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80935Eu, 0x82D189u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D18D;
L_82D18D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD18Du))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD18Du,0x82D18Du); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Du,cpu,0xA2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD18Du, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D18D LDX
    cpu.setX(0x0u, 16);
    goto L_82D190;
L_82D190:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD190u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u,cpu,0x86u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD190u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D190 STX
    hw.write(cpu.address("dp", 0x63u), cpu.x, cpu.x8?8:16);
    goto L_82D192;
L_82D192:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD192u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD192u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D192 LDA
    cpu.setA(0x80u, 16);
    goto L_82D195;
L_82D195:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD195u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD195u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD195u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D195 STA
    hw.write(cpu.address("dp", 0xAu), cpu.a, cpu.m8?8:16);
    goto L_82D197;
L_82D197:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD197u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD197u,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD197u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D197 LDA
    cpu.setA(0x94u, 16);
    goto L_82D19A;
L_82D19A:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Au))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Au, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19A STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D19C;
L_82D19C:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Cu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu,cpu,0xA9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Cu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19C LDA
    cpu.setA(0x9Eu, 16);
    goto L_82D19F;
L_82D19F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD19Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD19Fu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x02u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D19F STA
    hw.write(cpu.address("dp", 0x2u), cpu.a, cpu.m8?8:16);
    goto L_82D1A1;
L_82D1A1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A1u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A1 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1A3;
L_82D1A3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A3 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Cu), cpu.m8?8:16));
    goto L_82D1A5;
L_82D1A5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u,cpu,0x05u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A5u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x3Eu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A5 ORA
    cpu.logicOr(hw.readW(cpu.address("dp", 0x3Eu), cpu.m8?8:16));
    goto L_82D1A7;
L_82D1A7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u,cpu,0xF0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A7u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A7 BEQ -> $82D1D6
    if (cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D1D6; }
    goto L_82D1A9;
L_82D1A9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1A9u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1A9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1A9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D1AB;
L_82D1AB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ABu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ABu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1AD;
L_82D1AD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1ADu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1ADu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1AD AND
    cpu.logicAnd(0xFFu);
    goto L_82D1B0;
L_82D1B0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u,cpu,0x0Au);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B0u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B0 ASL
    cpu.aslA();
    goto L_82D1B1;
L_82D1B1:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B1u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B1u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B1 TAX
    cpu.transfer("TAX");
    goto L_82D1B2;
L_82D1B2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B2u, 6u, 4u, ((0x9E95C2u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B2 LDA
    cpu.loadA(hw.readW(((0x9E95C2u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1B6;
L_82D1B6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u,cpu,0xAAu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B6u, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B6 TAX
    cpu.transfer("TAX");
    goto L_82D1B7;
L_82D1B7:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1B7u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u,cpu,0xBFu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1B7u, 6u, 4u, ((0x9E8232u + cpu.x) & 0xFFFFFFu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1B7 LDA
    cpu.loadA(hw.readW(((0x9E8232u + cpu.x) & 0xFFFFFFu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1BB;
L_82D1BB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BBu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x00u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BB STA
    hw.write(cpu.address("dp", 0x0u), cpu.a, cpu.m8?8:16);
    goto L_82D1BD;
L_82D1BD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BDu, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BD LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0xCu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1BF;
L_82D1BF:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1BFu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu,cpu,0x38u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1BFu, 2u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1BF SEC
    cpu.setFlag('C', true);
    goto L_82D1C0;
L_82D1C0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u,cpu,0xE9u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C0u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C0 SBC
    cpu.sbc(0x8u);
    goto L_82D1C3;
L_82D1C3:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C3u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u,cpu,0x85u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C3u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x0Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C3 STA
    hw.write(cpu.address("dp", 0xCu), cpu.a, cpu.m8?8:16);
    goto L_82D1C5;
L_82D1C5:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C5u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C5u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C5u, 8u, 4u, 0x80887Eu, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D1C5 JSL -> $80887E stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD1C8u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD1C9u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x80887Eu, 0x82D1C5u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D1C9;
L_82D1C9:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1C9u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD1C9u,0x82D1C9u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u,cpu,0xA6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1C9u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1C9 LDX
    cpu.setX(hw.readW(cpu.address("dp", 0x63u), cpu.x8?8:16), cpu.x8?8:16);
    goto L_82D1CB;
L_82D1CB:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CBu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu,cpu,0xB5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CBu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1CB LDA
    cpu.loadA(hw.readW(cpu.address("dpx", 0x3Au), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D1CD;
L_82D1CD:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1CDu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1CDu, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1CD AND
    cpu.logicAnd(0xFF00u);
    goto L_82D1D0;
L_82D1D0:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D0u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u,cpu,0x95u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D0u, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dpx", 0x3Au), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D0 STA
    hw.write(cpu.address("dpx", 0x3Au), cpu.a, cpu.m8?8:16);
    goto L_82D1D2;
L_82D1D2:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D2u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D2u, 7u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x63u), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D2 INC
    cpu.incMem(hw, cpu.address("dp", 0x63u), cpu.m8?8:16);
    goto L_82D1D4;
L_82D1D4:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D4u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u,cpu,0x80u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D4u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D1D4 BRA -> $82D1A1
    goto L_82D1A1;
L_82D1D6:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD1D6u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD1D6u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D1D6 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D1D6u);return;} hw.unresolvedReturn(0x82D1D6u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

