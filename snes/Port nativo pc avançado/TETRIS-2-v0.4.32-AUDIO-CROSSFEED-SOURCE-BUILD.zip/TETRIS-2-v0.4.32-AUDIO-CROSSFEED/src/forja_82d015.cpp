#include "generated.hpp"
void sub_82D015_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D015u: goto L_82D015;
    case 0x82D018u: goto L_82D018;
    case 0x82D01Bu: goto L_82D01B;
    case 0x82D01Du: goto L_82D01D;
    case 0x82D01Fu: goto L_82D01F;
    case 0x82D021u: goto L_82D021;
    case 0x82D023u: goto L_82D023;
    case 0x82D025u: goto L_82D025;
    case 0x82D028u: goto L_82D028;
    case 0x82D02Bu: goto L_82D02B;
    case 0x82D02Du: goto L_82D02D;
    case 0x82D030u: goto L_82D030;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD015u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD015u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D015 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D018;
L_82D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D018 AND
    cpu.logicAnd(0xFFu);
    goto L_82D01B;
L_82D01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01B BNE -> $82D028
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D028; }
    goto L_82D01D;
L_82D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D01F;
L_82D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01F BNE -> $82D025
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D025; }
    goto L_82D021;
L_82D021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D023;
L_82D023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D023 BNE -> $82D028
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D028; }
    goto L_82D025;
L_82D025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D025 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82D028;
L_82D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D028 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D02B;
L_82D02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D02B BMI -> $82D030
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D030; }
    goto L_82D02D;
L_82D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 6u, 3u, cpu.address("abs", 0xD2C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D02D JSR -> $82D2C9 stack real
    { cpu.push16Value(hw,0xD02Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD030u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2C9u), 0x82D02Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D030;
L_82D030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false && cpu.c==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD030u,0x82D030u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D030 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D030u);return;} hw.unresolvedReturn(0x82D030u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D015_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D015u: goto L_82D015;
    case 0x82D018u: goto L_82D018;
    case 0x82D01Bu: goto L_82D01B;
    case 0x82D01Du: goto L_82D01D;
    case 0x82D01Fu: goto L_82D01F;
    case 0x82D021u: goto L_82D021;
    case 0x82D023u: goto L_82D023;
    case 0x82D025u: goto L_82D025;
    case 0x82D028u: goto L_82D028;
    case 0x82D02Bu: goto L_82D02B;
    case 0x82D02Du: goto L_82D02D;
    case 0x82D030u: goto L_82D030;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D015:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD015u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD015u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD015u, 5u, 3u, cpu.address("abs", 0x2140u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D015 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x2140u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D018;
L_82D018:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD018u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u,cpu,0x29u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD018u, 3u, 3u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D018 AND
    cpu.logicAnd(0xFFu);
    goto L_82D01B;
L_82D01B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01B BNE -> $82D028
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D028; }
    goto L_82D01D;
L_82D01D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Du, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x9Cu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01D LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x9Cu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D01F;
L_82D01F:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD01Fu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD01Fu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D01F BNE -> $82D025
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D025; }
    goto L_82D021;
L_82D021:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD021u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u,cpu,0xA5u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD021u, 4u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x6Fu), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D021 LDA
    cpu.loadA(hw.readW(cpu.address("dp", 0x6Fu), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D023;
L_82D023:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD023u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u,cpu,0xD0u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD023u, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D023 BNE -> $82D028
    if (!cpu.z) { hw.addCpuInternalCycles(1u); goto L_82D028; }
    goto L_82D025;
L_82D025:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD025u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u,cpu,0xEEu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD025u, 8u, 3u, cpu.address("abs", 0x017Bu), 4u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D025 INC
    cpu.incMem(hw, cpu.address("abs", 0x17Bu), cpu.m8?8:16);
    goto L_82D028;
L_82D028:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD028u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u,cpu,0xADu);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD028u, 5u, 3u, cpu.address("abs", 0x0802u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D028 LDA
    cpu.loadA(hw.readW(cpu.address("abs", 0x802u), cpu.m8?8:16), cpu.m8?8:16);
    goto L_82D02B;
L_82D02B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu,cpu,0x30u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Bu, 2u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D02B BMI -> $82D030
    if (cpu.n) { hw.addCpuInternalCycles(1u); goto L_82D030; }
    goto L_82D02D;
L_82D02D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD02Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du,cpu,0x20u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD02Du, 6u, 3u, cpu.address("abs", 0xD2C9u), 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D02D JSR -> $82D2C9 stack real
    { cpu.push16Value(hw,0xD02Fu); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD030u,false,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, ((std::uint32_t(cpu.pb)<<16)|0xD2C9u), 0x82D02Du); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D030;
L_82D030:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD030u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD030u,0x82D030u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD030u, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D030 RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D030u);return;} hw.unresolvedReturn(0x82D030u,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

