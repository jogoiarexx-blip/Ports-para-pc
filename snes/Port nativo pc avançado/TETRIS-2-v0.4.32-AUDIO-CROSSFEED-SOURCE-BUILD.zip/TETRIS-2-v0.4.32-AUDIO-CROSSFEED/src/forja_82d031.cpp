#include "generated.hpp"
void sub_82D031_E0M0X0C0(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D031u: goto L_82D031;
    case 0x82D035u: goto L_82D035;
    case 0x82D039u: goto L_82D039;
    case 0x82D03Bu: goto L_82D03B;
    case 0x82D03Du: goto L_82D03D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u, 8u, 4u, 0x84B827u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D031 JSL -> $84B827 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD034u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD035u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B827u, 0x82D031u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D035;
L_82D035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD035u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD035u,0x82D035u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D035 JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD038u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD039u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82D035u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D039;
L_82D039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD039u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD039u,0x82D039u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D039 SEP
    cpu.sep(0x20u);
    goto L_82D03B;
L_82D03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D03B INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82D03D;
L_82D03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D03D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D03Du);return;} hw.unresolvedReturn(0x82D03Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

void sub_82D031_E0M0X0CQ(CpuState& cpu, SnesRuntime& hw, std::uint32_t entryPc) {
  switch(entryPc&0xFFFFFFu){
    case 0x82D031u: goto L_82D031;
    case 0x82D035u: goto L_82D035;
    case 0x82D039u: goto L_82D039;
    case 0x82D03Bu: goto L_82D03B;
    case 0x82D03Du: goto L_82D03D;
    default: hw.unresolvedFlow(entryPc,entryPc,cpu); return;
  }
L_82D031:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD031u))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD031u, 8u, 4u, 0x84B827u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D031 JSL -> $84B827 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD034u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD035u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x84B827u, 0x82D031u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D035;
L_82D035:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD035u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD035u,0x82D035u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u,cpu,0x22u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD035u, 8u, 4u, 0x82BC35u, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 3u);
    // $82D035 JSL -> $82BC35 stack real
    { cpu.push8Value(hw,cpu.pb); cpu.push16Value(hw,0xD038u); const auto callFrame=hw.pushNativeReturn((std::uint32_t(cpu.pb)<<16)|0xD039u,true,cpu); hw.nativeCallPending=true; forja65_dispatch(cpu, hw, 0x82BC35u, 0x82D035u); if(hw.nativeReturnedCall!=callFrame)return; }
    goto L_82D039;
L_82D039:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD039u))return;
  if (!(cpu.e==false && cpu.m8==false && cpu.x8==false)) { hw.requestDispatch((std::uint32_t(cpu.pb)<<16)|0xD039u,0x82D039u); return; } // callee devolveu M/X/E diferente do previsto
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u,cpu,0xE2u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD039u, 3u, 2u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D039 SEP
    cpu.sep(0x20u);
    goto L_82D03B;
L_82D03B:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Bu))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu,cpu,0xE6u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Bu, 5u + ((cpu.d & 0xFFu)!=0u ? 1u : 0u), 2u, cpu.address("dp", 0x49u), 2u, SnesRuntime::NO_TIMING_ADDR, 0u, 0u);
    // $82D03B INC
    cpu.incMem(hw, cpu.address("dp", 0x49u), cpu.m8?8:16);
    goto L_82D03D;
L_82D03D:
  // PB e sincronizado na entrada do dispatcher; labels locais preservam o banco real, inclusive mirrors da ROM.
  if(hw.stopped)return;
  if(hw.serviceCpuEvents(cpu,(std::uint32_t(cpu.pb)<<16)|0xD03Du))return;
    hw.traceInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du,cpu,0x60u);
    hw.advanceCpuInstruction((std::uint32_t(cpu.pb)<<16)|0xD03Du, 6u, 1u, SnesRuntime::NO_TIMING_ADDR, 0u, SnesRuntime::NO_TIMING_ADDR, 0u, 2u);
    // $82D03D RTS stack real
    { auto raw=cpu.peekStack16(hw); auto dst=(std::uint32_t(cpu.pb)<<16)|((raw+1u)&0xFFFFu); if(!hw.nativeReturnMatches(dst,false,cpu)){ if(forja65_is_stack_return_target(dst,hw)){hw.retireRedirectedNativeReturn(cpu,false);cpu.pop16Value(hw);hw.requestDispatch(dst,0x82D03Du);return;} hw.unresolvedReturn(0x82D03Du,dst,cpu,"STACK-RTS"); } cpu.pop16Value(hw); hw.popNativeReturn(); return; }
}

