# Tetris 2 — v0.3.98 — integração PPU/OBJ com o Forja65

## Implementações no jogo (código C++ real)

- Substituído o compositor de sprites desatualizado pelo núcleo OBJ já corrigido do Forja65 v0.3.97, mantendo a interface C++ preexistente.
- Corrigido o cálculo de OBSEL $2101: banco base utiliza três bits; banco alternativo usa deslocamento (N+1) * 8192 bytes com wrap em VRAM.
- Corrigido Y wrap de sprites OAM de 8 bits quando atravessam a borda da tela.
- Sobreposições OBJ↔OBJ agora obedecem à ordem interna OAM; os bits de prioridade continuam disponíveis na composição OBJ↔BG.
- Respeitada a rotação do primeiro objeto ($2103 bit7) na leitura escalar e no caminho por linha.
- Cache dos quatro bytes de planos gráficos por tile no renderizador de linhas; invalidado a cada novo segmento de raster.
- Restaurado endereço interno de OAM na entrada de VBlank, exceto durante forced blank, em ambos os caminhos de timing.

## Testes e ferramentas

- `tests/sprite_crossfeed_smoke.cpp`: casos verificáveis de OBSEL, VRAM, OAM, Y wrap, rotação, DMA, VBlank e paridade escalar/por linha com sementes determinísticas.
- `CMakeLists.txt`: alvo `sprite_crossfeed_smoke` e entrada CTest; scripts `BUILD-WINDOWS.cmd` e `TESTAR-HARDWARE.cmd` agora incluem o alvo.
- `tools/compare_frame_traces.py`: compara hashes de vídeo, WRAM e PC separadamente, exibindo o primeiro frame divergente.
- `forja-tooling/tests/tetris-obj-crossfeed-v0398-regression.js`: regressão da saída do gerador Forja65; não é regeneração integral da CPU traduzida.

## Evidência obtida em Linux

- Compilação Release, `FORJA65_STRICT=ON`: sucesso, inclusive target `game`.
- CTest: 9 executados e aprovados, 1 teste `equivalence_vectors` ignorado pela ausência de vetores externos (total 10 registrados).
- Replay de 300 quadros: imagem, WRAM e PC iguais aos da v0.3.97 em todos os 300 quadros.
- Replay de 2.000 quadros: 0 diferenças em WRAM/PC; 345 quadros com framebuffer diferente; primeira diferença no quadro 333. As diferenças são de renderização, não prova de equivalência visual com hardware original. Instruções finais: 28.298.611.
- O replay longo de 12.000 quadros da v0.3.97 foi previamente reportado, mas NÃO foi concluído nesta revisão v0.3.98. Uma tentativa comparativa foi interrompida durante o percurso longo; não se afirma aprovação de 12.000 quadros nesta versão.
- Teste do gerador `tetris-obj-crossfeed-v0398-regression.js`: passou com ROM sintética e compilação C++.

## Limites

Não há validação visual contra captura do SNES, teste gráfico Windows ou confirmação de todas as telas, modos e fases. PPU, DMA/HDMA, SPC700/DSP e acesso aos dados ainda contêm fallback no runtime; **não é um port 100% sem hardware virtual**. O `equivalence_vectors` não dispõe de vetores de oracle. ZIP é código-fonte com assets, e não inclui `game.exe` Windows pronto.

## Como executar

Windows: `BUILD-WINDOWS.cmd` -> `TESTAR-HARDWARE.cmd` -> `RUN-WINDOWS.cmd`.
Linux: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DFORJA65_STRICT=ON && cmake --build build -j4 && ctest --test-dir build --output-on-failure`.

Comparador (Python 3): `python tools/compare_frame_traces.py CAMINHO_ANTIGO/forja65-frame-hashes.txt CAMINHO_NOVO/forja65-frame-hashes.txt --max-frames 2000 --allow-video-differences`.
