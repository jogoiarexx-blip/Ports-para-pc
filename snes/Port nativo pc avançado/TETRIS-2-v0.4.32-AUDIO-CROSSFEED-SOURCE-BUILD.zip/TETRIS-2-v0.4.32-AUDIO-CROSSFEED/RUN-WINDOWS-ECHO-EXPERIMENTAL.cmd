@echo off
setlocal
cd /d "%~dp0"
echo AVISO: eco DSP experimental com gravacao na RAM do SPC700.
echo Pode alterar os estados do jogo. Para testes somente.
set "FORJA65_ECHO_RAM_WRITES=1"
call RUN-WINDOWS-AUDIO.cmd
exit /b %ERRORLEVEL%
