# Tetris 2 v0.4.12 — APU instruction retirement (experimental)

## Implementado
- `FORJA65_SPC_SCHEDULER=strict`, somente junto de `FORJA65_SPC_TIMING=accurate`: adia a execução das instruções SPC700 até que seu **custo completo** esteja acumulado, inclusive penalidades dinâmicas de desvios condicionais. Evita que resultados de uma instrução longa se tornem visíveis com apenas dois ciclos disponíveis.
- Leitura auxiliar sem efeitos colaterais para prever o custo: não limpa os latches `$FD/$FE/$FF` nem escreve nas portas.
- Reescrita de `$F1` com bit de temporizador habilitado reinicia o contador de estágio 2 e seu latch de saída no **modo de temporização experimental**. A fase do prescaler permanece livre, como antes.
- Novo teste cobrindo os 256 opcodes × 6 combinações de flags, espera de ciclo da porta `$F4`, desvio condicional, e reinício de temporizador.
- O gerador Forja65 também recebeu as alterações e compila o mesmo teste em um runtime gerado a partir de uma ROM sintética.
- Novos scripts Windows para testar e comparar o agendador experimental.

## Validação deste pacote
- Compilação integral do executável Linux: APROVADA.
- CTest: **23 aprovados, 1 ignorado** (`equivalence_vectors`, sem dados externos); 0 falhas.
- Forja65: 15 regressões anteriores mais nova regressão v0.4.12 aprovadas.
- Replay do **modo estável** de 500 quadros: imagem `b97c33500b6d7229`, WRAM `2a07f32b0beb46f7`, 7.767.981 instruções — idênticos à v0.4.11.
- Replay **experimental strict** de 500 quadros: terminou sem erro; imagem `2cd3044dd9e31417`, WRAM `81982ba4ccf85d04`, 7.866.456 instruções. **Divergente** do modo estável, não validado contra um SNES real.
- Quadro 59: primeira escrita `$AA` do SPC ocorreu no ciclo master 50.320 com `accurate` e 50.390 com `accurate + strict`. `$CC` de porta 0 registrado inicialmente em 19.604.432 vs 19.604.282, respectivamente. As capturas têm timestamps aproximados de limite de instrução e não são prova de fidelidade.
- Compilação Windows ainda não realizada (requer compilador MSVC, CMake e Windows).

## Restrições e próxima etapa
O modo padrão é o mesmo de v0.4.11. A nova execução de instruções por orçamento completo é uma aproximação de **retirada por instrução**, não um emulador SPC700 ciclo a ciclo. Os acessos de memória internos ainda não têm timestamp individual e não existe uma captura de referência comprovada do SNES original. Não habilitar strict por padrão até confrontar o protocolo CPU–APU com um oráculo de hardware. A execução de todos os modos do Tetris 2 até o fim ainda não foi validada.

Executar: `BUILD-WINDOWS.cmd`, `TESTAR-HARDWARE.cmd`, `RUN-WINDOWS.cmd`. Para testar strict: `RUN-SPC-STRICT-EXPERIMENTAL.cmd`. Para comparar os rastros do quadro 59: `CAPTURAR-SPC-STRICT-QUADRO-59.cmd`.
