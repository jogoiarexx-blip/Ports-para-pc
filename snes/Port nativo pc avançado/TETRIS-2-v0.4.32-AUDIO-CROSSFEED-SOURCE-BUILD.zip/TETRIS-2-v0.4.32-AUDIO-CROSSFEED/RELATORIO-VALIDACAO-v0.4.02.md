# Relatório — Tetris 2 v0.4.02 + Forja65 v0.4.01

| Validação | Resultado |
|---|---|
| Compilação Linux do executável Tetris C++ | APROVADA |
| CTest Tetris | 14 aprovados, 1 ignorado (vetores externos ausentes), 0 falhas |
| Forja65 — regressões de integração v0.3.97 a v0.4.02 | 6/6 aprovadas |
| Gerador com ROM sintética compilando C++ do novo teste | APROVADA |
| Replay determinístico `validation/input-normal.txt` | 2.000 frames, encerramento normal |
| Hashes framebuffer, WRAM e PC versus Tetris v0.4.01 | 0 divergências em 2.000 frames |
| Compilação Windows efetiva | NÃO EXECUTADA (script atualizado) |
| Comparação com hardware SNES físico | NÃO EXECUTADA |
| Conclusão de todas as fases e modos | NÃO COMPROVADA |

## Perfil real do replay de 2.000 frames

- Acessos PPU: **4.774.122** (3 leituras, 4.774.119 escritas).
- `$2118` (VRAM low): **1.795.312** escritas.
- `$2119` (VRAM high): **1.795.312** escritas.
- `$2104` (OAM data): **923.168** escritas.
- `$2122` (CGRAM data): **193.536** escritas.
- Chamadas de sincronização de raster **evitadas nos ports apenas de endereço**: **5.431**. Isto não é o número de pixels renderizados nem de redraws completos eliminados.
- Bytes DMA processados: **4.715.520**, todos pelo despacho direto B-bus; isso não remove o estado de registradores SNES.
- APU/SPC700 e DSP ainda apresentam fallback de execução; sem avanço de migração de áudio nesta rodada.

Os perfis mostram que o próximo ganho relevante depende do processamento em blocos de dados VRAM/OAM/CGRAM sob preservação do tempo de barramento. `PPU_NATIVE_ONLY=NO` no modo padrão continua correto. Não afirmar porcentagens de port total, compatibilidade perfeita nem aceleração de FPS sem medição independente.
