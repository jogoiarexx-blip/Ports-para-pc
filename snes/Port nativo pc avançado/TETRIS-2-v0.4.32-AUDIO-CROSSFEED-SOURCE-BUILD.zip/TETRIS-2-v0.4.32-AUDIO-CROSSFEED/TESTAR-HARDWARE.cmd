@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>&1
if errorlevel 1 (
 echo CMake nao encontrado. Instale CMake e o compilador C++ do Visual Studio.
 pause
 exit /b 1
)
cmake -S . -B build-win -DFORJA65_STRICT=ON
if errorlevel 1 goto :fail
cmake --build build-win --config Release --target hardware_fixes_smoke sprite_crossfeed_smoke sprite_limits_smoke hdma_descriptor_smoke ppu_snapshot_row_smoke dma_native_parity_smoke ppu_raster_sync_smoke dma_vram_batch_smoke vram_access_smoke apu_dsp_registers_smoke spc_cycle_timers_smoke spc_semantics_smoke spc_ipl_handshake_smoke spc_cpu_port_observer_smoke spc_cpu_poll_runs_smoke scene_timeline_smoke
if errorlevel 1 goto :fail
ctest --test-dir build-win -C Release -R "(hardware_fixes_smoke|sprite_crossfeed_smoke|sprite_limits_smoke|hdma_descriptor_smoke|ppu_snapshot_row_smoke|dma_native_parity_smoke|ppu_raster_sync_smoke|dma_vram_batch_smoke|vram_access_smoke|apu_dsp_registers_smoke|spc_cycle_timers_smoke|spc_semantics_smoke|spc_ipl_handshake_smoke|spc_cpu_port_observer_smoke|spc_cpu_poll_runs_smoke|scene_timeline_smoke)" --output-on-failure
if errorlevel 1 goto :fail
echo.
echo Testes de CPU, PPU, DMA, HDMA, SPC700, DSP e sprites OAM aprovados.
pause
exit /b 0
:fail
echo.
echo Falha na compilacao ou nos testes. Veja a mensagem acima.
pause
exit /b 1
