# Tetris 2 — v0.3.97 — revisão de hardware / desempenho

## Mudanças efetivamente implementadas

- **CPU 65C816:** ADC/SBC BCD em 8/16 bits (mantendo overflow do resultado binário e carry decimal); MVN/MVP atualizam os índices X/Y em 16 bits mesmo quando a flag X=8.
- **PPU:** VRAM RD low/high $2139/$213A carrega o próximo endereço depois do incremento definido por VMAIN, em vez de reler o anterior. Testes de passos 1/32 palavras, incremento após porta alta/baixa e wrap.
- **DMA / HDMA:** corrige o wrap dentro do banco ao ler ponteiro indireto e ao avançar bytes HDMA. A rotina DMA já fazia wrap no banco; preservada.
- **SPC700:** leitura $FD-$FF entrega zero quando contador está zero, limpa contador após ler; timers reinicializam ao serem habilitados e não quando F1 repete o estado. `ApuBridge::spcRead/spcWrite` e interpretador SPC700 usam mesma semântica.
- **DSP:** `renderSample()` retorna par estéreo sem alocação de vetor a cada amostra. Renderização em bloco mantém a API anterior. Corrigidos deslocamentos de inteiros negativos indefinidos no decodificador BRR.
- **ROM:** `NativeRomStore::read()` usa `upper_bound` em regiões ordenadas em vez de varredura linear a cada leitura. Dados em lacunas seguem não encontrados.
- **Ferramentas:** gerador Forja65 v0.3.97 incorporado ao diretório `forja-tooling`, mantendo perfis/artefatos de análise do Tetris. O código de jogo já gerado foi corrigido pontualmente, não regenerado do zero para não apagar conhecimento/hints.

## Evidências e limitações

Há novo teste `tests/hardware_fixes_smoke.cpp` (executável/CTest `hardware_fixes_smoke`), incluindo CPU, VRAM, SPC, DMA/HDMA, ROM e DSP. O gerador também possui `tests/tetris-hardware-v0397-regression.js`, que valida o runtime C++ gerado por ROM sintética.

**Importante:** esta entrega não afirma equivalência integral ao SNES ou áudio SPC/DSP perfeito. O SPC700 ainda usa fallback por interpretação e o DSP BRR continua simplificado (envelope/eco ainda carecem equivalência). PPU e DMA mantêm parte da semântica de registradores simulados. Testes isolados não garantem que todos os modos/fases do Tetris são perfeitos. Benchmarks de FPS e executável Windows ainda dependem de medição/build no Windows.

## Uso

No Windows, execute `BUILD-WINDOWS.cmd`, `TESTAR-HARDWARE.cmd` e depois `RUN-WINDOWS.cmd`. Para diagnosticar fluxo sem interface, execute `RUN-HEADLESS.cmd` e `VALIDAR-NORMAL.cmd`/`VALIDAR-VERSUS.cmd` (estes comandos podem atualizar evidências de análise; faça backup antes de regenerar).

Linux: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DFORJA65_STRICT=ON && cmake --build build -j4 && ctest --test-dir build --output-on-failure`.
