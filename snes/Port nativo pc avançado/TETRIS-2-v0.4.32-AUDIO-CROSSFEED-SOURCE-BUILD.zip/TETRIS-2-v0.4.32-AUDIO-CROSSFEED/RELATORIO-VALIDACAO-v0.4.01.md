# Relatório de validação — Tetris 2 v0.4.01 / Forja65 v0.4.00

## Modificações verificadas

| Verificação | Resultado |
|---|---|
| Compilação Linux do jogo nativo, CMake C++20 | PASS |
| Suíte completa Tetris CTest | 13 PASS, 1 SKIP, 0 FAIL |
| Teste novo: paridade PPU snapshot versus compositor escalar | PASS — 30.960 comparações de pixels |
| Teste novo: paridade DMA genérico versus despacho B-bus direto | PASS |
| Forja65 gerador com ROM sintética e fixtures C++ compiladas | PASS |
| Regressões do gerador (hardware, OBJ, quotas OBJ, HDMA e PPU/DMA) | 5 PASS |
| Replay determinístico do binário recompilado, `input-normal.txt` | 2.000 quadros completos |
| Divergências framebuffer / WRAM / PC contra v0.4.00 | 0 / 0 / 0 |
| Equivalence vectors externos | SKIP — fixture não disponível |
| Teste contra PPU real de SNES com capturas de referência | NÃO EXECUTADO |
| Compilação real Windows de `game.exe` | NÃO EXECUTADO |

## Medição local da captura estática

Execução C++ otimizada (GCC -O2), framebuffer de 256×224 pixels com BG e sprites, um quadro:

- v0.4.00: aproximadamente **42 ms**.
- v0.4.01: aproximadamente **5 ms**.
- Ganho observado: **8,4 vezes** nessa operação específica.

Esse teste mede a captura estática `renderFrame()`, não a taxa de FPS de gameplay; o desempenho pode variar conforme compilador, cena e computador.

## Contadores do replay de 2.000 quadros

```
frames=2000
ppu_fallback_accesses=4774122
dma_bytes=4715520
dma_native_bytes=4715520
dma_fallback_bytes=0
apu_fallback_master_cycles=714736008
dsp_fallback_samples=1065180
```

Os bytes classificados como *DMA native* usam o despacho direto B-bus para PPU/APU/WRAM. Os efeitos de registradores continuam sendo simulados no runtime SNES; isso NÃO comprova que PPU, SPC700 ou DSP são completamente nativos.

## Reproduzir no Windows

1. Instalar Visual Studio 2022 (Desktop development with C++) e CMake.
2. Executar `BUILD-WINDOWS.cmd`.
3. Executar `TESTAR-HARDWARE.cmd`.
4. Executar `RUN-WINDOWS.cmd` ou `RUN-INPUT-REPLAY.cmd validation/input-normal.txt` para replay.
5. `FORJA65_DMA_MODE=virtual` força o caminho antigo (comparação).

A verificação de 2.000 quadros não equivale a zerar a campanha ou comprovar todos os modos, e os hashes iguais referenciam a implementação anterior, não uma captura física do SNES.
