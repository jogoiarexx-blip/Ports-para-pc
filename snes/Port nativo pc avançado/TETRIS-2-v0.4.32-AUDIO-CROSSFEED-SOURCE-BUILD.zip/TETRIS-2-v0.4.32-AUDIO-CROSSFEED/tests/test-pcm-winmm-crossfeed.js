"use strict";
const fs=require("node:fs"),os=require("node:os"),path=require("node:path"),cp=require("node:child_process");
const here=__dirname,dir=fs.mkdtempSync(path.join(os.tmpdir(),"tetris-pcm-crossfeed-"));
try{
 for(const [file,name,flags] of [
  ["pcm_output_v0435.cpp","pcm-output",[]],
  ["pcm_output_winmm_mock_v0435.cpp","pcm-winmm-mock",["-D_WIN32","-I"+path.join(here,"fixtures","winmm_v0435")]],
  ["pcm_output_48k_winmm_mock_v0435.cpp","pcm-48k-winmm-mock",["-D_WIN32","-I"+path.join(here,"fixtures","winmm_v0435")]]]){
  const out=path.join(dir,name+(process.platform==="win32"?".exe":""));
  cp.execFileSync(process.env.CXX||"g++",["-std=c++20","-Wall","-Wextra","-Werror","-O1","-I"+path.join(here,"..","src"),...flags,path.join(here,"fixtures",file),"-o",out,...(process.platform==="win32"&&!flags.length?["-lwinmm"]:[])],{cwd:dir,stdio:"inherit"});
  cp.execFileSync(out,[],{cwd:dir,stdio:"inherit"});
 }
 console.log("TETRIS_PCM_WINMM_CROSSFEED_PASS");
}finally{fs.rmSync(dir,{recursive:true,force:true});}
