#include "runtime.hpp"
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
static void env(const char*k,const char*v){
#ifdef _WIN32
  _putenv_s(k,v);
#else
  if(v&&*v)setenv(k,v,1);else unsetenv(k);
#endif
}
int main(){namespace fs=std::filesystem;try{
  env("FORJA65_CAPTURE_FRAMES","2,4,5");env("FORJA65_CAPTURE_FRAME","");
  env("FORJA65_CAPTURE_DIR","scene-timeline-smoke");env("FORJA65_CAPTURE_STOP","1");
  fs::remove_all("scene-timeline-smoke");fs::remove("forja65-scene-capture.txt");
  SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"timeline-smoke.srm",1u,true);
  hw.frameCounter=1;if(hw.maybeCaptureNativeScene())return 1;
  hw.frameCounter=2;if(!hw.maybeCaptureNativeScene())return 2;
  if(hw.sceneCaptureDone||hw.stopped||hw.maybeCaptureNativeScene())return 3;
  hw.frameCounter=3;if(hw.maybeCaptureNativeScene())return 4;
  hw.frameCounter=4;if(!hw.maybeCaptureNativeScene())return 5;
  hw.frameCounter=5;if(!hw.maybeCaptureNativeScene()||!hw.sceneCaptureDone||!hw.stopped)return 6;
  for(int n:{2,4,5})if(!fs::exists("scene-timeline-smoke/frame-"+std::to_string(n)+"/preview.ppm")||!fs::exists("scene-timeline-smoke/frame-"+std::to_string(n)+"/capture-manifest.txt"))return 7;
  if(fs::exists("scene-timeline-smoke/frame-3"))return 8;
  std::ifstream log("forja65-scene-capture.txt");int lines=0;for(std::string line;std::getline(log,line);)if(line.find("frame=")==0)lines++;
  if(lines!=3)return 9;
  env("FORJA65_CAPTURE_FRAMES","4,2");env("FORJA65_CAPTURE_DIR","scene-timeline-smoke-bad");
  SnesRuntime invalid("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"timeline-smoke.srm",1u,true);
  bool rejected=false;try{invalid.maybeCaptureNativeScene();}catch(const std::runtime_error&){rejected=true;}
  if(!rejected)return 10;
  env("FORJA65_CAPTURE_FRAMES","");env("FORJA65_CAPTURE_STOP","");
  std::cout<<"FORJA65_SCENE_TIMELINE_PASS 2,4,5; rejected unsorted schedule\n";
  return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 20;}}
