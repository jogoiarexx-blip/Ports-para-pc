#include "runtime.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <iostream>
#include <string>

static void cpuBcd(){
    CpuState cpu;
    cpu.decimalMode=true;cpu.m8=true;cpu.a=0xAB99;cpu.c=false;
    cpu.adc(0x01);assert(cpu.a==0xAB00&&cpu.c&&cpu.z);
    cpu.a=0xAB20;cpu.c=true;cpu.sbc(0x01);assert(cpu.a==0xAB19&&cpu.c&&!cpu.z);
    cpu.a=0xAB00;cpu.c=true;cpu.sbc(0x01);assert(cpu.a==0xAB99&&!cpu.c);
    cpu.m8=false;cpu.a=0x9999;cpu.c=false;cpu.adc(1);assert(cpu.a==0x0000&&cpu.c&&cpu.z);
    cpu.a=0x1000;cpu.c=true;cpu.sbc(1);assert(cpu.a==0x0999&&cpu.c);
    cpu.a=0;cpu.c=true;cpu.sbc(1);assert(cpu.a==0x9999&&!cpu.c);
    cpu.decimalMode=false;cpu.a=0x007F;cpu.m8=true;cpu.c=false;cpu.adc(1);assert((cpu.a&0xff)==0x80&&cpu.v&&!cpu.c);
}
static void ppuVramReads(){
    PpuState p;
    p.vram[0]=0x11;p.vram[1]=0xAA;p.vram[2]=0x22;p.vram[3]=0xBB;
    p.write(0x2115,0x00);p.write(0x2116,0);p.write(0x2117,0);
    assert(p.read(0x2139)==0x11);assert(p.read(0x2139)==0x11);assert(p.read(0x2139)==0x22);
    p.write(0x2115,0x80);p.write(0x2116,0);p.write(0x2117,0);
    assert(p.read(0x213A)==0xAA);assert(p.read(0x213A)==0xAA);assert(p.read(0x213A)==0xBB);
    p.write(0x2115,0x01);p.write(0x2116,0);p.write(0x2117,0);
    p.vram[64]=0x44;assert(p.read(0x2139)==0x11);assert(p.read(0x2139)==0x11);assert(p.read(0x2139)==0x44);
    // Crossing 0xffff wraps the word address; reads must come from 0.
    p.vram[65534]=0x76;
    p.write(0x2115,0);p.write(0x2116,0xFF);p.write(0x2117,0xFF);assert(p.read(0x2139)==0x76);assert(p.read(0x2139)==0x76);assert(p.read(0x2139)==0x11);
}
static void spcTimers(){
    ApuBridge apu;
    assert(apu.spcRead(0xFD)==0);assert(apu.spcRead(0xFE)==0);
    apu.spc.timerOut[0]=7;assert(apu.spcRead(0xFD)==7);assert(apu.spcRead(0xFD)==0);
    apu.spc.timerDiv[0]=98;apu.spc.timerStage[0]=31;apu.spc.timerOut[0]=5;
    apu.spcWrite(0xF1,1);assert(apu.spc.timersOn[0]);
    assert(apu.spc.timerDiv[0]==0&&apu.spc.timerStage[0]==0&&apu.spc.timerOut[0]==0);
    apu.spc.timerStage[0]=5;apu.spcWrite(0xF1,1);assert(apu.spc.timerStage[0]==5);
    apu.spcWrite(0xF1,0);apu.spcWrite(0xF1,1);assert(apu.spc.timerStage[0]==0);
    apu.spcWrite(0xF2,0x4C);apu.spcWrite(0xF3,1);assert(apu.keyOn==1);
}
static void dmaBankWrap(){
    SnesRuntime hw("assets/cart-data.bin",MapperKind::LoROM,0u,10u,0u,CartChip::None,"hardware-test.srm",1u,true);
    hw.ram[0xFFFF]=0xAA;hw.ram[0]=0xBB;hw.ram[0x10000]=0xCC;
    auto &d=hw.dma[0];d.a1b=0x7E;d.a1t=0xFFFF;d.das=2;d.dmap=0;d.bbad=0x22;
    hw.write8(0x2121,0);
    hw.executeDma(1);
    assert(hw.ppu.cgram[0]==0xAA && hw.ppu.cgram[1]==(0xBB&0x7F));
    assert(d.a1t==1&&d.a1b==0x7E);
    hw.ram[0xFFFF]=0x81; // HDMA repeat descriptor
    hw.ram[0]=0xFA;hw.ram[1]=0; // indirect offset crosses bank
    hw.dma[1]={};auto&hd=hw.dma[1];hd.a1b=0x7E;hd.a2a=0xFFFF;hd.dmap=0x40;hd.bbad=0x22;
    hw.hdmaActive=2;hw.hdmaLines[1]=0;hw.hdmaTransfer[1]=true;
    hw.frameTimingActive=true;hw.currentMasterCycle=1106;hw.currentScanline=0;hw.hdmaExecutedThisLine=true;
    hw.executeHdmaLine();
    std::cerr<<"HDMA das="<<std::hex<<hd.das<<" a2a="<<hd.a2a<<" active="<<(unsigned)hw.hdmaActive<<std::dec<<"\n";assert(hd.das==0x00FB&&hd.a2a==2);
}
static void romLookup(){
    NativeRomStore r;r.regions={{100,{1,2,3}},{110,{9,8}}};std::uint8_t q=0;
    assert(!r.read(99,q));assert(r.read(101,q)&&q==2);
    assert(!r.read(103,q));assert(r.read(110,q)&&q==9);
    assert(!r.read(112,q));
}
static void dspSamples(){
    SpcDsp d;std::vector<std::uint8_t>ram(65536,0);
    d.regs[0x0C]=127;d.regs[0x1C]=127;
    auto pair=d.renderSample(ram);auto vector=d.render(ram,1);
    assert(vector.size()==2&&vector[0]==pair[0]&&vector[1]==pair[1]);
}
int main(){cpuBcd();ppuVramReads();spcTimers();dmaBankWrap();romLookup();dspSamples();std::cout<<"HARDWARE_FIXES_SMOKE_OK CPU PPU SPC DMA HDMA ROM DSP\n";}
