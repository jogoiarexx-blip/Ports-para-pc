#include "runtime.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <algorithm>
#include <cstdint>
#include <iostream>
#include <vector>

static void configure(ApuBridge& a) {
  a.interleaveSpcDsp = true;
  a.accurateSpcTiming = true;
  a.strictSpcScheduler = true;
  a.correctedSpcSemantics = true;
  a.ntscSpcClock = true;
  a.spc.control = 0;
  a.spc.pc=0x400;
  a.spc.ram[0x400]=0x2f; a.spc.ram[0x401]=0xfe; // BRA loop, no DSP writes
  a.enableMemoryPcmCapture(true);
  a.dsp.interpolation=SpcDsp::Interpolation::Linear;
  a.spc.ram[0x100]=0x00;a.spc.ram[0x101]=0x02;
  a.spc.ram[0x102]=0x00;a.spc.ram[0x103]=0x02;
  a.spc.ram[0x200]=0x03;
  for(unsigned i=0;i<8;i++)a.spc.ram[0x201+i]=0x77;
  auto wr=[&](unsigned r,unsigned v){a.dsp.writeReg((std::uint8_t)r,(std::uint8_t)v,a.spc.ram);};
  wr(0x5d,1);wr(0x00,127);wr(0x01,127);
  wr(0x02,0);wr(0x03,0x10);wr(0x05,0x8f);
  wr(0x0c,127);wr(0x1c,127);wr(0x4c,1);
}
int main(){
  ApuBridge always,gated,old;
  for(auto* a:{&always,&gated,&old})configure(*a);
  always.setNativeDsp(true);
  gated.clockDspWhileSilent=true;
  old.clockDspWhileSilent=false;
  constexpr unsigned warm=672u*40u, after=672u*70u;
  always.tickMasterCycles(warm);
  gated.tickMasterCycles(warm);
  old.tickMasterCycles(warm);
  const auto early=always.dspNativeSamples;
  assert(early==gated.dspFallbackSamples&&early==old.dspFallbackSamples);
  assert(early==gated.dspSilentClockedSamples);
  assert(old.dspSilentClockedSamples==0);
  assert(gated.nativePcm.empty()&&old.nativePcm.empty());
  gated.setNativeDsp(true);
  old.setNativeDsp(true);
  always.tickMasterCycles(after);
  // Disparate host clock batching should not affect SPC instructions or PCM.
  for(unsigned left=after,step=0;left;){unsigned n=std::min(left,1u+(step++*1013u)%1703u);gated.tickMasterCycles(n);left-=n;}
  old.tickMasterCycles(after);
  assert(always.dspNativeSamples==gated.dspNativeSamples+early);
  assert(gated.nativePcm.size()*sizeof(std::int16_t)>0);
  assert(std::equal(gated.nativePcm.begin(),gated.nativePcm.end(),always.nativePcm.begin()+2*early));
  assert(always.spc.pc==gated.spc.pc);
  assert(always.spcExecutedCycles==gated.spcExecutedCycles);
  assert(always.dspMasterRemainder==gated.dspMasterRemainder);
  assert(always.ntscCycleCredit==gated.ntscCycleCredit);
  assert(old.nativePcm!=gated.nativePcm); // regression: disabled clock loses BRR/ADSR phase
  // Exact one-second phase lock: even with DSP disabled, SPC and DSP clocks
  // must agree for monolithic input and deliberately uneven CPU/DMA blocks.
  ApuBridge nominal,scattered;
  for(auto* a:{&nominal,&scattered})configure(*a);
  nominal.tickMasterCycles((unsigned)ApuBridge::DSP_MASTER_HZ);
  unsigned left=(unsigned)ApuBridge::DSP_MASTER_HZ,seq=0;
  while(left){unsigned n=std::min(left,1u+(seq++*1223u)%16383u);
    scattered.tickMasterCycles(n);left-=n;}
  assert(nominal.dspFallbackSamples==32000u);
  assert(scattered.dspFallbackSamples==nominal.dspFallbackSamples);
  assert(nominal.spcExecutedCycles==1024000u);
  assert(scattered.spcExecutedCycles==nominal.spcExecutedCycles);
  assert(nominal.dspMasterRemainder==0u&&scattered.dspMasterRemainder==0u);
  assert(nominal.ntscCycleCredit==0&&scattered.ntscCycleCredit==0);
  assert(nominal.spc.pc==scattered.spc.pc);
  std::cout<<"FORJA65_SPC_DSP_SYNC_V0435_PASS silent_clocked="<<gated.dspSilentClockedSamples
    <<" resumed_samples="<<gated.dspNativeSamples<<" PCM=identical SPC=identical old=divergent exact_1s=32000DSP/1024000SPC\n";
}
