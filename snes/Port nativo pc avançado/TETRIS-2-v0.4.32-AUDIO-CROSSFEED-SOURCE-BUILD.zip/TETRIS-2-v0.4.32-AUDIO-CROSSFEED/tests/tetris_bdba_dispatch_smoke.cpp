#include "generated.hpp"
#include <array>
#include <iostream>
#include <stdexcept>
void sub_82BDBA_E0M0X0C0(CpuState&,SnesRuntime&,std::uint32_t);
void sub_82BDD7_E0M0X0CQ(CpuState&,SnesRuntime&,std::uint32_t);
void sub_82BDF2_E0M0X0CQ(CpuState&,SnesRuntime&,std::uint32_t);
void sub_82BDFC_E0M0X0CQ(CpuState&,SnesRuntime&,std::uint32_t);
void sub_82BDC8_E0M0X0CQ(CpuState&,SnesRuntime&,std::uint32_t);
void forja65_dispatch(CpuState&,SnesRuntime&,std::uint32_t,std::uint32_t) { throw std::runtime_error("unexpected nested dispatcher"); }
bool forja65_is_stack_return_target(std::uint32_t t,SnesRuntime&) {return t==0x82BDC8u;}
void forja65_wait(CpuState&,SnesRuntime&,std::uint32_t){}
int main(int argc,char**argv){
 try{
 const std::string cart=(argc>1)?argv[1]:"assets/cart-data.bin";
 const std::array<std::uint16_t,7> expected={0xBDD7,0xBDF2,0xBDFC,0xBE05,0xBE22,0xBEA9,0xBF0A};
 for(unsigned i=0;i<expected.size();++i){
  SnesRuntime hw(cart,MapperKind::LoROM,0u,10u,0u,CartChip::None,"",1u,true);
  CpuState cpu{};
  cpu.pb=0x82;cpu.db=0x80;cpu.e=false;cpu.m8=false;cpu.x8=false;cpu.c=false;cpu.s=0x1FE0u;
  hw.write(0x000176u,i,16);
  sub_82BDBA_E0M0X0C0(cpu,hw,0x82BDBAu);
  if(!hw.dispatchPending||hw.dispatchTarget!=(0x820000u|expected[i])||hw.dispatchFrom!=0x82BDC5u||cpu.s!=0x1FDEu||cpu.peekStack16(hw)!=0xBDC7u){
   std::cerr<<"FAIL i="<<i<<" dst="<<std::hex<<hw.dispatchTarget<<" source="<<hw.dispatchFrom<<" SP="<<cpu.s<<" stack="<<cpu.peekStack16(hw)<<"\n";
   return 3;
  }
  std::cout<<"OK "<<i<<" -> $82:"<<std::hex<<expected[i]<<std::dec<<"\n";
 }
 // Verify three self-contained table arms return through the PEA-generated
 // $82:BDC8 trampoline, then the original JSR frame at $82:CFC7.
 for(unsigned i=0;i<3;++i){
  SnesRuntime hw(cart,MapperKind::LoROM,0u,10u,0u,CartChip::None,"",1u,true);
  CpuState cpu{};cpu.pb=0x82;cpu.db=0x80;cpu.e=false;cpu.m8=false;cpu.x8=false;cpu.c=false;cpu.s=0x1FE0u;
  hw.write(0x000176u,i,16);
  cpu.push16Value(hw,0xCFC6u);
  auto token=hw.pushNativeReturn(0x82CFC7u,false,cpu);
  sub_82BDBA_E0M0X0C0(cpu,hw,0x82BDBAu);
  const auto branch=hw.dispatchTarget;
  hw.dispatchPending=false;
  if(i==0)sub_82BDD7_E0M0X0CQ(cpu,hw,branch);
  if(i==1)sub_82BDF2_E0M0X0CQ(cpu,hw,branch);
  if(i==2)sub_82BDFC_E0M0X0CQ(cpu,hw,branch);
  if(!hw.dispatchPending||hw.dispatchTarget!=0x82BDC8u){std::cerr<<"missing PEA trampoline for index "<<i<<"\n";return 4;}
  hw.dispatchPending=false;
  sub_82BDC8_E0M0X0CQ(cpu,hw,0x82BDC8u);
  if(cpu.s!=0x1FE0u||hw.nativeReturnedCall!=token||!hw.nativeReturns.empty()){
   std::cerr<<"incorrect JSR stack unwind for index "<<i<<"\n";return 5;
  }
  std::cout<<"OK end-to-end stack / PEA / RTS index "<<i<<"\n";
 }
 return 0;
 }catch(const std::exception&e){std::cerr<<"smoke: "<<e.what()<<"\n";return 2;}
}
