#include "runtime.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <filesystem>
#include <iostream>
int main(){
  ApuBridge apu;
  apu.setNativeDsp(true);
  apu.configureAudioOutput(false,true);
  // A valid BRR voice goes through the same SPC $F2/$F3 control path as the game.
  apu.spc.ram[0x100]=0;apu.spc.ram[0x101]=2;
  apu.spc.ram[0x102]=0;apu.spc.ram[0x103]=2;
  apu.spc.ram[0x200]=3;
  for(int i=0;i<8;i++)apu.spc.ram[0x201+i]=0x77;
  auto write=[&](unsigned r,unsigned v){apu.spcWrite(0xF2,(std::uint8_t)r);apu.spcWrite(0xF3,(std::uint8_t)v);};
  write(0x0C,90);write(0x1C,90);write(0x00,100);write(0x01,100);
  write(0x02,0);write(0x03,0x10);write(0x05,0x8F);
  write(0x5D,1);write(0x4C,1);
  apu.tickDspMasterCycles((unsigned)((ApuBridge::DSP_MASTER_HZ*500ull+ApuBridge::DSP_OUTPUT_RATE_HZ-1ull)/ApuBridge::DSP_OUTPUT_RATE_HZ));
  apu.finishAudioOutput();
  assert(apu.dspNativeSamples==500);
  assert(apu.pcmOutput.framesGenerated==500);
  assert(apu.pcmOutput.framesNonzero>0);
  assert(apu.pcmOutput.peak>0);
  assert(apu.pcmOutput.waveFrames==500);
  assert(std::filesystem::file_size("forja65-native-audio.wav")==44+500*4);
  std::filesystem::remove("forja65-native-audio.wav");
  std::cout<<"SPC registers -> BRR DSP -> stereo PCM -> streamed WAV PASS\n";
}
