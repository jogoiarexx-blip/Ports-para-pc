#include "generated.hpp"
#include <stdexcept>
#define assert(x) do { if(!(x)) throw std::runtime_error("victory CFG smoke assertion failed: " #x); } while(false)
#include <cstdint>
#include <iostream>
#include <fstream>
#include <vector>

void sub_82CE65_E0M0X0C0(CpuState&,SnesRuntime&,std::uint32_t);
void sub_82937D_E0M1X0C0(CpuState&,SnesRuntime&,std::uint32_t);
static unsigned calleeCalls=0;
// Only the generated victory routines are linked here. Subcalls to the already
// translated CPU routines are modeled as well-formed stack returns in this unit
// test; end-to-end execution must still be checked separately.
void forja65_dispatch(CpuState&cpu,SnesRuntime&hw,std::uint32_t target,std::uint32_t){
  assert(target==0x82D03Eu || target==0x82D15Eu);
  ++calleeCalls;
  cpu.pop16Value(hw);
  hw.popNativeReturn();
  cpu.m8=false;
}
bool forja65_is_stack_return_target(std::uint32_t target,SnesRuntime&){
  return target==0x82937Du;
}
int main(){
  // Verify that these are the original ROM's indexed JMP table values, not
  // hand-authored substitutes for winning the game.
  std::ifstream cartridge("assets/cart-data.bin",std::ios::binary);
  assert(cartridge.good());
  std::vector<unsigned char> rom((std::istreambuf_iterator<char>(cartridge)),{});
  assert(rom.size()==1048576u);
  auto rb=[&](std::uint32_t pc){
    return rom.at(((pc>>16)&0x7Fu)*0x8000u+(pc&0x7FFFu));
  };
  assert(rb(0x829377u)==0xF4u && rb(0x82937Au)==0x7Cu);
  assert(rb(0x82937Bu)==0x86u && rb(0x82937Cu)==0x93u);
  constexpr unsigned short destinations[13]={0xCE65,0xCE75,0xCEC0,0xCEDF,0xCF16,0xCF47,0xCFA0,0xCFC8,0xD00B,0xD013,0xD014,0xD015,0xD031};
  for(int i=0;i<13;++i){
    const unsigned lo=rb(0x829386u+i*2u),hi=rb(0x829387u+i*2u);
    assert(((hi<<8)|lo)==destinations[i]);
  }
  SnesRuntime hw;
  CpuState cpu;
  cpu.e=false;cpu.m8=false;cpu.x8=false;cpu.c=false;cpu.pb=0x82;cpu.db=0x80;cpu.s=0x1FED;
  // Genuine outer call; next PEA trampoline is not allowed to consume it.
  cpu.push16Value(hw,0x93FF);
  hw.pushNativeReturn(0x829400u,false,cpu);
  const auto outerDepth=hw.nativeReturns.size();
  cpu.push16Value(hw,0x937Cu);
  hw.write(0x017B,0,16);
  sub_82CE65_E0M0X0C0(cpu,hw,0x82CE65);
  assert(hw.dispatchPending && hw.dispatchTarget==0x82937Du);
  assert(hw.nativeReturns.size()==outerDepth);
  assert(cpu.m8 && hw.read(0x6F)==0x20 && hw.read(0x017B)==1);
  assert(hw.apu.spc.portIn[0]==0x83);
  hw.dispatchPending=false;
  sub_82937D_E0M1X0C0(cpu,hw,0x82937D);
  assert(calleeCalls==2);
  assert(hw.nativeReturns.empty());
  assert(cpu.s==0x1FED);
  std::cout << "TETRIS_VICTORY_CFG_PASS continuation=82937D jump_table_entries=13 calls=2 outer_frame_preserved=1\n";
}
