#include "runtime.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <iostream>
#include <string>

int main(){
  ApuBridge a;
  a.tracePorts=true;
  a.traceCpuReads=true;
  a.traceCpuReadChanges=true;
  a.spcWrite(0xF4,0xAA); // APU -> CPU port 0
  assert(a.read(0)==0xAA);
  assert(a.read(0)==0xAA); // polling the same value is compressed
  a.write(0,0xCC);       // CPU -> APU must not echo back
  assert(a.read(0)==0xAA);
  assert(a.spcRead(0xF4)==0xCC);
  a.spcWrite(0xF4,0xBB);
  assert(a.read(0)==0xBB);
  assert(a.read(4)==0);
  assert(a.cpuPortReadCounts[0]==4);
  unsigned qCount=0;
  for(const auto&e:a.portEvents){
    if(e.side!='Q')continue;
    assert(e.port==0);
    assert(e.value==(qCount<2?0xAA:0xBB));
    ++qCount;
  }
  assert(qCount==3);
  assert(a.savePortTrace("port-observer-smoke.csv"));
  std::ifstream file("port-observer-smoke.csv");
  const std::string data((std::istreambuf_iterator<char>(file)),std::istreambuf_iterator<char>());
  assert(data.find("# cpu_reads=4,0,0,0")!=std::string::npos);
  file.close(); std::filesystem::remove("port-observer-smoke.csv");
  // Full mode logs every poll; without tracing, port values are unchanged.
  ApuBridge b;
  b.tracePorts=true; b.traceCpuReads=true; b.traceCpuReadChanges=false;
  b.spcWrite(0xF4,0xAA);
  assert(b.read(0)==0xAA && b.read(0)==0xAA);
  unsigned qAll=0;for(const auto&e:b.portEvents)if(e.side=='Q')++qAll;
  assert(qAll==2);
  ApuBridge c;
  c.spcWrite(0xF4,0xAA);
  assert(c.read(0)==0xAA && c.portEvents.empty() && c.cpuPortReadCounts[0]==0);
  std::cout<<"SPC_CPU_PORT_OBSERVER_PASS compressed=3 full=2 isolation=PASS\n";
}
