// Integration regression for the genuine translated CPU dispatch chain used
// after the Tetris 2 victory JMP ($9386,X) at $82:937A.
// This is NOT a full game-winning replay: the CPU/WRAM state is synthetic.
#include "generated.hpp"
#include <iostream>
#include <stdexcept>

static void require(bool ok, const char* desc) {
  if (!ok) throw std::runtime_error(desc);
}

int main() {
  try {
    SnesRuntime hw("assets/cart-data.bin", MapperKind::LoROM,
                   0, 10, 0, CartChip::None, "", 1, true);
    CpuState cpu;
    cpu.e = false; cpu.m8 = false; cpu.x8 = false; cpu.c = false;
    cpu.pb = 0x82; cpu.db = 0x80; cpu.s = 0x1FDA;
    cpu.y = 0xFFFE; cpu.x = 0;
    const auto initialStack = cpu.s;
    // A surrounding translated JSR frame, then the ROM's PEA $937C
    // trampoline. This must be preserved until the *correct* final RTS.
    cpu.push16Value(hw, 0x93FF);
    hw.pushNativeReturn(0x829400u, false, cpu);
    cpu.push16Value(hw, 0x937Cu);
    hw.beginFrame();
    forja65_dispatch(cpu, hw, 0x82937Au, 0x829377u);
    require(!hw.stopped, "victory dispatcher halted");
    require(!hw.dispatchPending, "victory dispatcher left unresolved flow");
    require(hw.nativeReturns.empty(), "victory dispatcher left native returns");
    require(cpu.s == initialStack, "victory dispatcher corrupted stack");
    require(hw.apu.spc.portIn[0] == 0x83,
            "victory callback did not send the expected APU command");
    // New Windows trace: $82CEBF (RTS) -> $82937D with E=0,M=0,X=0,C=0.
    // The native JSR frame and PEA pointer must remain consistent across the
    // REP #$20 instruction.  The v0.4.19 dispatcher failed before this opcode.
    {
      SnesRuntime observed("assets/cart-data.bin", MapperKind::LoROM,
                           0, 10, 0, CartChip::None, "", 1, true);
      CpuState resumed;
      resumed.e=false;resumed.m8=false;resumed.x8=false;resumed.c=false;
      resumed.pb=0x82;resumed.db=0x80;resumed.s=0x1FD3;
      resumed.x=2;resumed.y=0xFFFE;
      resumed.push16Value(observed,0x93FF);
      observed.pushNativeReturn(0x829400u,false,resumed);
      observed.beginFrame();
      forja65_dispatch(resumed,observed,0x82937Du,0x82CEBFu);
      require(!observed.stopped,"M0 victory continuation halted");
      require(!observed.dispatchPending,"M0 victory continuation not dispatched");
      require(resumed.m8==false,"REP #$20 did not leave M=0");
      require(observed.nativeReturns.empty(),"M0 continuation did not unwind native return");
      require(resumed.s==0x1FD3,"M0 continuation changed outer stack");
    }
    std::cout << "VICTORY_DISPATCH_PASS ROM_JMP=82937A CALLBACK=82CE65 "
                 "RETURN=82937D APU_COMMAND=83 nativeDepth=0\n";
    return 0;
  } catch (const std::exception& e) {
    std::cerr << "VICTORY_DISPATCH_FAIL " << e.what() << '\n';
    return 1;
  }
}
