# Tetris 2 v0.4.11 — CPU/APU poll window e PC

## Correções e novos recursos
- Adicionado `FORJA65_APU_TRACE_READS=window`: divide séries de consultas iguais em janelas de até 1364 master cycles (aproximação de uma scanline NTSC).
- Uma escrita S-CPU→APU ou SPC700→S-CPU na porta correspondente inicia nova série de consultas; não comprime através de uma barreira causal.
- Os eventos Q registram `cpu_pc` e `last_cpu_pc` (valores decimais no CSV). O PC é o endereço da instrução em execução; o timestamp continua sendo o limite da instrução, não o ciclo exato de barramento.
- Corrigido o descarte silencioso de consultas quando uma série anterior foi invalidada.
- Comparador compatível com CSV das versões antigas e enriquecido com o PC da CPU quando disponível.
- `CAPTURAR-SPC-QUADRO-59.cmd` usa o modo `window`, preservando o modo estável do jogo.
- Atualizados os testes antigos de observação de portas e IPL para o novo cabeçalho e a correta separação de grupos de consultas.

## Validação realizada neste ambiente
- Linux CMake game: compilação completa PASS.
- CTest Tetris: 22 aprovados, 1 ignorado (equivalence_vectors sem vetores externos), 0 falhas.
- Forja65: 14 regressões anteriores + regressão nova `tetris-spc-poll-window-v0411` aprovadas; código recém-gerado compilado em C++.
- Capturas: 59 quadros em ambos os modos, 0 eventos descartados; modo estável com QA status literalmente igual à captura da v0.4.10.
- A primeira diferença de contagem em janelas locais foi na Q-run 50, porta 0 valor $AA: 6 polls estável, 15 no experimental; PC 65C816 $80:A581, instrução CMP $2140, aguardando resposta $CC.
- Timestamps das consultas são aproximados e ainda não há referência do SNES para declarar qual temporização é a fiel.

## Limitações
- Não foi demonstrado gameplay completo nem equivalência com áudio PCM original.
- O SPC700 de temporização experimental permanece opt-in; o modo estável continua o padrão.
- Executável Windows não compilado; compile usando BUILD-WINDOWS.cmd antes de jogar.
- A captura a partir de quadros posteriores ainda pode superar o limite de 32768 eventos; o CSV informa `# dropped` e a contagem total de polls.

## Comandos
No Windows: BUILD-WINDOWS.cmd, TESTAR-HARDWARE.cmd e CAPTURAR-SPC-QUADRO-59.cmd.
No Linux com runtime compilado: FORJA65_APU_IPL_TRACE=1 FORJA65_APU_TRACE_READS=window FORJA65_CAPTURE_SPC_FRAME=59 FORJA65_CAPTURE_SPC_STOP=1 ./game
Exemplo dos dados gerados: `validation/v0411-cpu-apu-poll-window/`.
