# Tetris 2 v0.4.26

- DSP 8 vozes: oscilador de ruido LFSR (NON/$3D), pitch modulation PMON/$2D entre vozes 1..7, leitura e escrita de eco em SPC RAM (ESA/$6D, EDL/$7D, EON/$4D), FIR 8 taps xF, feedback EFB/$0D, EVOL L/R e FLG bit 5 (echo-write inhibit).
- O modo de eco que grava memoria real do SPC700 requer `FORJA65_ECHO_RAM_WRITES=1`; por padrao bloqueado no port para reduzir risco de sobrepor codigo SPC nao validado. Mesmo com escrita bloqueada, a leitura de eco pode ocorrer em modo DSP conforme configuracao.
- Regressao especifica do eco inativo: memoria SPC baixa intacta se EON=EDL=0.
- `BUILD-WINDOWS.cmd` inclui teste `dsp_echo_noise_pmon_v0426_smoke`; nenhum gerador Forja65 necessario para build normal.
- Correcoes anteriores de flow $82:BDBA, CPU, PPU, DMA, BRR, ADSR e PCM preservadas.
- Testes locais: CMake 6/6 DSP/audio/fluxo; compilacao Linux game PASS; jogo ate 6000 frames em replay normal PASS, sem crash; 1200 frames audio identico ao baseline da v0.4.25 quanto a contagem, pico e estado SPC.
- Limitacoes: nao bit-exato ao DSP do console; interpolacao ainda linear; eco/timing nao comparados a captura real do SNES; dispositivo Windows nao testado.
