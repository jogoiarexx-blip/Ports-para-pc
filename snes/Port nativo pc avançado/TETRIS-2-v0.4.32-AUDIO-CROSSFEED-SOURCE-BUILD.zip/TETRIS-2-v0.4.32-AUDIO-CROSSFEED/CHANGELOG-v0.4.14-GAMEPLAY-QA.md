# Tetris 2 v0.4.14 — QA real dos controles e replay

## Bugs corrigidos
- Replay ausente era ignorado silenciosamente: agora `FORJA65_INPUT_REPLAY` com caminho inválido interrompe a execução, em vez de executar sem controles.
- Parser de replay rejeita linhas incompletas, números inválidos, `joy1/joy2` maiores que 16 bits, chaves duplicadas, quadro duplicado/fora de ordem e arquivo sem eventos.
- Caminhos do arquivo de controles em `RUN-INPUT-REPLAY.cmd` e do gravador `RUN-INPUT-RECORD.cmd` passaram a ser absolutos; não se perdem ao mudar para `bin`.
- `VALIDAR-REPLAY.cmd` não aponta mais para `validation/input-gameplay.txt` (inexistente). Agora executa QA A/B usando `validation/input-normal.txt` por padrão e aceita cenários e duração como parâmetros.
- Captura de hashes permite arquivo de destino isolado por processo via `FORJA65_FRAME_HASH_PATH`.
- Acrescentados `tests/gameplay_input_smoke.cpp`, `tools/validate_gameplay_replay.py` e roteiro curto `validation/input-menu-600.txt`.

## Testes executados nesta rodada (Linux)
- Compilação integral C++ com CMake: **PASS**.
- CTest: **25 PASS, 1 SKIP**, 0 FAIL. O ignorado exige vetores de equivalência externos.
- Forja65: **18 PASS** nos testes de integração específica do Tetris, incluindo código recém-gerado e compilado com a correção de entrada.
- Replays A/B de **600 quadros cada**, mesmo executável, mesmos ajustes, uma execução sem comandos e outra com START nos quadros 360, 420 e 480.
- Primeiro desvio de WRAM e PC: quadro **360**; primeiro desvio visual: quadro **363**; diferenças em 240 quadros WRAM, 239 quadros PC e 237 quadros visuais; **nenhuma diferença antes do primeiro START**.
- A gravação dos controles efetivamente observados foi comparada frame a frame com a entrada programada; os estados coincidiriam (600 registros).

## Limitações
- Isto comprova que comandos programados alteram a execução, **não** comprova tela específica alcançada, primeira fase concluída, modo versus concluído ou fidelidade ao SNES original.
- Windows/MSVC não foi compilado neste ambiente. O pacote contém fonte, scripts e os testes para sua máquina.
- O runtime estável de PPU/CPU/DMA/SPC700/DSP foi preservado, exceto pelo fail-fast no replay e pela escolha opcional do caminho do hash.

## Para testar no Windows
1. Extraia o ZIP e execute `BUILD-WINDOWS.cmd`.
2. Rode `VALIDAR-REPLAY.cmd` (padrão: gameplay normal com 2000 quadros).
3. Para o roteiro curto, execute `VALIDAR-REPLAY.cmd validation\input-menu-600.txt 600`.
4. Para os demais cenários, especifique o arquivo e um total de quadros maior que o último evento, como `VALIDAR-REPLAY.cmd validation\input-versus-com.txt 3200` ou `VALIDAR-REPLAY.cmd validation\input-pause-retry.txt 6200`.
5. Confira `validation/gameplay-ab/report.json`, logs e hashes. O script falha se houver divergências antes das entradas ou se nenhum estado mudar após elas.

O arquivo `validation/v0414-gameplay-ab/report.json` contém o resultado da comparação de 600 quadros desta rodada.
