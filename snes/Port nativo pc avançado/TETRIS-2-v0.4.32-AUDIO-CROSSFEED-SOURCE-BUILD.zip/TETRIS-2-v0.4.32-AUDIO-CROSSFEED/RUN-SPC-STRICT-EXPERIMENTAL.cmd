@echo off
setlocal
cd /d "%~dp0"
set FORJA65_SPC_TIMING=accurate
set FORJA65_SPC_SCHEDULER=strict
set FORJA65_SPC_CLOCK=
echo SPC700: instruction-retirement STRICT (experimental).
echo This is NOT the default mode and is not yet SNES-equivalence verified.
call RUN-WINDOWS.cmd
