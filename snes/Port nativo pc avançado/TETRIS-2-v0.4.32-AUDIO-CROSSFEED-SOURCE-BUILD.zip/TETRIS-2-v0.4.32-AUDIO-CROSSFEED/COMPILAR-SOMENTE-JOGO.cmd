@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target game --parallel || goto :err
if not exist "build-win\Release\game.exe" (echo ERRO: game.exe nao foi gerado. & goto :err)
if not exist bin mkdir bin
copy /Y "build-win\Release\game.exe" "bin\game.exe" >nul || goto :err
xcopy /E /I /Y "assets" "bin\assets" >nul || goto :err
copy /Y "RUN-WINDOWS.cmd" "bin\RUN-WINDOWS.cmd" >nul
copy /Y "RUN-WINDOWS-AUDIO.cmd" "bin\RUN-WINDOWS-AUDIO.cmd" >nul
copy /Y "RUN-WINDOWS-AUDIO-LEGACY-KEYS.cmd" "bin\RUN-WINDOWS-AUDIO-LEGACY-KEYS.cmd" >nul
copy /Y "RUN-NATIVE-AUDIO.cmd" "bin\RUN-NATIVE-AUDIO.cmd" >nul
if exist "forja65-build-manifest.txt" copy /Y "forja65-build-manifest.txt" "bin\forja65-build-manifest.txt" >nul

echo.
echo OK: compilacao apenas do jogo concluida.
echo Para jogar com audio: RUN-WINDOWS-AUDIO.cmd
pause
exit /b 0
:err
echo.
echo FALHA na compilacao do jogo. Leia as mensagens acima.
pause
exit /b 1
