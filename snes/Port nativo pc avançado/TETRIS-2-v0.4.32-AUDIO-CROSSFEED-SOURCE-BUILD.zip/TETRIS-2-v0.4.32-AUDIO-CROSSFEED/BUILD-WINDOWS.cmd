@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul || (echo ERRO: CMake nao encontrado no PATH. & pause & exit /b 1)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 || goto :err
cmake --build build-win --config Release --target game runtime_smoke scene_capture_smoke oracle_learning_smoke deterministic_input_smoke native_dependency_smoke native_migration_smoke rom_pack_builder equivalence_runner framework_smoke hardware_fixes_smoke sprite_crossfeed_smoke sprite_limits_smoke hdma_descriptor_smoke ppu_snapshot_row_smoke dma_native_parity_smoke ppu_raster_sync_smoke dma_vram_batch_smoke vram_access_smoke apu_dsp_registers_smoke spc_cycle_timers_smoke spc_semantics_smoke spc_ipl_handshake_smoke spc_cpu_port_observer_smoke spc_cpu_poll_runs_smoke spc_strict_scheduler_smoke spc_register_edges_smoke gameplay_input_smoke scene_timeline_smoke tetris_victory_cfg_smoke tetris_victory_dispatch_smoke pcm_audio_output_smoke audio_signal_smoke dsp_envelopes_v0425_smoke dsp_echo_noise_pmon_v0426_smoke dsp_gaussian_v0427_smoke dsp_envelope_clock_v0428_smoke dsp_key_timing_v0429_smoke dsp_fractional_clock_v0430_smoke dsp_spc_interleave_v0431_smoke dsp_continuous_sync_crossfeed_smoke dsp_fir_noise_crossfeed_smoke tetris_bdba_dispatch_smoke || goto :err
ctest --test-dir build-win -C Release --output-on-failure || goto :err
if not exist bin mkdir bin
copy /Y build-win\Release\game.exe bin\game.exe >nul
xcopy /E /I /Y assets bin\assets >nul
copy /Y RUN-WINDOWS.cmd bin\RUN-WINDOWS.cmd >nul
copy /Y RUN-WINDOWS-AUDIO.cmd bin\RUN-WINDOWS-AUDIO.cmd >nul
copy /Y RUN-WINDOWS-AUDIO-LEGACY-KEYS.cmd bin\RUN-WINDOWS-AUDIO-LEGACY-KEYS.cmd >nul
copy /Y RUN-WINDOWS-AUDIO-LEGACY-CLOCK.cmd bin\RUN-WINDOWS-AUDIO-LEGACY-CLOCK.cmd >nul
copy /Y RUN-WINDOWS-AUDIO-INTERLEAVED.cmd bin\RUN-WINDOWS-AUDIO-INTERLEAVED.cmd >nul
copy /Y RUN-WINDOWS-AUDIO-48KHZ.cmd bin\RUN-WINDOWS-AUDIO-48KHZ.cmd >nul
copy /Y RUN-WINDOWS-AUDIO-SYNC-REFERENCE.cmd bin\RUN-WINDOWS-AUDIO-SYNC-REFERENCE.cmd >nul
copy /Y RUN-WINDOWS-ECHO-EXPERIMENTAL.cmd bin\RUN-WINDOWS-ECHO-EXPERIMENTAL.cmd >nul
copy /Y RUN-NATIVE-AUDIO.cmd bin\RUN-NATIVE-AUDIO.cmd >nul
copy /Y RUN-SPC-TIMING-EXPERIMENTAL.cmd bin\RUN-SPC-TIMING-EXPERIMENTAL.cmd >nul
copy /Y RUN-SPC-STRICT-EXPERIMENTAL.cmd bin\RUN-SPC-STRICT-EXPERIMENTAL.cmd >nul
copy /Y CAPTURAR-SPC-STRICT-QUADRO-59.cmd bin\CAPTURAR-SPC-STRICT-QUADRO-59.cmd >nul
copy /Y RUN-SPC-SEMANTICS-EXPERIMENTAL.cmd bin\RUN-SPC-SEMANTICS-EXPERIMENTAL.cmd >nul
copy /Y RUN-SPC-COMBINED-EXPERIMENTAL.cmd bin\RUN-SPC-COMBINED-EXPERIMENTAL.cmd >nul
copy /Y RUN-SPC-NTSC-EXPERIMENTAL.cmd bin\RUN-SPC-NTSC-EXPERIMENTAL.cmd >nul
copy /Y CAPTURAR-SPC-QUADRO-59.cmd bin\CAPTURAR-SPC-QUADRO-59.cmd >nul
if not exist bin\tools mkdir bin\tools
copy /Y tools\compare_spc_snapshots.py bin\tools\compare_spc_snapshots.py >nul
copy /Y tools\compare_apu_ports.py bin\tools\compare_apu_ports.py >nul
copy /Y RUN-ORACLE.cmd bin\RUN-ORACLE.cmd >nul
copy /Y RUN-HEADLESS.cmd bin\RUN-HEADLESS.cmd >nul
copy /Y RUN-INPUT-RECORD.cmd bin\RUN-INPUT-RECORD.cmd >nul
copy /Y RUN-INPUT-REPLAY.cmd bin\RUN-INPUT-REPLAY.cmd >nul
copy /Y VALIDAR-REPLAY.cmd bin\VALIDAR-REPLAY.cmd >nul
copy /Y CAPTURAR-GAMEPLAY.cmd bin\CAPTURAR-GAMEPLAY.cmd >nul
copy /Y tools\validate_gameplay_replay.py bin\tools\validate_gameplay_replay.py >nul
if not exist bin\validation mkdir bin\validation
copy /Y validation\input-normal.txt bin\validation\input-normal.txt >nul
copy /Y validation\input-pause-retry.txt bin\validation\input-pause-retry.txt >nul
copy /Y validation\input-versus-com.txt bin\validation\input-versus-com.txt >nul
copy /Y forja65-build-manifest.txt bin\forja65-build-manifest.txt >nul
echo.
echo OK: bin\game.exe
pause
exit /b 0
:err
echo.
echo FALHA NO BUILD NATIVO. Veja as mensagens acima.
pause
exit /b 1
