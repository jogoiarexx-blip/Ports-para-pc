# Tetris 2 v0.4.18 — colisões laterais e transição de peças

## O que foi comprovado com o executável real

A base de runtime C++ utilizada na validação é a v0.4.15 (mesmas rotinas de jogo das v0.4.16 e v0.4.17). A execução de duas sessões de **1970 quadros** manteve LEFT e RIGHT pressionados de 1835 a 1960. Os quatro sprites OAM da peça (tiles 2,3,11,5) chegaram a x=88 (esquerda) e x=144 (direita) no quadro 1860; a posição horizontal ficou constante até o quadro 1970, enquanto a peça continuou descendo (mais 48 pixels verticais após contato). O verificador bloqueia sucesso se a peça ultrapassar o limite, deixar de descer, se perder sprites, se o formato mudar ou se as sessões divergirem antes do comando.

A descida sustentada de 1835 a 2380 foi reproduzida até **2400 quadros**. Quadros 1875, 1900 e 1925: os sprites ativos da peça antiga desaparecem no quadro 1900, a área visível do tabuleiro permanece pixel a pixel idêntica à do quadro 1875 (13776 pixels analisados) e uma nova peça com tiles 2,4,5,13 aparece no alto no quadro 1925. Isso confirma o handoff visual observado, sem demonstrar lógica geral de empilhamento ou limpeza de linhas.

## Melhorias implementadas

- `tools/gameplay_wall_qa.py`: lê OAM, valida colisão em ambas paredes, queda após contato, assinatura da peça e controle determinístico sem conflito de eventos.
- `tools/gameplay_lock_qa.py`: compara OAM e framebuffer para detectar a transição entre duas peças sem desaparecimento visual do tabuleiro.
- `tests/test_gameplay_wall_lock_qa.py`: casos positivos e negativos (parede atravessada, ausência de movimento, imagem truncada, assinatura errada, entrada sobreposta, etc.).
- `VALIDAR-COLISOES-GAMEPLAY.cmd`: no Windows recompila apenas pela ferramenta `BUILD-WINDOWS.cmd` separada e reproduz automaticamente as três execuções. Requer Python 3 e executável game.exe compilado.

## Limitações

- Nenhum algoritmo de CPU, PPU, DMA/HDMA ou SPC700/DSP foi modificado nesta versão.
- Não comprova linha eliminada, pontuação, vitória ou fidelidade ao hardware original.
- Não é um Windows game.exe pré-compilado. O replay real foi executado com o binário Linux da versão anterior de mesmo runtime.
