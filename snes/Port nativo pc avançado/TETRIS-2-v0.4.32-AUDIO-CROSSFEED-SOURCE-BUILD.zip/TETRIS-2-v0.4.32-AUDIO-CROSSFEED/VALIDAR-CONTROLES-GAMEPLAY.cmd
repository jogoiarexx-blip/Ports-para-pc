@echo off
setlocal
cd /d "%~dp0"
set "GAME=%~dp0bin\game.exe"
set "CART=%~dp0bin\assets\cart-data.bin"
if not exist "%GAME%" (
  set "GAME=%~dp0game.exe"
  set "CART=%~dp0assets\cart-data.bin"
)
if not exist "%GAME%" (echo ERRO: compile com BUILD-WINDOWS.cmd antes. & exit /b 2)
if not exist "%CART%" (echo ERRO: cart-data.bin nao encontrado. & exit /b 2)
set "PY=python"
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
%PY% --version >nul 2>nul
if errorlevel 1 (echo ERRO: Python 3 necessario para validacao. & exit /b 2)
%PY% "tools\gameplay_controls_qa.py" --game "%GAME%" --cart "%CART%" --trace "validation\input-control-v0416.txt" --output "validation\v0417-controls-qa" --report "validation\v0417-controls-qa\resultado-controles.json"
if errorlevel 1 (echo FALHA: validacao de movimento/rotacao. & exit /b 3)
echo APROVADO: esquerda, direita, rotacao e descida (QA visual).
exit /b 0
