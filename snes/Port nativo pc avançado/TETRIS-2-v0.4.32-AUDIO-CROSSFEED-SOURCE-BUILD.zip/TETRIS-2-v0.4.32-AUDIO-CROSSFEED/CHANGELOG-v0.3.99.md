# Tetris 2 v0.3.99 — PPU OBJ 32/34 + STAT77

## Correções de runtime

- Substituído renderizador OAM sem limite por avaliação de até 32 sprites elegíveis em cada linha. A seleção acompanha o início da rotação configurada em $2103.
- A leitura dos tiles/slivers (8 px) ocorre na ordem reversa entre os sprites selecionados, com orçamento máximo de 34 blocos e prioridade interna correta.
- Sprites em X=-256 consomem orçamento da seleção, mas não desenham pixels na tela.
- Os blocos gráficos são lidos da VRAM existente, com correção de X flip, Y flip, múltiplos tiles e transparência; os caminhos escalar e por linha mantêm paridade.
- STAT77 ($213E) sinaliza bit 6 (range-over) e bit 7 (time-over). Flags reiniciam quando começa novo quadro; o comportamento exato por dot do SNES ainda não foi validado.
- Mantidos os aperfeiçoamentos de CPU/DMA/HDMA/SPC700/DSP presentes na v0.3.98.

## Testes

- Novo `sprite_limits_smoke`, cobrindo range-over, time-over, X=-256, flip e reinício dos indicadores.
- `sprite_crossfeed_smoke` preservado.
- CMake, `BUILD-WINDOWS.cmd` e `TESTAR-HARDWARE.cmd` atualizados.
- Forja65 sincronizado: o novo projeto gerado pelo gerador passa nos mesmos testes de limite de sprites.

## Resultado Linux (nesta execução)

- Executável `game` compilado em Linux (build de validação Debug, sem símbolos) e replay headless de 2.000 quadros concluído.
- Comparação no MESMO cenário com o executável anterior v0.3.97: vídeo=0 divergências, WRAM=0 e PC=0 em 2.000 quadros.
- CTest: 10 executados com sucesso, 1 `equivalence_vectors` ignorado por ausência de vetores externos; 11 entradas totais.
- Regressões do gerador `tetris-hardware-v0397`, `tetris-obj-crossfeed-v0398` e `tetris-obj-limits-v0399` aprovadas.
- O teste isolado `sprite_limits_smoke` passou com AddressSanitizer e UndefinedBehaviorSanitizer.

## Limites importantes

Sem comparação de pixels com oracle/captura do SNES original; sem confirmação de todas as fases e modos; sem validação visual no Windows. CPU/PPU/DMA/HDMA/SPC700/DSP mantêm fallbacks de hardware virtual em runtime. Não é um port 100% independente do SNES. Não inclui game.exe para Windows; executar BUILD-WINDOWS.cmd no computador com Visual Studio 2022+CMake.
