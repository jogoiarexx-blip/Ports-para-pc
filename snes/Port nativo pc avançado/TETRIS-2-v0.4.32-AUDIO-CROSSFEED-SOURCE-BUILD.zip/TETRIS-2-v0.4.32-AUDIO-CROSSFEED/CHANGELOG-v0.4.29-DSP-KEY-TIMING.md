# Tetris 2 v0.4.29 — KON/KOFF, atraso BRR e ENDX

Base: Tetris 2 v0.4.28 (replay e DSP ADSR/GAIN preservados).

## Alterações

- KON deixa de disparar imediatamente na escrita do registro DSP quando o jogo usa o novo modo: é consumido no relógio de chave das amostras PCM, a cada 2 quadros estéreo.
- Inclui cinco quadros estéreo de preparação silenciosa da voz antes do primeiro decode BRR. Leitura BRR e avanço de phase aguardam a preparação.
- KOFF é verificado no mesmo relógio e aplica release gradual; KON reinicia envelope, histórico BRR e limpa ENDX da voz.
- ENDX é preparado quando o bloco BRR END termina e tornado visível na próxima amostra, inclusive em loops; escrita de ENDX limpa valor visível e evento pendente.
- FLG RESET invalida acionamentos pendentes de KON e desativa vozes.
- Divisão de lotes de amostras mantém o mesmo estado de áudio (determinismo do DSP).

## Segurança e compatibilidade

Modo novo habilitado por padrão no runtime do jogo. Para comparar com o comportamento anterior:

    set FORJA65_DSP_KEYS=legacy
    RUN-WINDOWS-AUDIO.cmd

Sem valor ou com FORJA65_DSP_KEYS=hardware: agendamento novo habilitado.
Outros modos permanecem disponíveis: FORJA65_DSP_ENVELOPE=legacy,
FORJA65_DSP_INTERPOLATION=linear; as opções são independentes.
O eco com gravação na RAM continua experimental e requer FORJA65_ECHO_RAM_WRITES=1.

## Validação

- Teste unitário novo: tests/dsp_key_timing_v0429_smoke.cpp
- Testes DSP das versões anteriores continuam incluídos.
- Teste integrado nativo Linux: replay normal de 1200 frames, áudio WAV 32kHz estéreo,
  17.224.552 instruções, 639.108 amostras, framebuffer hash 6613cefdf0d2091,
  WRAM hash 70263db67c0c3ea.
- Ainda não há prova de fidelidade bit-a-bit ou reprodução efetiva do dispositivo de áudio no Windows.
- A verificação específica acima não garante vitória nem execução de 6000 frames.

Referências externas de implementação:
https://github.com/snes9xgit/snes9x/blob/master/apu/bapu/dsp/SPC_DSP.cpp
https://snes.nesdev.org/wiki/S-DSP_registers
