# Tetris 2 v0.4.20 — segundo crash na vitória

## Evidência fornecida pelo usuário
- `unresolved-state`, quadro 5087, 71.285.383 instruções.
- `$82:CEBF` (RTS) retorna para `$82:937D` com `E=0, M=0, X=0, C=0`.
- `$82:937D` já constava no dispatcher da v0.4.19, mas apenas em `M=1`.

## Correção
- Entrada `M=0` da rotina `$82:937D` foi ligada ao mesmo corpo recompilado do `REP #$20`; essa instrução é invariante para o tamanho de acumulador e estabelece `M=0`.
- Nenhum salto forçado, alteração artificial do valor de M ou supressão de exceção foi introduzido.
- A v0.4.19 já tratava 13 destinos de tabela. A correção é a variante de estado do retorno.
- O teste `tetris_victory_dispatch_smoke` ganhou um segundo percurso que invoca o dispatcher com exatamente o estado reportado.

## Limites
- Passar no teste específico não comprova o fim da partida completa, nem a equivalência visual ao SNES original.
- Não alterar PPU/DMA/HDMA/SPC700/DSP nesta hotfix.
- O pacote Forja65 complementar é um hotfix de seu ramo 0.4.18: não deve substituir sem comparação o ramo 0.4.19 CROSSFEED-MULTIGAME que o usuário usa em outros chats.
