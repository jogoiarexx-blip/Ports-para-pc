@echo off
setlocal
set FORJA65_APU_DSP_INTERLEAVE=1
call "%~dp0RUN-WINDOWS-AUDIO.cmd"
