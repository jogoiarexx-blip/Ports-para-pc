@echo off
setlocal
cd /d "%~dp0"
call "%~dp0BUILD-WINDOWS.cmd"
if errorlevel 1 (echo ERRO: build falhou. & exit /b 1)
if not exist bin\game.exe (echo ERRO: executavel ausente. & exit /b 1)
set "ARQUIVO=%~dp0TETRIS-2-v0.4.32-AUDIO-PORTATIL-WINDOWS.zip"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -LiteralPath '%~dp0bin\game.exe','%~dp0bin\assets','%~dp0bin\RUN-WINDOWS.cmd','%~dp0bin\RUN-WINDOWS-AUDIO.cmd','%~dp0bin\RUN-WINDOWS-AUDIO-48KHZ.cmd','%~dp0bin\RUN-WINDOWS-AUDIO-SYNC-REFERENCE.cmd' -DestinationPath '%ARQUIVO%' -Force"
if errorlevel 1 (echo ERRO: pacote nao gerado. & exit /b 1)
echo ZIP PORTATIL WINDOWS GERADO: %ARQUIVO%
pause
