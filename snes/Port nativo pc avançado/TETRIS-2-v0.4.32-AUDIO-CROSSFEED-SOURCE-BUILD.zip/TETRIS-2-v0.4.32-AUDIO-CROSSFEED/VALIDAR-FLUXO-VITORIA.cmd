@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
if exist "build-win\Release\tetris_victory_cfg_smoke.exe" (
  pushd "build-win\Release"
  tetris_victory_cfg_smoke.exe
  set "CODE=!ERRORLEVEL!"
  popd
  if not "!CODE!"=="0" (echo ERRO no teste do fluxo de vitoria. & pause & exit /b !CODE!)
  tetris_victory_dispatch_smoke.exe
  set "CODE=!ERRORLEVEL!"
  if not "!CODE!"=="0" (echo ERRO na cadeia real de callbacks. & pause & exit /b !CODE!)
  echo Testes do fluxo de vitoria PASSARAM. Ainda e necessario testar uma partida completa.
  pause
  exit /b 0
)
echo Teste nao compilado. Execute BUILD-WINDOWS.cmd primeiro.
pause
exit /b 1
