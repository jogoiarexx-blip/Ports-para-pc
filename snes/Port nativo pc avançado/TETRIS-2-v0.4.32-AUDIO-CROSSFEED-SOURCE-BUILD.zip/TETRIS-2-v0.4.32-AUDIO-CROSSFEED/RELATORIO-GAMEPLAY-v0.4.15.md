# Tetris 2 v0.4.15 — verificacao visual da progressao

## Avanco comprovado

O Tetris 2 chega a uma tela de configuracao de rodada e depois ao tabuleiro jogavel, usando o replay deterministico `validation/input-normal.txt`. Imagens extraidas diretamente do framebuffer nativo; veja `validation/v0415-gameplay-visual/painel-quatro-quadros.png`.

| Quadro | Evidencia observada |
|---|---|
| 425 | Titulo TETRIS 2 e mensagem PUSH ANY BUTTON |
| 485 | Ainda na tela de titulo |
| 1200 | ROUND 1 e SPEED MED 4 na configuracao |
| 1750 | Tabuleiro de jogo renderizado com interface e pecas |

A nova captura multipla `FORJA65_CAPTURE_FRAMES=425,485,1200,1750` exporta quatro cenas COMPLETAS numa unica execucao, em pastas `frame-N`. Cada captura inclui preview, VRAM, CGRAM, OAM, mapa, tiles e manifestos. Todos os quatro previews corresponderam **byte a byte** aos das quatro execucoes independentes com a mesma entrada na v0.4.14. O caminho antigo `FORJA65_CAPTURE_FRAME=N` permanece disponivel.

## Regressao

- CMake + compilacao integral do jogo em Linux: PASS.
- CTest Tetris: 26 PASS, 1 SKIP por falta de vetores externos; nenhuma falha.
- Regressao Forja65: 19 testes Tetris PASS, incluindo geracao de runtime e compilacao C++ com nova captura multipla.
- Novo smoke de timeline: quadros 2,4,5; sem duplicata; falha explicita em lista decrescente.
- O comando `CAPTURAR-GAMEPLAY.cmd` reproduz o teste no Windows apos `BUILD-WINDOWS.cmd`.
- Nenhuma alteracao em timing, logica do jogo, renderizacao, SPC700 ou DMA nesta revisao; somente a infraestrutura de captura e seus testes.

## Limitacoes

Nao foram ainda demonstrados: partidas vencidas, remocao de linhas, pausa/retorno, todos os modos de jogo, fidelidade de pixels/audio contra o SNES original e compilacao Windows neste ambiente. O frame 1750 demonstra entrada no gameplay e NAO conclusao de fase. SPC700 strict permanece experimental.

## Comandos

No Windows: `BUILD-WINDOWS.cmd`, `TESTAR-HARDWARE.cmd`, `CAPTURAR-GAMEPLAY.cmd`. As imagens ficam em `validation/capturas-v0415/frame-N/preview.ppm`. Para abrir imagens sem conversor, consulte os PNG ja incluidos em `validation/v0415-gameplay-visual`.

No Linux: configure/compile via CMake; defina `FORJA65_HEADLESS=1`, `FORJA65_UNCAPPED=1`, `FORJA65_HEADLESS_FRAMES=1750`, `FORJA65_CAPTURE_FRAMES=425,485,1200,1750`, `FORJA65_CAPTURE_STOP=1`, `FORJA65_CAPTURE_DIR=destino` e `FORJA65_INPUT_REPLAY` apontando para o roteiro absoluto; execute `game` na pasta que contem `assets`.
