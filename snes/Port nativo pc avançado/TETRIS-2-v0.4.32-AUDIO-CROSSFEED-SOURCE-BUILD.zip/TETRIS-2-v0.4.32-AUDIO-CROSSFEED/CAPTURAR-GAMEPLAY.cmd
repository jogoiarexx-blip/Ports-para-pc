@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "FORJA65_CAPTURE_FRAMES=425,485,1200,1750"
set "FORJA65_CAPTURE_STOP=1"
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_HEADLESS_FRAMES=1750"
set "FORJA65_CAPTURE_DIR=%~dp0validation\capturas-v0415"
set "FORJA65_INPUT_REPLAY=%~dp0validation\input-normal.txt"
if not exist "%FORJA65_INPUT_REPLAY%" (echo Roteiro de controles nao encontrado & exit /b 2)
if exist bin\game.exe (
  pushd bin
  game.exe
  set "RC=!errorlevel!"
  popd
) else if exist game.exe (
  game.exe
  set "RC=!errorlevel!"
) else (
  echo Compile primeiro com BUILD-WINDOWS.cmd
  exit /b 1
)
if not "%RC%"=="0" (echo Falha na captura, codigo %RC% & exit /b %RC%)
for %%F in (425 485 1200 1750) do if not exist "%FORJA65_CAPTURE_DIR%\frame-%%F\preview.ppm" (
  echo Captura ausente: %%F
  exit /b 3
)
echo Capturas geradas em validation\capturas-v0415\frame-N\preview.ppm
echo Consulte RELATORIO-GAMEPLAY-v0.4.15.md para os quadros confirmados.
exit /b 0
