# Tetris 2 — validação independente de áudio

- Build Linux GCC C++20 em modo Debug (`-O0 -g0`): `game` compilado e linkado.
- CMake smoke tests relacionados a áudio: **7/7 PASS**.
- Testes PCM adicionais com Windows/WinMM simulado: **3/3 PASS**, incluindo 48 kHz.
- Runtime headless até **2200 frames**: saída código 0, `runtime_started=PASS`, `dsp_native_samples=1171410`, `nonzero_frames=396951`, `peak=2168` no modo atualizado.
- WAV **32000 Hz estéreo**, aproximadamente 36,6 s.
- Perfil legado com as 3 flags `legacy` completou os mesmos 2200 frames com áudio: sha256 PCM atualizado `50f795fc51405d1d...`, legado `b4f1381ec70ffa20...`; **624385/2342820** amostras individuais diferem. Hash truncado apenas para exibição (não usar como checksum completo).
- O resultado não demonstra qualidade subjetiva superior nem paridade com captura física do S-DSP.
- Testes de execução física Windows e pacote `game.exe` pré-compilado **não disponíveis neste ambiente**; arquivos `BUILD-WINDOWS.cmd` e `GERAR-PORTATIL-WINDOWS.cmd` para executar localmente.
