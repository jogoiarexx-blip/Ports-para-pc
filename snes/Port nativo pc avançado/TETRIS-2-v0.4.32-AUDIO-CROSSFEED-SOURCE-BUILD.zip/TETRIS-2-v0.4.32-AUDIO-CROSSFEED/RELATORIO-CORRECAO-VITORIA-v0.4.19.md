# Tetris 2 v0.4.19 — fechamento inesperado após vitória

**Fonte do erro:** `forja65-runtime-hints(5).txt` e `forja65-crash-trace(5).txt` enviados pelo usuário.

## Causa reproduzível

- `reason=unresolved-flow`, quadro `21973`, instrução `305101208`
- De `$82:937A` (`JMP ($9386,X)`) para `$82:CE65` com X=0 e E0/M0/X0/C0
- A ROM validada SHA256 `70dea29a928c1625def31c862dc74960e39e587e416b45829efc21f13ebd9630` contém o opcode `A9` em `$82:CE65`
- O endereço ainda não tinha entrada no dispatcher C++ original do jogo.
- `$82:9377` contém `PEA $937C`. Quando a rotina retorna via `RTS`, o fluxo segue para `$82:937D`; esse endereço também não estava no dispatcher.

## Alterações

1. Integrado o código recompilado com prova de opcode original para `$82:CE65`, `$82:937D`, `$82:D03E` e `$82:D15E`.
2. Traduzidos e adicionados os 13 destinos do salto indireto em `$82:9386` (índices 0 a 12), sem substituir implementações anteriores.
3. O runtime ganhou compatibilidade com os quadros de retorno C++ mais recentes do Forja65, preservando APIs antigas, e guarda a posição real da pilha para não confundir o `PEA` com retornos de `JSR`.
4. Adicionados `tetris_victory_cfg_smoke` e `tetris_victory_dispatch_smoke` ao CTest e à compilação Windows. O segundo usa todos os objetos reais da CPU traduzida para percorrer o salto, o callback, a continuação e as chamadas subsequentes. Incluído auditor de tabela LoROM no Forja65 e no tooling local.
5. O dispatcher tinha uma lista anterior de retornos autorizados, que não incluía a continuação recém-traduzida `$82:937D`. Foi adicionada somente essa autorização, comprovada pela sequência `PEA $937C; JMP ($9386,X)` na ROM, evitando permitir retornos arbitrários.

## Validação executada

- Prova de ROM dos destinos integrados e auditor de tabela **13/13** com retorno `$82:937D` traduzido.
- Compilação completa do `game` Linux: **PASSOU** (CMake/Ninja, Debug).
- `tetris_victory_cfg_smoke`: **PASSOU** (inclui transferência de APU `$83`, atualização de WRAM, e preservação da pilha no retorno `PEA/RTS`).
- `tetris_victory_dispatch_smoke`: **PASSOU**. Percorre os callbacks traduzidos reais, exige retorno sem fluxo pendente, pilha equilibrada e escrita do comando `$83` à APU. Usa um estado sintético; não representa uma vitória completa.
- CTest selecionado: **6/6** (`runtime_smoke`, `hardware_fixes_smoke`, `dma_native_parity_smoke`, `spc_register_edges_smoke`, `tetris_victory_cfg_smoke`, `tetris_victory_dispatch_smoke`).
- Headless sem controle adicional: **500 quadros, sem erro** após a última alteração do dispatcher.
- Replay com controles solicitado para 2.500 quadros excedeu o limite de execução; **não validado como completo**.
- **Não reproduzida** a vitória integral de 21.973 quadros: não recebemos o replay de entradas que conduziu à vitória, nem um savestate do momento. Esta correção fecha o fluxo específico do log e as rotas traduzidas, mas não é prova de término completo da partida.
- `game.exe` Windows **não compilado aqui**; o usuário ainda precisa rodar `BUILD-WINDOWS.cmd`.

## Como testar no Windows

1. Execute `BUILD-WINDOWS.cmd` (inclui teste `tetris_victory_cfg_smoke`).
2. Execute `VALIDAR-FLUXO-VITORIA.cmd` para validar os dois testes da vitória, inclusive o dispatcher C++ completo.
3. Jogue normalmente via `RUN-WINDOWS.cmd` e vença uma partida. Se surgir novo fluxo não compilado, envie os arquivos de *runtime hints* e *crash trace* recém-gerados.

**Observação:** os testes unitários e a prova de ROM não substituem comparação com referência original do SNES nem uma partida completa.
