@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo FALTA NODE.JS & exit /b 1)
node tests\test-pcm-winmm-crossfeed.js || exit /b 1
echo AUDIO CROSSFEED PASS
pause
