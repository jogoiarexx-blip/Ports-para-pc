# Tetris 2 v0.4.28 — envelope hardware clock

- Contador S-DSP compartilhado de 30.720 ticks entre todas as oito vozes.
- Tabela oficial de períodos e offsets por taxa, em 32-kHz PCM.
- Curva exponencial ADSR/GAIN: diminui 1 antes do deslocamento de 8 bits.
- ADSR attack/decay/sustain, bent-line GAIN com hiddenEnv e KOFF preservados.
- Rollback por `FORJA65_DSP_ENVELOPE=legacy`.
- Script BUILD-WINDOWS.cmd passa a compilar também testes DSP Gaussian e envelope.
- Jogo standalone sem gerador JS; nenhuma parte do Forja foi adicionada.

## Resultados

- 8/8 testes C++ selecionados aprovados.
- Compilação completa do executável Linux aprovada (-O0 para acelerar teste).
- 1.200 frames em replay input-normal, 639.108 amostras estéreo; 283.041 quadros audíveis.
- SHA/WRAM e framebuffer preservados no replay de 1.200 frames.
- 6.000 frames ainda não validados; áudio físico Windows ainda não validado.
