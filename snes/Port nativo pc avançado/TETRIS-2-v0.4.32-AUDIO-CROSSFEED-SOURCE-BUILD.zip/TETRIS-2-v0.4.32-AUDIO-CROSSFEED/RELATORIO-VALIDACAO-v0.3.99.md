# Validação técnica — Tetris 2 v0.3.99

**Base:** Tetris 2 v0.3.98 com regras de OBJ do Forja65 v0.3.97.
**Entrega cruzada:** Forja65 v0.3.98 (novo código de geração e testes do OBJ).

| Verificação | Resultado |
|---|---|
| C++/CMake Linux com `FORJA65_STRICT=ON` | Build completo, target `game`, sucesso |
| Testes CTest do Tetris | 10 aprovados, 1 ignorado, 0 falhas |
| Teste novo sprites 32/34 / OAM | Aprovado |
| AddressSanitizer + UBSan do teste novo | Aprovado |
| Generator QA: hardware-v0397 | Aprovado |
| Generator QA: obj-crossfeed-v0398 | Aprovado |
| Generator QA: obj-limits-v0399 | Aprovado |
| Replay headless 2.000 quadros | Concluído |
| v0.3.97 x v0.3.99, mesmo replay: vídeo | 0 quadros divergentes |
| v0.3.97 x v0.3.99, mesmo replay: WRAM | 0 quadros divergentes |
| v0.3.97 x v0.3.99, mesmo replay: PC | 0 quadros divergentes |

O registro histórico `validation/baseline-normal-12000` dentro do pacote veio da geração inicial e **não** é usado como referência dessa comparação: foi executada uma nova v0.3.97 no mesmo ambiente e com o mesmo trace, guardado em `validation/replay-v0397-normal-2000`.

**Observação:** igualdade com a v0.3.97 não constitui prova de correspondência ao SNES original. O OBJ agora contém testes artificiais que exercitam excedentes e bordas não encontrados necessariamente no replay de 2.000 quadros. CPU/DMA/HDMA/SPC700/DSP não receberam nova alteração funcional nesta iteração. O teste de vetores externos `equivalence_vectors` continua não executado por falta do oracle. Não se testou `game.exe` Windows.

Comandos Linux: `cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_FLAGS_DEBUG="-O0 -g0" -DFORJA65_STRICT=ON && cmake --build build -j4 && ctest --test-dir build --output-on-failure`.
Windows: `BUILD-WINDOWS.cmd`, `TESTAR-HARDWARE.cmd` e `RUN-WINDOWS.cmd`.
