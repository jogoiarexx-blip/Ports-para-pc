@echo off
setlocal
set FORJA65_SPC_TIMING=accurate
call "%~dp0RUN-WINDOWS.cmd"
exit /b %ERRORLEVEL%
