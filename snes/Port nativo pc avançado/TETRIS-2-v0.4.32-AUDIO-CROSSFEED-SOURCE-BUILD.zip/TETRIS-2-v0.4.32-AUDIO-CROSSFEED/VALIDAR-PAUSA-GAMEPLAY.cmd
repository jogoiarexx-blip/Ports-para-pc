@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
set "ROOT=%~dp0"
set "GAME=%ROOT%bin\game.exe"
set "WORK=%ROOT%bin"
if not exist "%GAME%" (
  set "GAME=%ROOT%game.exe"
  set "WORK=%ROOT%"
)
if not exist "!GAME!" (echo ERRO: execute BUILD-WINDOWS.cmd primeiro. & exit /b 2)
set "BASE=%ROOT%validation\qa-v0416"
set "SCHEDULE=1750,1830,1900,2050,2150,2250,2400"
set "FORJA65_HEADLESS=1"
set "FORJA65_UNCAPPED=1"
set "FORJA65_CAPTURE_FRAMES=%SCHEDULE%"
set "FORJA65_CAPTURE_STOP=1"
set "FORJA65_HEADLESS_FRAMES=2400"
set "FORJA65_CAPTURE_FRAME="
for %%C in (control pause) do (
  set "TRACE=%ROOT%validation\input-%%C-v0416.txt"
  if not exist "!TRACE!" (echo Roteiro ausente: !TRACE! & exit /b 3)
  if exist "%BASE%\%%C" rmdir /s /q "%BASE%\%%C"
  set "FORJA65_INPUT_REPLAY=!TRACE!"
  set "FORJA65_CAPTURE_DIR=%BASE%\%%C"
  pushd "!WORK!"
  "!GAME!"
  set "RC=!errorlevel!"
  popd
  if not "!RC!"=="0" (echo ERRO: replay %%C falhou com codigo !RC! & exit /b !RC!)
  for %%F in (1750 1830 1900 2050 2150 2250 2400) do (
    if not exist "%BASE%\%%C\frame-%%F\preview.ppm" (echo Faltou %%C quadro %%F & exit /b 4)
  )
)
set "SCRIPT=%ROOT%tools\gameplay_transition_qa.py"
set "RULES=%ROOT%validation\v0416-pause-qa\pause-rules.json"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%SCRIPT%" --baseline "%BASE%\control" --variant "%BASE%\pause" --rules "%RULES%" --report "%BASE%\resultado.json"
) else (
  where python >nul 2>nul || (echo Python 3 nao encontrado para a comparacao. & exit /b 5)
  python "%SCRIPT%" --baseline "%BASE%\control" --variant "%BASE%\pause" --rules "%RULES%" --report "%BASE%\resultado.json"
)
if errorlevel 1 (echo FALHA: QA visual de pausa/retomada. & exit /b 6)
echo PASSOU: pause congelada e retomada, baseado em capturas reais.
exit /b 0
