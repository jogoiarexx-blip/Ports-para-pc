# Tetris 2 Native PC v0.4.09 — CPU/APU observable port traces

## Escopo

Esta versao **nao ativa nem modifica a temporizacao experimental**. O objetivo e investigar o instante em que a CPU percebe a resposta do SPC700 (o trace v0.4.08 capturava apenas writes). As quatro portas fisicas continuam implementadas como pares de latches independentes, nos dois sentidos.

- Novo `FORJA65_APU_TRACE_READS=changes`: com `FORJA65_APU_IPL_TRACE=1`, escreve no CSV eventos `Q` (leituras observadas pela CPU). So registra a primeira consulta de cada porta ou quando o valor observado muda, preservando contadores brutos de cada consulta.
- `FORJA65_APU_TRACE_READS=all` captura cada leitura (pode atingir o limite de 32768 eventos). Padrao e **desligado**.
- Novas linhas `# cpu_reads=n0,n1,n2,n3` no final de `apu-ports.csv`. Os eventos antigos `C`, `S` e `R` continuam intactos.
- `tools/compare_apu_ports.py` agora compara a subsequencia `Q`, calcula contagem de consultas e informa a primeira diferenca observavel, quando existir.
- `CAPTURAR-SPC-QUADRO-59.cmd` ativa a captura de leituras comprimidas; `TESTAR-HARDWARE.cmd` e `BUILD-WINDOWS.cmd` foram atualizados.
- Novo smoke test C++ `spc_cpu_port_observer_smoke` e regressao `tetris-spc-port-observer-v0409-regression.js` no Forja65.

## Evidencia medida (Linux)

| Item | Estavel | SPC timing experimental |
|---|---:|---:|
| Quadros capturados | 60 (snapshot frame 59) | 60 (snapshot frame 59) |
| Eventos | 19.774 | 11.330 |
| Consultas de CPU à porta 0 | 24.367 | 28.589 |
| Consultas de CPU à porta 1 | 44 | 44 |
| Leituras Q registradas | 4.930 | 2.819 |
| Eventos perdidos | 0 | 0 |

O prefixo comum de **2.819 leituras Q** tem os mesmos pares porta/valor nas duas execucoes. Isso **nao** demonstra equivalencia completa, apenas o prefixo compartilhado; as contagens divergem por causa do ritmo das instrucoes. A ordem/valor dos eventos no prefixo comum tambem coincide.

- Replay normal v0.4.08 x v0.4.09: 500 quadros, arquivos de hash identicos byte a byte (framebuffer, WRAM e PC), SHA-256 `39e82283a865a409ecb28ec8ed22a113211c2eff97503730f2b720b6af4c2b2e`.
- Tetris Linux: compilacao completa aprovada; CTest **21 aprovados, 1 ignorado** (vetores externos ausentes).
- Forja65: **13/13** testes Tetris de regressao com geracao de runtime aprovados.
- Windows: scripts revisados, mas `game.exe` ainda nao foi compilado nem testado no Windows.

## Limites

`Q` permite identificar as transicoes **observadas** pela CPU, mas os tempos no CSV continuam amostrados em limites de instrucao, nao no ciclo exato do barramento. A captura de 60 quadros nao e uma prova de fidelidade ao SPC700 do SNES original. O modo accurate continua opt-in. A sequencia de todas as fases e modos do Tetris 2 nao foi validada.
