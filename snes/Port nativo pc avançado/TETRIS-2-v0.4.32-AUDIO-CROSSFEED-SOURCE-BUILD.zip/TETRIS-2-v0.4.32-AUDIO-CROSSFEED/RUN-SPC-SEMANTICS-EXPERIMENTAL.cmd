@echo off
setlocal
set FORJA65_SPC_SEMANTICS=corrected
call "%~dp0RUN-WINDOWS.cmd"
exit /b %ERRORLEVEL%
