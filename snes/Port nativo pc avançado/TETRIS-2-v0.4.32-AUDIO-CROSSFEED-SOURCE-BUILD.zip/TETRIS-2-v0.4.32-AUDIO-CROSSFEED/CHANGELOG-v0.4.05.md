# Tetris 2 v0.4.05 — SPC700/DSP/BRR

## Corrigido no runtime nativo C++

1. `$F2/$F3` (SPC700): bit 7 do registrador DSPADDR impede escritas em DSPDATA. Leituras permanecem disponíveis pelo endereço de DSP mascarado para 7 bits. O endereço completo é preservado; a sombra de estado do DSP agora reflete o valor efetivamente escrito, inclusive registradores write-to-clear.
2. `DSP FLG $6C`: bit 6 (mute) produz saída PCM silenciosa, sem interromper a progressão de amostras/vozes. Bit 7 (soft reset) desliga vozes na implementação simplificada atual, evitando notas presas. O envelope real de release ainda não está reproduzido ciclo a ciclo.
3. Decodificador BRR: corrigida a transição de blocos de 9 bytes. Quando `blockPos` chega a 16, o cabeçalho END/LOOP é agora processado antes de buscar o bloco seguinte. Antes, um decode de continuação pulava o END na borda do bloco.
4. DSP `ENDX $7C`: registra fim de bloco END, inclusive em loop; limpar por escrita em `$7C`; iniciar uma nota nova (KON) limpa o bit correspondente. A reinicialização de KON também limpa `Voice.header` para não herdar o END da nota anterior.
5. Regressões dedicadas em `tests/apu_dsp_registers_smoke.cpp`, integradas ao CTest e aos comandos `BUILD-WINDOWS.cmd` / `TESTAR-HARDWARE.cmd`.

## Verificado neste ambiente (Linux)

- C++ compilado e teste específico em modo estrito (-Wall -Wextra -Wpedantic -Werror): APROVADO.
- CMake/CTest total: 17 aprovados, 1 ignorado (`equivalence_vectors` sem vetores externos), 0 falhas.
- Forja65: 9 regressões cruzadas passaram; gerou runtime C++ sintético e compilou/executou os casos de SPC/DSP.
- Replay de `validation/input-normal.txt`: 2.000 quadros, mesmo arquivo de hashes (framebuffer, WRAM, PC) da v0.4.04 com entradas equivalentes. Não foi feito teste de equivalência sonora com SPC/DSP original.
- Windows: scripts atualizados, mas não foi compilado um .exe para Windows aqui.

## Pendências importantes

- Timing do SPC700 ainda é simplificado: o passo do interpretador retorna custo fixo e há imprecisões em temporizadores e sincronização CPU-APU.
- O DSP ainda não reproduz ADSR, GAIN, interpolação gaussiana, eco/FIR, BRR clipping e key-off/release em fidelidade de hardware.
- Nenhum trecho deste teste comprova os modos/fases inteiros; o jogo segue como port híbrido em C++ com dependências de hardware virtual.

## Referências

- https://snes.nesdev.org/wiki/S-DSP_registers
- https://snes.nesdev.org/wiki/S-SMP
- https://snes.nesdev.org/wiki/APU_register_table/DSP_global
