@echo off
setlocal
cd /d "%~dp0"
if not exist "bin\game.exe" (
  echo Nao encontrei bin\game.exe. Execute BUILD-WINDOWS.cmd primeiro.
  pause
  exit /b 2
)
set "FORJA65_HEADLESS=1"
set "FORJA65_HEADLESS_FRAMES=2000"
set "FORJA65_PPU_REGISTER_PROFILE=1"
set "FORJA65_FRAME_HASHES=1"
set "FORJA65_INPUT_REPLAY=%~dp0validation\input-normal.txt"
pushd bin
if exist forja65-ppu-register-profile.csv del /q forja65-ppu-register-profile.csv
if exist forja65-frame-hashes.txt del /q forja65-frame-hashes.txt
game.exe
set "RUN_CODE=%ERRORLEVEL%"
popd
if not "%RUN_CODE%"=="0" (
  echo O replay falhou com codigo %RUN_CODE%.
  pause
  exit /b %RUN_CODE%
)
echo.
echo Perfil: bin\forja65-ppu-register-profile.csv
echo Replay: bin\forja65-frame-hashes.txt
pause
exit /b 0
