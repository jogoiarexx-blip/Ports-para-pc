# Tetris 2 v0.4.32 — atualização DSP/PCM independente

Base 0.4.31 preservada. Recebe modos DSP FIR 15-bit/ring correto, noise por relógio de envelope, volume /128 do Forja 0.4.35. Mantém compatibilidade independente por flags =legacy. Recebe modo opt-in para DSP avançar quando PCM está desabilitado do 0.4.34.3. Transporte de PCM atualizado incluindo WinMM 48 kHz opcional (WAV continua 32 kHz). Acrescentados dois testes C++ e launchers opcionais; não é uma mesclagem de projetos. Para reverter o processamento: FORJA65_DSP_ECHO_FIR=legacy, FORJA65_DSP_NOISE_CLOCK=legacy, FORJA65_DSP_VOLUMES=legacy. Sem captura de hardware não é possível atestar PCM bit a bit.

**Build Windows:** os novos testes foram incorporados à lista de targets do `BUILD-WINDOWS.cmd` para que o `ctest` não tente executar binários não compilados.
