# Tetris 2 v0.4.31 — sincronização SPC700/DSP por amostra

Base: Tetris 2 v0.4.30. Projeto independente (sem gerador Forja65).

## Problema corrigido

Antes, `ApuBridge::tickMasterCycles()` consumia todo o orçamento SPC700 do lote recebido e só depois renderizava as amostras DSP desse lote. Assim, uma escrita SPC em $F3 na parte final de um lote podia alterar amostras anteriores ao instante da escrita. O problema dependia do tamanho dos lotes recebidos pelo runtime.

## Implementação

- `tickSpcMasterCycles()` mantém intacto o funcionamento anterior do intérprete/nativo SPC700.
- `tickMasterCycles()` oferece interleaving opcional: divide o orçamento em fatias que terminam no limite da próxima amostra DSP (acumulador fracionário v0.4.30), avança SPC e somente então renderiza a amostra correspondente.
- `FORJA65_APU_DSP_INTERLEAVE=1` habilita o novo algoritmo. Sem essa variável, conserva a ordem da v0.4.30. `RUN-WINDOWS-AUDIO-INTERLEAVED.cmd` facilita o teste no Windows.
- Contador `dspInterleaveSlices` e campos no manifesto SPC permitem auditar o modo de relógio utilizado.
- Mantidos BRR, ADSR/GAIN, Gaussian, KON/KOFF, ENDX, NON, PMON, eco, WAV e configuração do relógio antigo.

## Limitações

O SPC ainda roda por instrução, e as mudanças de estado de uma instrução são observadas ao final dela; isto **não** modela cada microciclo do barramento F2/F3 do SPC700 nem confirma equivalência com o hardware. A opção permanece experimental até comparação com captura de referência. Novas diferenças de áudio PCM são esperadas. O jogo usa um replay de teste e não há validação física do Windows.

## Execução

1. `BUILD-WINDOWS.cmd`
2. `RUN-WINDOWS-AUDIO.cmd` — modo compatível
3. `RUN-WINDOWS-AUDIO-INTERLEAVED.cmd` — modo novo

Para validar no Linux: `cmake -S . -B build && cmake --build build --target game dsp_spc_interleave_v0431_smoke -j3 && ctest --test-dir build -R dsp_spc_interleave_v0431_smoke --output-on-failure`.
