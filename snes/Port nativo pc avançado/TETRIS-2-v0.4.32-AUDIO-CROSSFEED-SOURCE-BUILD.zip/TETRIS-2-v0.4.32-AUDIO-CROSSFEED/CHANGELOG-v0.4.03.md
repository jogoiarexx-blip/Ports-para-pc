# Tetris 2 v0.4.03 — VRAM DMA em branco e latch CGRAM

## Implementado
- `PpuState::writeVramDataFast()`: escrita equivalente a `$2118/$2119`, chamada apenas pelo barramento de DMA/HDMA quando não há pixel ativo a ser composto (VBlank/HBlank/forced blank ou antes do início do frame).
- `SnesRuntime::ppuPortWrite(..., fromDma)`: preserva `observeBus`, contagem de acessos, avanço de DMA/HDMA por byte e registros de endereço; continua usando a rota original durante pixels ativos.
- `syncPpuForWrite(0x2122)`: o primeiro byte altera somente o latch `cgSavedByte`, sem forçar sincronização do raster; o segundo byte continua sincronizado antes de atualizar a paleta.
- Perfil PPU opcional acrescenta `cgram_latch_raster_sync_skips` e `dma_vram_fast_bytes`.
- Teste `dma_vram_batch_smoke` compara 64 cenários de modo DMA/incremento/remapeamento, ciclo da CPU, VRAM e registros, além da paridade raster CGRAM.

## Validação real nesta entrega
- Linux: CMake e compilação completa do executável `game` concluídos (build de QA `-O0 -DNDEBUG`, não representa build otimizado final).
- Tetris CTest: 15 testes aprovados, 1 ignorado por falta de vetores externos.
- Forja65: 7 regressões da família Tetris passaram, inclusive geração de runtime sintético, compilação C++ e execução dos testes.
- Replay determinístico de 2.000 quadros usando `validation/input-normal.txt`: 0 diferenças de framebuffer, WRAM ou PC contra `validation/v0400-hdma/forja65-frame-hashes.txt` (referência anterior).
- Contadores no replay: 3.590.624 bytes DMA de VRAM pela rota rápida; 96.768 sincronizações CGRAM evitadas no primeiro byte; nenhum FPS medido aqui.
- Windows: arquivos `.cmd` e CMake atualizados, porém compilação/execução Windows NÃO foram realizadas neste ambiente.

## Limites e próximo gargalo
- O caminho rápido continua mantendo PPU virtual e DMA byte a byte; não é prova de port 100% nativo.
- Sem prova de equivalência ao SNES real, nem de que todos os modos e fases estejam concluídos.
- Próximo passo: referências SNES para portas PPU sob display ativo, aceleração adicional mantendo ciclo individual e investigação SPC700/DSP.
