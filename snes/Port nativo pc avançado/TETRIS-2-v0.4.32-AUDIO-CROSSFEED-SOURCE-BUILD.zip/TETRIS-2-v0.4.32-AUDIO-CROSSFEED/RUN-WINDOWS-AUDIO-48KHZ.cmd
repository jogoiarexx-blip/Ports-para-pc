@echo off
setlocal
set FORJA65_AUDIO_DEVICE_RATE=48000
call "%~dp0RUN-WINDOWS-AUDIO.cmd"
