# Tetris 2 v0.4.27 — DSP Gaussian

- Interpolação S-DSP de quatro amostras, 512 coeficientes inteiros, truncamento de cada multiplicação, wrapping de 16 bits após os três primeiros termos, saturação de 16 bits e bit inferior limpo.
- Histórico dos três últimos samples decodificados entre os blocos BRR, inclusive blocos END+LOOP; não decodifica dados da RAM prematuramente.
- `FORJA65_DSP_INTERPOLATION=gaussian` é padrão **no jogo**, e `FORJA65_DSP_INTERPOLATION=linear` conserva o modo antigo em caso de incompatibilidade. O objeto DSP instanciado isoladamente começa no modo linear para manter testes legados e compatibilidade de API.
- Preservadas correções do fluxo `$82:BDBA`, eco experimental protegido por `FORJA65_ECHO_RAM_WRITES`, NON, PMON, ADSR/GAIN e WAV em tempo real.
- Não significa áudio SNES idêntico ao hardware: envelopes, temporização, eco e BRR ainda necessitam oráculo externo e comparação PCM real.
- Projeto Tetris permanece sem ferramentas do conversor Forja65.
