# Tetris 2 v0.4.22 — busca guiada por objetivos

## Diagnóstico
A análise da v0.4.21 identificava corretamente os três alvos piscantes, porém confundia grupos conectados em formato L com combinações que desaparecem. O jogo exige **3 ou mais blocos da mesma cor em linha horizontal ou vertical** (manual do SNES, https://www.videogamemanual.com/snes/Tetris%202%20%28USA%29.pdf). Isso foi corrigido.

No tabuleiro inicial, o alvo amarelo (linha 20, coluna 8) possui uma oportunidade de eliminação por linha horizontal: (20, 6), (20, 7), (20, 8), onde falta uma peça amarela na coluna 6. A jogada precisa respeitar a gravidade e a colisão real; a geometria sozinha não prova que um comando será bem-sucedido.

## Melhorias
- `tools/tetris2_target_qa.py`: agora separa conectividade genérica de trincas horizontais/verticais legítimas; fornece oportunidades por alvo e elimina falsos positivos em L.
- `tools/tetris2_strategy_search.py`: gera e executa até oito replays distintos no jogo REAL (sem cheats), coleta WRAM final, ordena resultados por alvos restantes e preserva cada entrada/saída. Tempo elevado: cada execução volta ao título e segue até 2400 quadros.
- `TENTAR-PRIMEIRA-FASE-AUTO.cmd`: automatiza busca de aberturas no Windows após compilar.
- `src/runtime.hpp`: observador opcional `FORJA65_TARGET_PROGRESS_CSV` registra mudanças reais no número de blocos especiais durante o jogo. Não modifica CPU, gráficos, DMA nem áudio.
- `tools/test_tetris2_goal_planner.py`: regressões do analisador, incluindo caso em L que antes podia induzir estratégia errada.

## Segurança e limites
A versão preserva o retorno do dispatcher `$82:937D` em M=0 corrigido na v0.4.20, comprovado no código v0.4.21. **Não declarar a vitória** sem replay com 0 alvos e tela da fase seguinte. O relatório de execução será incorporado aos resultados locais conforme o teste, sem inventar confirmação.

## Resultados reais desta rodada

- Foram executadas oito aberturas até 2.400 quadros. A entrada `validation/v0422-search/red-cleared-replay.txt` (`left_8`) reduziu **3 para 2** blocos piscantes: o alvo vermelho/rosa desapareceu, com azul e amarelo ainda presentes na WRAM. As outras sete aberturas não retiraram alvos nesse horizonte.
- A partir dessa abertura, mais oito variações foram testadas até 3.000 quadros. Seis ainda mantiveram 2 alvos. Em duas (`straight` e `rotate_B`), a captura visual confirmou **TRY AGAIN?** (derrota), e a WRAM deixou de conter um tabuleiro reconhecível. Portanto, o contador bruto zero NÃO É vitória. O analisador agora exige tabuleiro plausível e a ferramenta distingue `board_looks_active`; a vitória segue NÃO CONFIRMADA.
- Capturas de referência em `validation/v0422-search/cleared-red.png` e `try-again.png`, acompanhadas das capturas de RAM e relatórios de oito tentativas cada.
- Teste C++ autônomo do observador CSV (início com três alvos e remoção de um): aprovado. O header de runtime compilou com o main C++ em verificação de sintaxe. Os algoritmos de CPU/PPU/DMA/áudio não foram alterados; recompile o jogo inteiro no Windows com `BUILD-WINDOWS.cmd` para ativar o monitor novo.

## Próximo objetivo
Reduzir a pilha de peças e planejar a segunda jogada sem segurar a descida por centenas de quadros; confirmar nova eliminação e transição visual de fase.
