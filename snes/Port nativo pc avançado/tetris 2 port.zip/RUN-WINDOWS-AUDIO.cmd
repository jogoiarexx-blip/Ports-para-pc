@echo off
setlocal
cd /d "%~dp0"
set "FORJA65_AUDIO_MODE=native"
set "FORJA65_AUDIO_GAIN=100"
rem Normal gameplay with 32kHz Windows waveOut output. No WAV recording.
call RUN-WINDOWS.cmd
if exist "forja65-audio-report.txt" type "forja65-audio-report.txt"
if exist "bin\forja65-audio-report.txt" type "bin\forja65-audio-report.txt"
exit /b %ERRORLEVEL%
