@echo off
setlocal
cd /d "%~dp0"
set FORJA65_DSP_KEYS=legacy
call RUN-WINDOWS-AUDIO.cmd
exit /b %ERRORLEVEL%
