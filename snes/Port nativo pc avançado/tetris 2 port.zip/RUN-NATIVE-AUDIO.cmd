@echo off
setlocal
cd /d "%~dp0"
rem Offline test: ~10 seconds of intro may be silent; 2200 frames reaches gameplay audio.
set "FORJA65_AUDIO_MODE=native"
set "FORJA65_AUDIO_DUMP=1"
set "FORJA65_AUDIO_GAIN=100"
set "FORJA65_HEADLESS=1"
set "FORJA65_HEADLESS_FRAMES=%~1"
if "%FORJA65_HEADLESS_FRAMES%"=="" set "FORJA65_HEADLESS_FRAMES=2200"
call RUN-WINDOWS.cmd
if exist "forja65-audio-report.txt" type "forja65-audio-report.txt"
if exist "bin\forja65-audio-report.txt" type "bin\forja65-audio-report.txt"
echo Consulte forja65-native-audio.wav e forja65-audio-report.txt (na pasta bin se houver).
pause
