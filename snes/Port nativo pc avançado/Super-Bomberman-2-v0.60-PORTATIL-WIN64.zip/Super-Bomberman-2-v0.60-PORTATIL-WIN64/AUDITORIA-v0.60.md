# Bomberman v0.60 — correções e auditoria

CPU 65C816 e SPC700 executaram por código C++ compilado nas rotas verificadas abaixo. A produção não liga o interpretador da CPU. O SPC700 usa operações fixas por PC/opcode, operandos vivos e falha explícita em código não compilado.

## Execução reproduzida: antes e depois

| Rota | Password | Quadros | CPU interpretada v0.59 | CPU interpretada v0.60 | Fallback SPC700 v0.60 |
|---|---|---:|---:|---:|---:|
| 1-1 | 4361 | 6000 | 0 | 0 | 0 |
| 2-1 | 6442 | 6000 | 0 | 0 | 0 |
| 3-1 | 3903 | 6000 | 0 | 0 | 0 |
| 4-1 | 9564 | 6000 | 90597 | 0 | 0 |
| 5-1 | 7735 | 6000 | 775413 | 0 | 0 |
| 1-7 | 1753 | 6000 | 0 | 0 | 0 |
| 2-7 | 2764 | 6000 | 84136 | 0 | 0 |
| 3-7 | 3764 | 6000 | 59948 | 0 | 0 |
| 4-7 | 4764 | 6000 | 51246 | 0 | 0 |
| 5-7 | 5764 | 6000 | 225025 | 0 | 0 |
| original-24000 | gravação original | 24000 | 765496 | 0 | 0 |

Todos terminaram com saída 0. Contagem de instruções, NMI/IRQ, hash da WRAM inteira e hash final do framebuffer são idênticos à referência; os dez acessos também coincidem com os relatórios v0.59. Os 24.000 quadros reproduzem 310.490.628 instruções, 23.916 NMI, framebuffer c3a7c4512024a329 e WRAM 9d0b185975f72f23.

O backend SPC700 compilado não chama o interpretador ou o preditor genérico de opcodes. O runtime ainda contém um decoder genérico dormente; a produção instala o hook compilado. O perfil de treinamento usa interpretação de referência e seu contador de hook não foi usado como prova nativa.

## Testes e áudio

- CTest: 76 passaram; 1 vetor externo opcional ignorado (77 cadastrados).
- CPU: 4345 especializações em 43 unidades; semântica, periféricos, estados, espelhos e retornos comparados à implementação anterior.
- SPC700: 2270 pares observados; testes em todos os endereços compilados, operandos vivos, temporizadores, DSP, PCM e código desconhecido.
- Geração reproduzível com baseline imutável, identidade de ROM, guardas de bytes/ABI e perfis de execução arquivados.

WAVs completos de 6.000 quadros byte a byte iguais à referência:

| Rota | SHA256 do WAV |
|---|---|
| 1-1 | `94b02815a0b532f5cdc9b2b9ab2ac256b30a59c13c8b6e270e40669ed559ea7d` |
| 5-7 | `5582d43fdcf4bdb06bc628cb013f0cee245ce9845d17fcf58f874b040b980127` |

## Correção da continuação da CPU

CC1DF3 precisava da variante M0 após uma chamada interna que muda a largura do acumulador. A falha foi reproduzida em teste antes da correção. O perfil de todas as instruções realmente executadas pelo fallback complementou as sementes de entrada de bloco. Os novos espelhos físicos e os retornos para novos rótulos compilados também receberam regressões.

## Passwords e atalhos preservados

| Código | Fase | Preset inicial |
|---|---|---|
| 1753 | 1-7 | Preset anterior |
| 2764 | 2-7 | 6 vidas, fogo 4, 3 bombas, 2 corações extras finitos e chute |
| 3764 | 3-7 | Mesmo preset de 2764 |
| 4764 | 4-7 | Mesmo preset de 2764 |
| 5764 | 5-7 | Mesmo preset de 2764 |

Os 11 códigos originais, o atalho 2-1 e os demais atalhos continuam disponíveis. Os presets especiais são aplicados uma vez; dano e consumo seguem as regras normais. Esses passwords são próprios deste port.

## Forja, limites e pendências

O Forja REV216 entrega as ferramentas para o ABI legado, os perfis observados e a procedência. O catálogo histórico passou de 620 para 746 estados de entrada; os perfis de instruções e continuações ficam identificados separadamente. As notas históricas da REV215 foram mantidas: maior cobertura AOT não certifica fidelidade de hardware. O runtime moderno do Forja não foi transplantado silenciosamente para o ABI legado do jogo.

Os replays testam acesso e execução pelos caminhos exercitados. Não certificam que todas as fases e chefes foram concluídos, nem que todos os caminhos da campanha foram visitados. PPU, DMA/HDMA e leituras de ROM ainda usam o runtime SNES descrito nos relatórios de dependências. Não há certificação global de jogo 100% convertido para lógica independente de hardware virtual.

O EXE Windows foi compilado do mesmo fonte e validado como PE64 com DLLs do sistema. A execução foi testada no Linux; o EXE não foi executado no Windows nesta rodada. Os executáveis de referência e testes não entram no portátil.

## Reprodução e pacotes

Fonte, Forja e portátil são arquivos separados. Consulte os READMEs das ferramentas de geração e BUILD-PORTATIL-v0.60.ps1. Evidências, entradas de geração e resultados estão em reports/v0.60 e reports/v0.60-spc no fonte.

EXE SHA256: `63e35011665d63fffddfd1bb3d640ca62ae7eeb3d4b1979cede7729486d2e914`. DLLs: GDI32.dll, KERNEL32.dll, msvcrt.dll, USER32.dll, WINMM.dll, XINPUT9_1_0.dll.


## Notas de engenharia por subsistema

Referência histórica mantida, sem nova recertificação de fidelidade. A evolução medida nesta entrega está na tabela de execução acima.

| Subsistema | REV215 | REV216 |
|---|---:|---:|
| CPU 65C816 | 7,7 | 7,7 |
| PPU | 7,4 | 7,4 |
| DMA | 7,8 | 7,8 |
| HDMA | 7,4 | 7,4 |
| WRAM | 6,2 | 6,2 |
| VRAM | 8,0 | 8,0 |
| OAM | 7,5 | 7,5 |
| CGRAM | 7,5 | 7,5 |
| SPC700 | 6,8 | 6,8 |
| DSP | 7,0 | 7,0 |
| SA-1 | 6,0 | 6,0 |
| SRAM | 7,2 | 7,2 |
| Timing | 6,8 | 6,8 |
| CFG/AOT | 8,0 | 8,0 |
| AUTOPORTE | 8,6 | 8,6 |
