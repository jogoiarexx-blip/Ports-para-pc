# OpenBOR Native Builder v0.27.0

Conversor/portador genérico em C++ para projetos OpenBOR. Aceita pasta, ZIP, PAK ou um ZIP completo do OpenBOR contendo `Paks/*.pak`, localiza o jogo, preserva os assets, gera dados/C++ e cria um runtime nativo próprio. Não há correções hardcoded por jogo.

## Fluxo

```text
PASTA / ZIP / PAK OPENBOR
  -> detecção/extração segura
  -> ProjectScanner + CompatibilityAnalyzer
  -> parsers de models/levels/scripts/assets
  -> geração de runtime C++
  -> build nativo
  -> test
  -> pacote portátil
```

`CONVERT SUCCESS`, `NATIVE BUILD SUCCESS` e `GAME COMPATIBILITY` são resultados diferentes. Um executável compilado não implica paridade total de gameplay.

## CLI

```text
openbor-native-builder analyze <pasta|jogo.zip|jogo.pak> [saida]
openbor-native-builder convert <pasta|jogo.zip|jogo.pak> [saida]
openbor-native-builder build <pasta|jogo.zip|jogo.pak> <saida>
openbor-native-builder scan <pasta|jogo.zip|jogo.pak>
openbor-native-builder audit <pasta|jogo.zip|jogo.pak>
openbor-native-builder repair <pasta|jogo.zip|jogo.pak> <saida>
openbor-native-builder test <port>
openbor-native-builder package <port>
```

No Windows, abrir o Builder sem argumentos permite escolher pasta, ZIP ou PAK. O script `BUILD-PORTABLE-WINDOWS.cmd` procura CMake no PATH, Visual Studio/Build Tools, `C:\Program Files\CMake` e `tools/cmake/bin`.

## Destaques da v0.27

- `scene`/`animation` passam a gerar cutscenes nativas temporizadas antes das fases.
- `bossmusic` troca a música no boss e restaura a música da fase quando ele termina.
- `water`, sombras e `diesound` entram no runtime.
- `lifespan`, `landframe`, `offscreenkill`, `nopain`, `nodrop` e HUD `nolife` ganham comportamento nativo.
- `defense` reduz dano/knockdown por tipo de ataque.
- `blast`/`burn` participam da seleção de animações de reação.
- Todo o sistema de comandos/combos/IA/armas da v0.26 continua incluído.
- `modelflag no_basic` impede que weapon-model herde animações básicas ausentes do personagem base; flags `no_weapon/no_script` são preservadas para compatibilidade/análise.
- Child follow/recall por eixo, offsets de recall, animação de recall e ajuste de direção (`same/opposite/left/right/away/toward`).
- IA sem arma pode procurar e coletar um item-arma compatível com sua lista `weapons`.
- Mantidos weapon loss/drop, `shootnum`, `typeshot`, `summonframe/unsummonframe`, branch, palettes/remaps, ScriptVM, blocking, desenho por script, multiplayer local e entrada ZIP/PAK das versões anteriores.

## Compatibilidade atual

O Builder já é funcional como conversor, mas não é uma reimplementação 100% completa do OpenBOR. Continuam `PARTIAL`, entre outros:

- layouts históricos raros de `combostyle 1`/command buffer;
- model-copy completo para `modelflag no_weapon/no_script` e todos os campos legados;
- bind avançado independente do sistema parent/child e algumas APIs modernas de child;
- alguns estilos históricos de IA, armas e comportamento de drop;
- subscreens, blending/drawmethod e efeitos de layer especializados;
- casos históricos de palette indexada/remap e UIs/cutscenes específicas;
- OGG/OGA sem decoder do sistema: no Windows ainda é tentado via Media Foundation. Um decoder Vorbis realmente embutido continua pendente.

## Build portátil no Windows

**Atalho recomendado:** execute `GERAR-PORTATIL-WINDOWS.cmd` para preparar as ferramentas e compilar em uma unica etapa.

1. Extraia o projeto.
2. Se necessário, execute `INSTALAR-FERRAMENTAS-WINDOWS.cmd`. O instalador primeiro detecta CMake/MSVC e só instala o que estiver faltando; ele não trata "nenhuma atualização disponível" como erro.
3. Opcionalmente execute `VERIFICAR-FERRAMENTAS-WINDOWS.cmd` para confirmar CMake + workload C++.
4. Execute `BUILD-PORTABLE-WINDOWS.cmd`.
5. O Builder portátil será criado em `dist-portable`.

Depois de compilado, o Builder/port gerado não precisa do OpenBOR original para executar o runtime convertido.
