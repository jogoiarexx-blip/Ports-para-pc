# Changelog

## v0.27.0 — Cutscene, Effects & Legacy Gameplay Parity

- `scene`/`animation` entries in `levels.txt` now become timed native cutscene stages; frame/delay sequences are parsed from cutscene text files and auto-advance into gameplay.
- `bossmusic` starts when the first boss spawns and normal stage music is restored after all bosses are defeated.
- `water` stage metadata produces a native water overlay (exact translucency/palette behavior remains partial).
- `shadow` renders a basic ground shadow for native entities/player.
- `diesound` file metadata plays on entity death.
- `lifespan`, `offscreenkill` and `landframe` now affect entity lifecycle/landing.
- `defense` applies per-attack-type damage and knockdown factors to player/coop/enemies.
- `nopain`, `nodrop`, `nolife`, `nodieblink` and `noquake` are preserved with native runtime paths where applicable.
- `blast`/`burn` reaction metadata now participates in knockdown reaction animation selection.
- Regression fixture added for cutscene + bossmusic + water + shadow/diesound/lifespan/landframe/defense.
- Builder CTest and generated-runtime smoke tests pass with exit code 0.

## v0.26.1 — Compatibility Report & Legacy Command Fix

- Inline `@script ... @end_script` bodies are no longer misclassified as model commands.
- `@cmd` is recognized as inline OpenBORScript instead of UNKNOWN.
- Scene `animation` and `scene` entries are recognized as cutscene metadata.
- Known legacy OpenBOR commands now report PARTIAL instead of UNKNOWN until their exact runtime behavior is implemented.
- Keeps the v0.26 MSVC portability fixes (parser nesting and runtime-template string splitting).

### Toolchain hotfix (Windows)
- Corrigido instalador que tratava `winget` sem atualizacao do CMake como falha.
- CMake existente agora e detectado antes de chamar `winget`.
- Corrigida deteccao do CMake embutido no Visual Studio 2022 Build Tools em `Program Files`.
- Se Visual Studio/Build Tools existir sem workload C++, o instalador usa o Visual Studio Installer para adicionar `Desktop development with C++`.
- Adicionado `VERIFICAR-FERRAMENTAS-WINDOWS.cmd` para diagnosticar CMake e MSVC antes do build.


## v0.26.0 — Dynamic Commands, Combo Branches, Child & AI

- `com/cmd`: histórico ampliado para 128 ticks com press/release, hold min/max, hold-trigger, chord grace e sequence grace.
- `cancel`: passa a usar o mesmo matcher temporal do sistema de comandos.
- `combostyle 1`: zeros do `atchain` são preservados como separadores e o runtime escolhe o ramo por `range`, `rangez` e `rangea`.
- Ranges de animação são preservados no código C++ gerado.
- Child follow/recall por eixo, offsets de recall, animação configurável e ajuste de direção.
- `modelflag no_basic` entra no overlay de weapon-model; `onmodelcopy` é tratado como hook runtime.
- IA pode procurar e coletar itens-arma compatíveis.
- Mantidos `weaploss`, drop counter, `shootnum`, `typeshot`, summon/unsummon, combo/counter/cancel, ScriptVM, palettes e entrada ZIP/PAK das versões anteriores.
- OGG/Vorbis embutido independente continua pendente e permanece explicitamente `PARTIAL`.

## v0.25.0 — Commands, Weapon Loss & Child Lifecycle

- `com/cmd` com histórico por jogador e comandos básicos de direção/botão/chord/release.
- Weapon-model fornece a lista de comandos ativa.
- `weaploss`, `weapon_loss_condition`, drop counter, `typeshot`/`shootnum` e item físico de arma no chão.
- `unsummonframe`, `summonkill`, follow/recall básico e vínculo pai-filho estável.
- Bridge adicional para IA legada chase/biker/arrow.

## v0.24.0 — Combos, counters, weapon-model e child-spawn

- `atchain`, `combodelay` e `combostyle` alimentam a cadeia nativa de ataques; estilo livre (`combostyle 2`) e sequência estática são executados no runtime.
- `followanim`/`followcond` redirecionam o atacante para `followN` a partir do resultado do golpe.
- `counterrange`/`counterframe` entram na resolução de combate com janela de frames, condição, direção/unblockable básica e opção de receber ou não o dano.
- `cancel` usa janela de frames, requisito de hits e inputs comuns para trocar para a animação alvo.
- `weapons`, `weapnum`, `shootnum`, `reload` e `weaponframe` possuem estado nativo e independente por jogador local.
- `subentity`, `custentity`, `spawnframe` e `summonframe` geram entidades-filhas nativas.

## v0.23.0 — Combate, IA, armas e projéteis

- Parser/runtime passaram a consumir `aggression`, `aiattack` e `aimove`; os modos comuns de perseguição, evitar, wander, no-move, ataques long/melee/noattack/always e dodge influenciam a IA nativa.
- `candamage`, `hostile` e `projectilehit` entram na filtragem de alvos de ataques e projéteis, com fallback para a regra legada quando o modelo não define máscara.
- Combos do player e coop descobrem `attackN` além de `attack3`; `attack4+` deixa de ficar apenas preservado como animação.
- `ondoattackscript` é disparado quando player, coop, inimigo ou `performattack()` inicia um ataque; `performattack()` passa a iniciar estado/cooldown/hit real em vez de trocar somente a animação.
- Grabs respeitam `nograb/cantgrab`, `grabforce` e resistência; arremessos consomem `throwdamage`, `throwdist` e `throwheight`.
- Projéteis consomem `subject_to_gravity`, `bounce` e `bouncefactor`, incluindo quique no chão e término/explosão ao esgotar os bounces.
- Armas/projéteis no coop ganharam estado por jogador: P2-P4 mantêm item equipado e estado de disparo próprios, sem reutilizar o estado global de P1.
- Novas constantes OpenBOR de `TYPE_*`, `AIMOVE*` e `AIATTACK*` foram mapeadas para scripts e para a lógica nativa de combate/IA.
- Regressão ampliada com fixture específico de IA/combate/attack4, filtros de facção, gravidade/bounce, `performattack`, `ondoattack` e isolamento de arma no coop.
- Entrada universal pasta/ZIP/PAK e todas as correções das versões anteriores foram preservadas.
- Runtime gerado não confunde flags CLI como `--headless` com a pasta raiz do port; persistência de `graphics.ini` continua apontando para a pasta do executável.

## v0.22.0 — Blocking, desenho por script e propriedades modernas

- Runtime ganhou bloqueio/guard nativo usando `blockodds`, `blockpain`, `thold`/`blockthreshold`, `guardpoints`, `guardrate`, `blockback`, guard cost, penetração, direção e contexto de `didblockscript`.
- Player, coop e inimigos podem bloquear durante a resolução real do ataque; `didhitscript` do atacante recebe informação de golpe bloqueado.
- `onblockwscript`, `onblockzscript`, `onblocksscript` e `onblockoscript` foram ligados a limites e obstáculos básicos; variantes A/Y/P continuam registradas como compatibilidade parcial.
- Parser/geração de ataque ganhou fall force, penetration, guard cost, juggle cost, pause time e tag.
- ScriptVM/host ganhou acesso moderno a propriedades de entidade/modelo/fase e novas constantes `ENTITY_PROPERTY_*`, `MODEL_PROPERTY_*`, `LEVEL_PROPERTY_*` e `BLOCK_STATE_*`.
- Fila de desenho por script implementada com `drawdot`, `drawline`, `drawbox`, `drawstring`, `drawsprite`, `loadsprite`/`freesprite`, `getgfxproperty` e `rgbcolor`; comandos são ordenados por `z` antes da apresentação.
- Scripts globais `update.c` e `updated.c` passam a executar no gameplay.
- `onkillscript` é disparado quando a entidade é efetivamente removida, separado do evento de morte; comando legado `script` funciona como alias de `updatescript`.
- Regressão ampliada para blocking/guard, hooks de bloqueio, APIs de desenho e propriedades modernas.
- Entrada universal pasta/ZIP/PAK e toda a compatibilidade de ScriptVM da v0.21 foram preservadas.
- OGG independente do codec do Windows **ainda não foi embutido**; essa limitação permanece explicitamente reportada.

## v0.21.0 — OpenBORScript, hooks e entidades estáveis

- Runtime passou a manter entidades em armazenamento com endereços estáveis, evitando invalidar handles usados por `self`, `getentity()` e scripts quando novos spawns são adicionados.
- ScriptVM/host ampliado com `getentity`, `getentityproperty`, `changeentityproperty`, `findtarget`, `checkrange`, entity vars, player properties, `openborconstant`, `setidle` e `updateframe`.
- Spawn por script ganhou `clearspawnentry`, `setspawnentry`, `spawn`/`spawnentity`; `spawnscript` é preservado e executado com contexto do spawn.
- `playerkeys()` passou a refletir estados held/new/released do teclado/XInput; `keyscript`, `key1.c`...`key4.c` e `keyall.c` são disparados no runtime, com `playkeys`/`disablekeys` integrados ao input nativo.
- Contextos de ScriptVM separados por jogador cooperativo, incluindo `self`, `player`, estados de tecla e velocidades impostas por script.
- `onmovexscript`, `onmovezscript` e `onentitycollision` passam a ser invocados pelo runtime; colisão avançada permanece parcial.
- Contexto dos hooks de combate foi ampliado: `takedamagescript`/`didhitscript` e reações subsequentes recebem atacante/alvo, dano, tipo de ataque, drop e campos auxiliares de bloqueio/juggle.
- `getentityproperty` cobre propriedades legadas comuns como `animpos`, `animationID`, `xdir`, `zdir`, `tossv`, vida, posição, direção, mapa e estado de ataque.
- Regressão nova cobre hooks de tecla/movimento/colisão/spawn/combate, APIs de entidade e estabilidade de handles.
- `BUILD-PORTABLE-WINDOWS.ps1` procura CMake portátil em `tools/cmake/bin` antes dos locais do sistema.
- Workflow `.github/workflows/build-portable-win64.yml` incluído para CTest e teste end-to-end do port em Windows x64.
- Toda a entrada universal ZIP/PAK, branch, palettes, áudio e combate numérico da v0.20 foi mantida.

## v0.20.0 — Paridade de campanha, scripts, áudio, palettes e combate

- `levels.txt` `branch <name>` agora é tratado como destino de campanha para o próximo `file`, em vez de ser confundido com evento interno da fase.
- `jumptobranch(name, immediate)` resolve esses destinos no runtime; salto imediato é aplicado num ponto seguro do frame e salto não imediato entra quando a fase termina.
- `openborvariant("current_branch")` e `openborvariant("current_level")` foram adicionados ao ScriptVM.
- Alterações de `z`/altura do background entre arquivos do mesmo set são preservadas por fase.
- Pré-processador do ScriptVM ganhou macros `#define NAME(args)` com expansão de macros objeto/função e limite contra recursão infinita.
- Windows: MP3/FLAC são decodificados por Media Foundation; OGG/OGA/AAC/M4A são tentados quando o codec está disponível no sistema; XAudio2 continua sendo o backend de reprodução.
- `palette`, `alternatepal`, `remap` e `map/colormap` entram no runtime: referências por imagem e arquivos Adobe/OpenBOR `.act` geram remapeamento de cor por entidade/player.
- Jogadores cooperativos usam mapas alternativos automaticamente quando disponíveis; spawns usam o `map/colormap` definido pelo jogo.
- Tipos numerados de ataque podem selecionar `painN`, `fallN` e `riseN`, com fallback para as animações genéricas.
- Entrada universal da v0.19 (pasta/ZIP/PAK/ZIP completo do OpenBOR com `Paks/*.pak`) e todas as proteções de caminho foram mantidas.
- Regressão ampliada para branch de campanha, `z` por arquivo, macros de função, palette/remap e geração dos novos backends.

## v0.19.0

- Novo `InputResolver`: pasta, ZIP e PAK usam o mesmo pipeline de análise/conversão.
- ZIPs aninhados têm a raiz OpenBOR `data/` detectada automaticamente.
- ZIPs completos do OpenBOR com `Paks/*.pak` são aceitos; o Builder extrai PAKs internamente e seleciona o melhor projeto detectado.
- Extrator PAK nativo com validação de assinatura `PACK`, índice, offsets/tamanhos, limites defensivos e proteção contra traversal.
- Workspace temporário RAII: extrações não alteram a origem e são limpas automaticamente.
- GUI Windows ganhou seletor de ZIP/PAK além do seletor de pasta.
- `bglayer`/`fglayer` corrigidos para ratios float, ordem correta de profundidade, offsets, spacing/repeat e renderização básica de múltiplas camadas.
- `levelscript` é parseado/gerado e executado na entrada da fase; APIs ainda não mapeadas continuam diagnosticadas como PARTIAL.
- `scrollspeed` passou a influenciar o avanço da câmera no runtime.
- Builder procura CMake no PATH, em `tools/cmake/bin` e instalações comuns do Visual Studio/CMake.
- Scripts Windows atualizados com diagnóstico de CMake/MSVC e instalador auxiliar via winget.
- Regressão ampliada com ZIP aninhado, PAK direto e ZIP estilo distribuição OpenBOR contendo `Paks/TestGame.pak`.
- Teste end-to-end validado: OpenBOR ZIP -> extração PAK -> análise -> conversão -> compilação do runtime -> pacote portátil -> smoke test headless.

## v0.18.0

- ScriptVM ampliado com `switch/case/default`, `do/while`, operador ternário, operadores bitwise/shift compostos e pré-processamento básico (`#define`, `#include`, `#import`, condicionais simples).
- Includes/imports passam por normalização e validação de caminho; macros de função continuam explicitamente diagnosticadas.
- Analisador de compatibilidade reconhece a sintaxe nova e funções declaradas em arquivos incluídos/importados.
- `animationscript` passa a rodar na entrada de frame, e não a cada tick; contexto recebe o índice do frame.
- `flipframe` é parseado, emitido no C++ gerado e aplicado por player, entidades, coop e projéteis.
- `wait`, `group` e `blockade` ganharam semântica de runtime mais próxima do OpenBOR; `group min/max` controla reposição e `blockade` cria piso de backtracking.
- Áudio passou a aceitar múltiplos efeitos simultâneos, loop/speed/gain por efeito e APIs de script para música/samples.
- Decoder WAV ampliado para PCM 8/16/24/32-bit e IEEE float32.
- OGG/MP3/FLAC continuam preservados e diagnosticados até a inclusão de decoders nativos.
- Fixtures/regressão ampliados para `flipframe`, `switch`, `do/while`, ternário e `#include`.

## v0.17.0

- `models.txt` virou registro autoritativo dos modelos; aliases externos e nomes internos agora são preservados separadamente.
- Runtime procura modelos por alias de registro e também por nome interno, eliminando spawns sem modelo quando `load X` e `name Y` diferem.
- `PortGenerator` grava `openbor-video.ini`; GUI e CLI passam a gerar a mesma resolução lógica.
- Runtime gerado usa a pasta do executável como raiz por padrão no Windows, removendo dependência do current working directory.
- `ProjectScanner` reconhece ports em `assets/openbor-data`; `test <port>` agora valida ports reais.
- `build` chama CMake e produz o executável nativo do port; `package` cria pacote ZIP portátil.
- CMake/CTest agora inclui `tests/regression.cpp` oficialmente.
- Testes falsos (`|| true` e traversal só por string) foram substituídos por verificações reais.
- Adicionado `SafePath` para normalização, contenção em `data/` e rejeição de traversal/caminhos absolutos.
- Cópia de assets ignora symlinks para impedir escapes da origem.
- `StageInstruction` preserva a ordem original entre spawns e eventos, incluindo `branch`, enquanto as tabelas ordenadas por `at` permanecem disponíveis para o runtime atual.
- Workflow Windows executa regressão + conversão/build/test/package end-to-end de um fixture.
- Versões/documentação/artifacts foram alinhados em 0.17.0.

## v0.16.0

- Registro central de comandos OpenBOR com parser/runtime separados.
- Resolução lógica detectada em `video.txt`.
- Spawns estáveis por `at` + id e correções de câmera/trigger.
- Eventos básicos de fase consumidos uma vez.
- Compatibilidade desconhecida registrada sem abortar conversão.
- Multiplayer local, remap de controles, HUD e save de grupo.

## v0.27.0 — Dynamic Commands, Combo Branches e Child/AI
- Matcher `com/cmd` com hold min/max, hold-trigger, release, chord grace e sequence grace.
- `combostyle 1` com seleção dinâmica de ramo por `range/rangez/rangea`.
- Follow/recall de filhos por eixo, offsets, animação e direção.
- `modelflag no_basic` no overlay de arma e `onmodelcopy` reconhecido como caminho runtime.
- IA procura/coleta armas compatíveis.
- OGG embutido permanece pendente; sem falsa marcação de compatibilidade completa.
