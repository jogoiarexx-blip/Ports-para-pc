#include "GameplayGenerator.hpp"
#include <fstream>
#include <iomanip>
#include <cctype>
#include <sstream>

namespace {
std::string esc(const std::string& s){ std::string o; for(char c:s){ if(c=='\\'||c=='\"') o+='\\'; o+=c; } return o; }
std::string floatLit(float v){ std::ostringstream ss; ss<<std::fixed<<std::setprecision(3)<<v; std::string out=ss.str(); while(out.size()>2&&out.back()=='0')out.pop_back(); if(!out.empty()&&out.back()=='.')out+='0'; return out+"f"; }
}

void GameplayGenerator::generate(const std::vector<CharacterDef>& chars, const std::filesystem::path& outDir) {
    auto gen=outDir/"runtime"/"generated"; std::filesystem::create_directories(gen);
    std::ofstream h(gen/"GeneratedCharacters.hpp");
    h << R"CPP(#pragma once
#include <cstddef>
namespace generated {
struct Box { int x,y,w,h; };
struct AttackBox { int x,y,w,h,damage,type,fallForce,penetration,guardCost,juggleCost,pauseTime,tag; };
struct PaletteRemap { const char* source; const char* target; };
struct Defense { int attackType; float damageFactor; float knockdownFactor; int pain; };
struct Command { const char* sequence; const char* targetAnimation; };
struct Cancel { int startFrame,endFrame,hits; const char* command; const char* targetAnimation; };
struct DrawMethod { bool enabled; float scaleX,scaleY; bool flipX,flipY; float shiftX; int alphaMode,remap,fillColor,rotate; bool flipRotate; };
struct Frame { const char* sprite; int delay; int offsetX; int offsetY; bool hasBBox; Box bbox; bool hasAttack; AttackBox attack; bool knockdown; int dropVx; int dropVy; int pauseTime; const char* sound; float moveX,moveZ,moveA; DrawMethod draw; };
struct Animation {
  const char* name; const Frame* frames; std::size_t frameCount;
  bool loop; int loopStart; int loopEnd; int flipFrame;
  int jumpFrame; float jumpVelocityY,jumpVelocityX,jumpVelocityZ;
  int throwFrame,tossFrame,projectileOffsetY; float projectileVelocityX,projectileVelocityY,projectileVelocityZ;
  const char* custKnife; const char* custBomb; int weaponFrame; int weaponIndex;
  int followAnim; int followCond; int counterStart; int counterEnd; int counterCond; bool counterTakesDamage;
  bool hasRangeX; float rangeXMin,rangeXMax; bool hasRangeZ; float rangeZMin,rangeZMax; bool hasRangeA; float rangeAMin,rangeAMax;
  const Cancel* cancels; std::size_t cancelCount;
  const char* custEntity; int spawnFrame; float spawnOffsetX,spawnOffsetZ,spawnOffsetA; bool spawnScreenRelative; bool summonFrame; int unsummonFrame;
};
struct Character {
  const char* modelName; const char* name; const char* type; const char* subtype; int health; float speed; float runSpeed; int jumpHeight; int jumpMoveX; int jumpMoveZ;
  int jugglePoints; int grabDistance; int blockOdds; int blockPain; int blockThreshold; int guardPoints; int guardRate; bool blockBack;
  const int* attackChain; std::size_t attackChainCount; int comboStyle; int comboDelay; const char* subEntityModel; int weaponNumber; int shootNum; int reloadAmount;
  const Command* commands; std::size_t commandCount; bool weaponLossDefined; int weaponLossFlag; int weaponLossIndex; int weaponDropCounter; bool typeShot; bool animalWeapon; int summonKill; float childFollowOffsetX,childFollowOffsetY,childFollowOffsetZ,childFollowRange,childRecallRange;
  float childFollowRangeXMin,childFollowRangeXMax,childFollowRangeYMin,childFollowRangeYMax,childFollowRangeZMin,childFollowRangeZMax;
  float childRecallRangeXMin,childRecallRangeXMax,childRecallRangeYMin,childRecallRangeYMax,childRecallRangeZMin,childRecallRangeZMax;
  float childRecallOffsetX,childRecallOffsetY,childRecallOffsetZ; const char* childRecallAnimation; int childDirectionAdjust; int modelCopyFlags;
  int aggression; int aiAttack; int aiMove; int canDamageMask; int hostileMask; int projectileHitMask; bool noGrab; int grabForce; int grabResistance; int throwDamage; float throwDistance; float throwHeight; int bounce; float bounceFactor; bool subjectToGravity;
  int shadow; const char* dieSound; int lifespan; int landFrame; int blastReaction; int burnReaction; bool noPain; bool noDrop; bool noDieBlink; bool noQuake; bool showLifeBar; int offscreenKill; const Defense* defenses; std::size_t defenseCount;
  const char* knifeModel; const char* bombModel; const char* projectModel;
  const char* const* weapons; std::size_t weaponCount;
  const char* palettePath; const char* const* alternatePalettes; std::size_t alternatePaletteCount; const PaletteRemap* paletteRemaps; std::size_t paletteRemapCount;
  const Animation* animations; std::size_t animationCount;
  const char* thinkScript; const char* updateScript; const char* keyScript;
  const char* onMoveXScript; const char* onMoveZScript; const char* onBlockAScript; const char* onBlockYScript; const char* onBlockZScript; const char* onBlockSScript; const char* onBlockWScript; const char* onBlockOScript; const char* onBlockPScript; const char* didBlockScript; const char* onDoAttackScript; const char* onKillScript; const char* onEntityCollisionScript; const char* onModelCopyScript;
  const char* animationScript; const char* takeDamageScript; const char* didHitScript; const char* onDrawScript; const char* onSpawnScript; const char* onDeathScript; const char* onPainScript; const char* onFallScript;
};
extern const Character kCharacters[];
extern const std::size_t kCharacterCount;
}
)CPP";

    std::ofstream cpp(gen/"GeneratedCharacters.cpp"); cpp << "#include \"GeneratedCharacters.hpp\"\nnamespace generated {\n";
    for(std::size_t ci=0;ci<chars.size();++ci){ const auto& c=chars[ci];
      for(std::size_t ai=0;ai<c.animations.size();++ai){ const auto& a=c.animations[ai]; cpp<<"static const Frame c"<<ci<<"_a"<<ai<<"_frames[] = {\n";
        if(a.frames.empty()) cpp<<"  {\"\",1,0,0,false,{0,0,0,0},false,{0,0,0,0,0,0,0,0,0,0,0,0},false,0,-3,0,\"\",0,0,0,{false,1,1,false,false,0,0,0,0,0,false}},\n";
        for(const auto& f:a.frames){ const auto& d=f.draw;
          cpp<<"  {\""<<esc(f.sprite)<<"\", "<<f.delay<<", "<<f.offsetX<<", "<<f.offsetY<<", "<<(f.hasBBox?"true":"false")<<", {"<<f.bbox.x<<","<<f.bbox.y<<","<<f.bbox.w<<","<<f.bbox.h<<"}, "<<(f.hasAttack?"true":"false")<<", {"<<f.attack.x<<","<<f.attack.y<<","<<f.attack.w<<","<<f.attack.h<<","<<f.attack.damage<<","<<f.attack.type<<","<<f.attack.fallForce<<","<<f.attack.penetration<<","<<f.attack.guardCost<<","<<f.attack.juggleCost<<","<<f.attack.pauseTime<<","<<f.attack.tag<<"}, "<<(f.knockdown?"true":"false")<<", "<<f.dropVx<<", "<<f.dropVy<<", "<<f.pauseTime<<", \""<<esc(f.sound)<<"\", "<<floatLit(f.moveX)<<", "<<floatLit(f.moveZ)<<", "<<floatLit(f.moveA)<<", {"<<(d.enabled?"true":"false")<<", "<<floatLit(d.scaleX)<<", "<<floatLit(d.scaleY)<<", "<<(d.flipX?"true":"false")<<", "<<(d.flipY?"true":"false")<<", "<<floatLit(d.shiftX)<<", "<<d.alphaMode<<", "<<d.remap<<", "<<d.fillColor<<", "<<d.rotate<<", "<<(d.flipRotate?"true":"false")<<"}},\n";
        } cpp<<"};\n";
        if(!a.cancels.empty()){cpp<<"static const Cancel c"<<ci<<"_a"<<ai<<"_cancels[] = {";for(std::size_t xi=0;xi<a.cancels.size();++xi){const auto&x=a.cancels[xi];if(xi)cpp<<',';cpp<<"{"<<x.startFrame<<","<<x.endFrame<<","<<x.hits<<",\""<<esc(x.command)<<"\",\""<<esc(x.targetAnimation)<<"\"}";}cpp<<"};\n";}
      }
      if(!c.attackChain.empty()){cpp<<"static const int c"<<ci<<"_chain[] = {";for(std::size_t qi=0;qi<c.attackChain.size();++qi){if(qi)cpp<<',';cpp<<c.attackChain[qi];}cpp<<"};\n";}
      if(!c.commands.empty()){cpp<<"static const Command c"<<ci<<"_commands[] = {";for(std::size_t qi=0;qi<c.commands.size();++qi){if(qi)cpp<<',';cpp<<"{\""<<esc(c.commands[qi].sequence)<<"\",\""<<esc(c.commands[qi].targetAnimation)<<"\"}";}cpp<<"};\n";}
      cpp<<"static const char* c"<<ci<<"_weapons[] = {"; if(c.weapons.empty())cpp<<"nullptr"; for(std::size_t wi=0;wi<c.weapons.size();++wi){if(wi)cpp<<',';cpp<<"\""<<esc(c.weapons[wi])<<"\"";} cpp<<"};\n";
      if(!c.alternatePalettes.empty()){cpp<<"static const char* c"<<ci<<"_altpals[] = {";for(std::size_t pi=0;pi<c.alternatePalettes.size();++pi){if(pi)cpp<<',';cpp<<"\""<<esc(c.alternatePalettes[pi])<<"\"";}cpp<<"};\n";}
      if(!c.paletteRemaps.empty()){cpp<<"static const PaletteRemap c"<<ci<<"_remaps[] = {";for(std::size_t ri=0;ri<c.paletteRemaps.size();++ri){if(ri)cpp<<',';cpp<<"{\""<<esc(c.paletteRemaps[ri].source)<<"\",\""<<esc(c.paletteRemaps[ri].target)<<"\"}";}cpp<<"};\n";}
      if(!c.defenses.empty()){cpp<<"static const Defense c"<<ci<<"_defenses[] = {";for(std::size_t di=0;di<c.defenses.size();++di){if(di)cpp<<',';const auto&d=c.defenses[di];cpp<<"{"<<d.attackType<<","<<floatLit(d.damageFactor)<<","<<floatLit(d.knockdownFactor)<<","<<d.pain<<"}";}cpp<<"};\n";}
      cpp<<"static const Animation c"<<ci<<"_animations[] = {\n";
      if(c.animations.empty())cpp<<"  {\"\",nullptr,0,false,0,-1,-1,0,0,0,-1,-1,70,2.0f,0.0f,0.0f,\"\",\"\",-1,0,0,0,-1,-1,0,true,false,0.0f,75.0f,false,0.0f,0.0f,false,-1000.0f,1000.0f,nullptr,0,\"\",-1,0.0f,0.0f,0.0f,false,false,-1},\n";
      for(std::size_t ai=0;ai<c.animations.size();++ai){const auto&a=c.animations[ai];cpp<<"  {\""<<esc(a.name)<<"\", c"<<ci<<"_a"<<ai<<"_frames, "<<a.frames.size()<<", "<<(a.loop?"true":"false")<<", "<<a.loopStart<<", "<<a.loopEnd<<", "<<a.flipFrame<<", "<<a.jumpFrame<<", "<<floatLit(a.jumpVelocityY)<<", "<<floatLit(a.jumpVelocityX)<<", "<<floatLit(a.jumpVelocityZ)<<", "<<a.throwFrame<<", "<<a.tossFrame<<", "<<a.projectileOffsetY<<", "<<floatLit(a.projectileVelocityX)<<", "<<floatLit(a.projectileVelocityY)<<", "<<floatLit(a.projectileVelocityZ)<<", \""<<esc(a.custKnife)<<"\", \""<<esc(a.custBomb)<<"\", "<<a.weaponFrame<<", "<<a.weaponIndex<<", "<<a.followAnim<<", "<<a.followCond<<", "<<a.counterStart<<", "<<a.counterEnd<<", "<<a.counterCond<<", "<<(a.counterTakesDamage?"true":"false")<<", "<<(a.hasRangeX?"true":"false")<<", "<<floatLit(a.rangeXMin)<<", "<<floatLit(a.rangeXMax)<<", "<<(a.hasRangeZ?"true":"false")<<", "<<floatLit(a.rangeZMin)<<", "<<floatLit(a.rangeZMax)<<", "<<(a.hasRangeA?"true":"false")<<", "<<floatLit(a.rangeAMin)<<", "<<floatLit(a.rangeAMax)<<", "<<(a.cancels.empty()?"nullptr":("c"+std::to_string(ci)+"_a"+std::to_string(ai)+"_cancels"))<<", "<<a.cancels.size()<<", \""<<esc(a.custEntity)<<"\", "<<a.spawnFrame<<", "<<floatLit(a.spawnOffsetX)<<", "<<floatLit(a.spawnOffsetZ)<<", "<<floatLit(a.spawnOffsetA)<<", "<<(a.spawnScreenRelative?"true":"false")<<", "<<(a.summonFrame?"true":"false")<<", "<<a.unsummonFrame<<"},\n";} cpp<<"};\n";
    }
    cpp<<"const Character kCharacters[] = {\n";
    if(chars.empty())cpp<<"  {},\n";
    for(std::size_t ci=0;ci<chars.size();++ci){const auto&c=chars[ci];cpp<<"  {\""<<esc(c.modelName)<<"\", \""<<esc(c.name)<<"\", \""<<esc(c.type)<<"\", \""<<esc(c.subtype)<<"\", "<<c.health<<", "<<floatLit(c.speed)<<", "<<floatLit(c.runSpeed)<<", "<<c.jumpHeight<<", "<<c.jumpMoveX<<", "<<c.jumpMoveZ<<", "<<c.jugglePoints<<", "<<c.grabDistance<<", "<<c.blockOdds<<", "<<c.blockPain<<", "<<c.blockThreshold<<", "<<c.guardPoints<<", "<<c.guardRate<<", "<<(c.blockBack?"true":"false")<<", "<<(c.attackChain.empty()?"nullptr":("c"+std::to_string(ci)+"_chain"))<<", "<<c.attackChain.size()<<", "<<c.comboStyle<<", "<<c.comboDelay<<", \""<<esc(c.subEntityModel)<<"\", "<<c.weaponNumber<<", "<<c.shootNum<<", "<<c.reloadAmount<<", "<<(c.commands.empty()?"nullptr":("c"+std::to_string(ci)+"_commands"))<<", "<<c.commands.size()<<", "<<(c.weaponLossDefined?"true":"false")<<", "<<c.weaponLossFlag<<", "<<c.weaponLossIndex<<", "<<c.weaponDropCounter<<", "<<(c.typeShot?"true":"false")<<", "<<(c.animalWeapon?"true":"false")<<", "<<c.summonKill<<", "<<floatLit(c.childFollowOffsetX)<<", "<<floatLit(c.childFollowOffsetY)<<", "<<floatLit(c.childFollowOffsetZ)<<", "<<floatLit(c.childFollowRange)<<", "<<floatLit(c.childRecallRange)<<", "<<floatLit(c.childFollowRangeXMin)<<", "<<floatLit(c.childFollowRangeXMax)<<", "<<floatLit(c.childFollowRangeYMin)<<", "<<floatLit(c.childFollowRangeYMax)<<", "<<floatLit(c.childFollowRangeZMin)<<", "<<floatLit(c.childFollowRangeZMax)<<", "<<floatLit(c.childRecallRangeXMin)<<", "<<floatLit(c.childRecallRangeXMax)<<", "<<floatLit(c.childRecallRangeYMin)<<", "<<floatLit(c.childRecallRangeYMax)<<", "<<floatLit(c.childRecallRangeZMin)<<", "<<floatLit(c.childRecallRangeZMax)<<", "<<floatLit(c.childRecallOffsetX)<<", "<<floatLit(c.childRecallOffsetY)<<", "<<floatLit(c.childRecallOffsetZ)<<", \""<<esc(c.childRecallAnimation)<<"\", "<<c.childDirectionAdjust<<", "<<c.modelCopyFlags<<", "<<c.aggression<<", "<<c.aiAttack<<", "<<c.aiMove<<", "<<c.canDamageMask<<", "<<c.hostileMask<<", "<<c.projectileHitMask<<", "<<(c.noGrab?"true":"false")<<", "<<c.grabForce<<", "<<c.grabResistance<<", "<<c.throwDamage<<", "<<floatLit(c.throwDistance)<<", "<<floatLit(c.throwHeight)<<", "<<c.bounce<<", "<<floatLit(c.bounceFactor)<<", "<<(c.subjectToGravity?"true":"false")<<", "<<c.shadow<<", \""<<esc(c.dieSound)<<"\", "<<c.lifespan<<", "<<c.landFrame<<", "<<c.blastReaction<<", "<<c.burnReaction<<", "<<(c.noPain?"true":"false")<<", "<<(c.noDrop?"true":"false")<<", "<<(c.noDieBlink?"true":"false")<<", "<<(c.noQuake?"true":"false")<<", "<<(c.showLifeBar?"true":"false")<<", "<<c.offscreenKill<<", "<<(c.defenses.empty()?"nullptr":("c"+std::to_string(ci)+"_defenses"))<<", "<<c.defenses.size()<<", \""<<esc(c.knifeModel)<<"\", \""<<esc(c.bombModel)<<"\", \""<<esc(c.projectModel)<<"\", c"<<ci<<"_weapons, "<<c.weapons.size()<<", \""<<esc(c.palettePath)<<"\", "<<(c.alternatePalettes.empty()?"nullptr":("c"+std::to_string(ci)+"_altpals"))<<", "<<c.alternatePalettes.size()<<", "<<(c.paletteRemaps.empty()?"nullptr":("c"+std::to_string(ci)+"_remaps"))<<", "<<c.paletteRemaps.size()<<", c"<<ci<<"_animations, "<<c.animations.size()<<", \""<<esc(c.thinkScript)<<"\", \""<<esc(c.updateScript)<<"\", \""<<esc(c.keyScript)<<"\", \""<<esc(c.onMoveXScript)<<"\", \""<<esc(c.onMoveZScript)<<"\", \""<<esc(c.onBlockAScript)<<"\", \""<<esc(c.onBlockYScript)<<"\", \""<<esc(c.onBlockZScript)<<"\", \""<<esc(c.onBlockSScript)<<"\", \""<<esc(c.onBlockWScript)<<"\", \""<<esc(c.onBlockOScript)<<"\", \""<<esc(c.onBlockPScript)<<"\", \""<<esc(c.didBlockScript)<<"\", \""<<esc(c.onDoAttackScript)<<"\", \""<<esc(c.onKillScript)<<"\", \""<<esc(c.onEntityCollisionScript)<<"\", \""<<esc(c.onModelCopyScript)<<"\", \""<<esc(c.animationScript)<<"\", \""<<esc(c.takeDamageScript)<<"\", \""<<esc(c.didHitScript)<<"\", \""<<esc(c.onDrawScript)<<"\", \""<<esc(c.onSpawnScript)<<"\", \""<<esc(c.onDeathScript)<<"\", \""<<esc(c.onPainScript)<<"\", \""<<esc(c.onFallScript)<<"\"},\n";}
    cpp<<"};\nconst std::size_t kCharacterCount = "<<chars.size()<<";\n}\n";

    std::size_t frames=0,drawFrames=0,rotated=0,scaled=0,alpha=0,remap=0,moving=0,scripted=0;
    for(const auto&c:chars){if(!c.thinkScript.empty()||!c.updateScript.empty()||!c.keyScript.empty()||!c.onMoveXScript.empty()||!c.onMoveZScript.empty()||!c.onEntityCollisionScript.empty()||!c.animationScript.empty()||!c.takeDamageScript.empty()||!c.didHitScript.empty()||!c.onDrawScript.empty()||!c.onSpawnScript.empty()||!c.onDeathScript.empty()||!c.onPainScript.empty()||!c.onFallScript.empty())++scripted;for(const auto&a:c.animations)for(const auto&f:a.frames){++frames;if(f.draw.enabled){++drawFrames;if(f.draw.rotate)++rotated;if(f.draw.scaleX!=1.0f||f.draw.scaleY!=1.0f)++scaled;if(f.draw.alphaMode)++alpha;if(f.draw.remap)++remap;}if(f.moveX!=0||f.moveZ!=0||f.moveA!=0)++moving;}}
    std::ofstream rep(outDir/"reports"/"advanced-animation-rendering.txt");
    rep<<"OpenBOR Native Builder v0.27.0 advanced animation/render report\nframes="<<frames<<"\ndrawmethod_frames="<<drawFrames<<"\nrotated_frames="<<rotated<<"\nscaled_frames="<<scaled<<"\nalpha_frames="<<alpha<<"\nremap_frames="<<remap<<"\nframe_move_commands="<<moving<<"\nscripted_models="<<scripted<<"\n";
    rep<<"native_drawmethod=scale,scalex,scaley,flipx,flipy,shiftx,rotate,fliprotate,fillcolor,alpha-software-modes-1-6\nnative_palette_remap=image-derived-remap,act-palette-files,palette-plus-alternatepal\npartial_drawmethod=exact-indexed-palette-lut,tint-channel-clipping\n";

    std::ofstream json(outDir/"reports"/"gameplay-data.json"); json<<"{\n  \"characters\": [\n";
    for(std::size_t i=0;i<chars.size();++i){const auto&c=chars[i];json<<"    {\"name\":\""<<esc(c.name)<<"\",\"type\":\""<<esc(c.type)<<"\",\"health\":"<<c.health<<",\"scripts\":{\"think\":\""<<esc(c.thinkScript)<<"\",\"update\":\""<<esc(c.updateScript)<<"\",\"draw\":\""<<esc(c.onDrawScript)<<"\"},\"animations\":[";for(std::size_t ai=0;ai<c.animations.size();++ai){const auto&a=c.animations[ai];json<<"{\"name\":\""<<esc(a.name)<<"\",\"frames\":[";for(std::size_t fi=0;fi<a.frames.size();++fi){const auto&f=a.frames[fi];json<<"{\"sprite\":\""<<esc(f.sprite)<<"\",\"delay\":"<<f.delay<<",\"move\":["<<f.moveX<<","<<f.moveZ<<","<<f.moveA<<"],\"draw\":{\"enabled\":"<<(f.draw.enabled?"true":"false")<<",\"scale\":["<<f.draw.scaleX<<","<<f.draw.scaleY<<"],\"rotate\":"<<f.draw.rotate<<",\"alpha\":"<<f.draw.alphaMode<<",\"remap\":"<<f.draw.remap<<"}}"<<(fi+1<a.frames.size()?",":"");}json<<"]}"<<(ai+1<c.animations.size()?",":"");}json<<"]}"<<(i+1<chars.size()?",":"")<<"\n";}json<<"  ]\n}\n";
}
