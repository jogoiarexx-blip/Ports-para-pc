#include "CharacterParser.hpp"
#include "TextDatabase.hpp"
#include "SafePath.hpp"
#include <algorithm>
#include <cmath>

namespace {
std::string lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return (char)std::tolower(c);}); return s;}
int toInt(const std::string& s, int d=0){ try { return std::stoi(s); } catch(...) { return d; } }
float toFloat(const std::string& s, float d=0){ try { return std::stof(s); } catch(...) { return d; } }
int normAngle(int a){ a%=360; if(a<0)a+=360; return a; }
std::string joinValues(const std::vector<std::string>& v, std::size_t first, std::size_t lastExclusive){
    std::string out; for(std::size_t i=first;i<lastExclusive&&i<v.size();++i){ if(!out.empty()) out+=' '; out+=v[i]; } return out;
}
void applyDrawMethod(DrawMethodDef& d, const std::vector<std::string>& v){
    if(v.empty()) return;
    auto sub=lower(v[0]);
    auto value=[&](std::size_t i,float def=0.0f){ return i<v.size()?toFloat(v[i],def):def; };
    if(sub=="scale") { d.enabled=true; d.scaleX=value(1,1.0f); d.scaleY=v.size()>2?value(2,d.scaleX):d.scaleX; return; }
    if(sub=="scalex") { d.enabled=true; d.scaleX=value(1,1.0f); return; }
    if(sub=="scaley") { d.enabled=true; d.scaleY=value(1,1.0f); return; }
    if(sub=="flipx") { d.enabled=true; d.flipX=toInt(v.size()>1?v[1]:"0")!=0; return; }
    if(sub=="flipy") { d.enabled=true; d.flipY=toInt(v.size()>1?v[1]:"0")!=0; return; }
    if(sub=="shiftx") { d.enabled=true; d.shiftX=value(1,0.0f); return; }
    if(sub=="alpha") { d.enabled=true; d.alphaMode=toInt(v.size()>1?v[1]:"0"); return; }
    if(sub=="remap") { d.enabled=true; d.remap=toInt(v.size()>1?v[1]:"0"); return; }
    if(sub=="fillcolor") { d.enabled=true; d.fillColor=toInt(v.size()>1?v[1]:"0"); return; }
    if(sub=="rotate") { d.enabled=true; d.rotate=normAngle(toInt(v.size()>1?v[1]:"0")); return; }
    if(sub=="fliprotate") { d.enabled=true; d.flipRotate=toInt(v.size()>1?v[1]:"0")!=0; return; }
    // Legacy positional drawmethod: scaleX scaleY flipX flipY shiftX alpha remap fill rotate flipRotate.
    d.enabled=true;
    d.scaleX=value(0,256.0f)/256.0f;
    d.scaleY=value(1,256.0f)/256.0f;
    d.flipX=toInt(v.size()>2?v[2]:"0")!=0;
    d.flipY=toInt(v.size()>3?v[3]:"0")!=0;
    d.shiftX=value(4,0.0f)/256.0f;
    d.alphaMode=toInt(v.size()>5?v[5]:"0");
    d.remap=toInt(v.size()>6?v[6]:"0");
    d.fillColor=toInt(v.size()>7?v[7]:"0");
    d.rotate=normAngle(toInt(v.size()>8?v[8]:"0"));
    d.flipRotate=toInt(v.size()>9?v[9]:"0")!=0;
}
void applyAnimationDirective(const std::string& key, const std::vector<std::string>& values, AnimationDef& anim, FrameDef& state){
    if (key == "loop" && !values.empty()) {
        anim.loop = toInt(values[0],0)!=0;
        if(values.size()>1) anim.loopStart=std::max(0,toInt(values[1],0));
        if(values.size()>2) anim.loopEnd=toInt(values[2],-1);
    }
    else if (key == "delay" && !values.empty()) {
        auto v=lower(values[0]);
        state.delay = (v=="infinite" || v=="inf") ? -1 : std::max(0,toInt(values[0],1));
    }
    else if (key == "offset" && values.size() >= 2) { state.offsetX=toInt(values[0]); state.offsetY=toInt(values[1]); }
    else if (key == "bbox" && !values.empty()) {
        if(lower(values[0])=="none") { state.hasBBox=false; state.bbox={}; }
        else if(values.size() >= 4) { auto b=HitBoxDef{toInt(values[0]),toInt(values[1]),toInt(values[2]),toInt(values[3])}; state.hasBBox=b.w>0&&b.h>0; state.bbox=b; }
    }
    else if ((key == "attack" || key.rfind("attack",0)==0) && !values.empty()) {
        if(lower(values[0])=="none" || values[0]=="0") { state.hasAttack=false; state.attack={}; state.knockdown=false; state.dropVx=0; state.dropVy=-3; state.pauseTime=0; }
        else if(values.size() >= 5) {
            int type=1; if(key.size()>6) type=std::max(1,toInt(key.substr(6),1));
            AttackBoxDef a; a.x=toInt(values[0]);a.y=toInt(values[1]);a.w=toInt(values[2]);a.h=toInt(values[3]);a.damage=toInt(values[4]);a.type=type;
            if(values.size()>5)a.fallForce=toInt(values[5],0);
            if(values.size()>6)a.penetration=toInt(values[6],0);
            if(values.size()>8)a.pauseTime=toInt(values[8],0);
            state.hasAttack=a.w>0&&a.h>0; state.attack=a; state.knockdown=a.fallForce>0; state.dropVx=0; state.dropVy=a.fallForce>0?-std::max(1,a.fallForce):-3; state.pauseTime=a.pauseTime;
        }
    }
    else if ((key == "guardcost" || key == "attack.block.cost") && !values.empty()) state.attack.guardCost=toInt(values[0],0);
    else if ((key == "noblock" || key == "attack.block.penetrate") && !values.empty()) state.attack.penetration=toInt(values[0],0);
    else if (key == "jugglecost" && !values.empty()) state.attack.juggleCost=std::max(0,toInt(values[0],0));
    else if ((key == "attack.tag" || key == "tag") && !values.empty()) state.attack.tag=toInt(values[0],0);
    else if (key == "fall" && !values.empty()) { state.attack.fallForce=toInt(values[0],0); state.knockdown = state.attack.fallForce!=0; }
    else if (key == "dropv" && !values.empty()) { state.dropVx=toInt(values[0]); if(values.size()>1) state.dropVy=toInt(values[1],-3); }
    else if ((key == "pausetime" || key == "attack.reaction.pause.time") && !values.empty()) { state.pauseTime=toInt(values[0]); state.attack.pauseTime=state.pauseTime; }
    else if (key == "sound" && !values.empty()) state.sound=values[0];
    else if (key == "move" && !values.empty()) state.moveX=toFloat(values[0]);
    else if (key == "movez" && !values.empty()) state.moveZ=toFloat(values[0]);
    else if (key == "movea" && !values.empty()) state.moveA=toFloat(values[0]);
    else if (key == "drawmethod") applyDrawMethod(state.draw,values);
    else if (key == "nodrawmethod") state.draw=DrawMethodDef{};
    else if (key == "flipframe" && !values.empty()) anim.flipFrame=toInt(values[0],-1);
    else if (key == "jumpframe" && !values.empty()) { anim.jumpFrame=toInt(values[0],-1); if(values.size()>1) anim.jumpVelocityY=toFloat(values[1]); if(values.size()>2) anim.jumpVelocityX=toFloat(values[2]); if(values.size()>3) anim.jumpVelocityZ=toFloat(values[3]); }
    else if (key == "custknife" && !values.empty()) anim.custKnife=values[0];
    else if ((key == "custbomb" || key == "custpbomb") && !values.empty()) anim.custBomb=values[0];
    else if ((key == "throwframe" || key == "shootframe" || key == "pshotframe") && !values.empty()) { anim.throwFrame=toInt(values[0],-1); if(values.size()>1) anim.projectileOffsetY=toInt(values[1],70); }
    else if (key == "tossframe" && !values.empty()) { anim.tossFrame=toInt(values[0],-1); if(values.size()>1) anim.projectileOffsetY=toInt(values[1],70); }
    else if (key == "projectile_velocity_x" && !values.empty()) anim.projectileVelocityX=toFloat(values[0],2.0f);
    else if (key == "projectile_velocity_y" && !values.empty()) anim.projectileVelocityY=toFloat(values[0],0.0f);
    else if (key == "projectile_velocity_z" && !values.empty()) anim.projectileVelocityZ=toFloat(values[0],0.0f);
    else if (key == "weaponframe" && !values.empty()) { anim.weaponFrame=toInt(values[0],-1); if(values.size()>1) anim.weaponIndex=toInt(values[1],0); }
    else if (key == "followanim" && !values.empty()) anim.followAnim=std::max(0,toInt(values[0],0));
    else if (key == "followcond" && !values.empty()) anim.followCond=std::max(0,toInt(values[0],0));
    else if (key == "counterframe" && values.size()>=3) { anim.counterStart=anim.counterEnd=std::max(0,toInt(values[0],0)); anim.counterCond=std::max(0,toInt(values[1],0)); anim.counterTakesDamage=toInt(values[2],1)!=0; }
    else if (key == "counterrange" && values.size()>=4) { anim.counterStart=std::max(0,toInt(values[0],0)); anim.counterEnd=std::max(anim.counterStart,toInt(values[1],anim.counterStart)); anim.counterCond=std::max(0,toInt(values[2],0)); anim.counterTakesDamage=toInt(values[3],1)!=0; }
    else if (key == "range" && values.size()>=2) { anim.hasRangeX=true; anim.rangeXMin=toFloat(values[0],0.0f); anim.rangeXMax=toFloat(values[1],75.0f); if(anim.rangeXMin>anim.rangeXMax)std::swap(anim.rangeXMin,anim.rangeXMax); }
    else if (key == "rangez" && values.size()>=2) { anim.hasRangeZ=true; anim.rangeZMin=toFloat(values[0],0.0f); anim.rangeZMax=toFloat(values[1],0.0f); if(anim.rangeZMin>anim.rangeZMax)std::swap(anim.rangeZMin,anim.rangeZMax); }
    else if (key == "rangea" && values.size()>=2) { anim.hasRangeA=true; anim.rangeAMin=toFloat(values[0],-1000.0f); anim.rangeAMax=toFloat(values[1],1000.0f); if(anim.rangeAMin>anim.rangeAMax)std::swap(anim.rangeAMin,anim.rangeAMax); }
    else if (key == "cancel" && values.size()>=5) { CancelDef c; c.startFrame=std::max(0,toInt(values[0],0)); c.endFrame=std::max(c.startFrame,toInt(values[1],c.startFrame)); c.hits=std::max(0,toInt(values[2],0)); c.command=joinValues(values,3,values.size()-1); c.targetAnimation=values.back(); anim.cancels.push_back(std::move(c)); }
    else if (key == "custentity" && !values.empty()) anim.custEntity=values[0];
    else if ((key == "spawnframe" || key == "summonframe") && !values.empty()) { anim.spawnFrame=std::max(0,toInt(values[0],0)); if(values.size()>1) anim.spawnOffsetX=toFloat(values[1],0.0f); if(values.size()>2) anim.spawnOffsetZ=toFloat(values[2],0.0f); if(values.size()>3) anim.spawnOffsetA=toFloat(values[3],0.0f); if(values.size()>4) anim.spawnScreenRelative=toInt(values[4],0)!=0; anim.summonFrame=(key=="summonframe"); }
    else if (key == "unsummonframe" && !values.empty()) anim.unsummonFrame=std::max(0,toInt(values[0],0));
    else if (key == "frame" && !values.empty()) { FrameDef committed=state; committed.sprite=values[0]; anim.frames.push_back(committed); state.sound.clear(); }
}

}

CharacterDef CharacterParser::parse(const std::filesystem::path& file, const std::filesystem::path& root) {
    CharacterDef out;
    out.sourceFile = std::filesystem::relative(file, root).generic_string();
    AnimationDef* currentAnim = nullptr;
    FrameDef state;

    for (const auto& e : TextDatabase::parse(file)) {
        auto key = lower(e.key);
        if (key == "name" && !e.values.empty()) out.name = e.values[0];
        else if (key == "type" && !e.values.empty()) out.type = e.values[0];
        else if (key == "subtype" && !e.values.empty()) out.subtype = e.values[0];
        else if (key == "health" && !e.values.empty()) out.health = toInt(e.values[0],100);
        else if (key == "speed" && !e.values.empty()) out.speed = toFloat(e.values[0],1.0f);
        else if (key == "runspeed" && !e.values.empty()) out.runSpeed = toFloat(e.values[0],0.0f);
        else if (key == "jumpheight" && !e.values.empty()) out.jumpHeight = toInt(e.values[0],4);
        else if (key == "jumpmove" && !e.values.empty()) { out.jumpMoveX=toInt(e.values[0]); if(e.values.size()>1) out.jumpMoveZ=toInt(e.values[1]); }
        else if (key == "knife" && !e.values.empty()) out.knifeModel=e.values[0];
        else if (key == "bomb" && !e.values.empty()) out.bombModel=e.values[0];
        else if (key == "project" && !e.values.empty()) out.projectModel=e.values[0];
        else if ((key == "weapon" || key == "weapons") && !e.values.empty()) { for(const auto& w:e.values) out.weapons.push_back(w); }
        else if (key == "weapnum" && !e.values.empty()) out.weaponNumber=std::max(0,toInt(e.values[0],0));
        else if (key == "shootnum" && !e.values.empty()) out.shootNum=std::max(0,toInt(e.values[0],0));
        else if (key == "reload" && !e.values.empty()) out.reloadAmount=std::max(0,toInt(e.values[0],0));
        else if ((key == "com" || key == "cmd") && e.values.size()>=2) { CommandDef c; c.targetAnimation=e.values.back(); c.sequence=joinValues(e.values,0,e.values.size()-1); out.commands.push_back(std::move(c)); }
        else if (key == "weaploss" && !e.values.empty()) { out.weaponLossDefined=true; out.weaponLossFlag=std::clamp(toInt(e.values[0],0),0,3); if(e.values.size()>1) out.weaponLossIndex=std::max(0,toInt(e.values[1],0)); }
        else if (key == "weapon_loss_index" && !e.values.empty()) { out.weaponLossDefined=true; out.weaponLossIndex=std::max(0,toInt(e.values[0],0)); }
        else if (key == "weapon_loss_condition" && !e.values.empty()) {
            out.weaponLossDefined=true;
            // Map modern loss-condition flags to the nearest legacy behavior the compact runtime can enforce.
            bool any=false,fall=false,death=false,stage=false,none=false;
            for(auto v:e.values){v=lower(v); if(v=="none") none=true; else if(v=="fall") fall=true; else if(v=="death") death=true; else if(v=="stage") stage=true; else if(v=="damage"||v=="pain"||v=="grabbed"||v=="grabbing"||v=="land_damage"||v=="default") any=true;}
            if(none&&!any&&!fall&&!death&&!stage) out.weaponLossFlag=3; else if(any) out.weaponLossFlag=0; else if(fall) out.weaponLossFlag=1; else if(death) out.weaponLossFlag=2; else if(stage) out.weaponLossFlag=3;
        }
        else if (key == "counter" && !e.values.empty()) out.weaponDropCounter=std::max(0,toInt(e.values[0],3));
        else if (key == "typeshot" && !e.values.empty()) out.typeShot=toInt(e.values[0],0)!=0;
        else if (key == "animal" && !e.values.empty()) out.animalWeapon=toInt(e.values[0],0)!=0;
        else if (key == "summonkill" && !e.values.empty()) out.summonKill=std::clamp(toInt(e.values[0],0),0,2);
        else if (key == "child_follow_offset_x" && !e.values.empty()) out.childFollowOffsetX=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_offset_y" && !e.values.empty()) out.childFollowOffsetY=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_offset_z" && !e.values.empty()) out.childFollowOffsetZ=toFloat(e.values[0],0.0f);
        else if ((key == "child_follow_range_base_max" || key == "child_follow_range_x_max") && !e.values.empty()) { out.childFollowRange=std::max(1.0f,std::fabs(toFloat(e.values[0],100.0f))); out.childFollowRangeXMax=out.childFollowRange; }
        else if ((key == "child_follow_range_base_min" || key == "child_follow_range_x_min") && !e.values.empty()) out.childFollowRangeXMin=toFloat(e.values[0],-100.0f);
        else if (key == "child_follow_range_y_max" && !e.values.empty()) out.childFollowRangeYMax=toFloat(e.values[0],100.0f);
        else if (key == "child_follow_range_y_min" && !e.values.empty()) out.childFollowRangeYMin=toFloat(e.values[0],-100.0f);
        else if (key == "child_follow_range_z_max" && !e.values.empty()) out.childFollowRangeZMax=toFloat(e.values[0],100.0f);
        else if (key == "child_follow_range_z_min" && !e.values.empty()) out.childFollowRangeZMin=toFloat(e.values[0],-100.0f);
        else if ((key == "child_follow_range_recall_base_max" || key == "child_follow_range_recall_x_max") && !e.values.empty()) { out.childRecallRange=std::max(out.childFollowRange,std::fabs(toFloat(e.values[0],300.0f))); out.childRecallRangeXMax=out.childRecallRange; }
        else if ((key == "child_follow_range_recall_base_min" || key == "child_follow_range_recall_x_min") && !e.values.empty()) out.childRecallRangeXMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_range_recall_y_max" && !e.values.empty()) out.childRecallRangeYMax=toFloat(e.values[0],300.0f);
        else if (key == "child_follow_range_recall_y_min" && !e.values.empty()) out.childRecallRangeYMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_range_recall_z_max" && !e.values.empty()) out.childRecallRangeZMax=toFloat(e.values[0],300.0f);
        else if (key == "child_follow_range_recall_z_min" && !e.values.empty()) out.childRecallRangeZMin=toFloat(e.values[0],-300.0f);
        else if (key == "child_follow_recall_offset_x" && !e.values.empty()) out.childRecallOffsetX=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_offset_y" && !e.values.empty()) out.childRecallOffsetY=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_offset_z" && !e.values.empty()) out.childRecallOffsetZ=toFloat(e.values[0],0.0f);
        else if (key == "child_follow_recall_animation" && !e.values.empty()) out.childRecallAnimation=e.values[0];
        else if (key == "child_follow_direction_adjust_config" && !e.values.empty()) { auto v=lower(e.values[0]); if(v=="same")out.childDirectionAdjust=1;else if(v=="opposite")out.childDirectionAdjust=2;else if(v=="left")out.childDirectionAdjust=3;else if(v=="right")out.childDirectionAdjust=4;else if(v=="away")out.childDirectionAdjust=5;else if(v=="toward")out.childDirectionAdjust=6;else out.childDirectionAdjust=toInt(e.values[0],0); }
        else if (key == "modelflag" && !e.values.empty()) { out.modelCopyFlags=0; for(auto v:e.values){v=lower(v);if(v=="no_basic")out.modelCopyFlags|=1;else if(v=="no_weapon")out.modelCopyFlags|=2;else if(v=="no_script")out.modelCopyFlags|=4;else if(v!="none")out.modelCopyFlags|=std::max(0,toInt(v,0));} }
        else if (key == "subentity" && !e.values.empty()) out.subEntityModel=e.values[0];
        else if (key == "atchain" && !e.values.empty()) { out.attackChain.clear(); for(const auto& v:e.values) out.attackChain.push_back(std::max(0,toInt(v,0))); }
        else if (key == "combostyle" && !e.values.empty()) out.comboStyle=std::clamp(toInt(e.values[0],0),0,2);
        else if (key == "combodelay" && !e.values.empty()) out.comboDelay=std::max(1,toInt(e.values[0],100));
        else if (key == "palette" && !e.values.empty()) out.palettePath=SafePath::normalizeOpenBOR(e.values[0]);
        else if (key == "alternatepal" && !e.values.empty()) out.alternatePalettes.push_back(SafePath::normalizeOpenBOR(e.values[0]));
        else if (key == "remap" && e.values.size()>=2) out.paletteRemaps.push_back({SafePath::normalizeOpenBOR(e.values[0]),SafePath::normalizeOpenBOR(e.values[1])});
        else if (key == "jugglepoints" && !e.values.empty()) out.jugglePoints = toInt(e.values[0],4);
        else if (key == "blockodds" && !e.values.empty()) out.blockOdds = toInt(e.values[0],-1);
        else if (key == "blockpain" && !e.values.empty()) out.blockPain = std::max(0,toInt(e.values[0],0));
        else if ((key == "thold" || key == "blockthreshold") && !e.values.empty()) out.blockThreshold = std::max(0,toInt(e.values[0],0));
        else if (key == "guardpoints" && !e.values.empty()) out.guardPoints = std::max(0,toInt(e.values[0],0));
        else if (key == "guardrate" && !e.values.empty()) out.guardRate = std::max(0,toInt(e.values[0],2));
        else if (key == "blockback" && !e.values.empty()) out.blockBack = toInt(e.values[0],0)!=0;
        else if (key == "aggression" && !e.values.empty()) out.aggression = std::max(0,toInt(e.values[0],0));
        else if (key == "aiattack" && !e.values.empty()) out.aiAttack = toInt(e.values[0],0);
        else if (key == "aimove" && !e.values.empty()) out.aiMove = toInt(e.values[0],1);
        else if (key == "candamage" && !e.values.empty()) out.canDamageMask = toInt(e.values[0],0);
        else if (key == "hostile" && !e.values.empty()) out.hostileMask = toInt(e.values[0],0);
        else if (key == "projectilehit" && !e.values.empty()) out.projectileHitMask = toInt(e.values[0],0);
        else if ((key == "nograb" || key == "cantgrab") && !e.values.empty()) out.noGrab = toInt(e.values[0],0)!=0;
        else if (key == "grabforce" && !e.values.empty()) out.grabForce = toInt(e.values[0],0);
        else if ((key == "grabresistance" || key == "grab_resistance") && !e.values.empty()) out.grabResistance = toInt(e.values[0],0);
        else if (key == "throwdamage" && !e.values.empty()) out.throwDamage = std::max(0,toInt(e.values[0],0));
        else if (key == "throwdist" && !e.values.empty()) out.throwDistance = toFloat(e.values[0],0.0f);
        else if (key == "throwheight" && !e.values.empty()) out.throwHeight = toFloat(e.values[0],0.0f);
        else if (key == "bounce" && !e.values.empty()) out.bounce = std::max(0,toInt(e.values[0],0));
        else if (key == "bouncefactor" && !e.values.empty()) out.bounceFactor = std::max(0.0f,toFloat(e.values[0],0.5f));
        else if ((key == "subject_to_gravity" || key == "subjecttogravity") && !e.values.empty()) out.subjectToGravity = toInt(e.values[0],0)!=0;
        else if (key == "shadow" && !e.values.empty()) out.shadow = toInt(e.values[0],1);
        else if (key == "diesound" && !e.values.empty()) out.dieSound = SafePath::normalizeOpenBOR(e.values[0]);
        else if (key == "lifespan" && !e.values.empty()) out.lifespan = std::max(0,toInt(e.values[0],0));
        else if (key == "landframe" && !e.values.empty()) out.landFrame = std::max(-1,toInt(e.values[0],-1));
        else if (key == "blast" && !e.values.empty()) out.blastReaction = std::max(0,toInt(e.values[0],0));
        else if (key == "burn" && !e.values.empty()) out.burnReaction = std::max(0,toInt(e.values[0],0));
        else if (key == "nopain" && !e.values.empty()) out.noPain = toInt(e.values[0],0)!=0;
        else if (key == "nodrop" && !e.values.empty()) out.noDrop = toInt(e.values[0],0)!=0;
        else if (key == "nodieblink" && !e.values.empty()) out.noDieBlink = toInt(e.values[0],0)!=0;
        else if (key == "noquake" && !e.values.empty()) out.noQuake = toInt(e.values[0],0)!=0;
        else if (key == "nolife" && !e.values.empty()) out.showLifeBar = toInt(e.values[0],0)==0;
        else if (key == "offscreenkill" && !e.values.empty()) out.offscreenKill = std::max(0,toInt(e.values[0],0));
        else if (key == "defense" && !e.values.empty()) { DefenseDef d; d.attackType=std::max(0,toInt(e.values[0],0)); if(e.values.size()>1)d.damageFactor=toFloat(e.values[1],1.0f); if(e.values.size()>2)d.knockdownFactor=toFloat(e.values[2],1.0f); if(e.values.size()>3)d.pain=toInt(e.values[3],0); out.defenses.push_back(d); }
        else if ((key == "grabdistance" || key == "grabin") && !e.values.empty()) out.grabDistance = std::max(8,toInt(e.values[0],30));
        else if (key == "thinkscript" && !e.values.empty()) out.thinkScript=e.values[0];
        else if ((key == "updatescript" || key == "script") && !e.values.empty()) out.updateScript=e.values[0];
        else if (key == "keyscript" && !e.values.empty()) out.keyScript=e.values[0];
        else if (key == "onmovexscript" && !e.values.empty()) out.onMoveXScript=e.values[0];
        else if (key == "onmovezscript" && !e.values.empty()) out.onMoveZScript=e.values[0];
        else if (key == "onblockascript" && !e.values.empty()) out.onBlockAScript=e.values[0];
        else if (key == "onblockyscript" && !e.values.empty()) out.onBlockYScript=e.values[0];
        else if (key == "onblockzscript" && !e.values.empty()) out.onBlockZScript=e.values[0];
        else if (key == "onblocksscript" && !e.values.empty()) out.onBlockSScript=e.values[0];
        else if (key == "onblockwscript" && !e.values.empty()) out.onBlockWScript=e.values[0];
        else if (key == "onblockoscript" && !e.values.empty()) out.onBlockOScript=e.values[0];
        else if (key == "onblockpscript" && !e.values.empty()) out.onBlockPScript=e.values[0];
        else if (key == "didblockscript" && !e.values.empty()) out.didBlockScript=e.values[0];
        else if ((key == "ondoattack" || key == "ondoattackscript") && !e.values.empty()) out.onDoAttackScript=e.values[0];
        else if ((key == "onkillscript" || key == "onkill_script") && !e.values.empty()) out.onKillScript=e.values[0];
        else if (key == "onentitycollision" && !e.values.empty()) out.onEntityCollisionScript=e.values[0];
        else if (key == "onmodelcopy" && !e.values.empty()) out.onModelCopyScript=e.values[0];
        else if (key == "animationscript" && !e.values.empty()) out.animationScript=e.values[0];
        else if ((key == "takedamagescript" || key == "takedamage_script") && !e.values.empty()) out.takeDamageScript=e.values[0];
        else if ((key == "didhitscript" || key == "didhit_script") && !e.values.empty()) out.didHitScript=e.values[0];
        else if ((key == "ondrawscript" || key == "ondraw_script") && !e.values.empty()) out.onDrawScript=e.values[0];
        else if ((key == "onspawnscript" || key == "onspawn_script") && !e.values.empty()) out.onSpawnScript=e.values[0];
        else if ((key == "ondeathscript" || key == "ondeath_script") && !e.values.empty()) out.onDeathScript=e.values[0];
        else if ((key == "onpainscript" || key == "onpain_script") && !e.values.empty()) out.onPainScript=e.values[0];
        else if ((key == "onfallscript" || key == "onfall_script") && !e.values.empty()) out.onFallScript=e.values[0];
        else if (key == "anim" && !e.values.empty()) {
            out.animations.push_back(AnimationDef{});
            out.animations.back().name = e.values[0];
            currentAnim = &out.animations.back();
            state = FrameDef{};
        } else if (currentAnim) {
            applyAnimationDirective(key, e.values, *currentAnim, state);
        }
    }
    if (out.name.empty()) out.name = file.stem().string();
    return out;
}

std::vector<CharacterDef> CharacterParser::parseAll(const std::filesystem::path& dataDir, const std::filesystem::path& root) {
    std::vector<CharacterDef> out;
    if (!std::filesystem::exists(dataDir)) return out;

    const auto models = dataDir / "models.txt";
    if (std::filesystem::exists(models)) {
        // models.txt is the authoritative OpenBOR model registry. The external name used by
        // stage spawns can intentionally differ from the internal `name` inside the model.
        for (const auto& e : TextDatabase::parse(models)) {
            auto key = lower(e.key);
            if (key != "load" || e.values.empty()) continue;

            std::string registryName;
            std::string rawPath;
            if (e.values.size() >= 2) {
                registryName = e.values[0];
                rawPath = e.values[1];
            } else {
                rawPath = e.values[0];
                registryName = std::filesystem::path(rawPath).stem().string();
            }

            auto modelFile = SafePath::resolveWithin(dataDir, rawPath);
            if (modelFile.empty() || !std::filesystem::is_regular_file(modelFile)) continue;
            auto parsed = parse(modelFile, root);
            if (parsed.animations.empty()) continue;
            parsed.modelName = registryName.empty() ? parsed.name : registryName;
            if (parsed.name.empty()) parsed.name = parsed.modelName;
            out.push_back(std::move(parsed));
        }
        if (!out.empty()) return out;
    }

    // Compatibility fallback for incomplete projects that omit/break models.txt.
    // This is deliberately secondary: valid projects must follow their registry.
    for (const auto& entry : std::filesystem::recursive_directory_iterator(dataDir)) {
        if (!entry.is_regular_file() || lower(entry.path().extension().string()) != ".txt") continue;
        auto parsed = parse(entry.path(), root);
        if (!parsed.animations.empty() && !parsed.name.empty()) {
            parsed.modelName = parsed.name;
            out.push_back(std::move(parsed));
        }
    }
    return out;
}
