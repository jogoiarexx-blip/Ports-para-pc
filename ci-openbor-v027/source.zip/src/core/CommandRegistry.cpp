#include "CommandRegistry.hpp"
#include <algorithm>
#include <cctype>
#include <string>

namespace {
std::string lower(std::string_view in){
    std::string s(in);
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return (char)std::tolower(c); });
    return s;
}
CommandInfo make(bool parser, bool runtime, const char* note, CommandStatus overrideStatus = CommandStatus::Unknown){
    CommandInfo info;
    info.parser = parser;
    info.runtime = runtime;
    info.note = note;
    if(overrideStatus != CommandStatus::Unknown) info.status = overrideStatus;
    else if(parser && runtime) info.status = CommandStatus::Supported;
    else if(parser && !runtime) info.status = CommandStatus::Partial;
    else info.status = CommandStatus::Unknown;
    return info;
}
}

const char* CommandRegistry::statusName(CommandStatus status){
    switch(status){
        case CommandStatus::Supported: return "SUPPORTED";
        case CommandStatus::Partial: return "PARTIAL";
        case CommandStatus::Unsupported: return "UNSUPPORTED";
        case CommandStatus::IgnoredSafely: return "IGNORED_SAFELY";
        case CommandStatus::Unknown: return "UNKNOWN";
    }
    return "UNKNOWN";
}

CommandInfo CommandRegistry::lookup(std::string_view command){
    const std::string c = lower(command);
    auto attackN = c.rfind("attack", 0) == 0 && c.size() > 6;
    if(c=="name"||c=="type"||c=="subtype"||c=="health"||c=="speed"||c=="runspeed"||c=="jumpheight"||c=="jumpmove")
        return make(true,true,"Model property applied to the generated entity.");
    if(c=="anim"||c=="frame"||c=="delay"||c=="offset"||c=="loop"||c=="move"||c=="movez"||c=="movea"||c=="sound"||c=="flipframe")
        return make(true,true,"Animation command executed by the native animation player.");
    if(c=="bbox"||c=="attack"||c=="attack1"||c=="attack2"||c=="attack3"||c=="fall"||c=="dropv"||c=="pausetime"||c=="guardcost"||c=="noblock"||c=="jugglecost"||c=="attack.tag"||c=="attack.block.cost"||c=="attack.block.penetrate"||c=="attack.reaction.pause.time")
        return make(true,true,"Per-frame hit/attack data. attack4+ is parsed; only 1-3 are bound to default controls.");
    if(attackN) return make(true,true,"Extra attackN boxes/animations are preserved and native combo discovery can advance through attack4+ when the model provides them.", CommandStatus::Partial);
    if(c=="drawmethod"||c=="nodrawmethod")
        return make(true,true,"Scale/flip/rotate/shift/fill and alpha modes 1-6 run in the software compositor. Indexed palette LUT remap remains partial.", CommandStatus::Partial);
    if(c=="jugglepoints"||c=="grabdistance"||c=="grabin"||c=="knife"||c=="bomb"||c=="project"||c=="blockodds"||c=="blockpain"||c=="thold"||c=="blockthreshold"||c=="guardpoints"||c=="guardrate"||c=="blockback")
        return make(true,true,"Combat/projectile/blocking model properties used by the native runtime.");
    if(c=="aggression"||c=="aiattack"||c=="aimove"||c=="candamage"||c=="hostile"||c=="projectilehit")
        return make(true,true,"OpenBOR AI/faction masks influence native targeting, movement, attack selection and projectile targets.", CommandStatus::Partial);
    if(c=="nograb"||c=="cantgrab"||c=="grabforce"||c=="grabresistance"||c=="grab_resistance"||c=="throwdamage"||c=="throwdist"||c=="throwheight")
        return make(true,true,"Native grab/throw resolution consumes these model values; uncommon legacy grab edge cases remain partial.", CommandStatus::Partial);
    if(c=="bounce"||c=="bouncefactor"||c=="subject_to_gravity"||c=="subjecttogravity")
        return make(true,true,"Projectile motion uses model gravity and bounce metadata.", CommandStatus::Partial);
    if(c=="jumpframe"||c=="throwframe"||c=="shootframe"||c=="pshotframe"||c=="tossframe"||c=="custknife"||c=="custbomb"||c=="custpbomb")
        return make(true,true,"Projectile spawn frames.");
    if(c=="modelflag")
        return make(true,true,"Weapon model-copy flags are parsed; no_basic prevents inherited basic animations while no_weapon/no_script are preserved for compatibility analysis.", CommandStatus::Partial);
    if(c=="range"||c=="rangez"||c=="rangea")
        return make(true,true,"Animation activation ranges feed dynamic combostyle=1 branch selection.");
    if(c=="atchain"||c=="combostyle"||c=="combodelay")
        return make(true,true,"Native player/coop combo chains use atchain/combodelay; combostyle=1 selects range branches from animation range/rangez/rangea metadata. Exotic legacy branch layouts remain partial.", CommandStatus::Partial);
    if(c=="com"||c=="cmd")
        return make(true,true,"OpenBOR command sequences use a 128-tick per-player history with press/release, passive hold min/max, auto hold-trigger, chord grace and sequence grace; weapon models can replace the active command list.", CommandStatus::Partial);
    if(c=="followanim"||c=="followcond"||c=="counterframe"||c=="counterrange")
        return make(true,true,"Follow/counter transitions execute from real hit results and frame windows.", CommandStatus::Partial);
    if(c=="cancel")
        return make(true,true,"Animation cancel windows, hit requirements and common OpenBOR input tokens are executed natively.", CommandStatus::Partial);
    if(c=="weapons"||c=="weapnum"||c=="shootnum"||c=="reload"||c=="weapon"||c=="weaponframe"||c=="weaploss"||c=="weapon_loss_index"||c=="weapon_loss_condition"||c=="counter"||c=="typeshot"||c=="animal")
        return make(true,true,"Weapon model swap, limited uses, inherited/overridden weaploss, drop counter and gun depletion behavior are active. Full model-copy/drop animation edge cases remain partial.", CommandStatus::Partial);
    if(c=="subentity"||c=="custentity"||c=="spawnframe"||c=="summonframe"||c=="unsummonframe"||c=="summonkill"||c=="child_follow_offset_x"||c=="child_follow_offset_y"||c=="child_follow_offset_z"||c.rfind("child_follow_range_",0)==0||c.rfind("child_follow_recall_",0)==0||c=="child_follow_direction_adjust_config")
        return make(true,true,"Child spawn/summon, unsummon, parent-death cleanup and follow/recall positioning execute in the native runtime.", CommandStatus::Partial);
    if(c=="thinkscript"||c=="updatescript"||c=="animationscript"||c=="takedamagescript"||c=="didhitscript"||c=="ondrawscript"||c=="onspawnscript"||c=="ondeathscript"||c=="onpainscript"||c=="onfallscript"||c=="onpain_script"||c=="onfall_script"||c=="takedamage_script"||c=="didhit_script"||c=="ondraw_script"||c=="onspawn_script"||c=="ondeath_script")
        return make(true,true,"Hook is invoked by ScriptVM. Unmapped APIs inside the script stay PARTIAL.", CommandStatus::Partial);
    if(c=="levelscript")
        return make(true,true,"Level script main() runs once when the native stage loads. Unmapped OpenBOR APIs remain partial.", CommandStatus::Partial);
    if(c=="keyscript"||c=="onmovexscript"||c=="onmovezscript"||c=="onentitycollision")
        return make(true,true,"Hook is fired by ScriptVM. Exact legacy event ordering and unmapped APIs remain partial.", CommandStatus::Partial);
    if(c=="spawnscript")
        return make(true,true,"Spawn-entry script runs after the model onspawn hook with self/spawnx/spawnz/spawny/spawnat locals.", CommandStatus::Partial);
    if(c=="onblockzscript"||c=="onblocksscript"||c=="onblockwscript"||c=="onblockoscript"||c=="didblockscript")
        return make(true,true,"Blocking hook is fired by the native collision/block runtime; uncommon legacy ordering remains partial.", CommandStatus::Partial);
    if(c=="onblockascript"||c=="onblockyscript"||c=="onblockpscript")
        return make(true,false,"Blocking hook is parsed, but platform/overhead exact firing remains partial.");
    if(c=="onkillscript") return make(true,true,"Runs when a runtime entity is actually removed after its death/removal delay.", CommandStatus::Partial);
    if(c=="script"||c=="updatescript") return make(true,true,"Legacy/update entity script is executed each runtime entity update. Unmapped APIs remain partial.", CommandStatus::Partial);
    if(c=="ondoattack"||c=="ondoattackscript")
        return make(true,true,"Hook fires when player, coop, enemy or ScriptVM performattack begins an attack.", CommandStatus::Partial);
    if(c=="onmodelcopy")
        return make(true,true,"onmodelcopy is invoked when a weapon model is applied; exact legacy model-copy ordering remains partial.", CommandStatus::Partial);
    if(c=="@script")
        return make(true,false,"Start marker for an inline OpenBORScript block. The body is analyzed as script source, not as model commands.", CommandStatus::Partial);
    // v0.27.0: Legacy/less-common OpenBOR commands confirmed by the official command registry.
    if(c=="@cmd")
        return make(true,false,"Inline OpenBORScript command directive. Its script text belongs to ScriptVM, not the model-command registry.", CommandStatus::Partial);
    if(c=="@end_script")
        return make(true,false,"End marker for an inline @script block. Script body is analyzed separately from model commands.", CommandStatus::Partial);
    if(c=="animation")
        return make(true,true,"Scene/cutscene animation entry is converted to a timed native cutscene frame sequence; advanced transitions remain partial.", CommandStatus::Partial);
    if(c=="scene"||c=="credits")
        return make(true,true,"levels.txt scene flow is converted to a native timed cutscene stage; credits-specific presentation remains partial.", CommandStatus::Partial);
    if(c=="2pitem"||c=="3pitem"||c=="4pitem")
        return make(true,false,"Player-count-specific stage item spawn is recognized; exact multiplayer spawn gating is not yet complete.", CommandStatus::Partial);
    if(c=="bossmusic")
        return make(true,true,"Boss music switches on first boss spawn and stage music is restored after all bosses are defeated; legacy offsets remain partial.", CommandStatus::Partial);
    if(c=="water"||c=="order")
        return make(true,true,"Legacy water metadata is rendered as a native stage overlay; exact palette/translucency and layer ordering remain partial.", CommandStatus::Partial);
    if(c=="shadow") return make(true,true,"Basic per-entity ground shadow is rendered; OpenBOR shadow palette/scale/light semantics remain partial.", CommandStatus::Partial);
    if(c=="fmap"||c=="hitflash"||c=="hitfx"||c=="icondie"||c=="iconposition"||c=="lifeposition"||c=="nameposition"||c=="quakeframe")
        return make(true,false,"Legacy visual/HUD effect command is recognized; exact OpenBOR rendering/HUD semantics remain partial.", CommandStatus::Partial);
    if(c=="blast"||c=="burn"||c=="death"||c=="falldie"||c=="riseattacktype"||c=="risetime"||c=="throw")
        return make(true,false,"Legacy combat/reaction command is recognized; exact OpenBOR reaction-state semantics remain partial.", CommandStatus::Partial);
    if(c=="defense")
        return make(true,true,"Legacy defense table applies per-attack-type damage and knockdown factors; rare pain/defense edge cases remain partial.", CommandStatus::Partial);
    if(c=="diesound")
        return make(true,true,"Death sound file metadata is played at native entity death; numeric legacy sample indexes remain partial.", CommandStatus::Partial);
    if(c=="lifespan"||c=="offscreenkill"||c=="landframe"||c=="nodieblink"||c=="nodrop"||c=="nopain"||c=="noquake")
        return make(true,true,"Legacy entity lifecycle/reaction flag has a native runtime path; exact historical edge cases remain partial.", CommandStatus::Partial);
    if(c=="subject_to_hole"||c=="antigravity"||c=="no_adjust_base"||c=="remove")
        return make(true,false,"Legacy entity lifecycle/physics flag is recognized; exact runtime behavior remains partial.", CommandStatus::Partial);
    if(c=="seta")
        return make(true,false,"Legacy animation-state command is recognized. Full historical seta behavior remains partial.", CommandStatus::Partial);
    if(c=="lives"||c=="colourdepth")
        return make(true,false,"Legacy global/UI configuration is recognized; the native runtime uses its own menu/display configuration.", CommandStatus::Partial);
    if(c=="set"||c=="file"||c=="z"||c=="music"||c=="background"||c=="panel"||c=="spawn"||c=="coords"||c=="at"||c=="alias"||c=="flip"||c=="boss"||c=="spawn1"||c=="direction"||c=="next")
        return make(true,true,"Stage/spawn command consumed by the generic stage runtime.");
    if(c=="bglayer"||c=="fglayer"||c=="frontpanel")
        return make(true,true,"Layer path, floating scroll ratios, offsets, spacing/repeat and foreground depth are rendered. Water/neon/palette-specific effects remain partial.", CommandStatus::Partial);
    if(c=="wall"||c=="platform"||c=="hole")
        return make(true,true,"Rectangular collision is active. Complex elevation and moving platforms are partial.", CommandStatus::Partial);
    if(c=="wait"||c=="group"||c=="blockade"||c=="branch"||c=="end"||c=="endlevel"||c=="scrollx"||c=="scrollspeed"||c=="cameratype"||c=="nojoin")
        return make(true,true,"wait/group/blockade execute with native runtime state. levels.txt branch labels and ScriptVM jumptobranch are supported; unusual legacy ordering remains partial.", CommandStatus::Partial);
    if(c=="item"||c=="map"||c=="health"||c=="score")
        return make(true,true,"Spawn properties.");
    if(c=="video"||c=="videomode"||c=="hresolution"||c=="vresolution")
        return make(true,true,"Logical resolution is detected from video.txt instead of assuming 320x240.");
    if(c=="palette"||c=="alternatepal"||c=="remap"||c=="colourmap"||c=="colormap")
        return make(true,true,"Palette/remap is applied at runtime from image or ACT palette references. Duplicate-color/index-only edge cases remain partial.", CommandStatus::Partial);
    if(c=="load")
        return make(true,true,"models.txt load entry registers the external model name and source file used by native spawns.");
    if(c=="know")
        return make(true,false,"models.txt declaration recognized; load entries are authoritative for generated model registration.");
    if(c=="mp"||c=="select"||c=="lifebarstatus"||c=="icon"||c=="nolife")
        return make(true,false,"Recognized menu/HUD command. Native HUD uses a generic layout, not the original lifebar.txt.");
    if(c=="comment"||c=="#"||c=="musicloop")
        return make(true,true,"", CommandStatus::IgnoredSafely);
    if(c.find("script")!=std::string::npos)
        return make(true,false,"Script-related command recorded without a dedicated runtime hook.");
    return make(false,false,"Command is not in the central registry. It is logged and does not abort conversion.", CommandStatus::Unknown);
}

std::string CommandRegistry::classifyLine(std::string_view command){
    auto info = lookup(command);
    std::string out = statusName(info.status);
    out += info.parser ? " parser=YES" : " parser=NO";
    out += info.runtime ? " runtime=YES" : " runtime=NO";
    if(info.note && *info.note){ out += " | "; out += info.note; }
    return out;
}
